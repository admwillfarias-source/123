/* AWR 5.58.0 — Busca rápida: sugestões locais (AWRSugest), resultado em cache
   (sessionStorage, 10 min) e pré-busca do resultado enquanto a pessoa escolhe.
   Ligado ao awr-search.js por window.awrY (substitui a função Y de lá). */
(function () {
	'use strict';
	var voando = {}, base = null, TTL = 6e5, timer = null;
	function chave(e) { var o = {}; Object.keys(e || {}).sort().forEach(function (k) { if (e[k] !== '' && e[k] != null) o[k] = e[k]; }); return 'awr_pc:' + JSON.stringify(o); }
	function ler(k) { try { var v = JSON.parse(sessionStorage.getItem(k) || 'null'); return v && Date.now() - v.t < TTL ? v.d : null; } catch (x) { return null; } }
	function gravar(k, d) { try { sessionStorage.setItem(k, JSON.stringify({ t: Date.now(), d: d })); } catch (x) {} }

	function produtos(e) {
		var k = chave(e), c = ler(k);
		if (c) return Promise.resolve(c);
		if (voando[k]) return voando[k];
		var p = base('produtos', e).then(function (d) {
			delete voando[k];
			if (d && !d.offline && d.produtos && d.produtos.length) gravar(k, d);
			return d;
		}, function (er) { delete voando[k]; throw er; });
		voando[k] = p;
		return p;
	}

	window.awrY = function (a, e, b) {
		base = base || b;
		var S = window.AWRSugest;
		if (a === 'sugestoes' && S) {
			var r = S.sugerir(e && e.q);
			if (r) return Promise.resolve(r);
			S.carregar();
		}
		if (a === 'produtos') return produtos(e || {});
		return b(a, e);
	};

	/* Pré-busca: mesma regra de ano do clique (função f do awr-search.js). */
	function anoDe(v, digitado) {
		var m = String(digitado || '').match(/\b(19[89]\d|20\d{2})\b/), h = m ? Number(m[0]) : null;
		return h && h >= v.yearStart && h <= v.yearEnd ? h : v.yearEnd;
	}
	function pre(v, digitado) {
		if (!base || !v || v.tipo !== 'veiculo' || !v.slug) return;
		produtos({ veiculo: v.slug, ano: anoDe(v, digitado) }).catch(function () {});
	}
	window.awrPre = function (lista, digitado, ul) {
		clearTimeout(timer);
		var vs = (lista || []).filter(function (v) { return v.tipo === 'veiculo'; });
		// Lista estável por 200 ms: adianta o resultado da 1ª sugestão.
		if (vs.length) timer = setTimeout(function () { pre(vs[0], digitado); }, 200);
		if (ul && !ul.__awrPre) {
			ul.__awrPre = 1;
			var ev = function (x) { var li = x.target.closest && x.target.closest('li[data-i]'); if (li && ul.__awrLista) pre(ul.__awrLista[Number(li.dataset.i)], ul.__awrDig); };
			ul.addEventListener('pointerdown', ev, { passive: true });
			ul.addEventListener('focusin', ev);
			ul.addEventListener('pointerover', ev, { passive: true });
		}
		if (ul) { ul.__awrLista = lista; ul.__awrDig = digitado; }
	};
	if (window.AWRSugest) window.AWRSugest.carregar();
})();
