# 5.36.4
- Inventário local: aviso de código de loja fora do padrão e orientação quando só parte das lojas é aceita.
