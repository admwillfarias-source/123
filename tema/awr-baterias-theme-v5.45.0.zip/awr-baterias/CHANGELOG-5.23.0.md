# AWR Baterias 5.23.0

- Corrigido "Entrega em 0 min" na home e nas páginas de cidade (Alvorada, Viamão, Sapiranga, Nova Santa Rita etc.): agora usa o prazo oficial da cidade.
- Selos de números (faixa e rodapé) mostram o prazo real da cidade ("Mesmo dia", "Dia seguinte" ou minutos).
- Grade de cidades da home exibe todas as cidades atendidas (incluindo Estância Velha, Nova Santa Rita, Eldorado do Sul e Guaíba).
- Prazos padronizados: Canoas 35 min, Esteio 40 min.
- Garantia exibida como "até 24 meses".
- Depoimentos manuais removidos; ficam só as avaliações reais do Google.
