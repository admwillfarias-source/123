# AWR Baterias 5.25.0

- gtag do Google Ads (Google for WooCommerce) deixa de carregar cedo nas páginas públicas; o tema sobe um único gtag.js após interação ou ~4 s.
- Cache das páginas públicas no CDN: 1 h + atualização em segundo plano (antes 5 min).
- Animações de carregamento usam só transparência/transformação; respeita "reduzir movimento".
- Blocos abaixo da primeira tela da home com content-visibility.
