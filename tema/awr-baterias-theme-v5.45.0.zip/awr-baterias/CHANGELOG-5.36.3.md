# 5.36.3
- Tag de verificação do Google fixa no tema (não depende de plugin).
- Acesso por http:// redireciona 301 para https:// (via CF-Visitor, sem laço).
