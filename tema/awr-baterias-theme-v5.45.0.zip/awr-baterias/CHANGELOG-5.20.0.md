# AWR Baterias 5.20.0

- Nova página-mãe canônica `/baterias-de-carro/`, com busca por veículo e tecnologias convencional, EFB e AGM.
- Home destaca carro, estacionária, moto e caminhão como quatro jornadas independentes.
- Menu principal leva diretamente aos quatro segmentos.
- Títulos, descrições e H1 dos hubs estacionária, moto e caminhão foram reforçados para intenção comercial.
- App ganhou seletor pesado por aplicação, 12V/24V e amperagem, mostrando somente preços e especificações da tabela oficial.
- Prazos de entrega continuam vindo da fonte única das cidades; nenhuma promessa local foi alterada.