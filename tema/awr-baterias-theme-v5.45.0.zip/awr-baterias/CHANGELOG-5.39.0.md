# 5.39.0 — Execução 4: blog e links internos

- Nova malha Blog ↔ Marcas ↔ Veículos (`assets/data/blog-links.json`, gerada de `src/data/blogLinks.ts` por `scripts/gen-blog-links.mjs`).
- Artigos: bloco "Baterias citadas neste guia" com links para as páginas de marca e de veículo citados no texto.
- Páginas de marca: bloco "Guias sobre bateria {marca}".
- Páginas nacionais de veículo (/baterias-para/{slug}/): bloco "Guias para escolher e cuidar da bateria".
