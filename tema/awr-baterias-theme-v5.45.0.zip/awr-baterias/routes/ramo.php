<?php
/**
 * /aplicacoes/{ramo}/ — página de ramo de aplicação.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$r = awr_ramo_by_slug( awr_param_a() );
if ( ! $r ) { get_template_part( '404' ); get_footer(); return; }

$wa     = awr_wa( 'Olá! Preciso de bateria para ' . mb_strtolower( $r['nome'] ) . '. Pode me ajudar?' );
$outras = array_values( array_filter( awr_ramos(), function ( $x ) use ( $r ) { return $x['slug'] !== $r['slug']; } ) );
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'trilha' => array( array( 'nome' => 'Aplicações', 'url' => home_url( '/aplicacoes/' ) ) ), 'atual' => $r['nome'] ) ); ?>
		<p class="awr-hub-hero__eyebrow"><?php echo esc_html( $r['tecnologia'] ); ?></p>
		<h1 class="awr-hub-hero__title"><?php echo esc_html( $r['h1'] ); ?></h1>
		<p class="awr-hub-hero__lead"><?php echo esc_html( $r['tagline'] ); ?></p>
		<div class="awr-hub-cta__wa-wrap" style="margin-top:1.5rem;">
			<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( $wa ); ?>">Pedir orçamento no WhatsApp</a>
		</div>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<div class="awr-hub-body awr-hub-body--narrow">
	<?php foreach ( (array) $r['intro'] as $par ) : ?>
		<p><?php echo esc_html( $par ); ?></p>
	<?php endforeach; ?>
</div>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Onde se aplica</h2>
		<ul class="awr-app-benefits">
			<?php foreach ( (array) $r['aplicacoes'] as $item ) : ?>
				<li><?php echo esc_html( $item ); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Por que comprar na AWR</h2>
		<ul class="awr-app-reco">
			<?php foreach ( (array) $r['beneficios'] as $b ) : ?>
				<li>
					<h3 class="awr-app-reco__modelo"><?php echo esc_html( $b['titulo'] ); ?></h3>
					<p class="awr-app-reco__ideal"><?php echo esc_html( $b['descricao'] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Perguntas frequentes</h2>
		<div class="awr-app-faq">
			<?php foreach ( (array) $r['faq'] as $f ) : ?>
				<details>
					<summary><?php echo esc_html( $f['pergunta'] ); ?></summary>
					<p><?php echo esc_html( $f['resposta'] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php if ( $outras ) : ?>
	<section class="awr-app-section">
		<div class="awr-hub-body">
			<h2 class="awr-app-section__title">Outras aplicações</h2>
			<ul class="awr-app-outras">
				<?php foreach ( $outras as $o ) : ?>
					<li>
						<a href="<?php echo esc_url( home_url( '/aplicacoes/' . $o['slug'] . '/' ) ); ?>">
							<div>
								<h3><?php echo esc_html( $o['nome'] ); ?></h3>
								<p><?php echo esc_html( $o['tagline'] ); ?></p>
							</div>
							<span class="awr-app-outras__arrow" aria-hidden="true">→</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
			<p style="margin-top:1rem;">Precisa de fornecimento recorrente ou nota em CNPJ? Veja as
				<a href="<?php echo esc_url( home_url( '/solucoes-b2b/' ) ); ?>">soluções B2B da AWR</a>.</p>
		</div>
	</section>
<?php endif; ?>

<?php awr_part( 'prova-social' ); ?>
<?php get_footer(); ?>
