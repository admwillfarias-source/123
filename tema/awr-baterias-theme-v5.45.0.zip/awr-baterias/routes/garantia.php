<?php
/** /garantia/ — solicitação de garantia via WhatsApp. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$awr_c = awr_company();
$awr_campos = array( 'nome' => 'Nome *', 'nota' => 'Nota fiscal ou nº do pedido *', 'modelo' => 'Modelo da bateria', 'data' => 'Data da compra', 'cidade' => 'Cidade' );
?>
<main class="awr-app-section"><div class="awr-hub-body" style="max-width:640px">
 <h1>Solicitar garantia</h1>
 <p>Preencha os dados e envie pelo WhatsApp. Depois mande as fotos da bateria e da nota fiscal na mesma conversa.</p>
 <form class="awr-gar" data-wa="<?php echo esc_attr( $awr_c['whatsapp_number'] ); ?>" style="display:grid;gap:10px">
  <?php foreach ( $awr_campos as $k => $l ) : ?><label><?php echo esc_html( $l ); ?><input name="<?php echo esc_attr( $k ); ?>" maxlength="200" <?php echo 'data' === $k ? 'type="date"' : ''; ?> <?php echo strpos( $l, '*' ) ? 'required' : ''; ?> style="width:100%;padding:10px"></label><?php endforeach; ?>
  <label>O que aconteceu? *<textarea name="problema" required rows="4" maxlength="500" style="width:100%;padding:10px"></textarea></label>
  <button class="awr-btn awr-btn--wa" type="submit">Enviar pelo WhatsApp</button>
 </form>
 <p><small>Prazos de garantia variam por marca e linha; o período vale a partir da data da nota fiscal.</small></p>
</div></main>
<script>
document.querySelector('.awr-gar').addEventListener('submit',function(e){e.preventDefault();var f=new FormData(this),m='Solicitação de garantia\nNome: '+f.get('nome')+'\nNota fiscal/pedido: '+f.get('nota')+'\nModelo: '+f.get('modelo')+'\nData da compra: '+f.get('data')+'\nCidade: '+f.get('cidade')+'\nProblema: '+f.get('problema')+'\n(Vou enviar fotos da bateria e da nota em seguida.)';window.open('https://wa.me/'+this.dataset.wa+'?text='+encodeURIComponent(m),'_blank','noopener')});
</script>
<?php get_footer();
