<?php
/**
 * /parceiros/ — programa de parceria, porte de src/routes/parceiros.tsx.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$c = awr_company();

$beneficios = array(
	array( 'titulo' => 'Comissão por indicação', 'texto' => 'Você indica, o cliente recebe e você recebe sua comissão direto.' ),
	array( 'titulo' => 'Entrega em 35 minutos', 'texto' => 'Sua oficina nunca mais segura o cliente esperando bateria.' ),
	array( 'titulo' => 'Suporte técnico', 'texto' => 'Tabela de aplicação atualizada e equipe para tirar dúvidas no WhatsApp.' ),
	array( 'titulo' => 'Nota fiscal e garantia', 'texto' => 'Distribuidor autorizado Moura, Heliar, Zetta e Excell.' ),
);

$passos = array(
	array( 'titulo' => 'Cadastre sua empresa', 'texto' => 'Envie nome da oficina, cidade e WhatsApp pelo formulário abaixo.' ),
	array( 'titulo' => 'Receba o combinado', 'texto' => 'Nossa equipe confirma os detalhes da parceria em até 1 dia útil.' ),
	array( 'titulo' => 'Indique e ganhe', 'texto' => 'A cada cliente indicado, entregamos e instalamos a bateria — e você recebe sua comissão.' ),
);

$cta_wa = awr_wa( 'Olá! Quero cadastrar minha empresa como parceira AWR Baterias.' );
?>
<main class="awr-parceiros">
	<div class="awr-container">
		<p class="awr-parceiros__crumbs">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Início</a> · Parceiros
		</p>

		<header class="awr-parceiros__hero">
			<span class="awr-parceiros__badge">Cadastro de oficinas</span>
			<h1 class="awr-parceiros__title">Seja parceiro AWR Baterias em Porto Alegre e região</h1>
			<p class="awr-parceiros__lead">
				Auto-elétricas, oficinas mecânicas, lava-rápidos e estacionamentos: indique bateria para seus
				clientes e ganhe comissão. Entrega e instalação em até 35 minutos, sem você sair do seu trabalho.
			</p>
		</header>

<?php awr_part( 'searchband' ); ?>


		<section class="awr-parceiros__benefits" aria-label="Benefícios para o parceiro">
			<?php foreach ( $beneficios as $b ) : ?>
				<div class="awr-parceiros__card">
					<h2><?php echo esc_html( $b['titulo'] ); ?></h2>
					<p><?php echo esc_html( $b['texto'] ); ?></p>
				</div>
			<?php endforeach; ?>
		</section>

		<section class="awr-parceiros__steps" aria-label="Como funciona">
			<h2 class="awr-section-title">Como funciona</h2>
			<ol>
				<?php foreach ( $passos as $i => $s ) : ?>
					<li>
						<span class="awr-parceiros__step-num"><?php echo esc_html( $i + 1 ); ?></span>
						<div>
							<h3><?php echo esc_html( $s['titulo'] ); ?></h3>
							<p><?php echo esc_html( $s['texto'] ); ?></p>
						</div>
					</li>
				<?php endforeach; ?>
			</ol>
		</section>

		<section class="awr-parceiros__form">
			<h2>Faça seu cadastro</h2>
			<p>Preencha abaixo e nossa equipe entra em contato pelo WhatsApp em até 1 dia útil.</p>
			<form class="awr-parceiros__form-grid" action="<?php echo esc_url( $cta_wa ); ?>" method="get" target="_top" rel="noopener">
				<label class="awr-parceiros__field awr-parceiros__field--full">
					Nome da oficina *
					<input required name="oficina" placeholder="Ex.: Auto Elétrica Silva" />
				</label>
				<label class="awr-parceiros__field">
					Cidade *
					<input required name="cidade" placeholder="Ex.: Porto Alegre" />
				</label>
				<label class="awr-parceiros__field">
					WhatsApp *
					<input required type="tel" name="whatsapp" placeholder="(51) 9 9999-9999" />
				</label>
				<label class="awr-parceiros__field awr-parceiros__field--full">
					CNPJ (opcional)
					<input name="cnpj" placeholder="00.000.000/0000-00" />
				</label>
				<button type="submit" class="awr-btn awr-btn--green awr-btn--xl awr-parceiros__submit">Enviar cadastro pelo WhatsApp</button>
				<p class="awr-parceiros__form-note">Ao enviar, abriremos uma conversa no WhatsApp com seus dados pré-preenchidos.</p>
			</form>
		</section>

		<section class="awr-parceiros__cta">
			<p>Prefere falar direto com a nossa equipe?</p>
			<div class="awr-parceiros__cta-buttons">
				<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( $cta_wa ); ?>">Quero ser parceiro</a>
				<a class="awr-btn awr-btn--outline awr-btn--xl" href="<?php echo esc_attr( $c['phone_href'] ); ?>">Ligar <?php echo esc_html( $c['phone'] ); ?></a>
			</div>
		</section>

		<?php awr_part( 'links-internos', array( 'tipo' => 'cidade' ) ); ?>
	</div>
</main>
<?php get_footer(); ?>
