<?php
/**
 * /bateria-a-domicilio-porto-alegre/ — paridade com src/routes/bateria-a-domicilio-porto-alegre.tsx.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$c      = awr_company();
$cta_wa = awr_wa( 'Olá! Quero bateria a domicílio em Porto Alegre. Podem vir até mim?' );

$passos = array(
	array( 'titulo' => 'Você informa o veículo', 'texto' => 'Pelo WhatsApp ou telefone, com marca, modelo e ano. Confirmamos a bateria certa e o valor final.' ),
	array( 'titulo' => 'A equipe sai para o seu endereço', 'texto' => 'Confirmamos o tempo real conforme bairro, trânsito e horário. Na Grande Porto Alegre, normalmente até 35 minutos.' ),
	array( 'titulo' => 'Teste no local', 'texto' => 'Antes de trocar, testamos a bateria e o alternador para confirmar que o problema é mesmo a bateria.' ),
	array( 'titulo' => 'Instalação e pagamento', 'texto' => 'Bateria nova instalada, nota fiscal, garantia de fábrica e retirada da bateria velha. Você paga só no fim.' ),
);

$inclui = array(
	array( 'titulo' => 'Instalação grátis', 'texto' => 'Técnico com ferramenta própria, sem custo adicional.' ),
	array( 'titulo' => 'Plantão até 22h', 'texto' => 'Porto Alegre das 06:30 às 22h, todos os dias.' ),
	array( 'titulo' => 'Garantia de fábrica', 'texto' => 'Nota fiscal e garantia Moura, Heliar ou Zetta.' ),
	array( 'titulo' => '10x sem juros', 'texto' => 'Pix, dinheiro, débito e crédito em até 10x.' ),
);

$faq = array(
	array( 'q' => 'Quanto tempo leva para chegar?', 'r' => 'Na Grande Porto Alegre o atendimento costuma sair em até 35 minutos. O tempo exato depende do bairro, do trânsito e do horário — confirmamos no WhatsApp antes de sair.' ),
	array( 'q' => 'A instalação é cobrada à parte?', 'r' => 'Não. A entrega e a instalação no local estão incluídas no preço da bateria.' ),
	array( 'q' => 'Vocês testam antes de trocar?', 'r' => 'Sim. Testamos a bateria e o alternador no local. Se o problema não for a bateria, você fica sabendo antes de comprar.' ),
	array( 'q' => 'Qual o horário de atendimento em Porto Alegre?', 'r' => 'Das 06:30 às 22h, todos os dias, para o atendimento a domicílio em Porto Alegre.' ),
	array( 'q' => 'Como posso pagar?', 'r' => 'Pix, dinheiro, cartão de débito e cartão de crédito em até 10x sem juros, na hora da instalação.' ),
);
?>
<main class="awr-parceiros">
	<div class="awr-container">
		<p class="awr-parceiros__crumbs">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Início</a> · Bateria a domicílio em Porto Alegre
		</p>

		<header class="awr-parceiros__hero">
			<span class="awr-parceiros__badge">Entrega e instalação gratuitas</span>
			<h1 class="awr-parceiros__title">Bateria a domicílio em Porto Alegre, entregue e instalada no seu endereço</h1>
			<p class="awr-parceiros__lead">
				Nossa equipe vai até você em casa, no trabalho, no posto ou no estacionamento. Teste de bateria e de
				alternador incluídos, bateria nova instalada na hora e pagamento só depois de tudo pronto.
			</p>
			<div class="awr-parceiros__cta-buttons">
				<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( $cta_wa ); ?>">Pedir no WhatsApp</a>
				<a class="awr-btn awr-btn--gold awr-btn--xl" href="<?php echo esc_attr( $c['phone_href'] ); ?>">Ligar <?php echo esc_html( $c['phone'] ); ?></a>
			</div>
		</header>

<?php awr_part( 'searchband' ); ?>

		<section class="awr-parceiros__steps" aria-label="Como funciona o atendimento a domicílio">
			<h2 class="awr-section-title">Como funciona o atendimento a domicílio</h2>
			<ol>
				<?php foreach ( $passos as $i => $s ) : ?>
					<li>
						<span class="awr-parceiros__step-num"><?php echo esc_html( $i + 1 ); ?></span>
						<div>
							<h3><?php echo esc_html( $s['titulo'] ); ?></h3>
							<p><?php echo esc_html( $s['texto'] ); ?></p>
						</div>
					</li>
				<?php endforeach; ?>
			</ol>
		</section>

		<section class="awr-parceiros__benefits" aria-label="O que está incluído">
			<?php foreach ( $inclui as $b ) : ?>
				<div class="awr-parceiros__card">
					<h2><?php echo esc_html( $b['titulo'] ); ?></h2>
					<p><?php echo esc_html( $b['texto'] ); ?></p>
				</div>
			<?php endforeach; ?>
		</section>

		<section class="awr-parceiros__benefits" aria-label="Lojas que atendem Porto Alegre">
			<?php
			foreach ( awr_stores() as $s ) :
				if ( 'porto-alegre' !== $s['cidadeSlug'] ) { continue; }
				?>
				<div class="awr-parceiros__card">
					<h2>AWR Baterias — <?php echo esc_html( $s['nome'] ); ?></h2>
					<p><?php echo esc_html( $s['enderecoCompleto'] ); ?></p>
					<p><?php echo esc_html( $s['horarios']['semana'] ); ?><?php echo ! empty( $s['horarios']['sabado'] ) ? ' · ' . esc_html( $s['horarios']['sabado'] ) : ''; ?></p>
					<p><a href="<?php echo esc_url( home_url( '/lojas/' . $s['slug'] . '/' ) ); ?>">Ver a unidade <?php echo esc_html( $s['nome'] ); ?> →</a></p>
				</div>
			<?php endforeach; ?>
		</section>

		<?php awr_part( 'faq', array( 'itens' => $faq, 'titulo' => 'Perguntas frequentes' ) ); ?>

		<section class="awr-parceiros__cta">
			<p>Precisa de bateria agora em Porto Alegre?</p>
			<div class="awr-parceiros__cta-buttons">
				<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( $cta_wa ); ?>">Falar no WhatsApp</a>
				<a class="awr-btn awr-btn--outline awr-btn--xl" href="<?php echo esc_attr( $c['phone_href'] ); ?>">Ligar <?php echo esc_html( $c['phone'] ); ?></a>
			</div>
		</section>

		<?php awr_part( 'links-internos', array( 'tipo' => 'cidade' ) ); ?>
	</div>
</main>

<?php
awr_jsonld( array(
	'@context'    => 'https://schema.org',
	'@type'       => 'Service',
	'@id'         => home_url( '/bateria-a-domicilio-porto-alegre/' ) . '#service',
	'name'        => 'Bateria a domicílio em Porto Alegre',
	'serviceType' => 'Entrega e instalação de bateria automotiva no local',
	'url'         => home_url( '/bateria-a-domicilio-porto-alegre/' ),
	'provider'    => array( '@type' => 'Organization', 'name' => 'AWR Baterias', 'url' => home_url( '/' ) ),
	'areaServed'  => array_map(
		function ( $cid ) {
			return array( '@type' => 'City', 'name' => $cid['nome'] );
		},
		array_values( awr_cidades() )
	),
) );
awr_faq_jsonld( $faq, home_url( '/bateria-a-domicilio-porto-alegre/' ) . '#faq' );
?>
<?php get_footer(); ?>
