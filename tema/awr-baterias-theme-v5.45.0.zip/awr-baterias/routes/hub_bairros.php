<?php
/**
 * /baterias-bairro/{cidade}/ — hub de bairros atendidos na cidade.
 * Paridade com src/routes/baterias-bairro.$cidade.index.tsx do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$cslug  = awr_param_a();
$cidade = awr_cidade_by_slug( $cslug );
if ( ! $cidade ) { get_template_part( '404' ); get_footer(); return; }

$bairros = awr_bairros_cidade( $cslug );
$loja    = awr_loja_do_bairro( $cslug );
$min     = ! empty( $cidade['tempoEntregaMin'] ) ? (int) $cidade['tempoEntregaMin'] : 35;
?>
<main class="awr-lojas">
	<section class="awr-lojas__hero">
		<div class="awr-container">
			<p class="awr-breadcrumb">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Início</a> /
				<a href="<?php echo esc_url( home_url( '/baterias-em/' . $cslug . '/' ) ); ?>"><?php echo esc_html( $cidade['nome'] ); ?></a> /
				<span>Bairros</span>
			</p>
			<h1 class="awr-lojas__title">Bairros atendidos em <?php echo esc_html( $cidade['nome'] ); ?></h1>
			<p class="awr-lojas__subtitle">
				<?php echo count( $bairros ); ?> bairros com entrega e instalação de bateria no local em até <?php echo (int) $min; ?> minutos. Escolha seu bairro para ver preço, prazo e a loja AWR responsável.
			</p>
		</div>
	</section>

<?php awr_part( 'searchband' ); ?>


	<section class="awr-lojas__grid-section">
		<div class="awr-container">
			<h2 class="awr-lojas__h2">Todos os bairros</h2>
			<ul class="awr-chips">
				<?php foreach ( $bairros as $b ) : ?>
					<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-bairro/' . $cslug . '/' . $b['slug'] . '/' ) ); ?>"><?php echo esc_html( $b['nome'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>

			<?php if ( $loja ) : ?>
				<p class="awr-lead">
					Loja responsável: <strong>AWR Baterias — <?php echo esc_html( $loja['nome'] ); ?></strong>,
					<?php echo esc_html( $loja['enderecoCompleto'] ); ?>.
					<a href="<?php echo esc_url( home_url( '/lojas/' . $loja['slug'] . '/' ) ); ?>">Ver detalhes da loja →</a>
				</p>
			<?php endif; ?>

			<?php awr_part( 'search', array( 'titulo' => 'Ver preço da bateria do seu carro' ) ); ?>
		</div>
	</section>
</main>

<?php
awr_jsonld( array(
	'@context'        => 'https://schema.org',
	'@type'           => 'BreadcrumbList',
	'itemListElement' => array(
		array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Início', 'item' => home_url( '/' ) ),
		array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Bateria em ' . $cidade['nome'], 'item' => home_url( '/baterias-em/' . $cslug . '/' ) ),
		array( '@type' => 'ListItem', 'position' => 3, 'name' => 'Bairros de ' . $cidade['nome'], 'item' => home_url( '/baterias-bairro/' . $cslug . '/' ) ),
	),
) );
?>
<?php get_footer(); ?>
