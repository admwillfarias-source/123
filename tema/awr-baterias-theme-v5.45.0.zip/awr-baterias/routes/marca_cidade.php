<?php
/**
 * /bateria/{marca}/{cidade}/
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$m       = awr_marca_by_slug( awr_param_a() );
$c       = awr_cidade_by_slug( awr_param_b() );
$mc_cob  = (bool) $c;
if ( ! $c ) { $c = awr_cidade_venda_by_slug( awr_param_b() ); }
if ( ! $m || ! $c ) { get_template_part( '404' ); get_footer(); return; }
$lojas = $mc_cob ? awr_stores_for_cidade( $c['slug'] ) : array();
$awr_c = awr_company();

$mc_min   = ! empty( $c['tempoEntregaMin'] ) ? (int) $c['tempoEntregaMin'] : 35;
$mc_bair  = $mc_cob && ! empty( $c['bairros'] ) ? (array) $c['bairros'] : array();
$wa_msg   = $mc_cob
	? 'Olá! Preciso de bateria ' . $m['nome'] . ' em ' . $c['nome'] . '. Podem confirmar preço e disponibilidade?'
	: 'Olá! Quero uma bateria ' . $m['nome'] . ' com envio para ' . $c['nome'] . '. Podem passar preço e prazo?';

?>
<div class="awrm-page">
	<section class="awrm-hero awrm-hero--navy">
		<div class="awrm-container">
			<?php
			awr_part( 'breadcrumb', array(
				'trilha' => array(
					array( 'nome' => $m['nome'], 'url' => home_url( '/marca/' . $m['slug'] . '/' ) ),
				),
				'atual'  => $c['nome'],
			) );
			?>

			<?php if ( $mc_cob ) : ?>
			<span class="awrm-hero__badge awrm-hero__badge--gold">Socorro de bateria · Entrega em <?php echo (int) $mc_min; ?> min</span>

			<h1 class="awrm-hero__title">
				Bateria <span class="awrm-hero__gold"><?php echo esc_html( $m['nome'] ); ?></span> em <?php echo esc_html( $c['nome'] ); ?> — entrega e instalação em até <?php echo (int) $mc_min; ?> min
			</h1>
			<p class="awrm-hero__tagline">
				<?php echo esc_html( $m['nomeCompleto'] ?? $m['nome'] ); ?> original com <?php echo ! empty( $m['garantiaMeses'] ) ? esc_html( $m['garantiaMeses'] . ' meses de garantia' ) : 'garantia'; ?> de fábrica, entregue e instalada no local em <?php echo esc_html( $c['nome'] ); ?> — sem taxa extra, sem enrolação.
			</p>
			<?php else : ?>
			<span class="awrm-hero__badge awrm-hero__badge--gold">Envio com rastreio · Nota fiscal e garantia</span>

			<h1 class="awrm-hero__title">
				Bateria <span class="awrm-hero__gold"><?php echo esc_html( $m['nome'] ); ?></span> em <?php echo esc_html( $c['nome'] ); ?> — preço à vista e envio rápido
			</h1>
			<p class="awrm-hero__tagline">
				<?php echo esc_html( $m['nomeCompleto'] ?? $m['nome'] ); ?> original com <?php echo ! empty( $m['garantiaMeses'] ) ? esc_html( $m['garantiaMeses'] . ' meses de garantia' ) : 'garantia'; ?> de fábrica, enviada para <?php echo esc_html( $c['nome'] ); ?> com rastreio e nota fiscal. Orçamento na hora pelo WhatsApp.
			</p>
			<?php endif; ?>

			<div class="awrm-hero__ctas">
				<a class="awrm-btn awrm-btn--gold" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $wa_msg ) ); ?>">Pedir Bateria <?php echo esc_html( $m['nome'] ); ?> agora</a>
				<a class="awrm-btn awrm-btn--green" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">Ligar agora — <?php echo esc_html( $awr_c['phone'] ); ?></a>
			</div>

			<p class="awrm-hero__note"><?php echo $mc_cob ? 'Aceitamos Pix, débito e crédito no local · Sem taxa extra · 10× sem juros' : 'Pagamento por Pix ou cartão · Nota fiscal em CPF ou CNPJ · Garantia de fábrica'; ?></p>

		</div>
	</section>

<?php awr_part( 'searchband' ); ?>


	<section class="awrm-section">
		<div class="awrm-container awrm-container--narrow">
			<h2 class="awrm-h2"><?php echo esc_html( $m['nomeCompleto'] ?? $m['nome'] ); ?> para o seu carro em <?php echo esc_html( $c['nome'] ); ?></h2>
			<?php if ( ! empty( $c['textoIntro'] ) ) : ?>
				<p class="awrm-p"><?php echo esc_html( $c['textoIntro'] ); ?></p>
			<?php endif; ?>
			<?php foreach ( (array) ( $m['introParagrafos'] ?? array() ) as $par ) : ?>
				<p class="awrm-p"><?php echo esc_html( $par ); ?></p>
			<?php endforeach; ?>
		</div>
	</section>

	<?php if ( ! empty( $m['beneficios'] ) ) : ?>
		<section class="awrm-section awrm-section--muted">
			<div class="awrm-container">
				<h2 class="awrm-h2">Por que escolher <?php echo esc_html( $m['nomeCompleto'] ?? $m['nome'] ); ?> em <?php echo esc_html( $c['nome'] ); ?></h2>
				<ul class="awrm-benefits">
					<?php foreach ( $m['beneficios'] as $b ) : ?>
						<li class="awrm-benefit-card">
							<span class="awrm-benefit-card__icon" aria-hidden="true">✓</span>
							<h3 class="awrm-benefit-card__title"><?php echo esc_html( $b['titulo'] ); ?></h3>
							<p class="awrm-benefit-card__desc"><?php echo esc_html( $b['descricao'] ); ?></p>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( ! empty( $m['modelosPopulares'] ) ) : ?>
		<section class="awrm-section">
			<div class="awrm-container">
				<h2 class="awrm-h2">Modelos <?php echo esc_html( $m['nome'] ); ?> mais entregues em <?php echo esc_html( $c['nome'] ); ?></h2>
				<div class="awrm-table-wrap">
					<table class="awrm-table">
						<thead>
							<tr>
								<th>Modelo</th>
								<th>Amperagem</th>
								<th>Carros compatíveis</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $m['modelosPopulares'] as $mp ) : ?>
								<tr>
									<td class="awrm-table__linha"><?php echo esc_html( $mp['linha'] ); ?></td>
									<td><?php echo esc_html( $mp['amperagem'] ); ?></td>
									<td><?php echo esc_html( implode( ', ', (array) $mp['carrosCompatveis'] ) ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $mc_bair ) : ?>
		<section class="awrm-section awrm-section--muted">
			<div class="awrm-container">
				<h2 class="awrm-h2">Bairros atendidos em <?php echo esc_html( $c['nome'] ); ?></h2>
				<ul class="awrm-bairro-list">
					<?php foreach ( $mc_bair as $b ) : ?>
						<li class="awrm-bairro-pill"><?php echo esc_html( $b ); ?></li>
					<?php endforeach; ?>
				</ul>
				<p class="awrm-p awrm-p--small">Não achou seu bairro? Atendemos toda <?php echo esc_html( $c['nome'] ); ?> — envie sua localização no WhatsApp que confirmamos o tempo exato.</p>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $lojas ) : ?>
		<section class="awrm-section">
			<div class="awrm-container">
				<h2 class="awrm-h2 awrm-h2--sm">Lojas mais próximas</h2>
				<ul class="awrm-store-grid">
					<?php foreach ( $lojas as $s ) : ?>
						<li class="awrm-store-card">
							<h3><a href="<?php echo esc_url( home_url( '/lojas/' . $s['slug'] . '/' ) ); ?>"><?php echo esc_html( $s['nome'] ); ?></a></h3>
							<p><?php echo esc_html( $s['enderecoCompleto'] ); ?></p>
							<?php if ( ! empty( $s['telefone'] ) ) : ?>
								<p><a href="tel:<?php echo esc_attr( preg_replace( '/\D/', '', $s['telefone'] ) ); ?>"><?php echo esc_html( $s['telefone'] ); ?></a></p>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</section>
	<?php endif; ?>

	<section class="awrm-container awrm-container--narrow awrm-cta-wrap">
		<div class="awrm-cta">
			<h3 class="awrm-cta__title">Fale agora com a AWR Baterias</h3>
			<p class="awrm-cta__text">Atendimento rápido em <?php echo esc_html( $c['nome'] ); ?> — preço na hora, entrega e instalação no local.</p>
			<div class="awrm-hero__ctas">
				<a class="awrm-btn awrm-btn--wa" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $wa_msg ) ); ?>">Pedir no WhatsApp</a>
				<a class="awrm-btn awrm-btn--outline" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">Ligar agora</a>
			</div>
		</div>
	</section>

	<?php
	awr_part( 'faq', array(
		'titulo' => 'Perguntas frequentes — Bateria ' . $m['nome'] . ' em ' . $c['nome'],
		'itens'  => awr_faq_cidade( $c, $m ),
	) );
	?>

	<section class="awrm-section awrm-section--muted">
		<div class="awrm-container">
			<h2 class="awrm-h2 awrm-h2--sm">Outras marcas disponíveis em <?php echo esc_html( $c['nome'] ); ?></h2>
			<ul class="awrm-compare-grid awrm-compare-grid--3">
				<?php foreach ( awr_marcas() as $o ) :
					if ( $o['slug'] === $m['slug'] || empty( $o['cidadePages'] ) ) { continue; }
					$meta = implode( ' · ', array_filter( array( $o['faixaPreco'] ?? '', ! empty( $o['garantiaMeses'] ) ? $o['garantiaMeses'] . ' meses' : '' ) ) );
					?>
					<li>
						<a class="awrm-compare-card" href="<?php echo esc_url( home_url( '/bateria/' . $o['slug'] . '/' . $c['slug'] . '/' ) ); ?>">
							<div>
								<p class="awrm-compare-card__title awrm-compare-card__title--sm">Bateria <?php echo esc_html( $o['nome'] ); ?> em <?php echo esc_html( $c['nome'] ); ?></p>
								<p class="awrm-compare-card__meta"><?php echo esc_html( $meta ); ?></p>
							</div>
							<span class="awrm-compare-card__arrow" aria-hidden="true">→</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>

	<div class="awrm-container">
		<?php awr_part( 'links-internos', array( 'tipo' => 'marca_cidade', 'slug' => $m['slug'], 'slug_b' => $c['slug'] ) ); ?>
	</div>
</div>
<?php get_footer(); ?>
