<?php
/**
 * /loja/ — catálogo WooCommerce com a mesma identidade do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$awr_route = awr_current_route();
$awr_cat   = in_array( $awr_route, array( 'shop_cat', 'shop_cat_page' ), true ) ? awr_param_a() : '';
$awr_page  = 1;
if ( 'shop_page' === $awr_route ) { $awr_page = max( 1, (int) awr_param_a() ); }
if ( 'shop_cat_page' === $awr_route ) { $awr_page = max( 1, (int) awr_param_b() ); }

$awr_ordem = awr_shop_order();
// 5.18.0: sem paginação — páginas antigas levam (301) para a primeira.
if ( $awr_page > 1 ) {
	wp_safe_redirect( awr_shop_url( $awr_cat, 1, $awr_ordem ), 301 );
	exit;
}
$awr_term  = $awr_cat ? awr_shop_categoria_by_slug( $awr_cat ) : null;
$awr_res   = awr_shop_query( $awr_cat, $awr_page, $awr_ordem );
$awr_cats  = awr_shop_categorias();

$awr_titulo = $awr_term ? $awr_term['nome'] : 'Loja de baterias';
$awr_lead   = $awr_term
	? 'Todos os modelos de ' . strtolower( $awr_term['nome'] ) . ' com entrega e instalação grátis em até 35 minutos em Porto Alegre e Grande POA.'
	: 'Catálogo completo Moura, Heliar, Zetta e Excell. Compre on-line em 1 minuto e receba com instalação grátis em até 35 minutos.';

awr_part( 'hero', array(
	'eyebrow' => 'Loja on-line',
	'h1'      => $awr_titulo,
	'gold'    => 'com entrega em 35 min',
	'lead'    => $awr_lead,
	'trilha'  => $awr_term ? array( array( 'nome' => 'Loja', 'url' => home_url( '/loja/' ) ) ) : array(),
	'atual'   => $awr_term ? $awr_term['nome'] : 'Loja',
) );

awr_part( 'searchband' );
?>

<div class="awr-hub-body">

	<?php if ( $awr_cats ) : ?>
		<nav class="awr-shop-filtros" aria-label="Categorias da loja">
			<a class="awr-chip<?php echo $awr_cat ? '' : ' awr-chip--active'; ?>" href="<?php echo esc_url( awr_shop_url( '', 1, $awr_ordem ) ); ?>">Todas</a>
			<?php foreach ( $awr_cats as $c ) : ?>
				<a class="awr-chip<?php echo $awr_cat === $c['slug'] ? ' awr-chip--active' : ''; ?>"
					href="<?php echo esc_url( awr_shop_url( $c['slug'], 1, $awr_ordem ) ); ?>">
					<?php echo esc_html( $c['nome'] ); ?> <span class="awr-chip__n"><?php echo esc_html( $c['total'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</nav>
	<?php endif; ?>

	<div class="awr-shop-toolbar">
		<p class="awr-shop-toolbar__count">
			<strong><?php echo esc_html( $awr_res['total'] ); ?></strong> produto<?php echo 1 === (int) $awr_res['total'] ? '' : 's'; ?>
		</p>
		<ul class="awr-shop-toolbar__ordem" aria-label="Ordenar por">
			<?php foreach ( awr_shop_orders() as $ok => $label ) : ?>
				<li><a class="awr-chip awr-chip--sm<?php echo $ok === $awr_ordem ? ' awr-chip--active' : ''; ?>"
					href="<?php echo esc_url( awr_shop_url( $awr_cat, 1, $ok ) ); ?>"><?php echo esc_html( $label ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</div>

	<?php if ( $awr_res['produtos'] ) : ?>
		<div class="awr-cards awr-cards--shop">
			<?php foreach ( $awr_res['produtos'] as $awr_i => $awr_p ) : ?>
				<?php awr_part( 'card-bateria', array( 'produto' => $awr_p, 'eager' => $awr_i < 4 ) ); ?>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<p class="awr-empty">Nenhum produto encontrado nesta categoria. Fale com a gente no WhatsApp que encontramos a bateria certa para você.</p>
	<?php endif; ?>


	<?php awr_part( 'trustbar' ); ?>
	<?php awr_part( 'links-internos', array( 'tipo' => 'amperagem' ) ); ?>
</div>
<?php get_footer(); ?>
