<?php
/** /rastrear-pedido/ — consulta de pedido via WhatsApp. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$awr_c = awr_company();
?>
<main class="awr-app-section"><div class="awr-hub-body" style="max-width:560px">
 <h1>Rastrear pedido</h1>
 <p>Informe o número do pedido. A equipe responde com o status da entrega local ou o código da transportadora.</p>
 <form class="awr-ras" data-wa="<?php echo esc_attr( $awr_c['whatsapp_number'] ); ?>" style="display:grid;gap:10px">
  <label>Número do pedido *<input name="p" required maxlength="30" style="width:100%;padding:10px"></label>
  <label>CEP de entrega<input name="cep" maxlength="9" style="width:100%;padding:10px"></label>
  <button class="awr-btn awr-btn--wa" type="submit">Consultar no WhatsApp</button>
 </form>
</div></main>
<script>
document.querySelector('.awr-ras').addEventListener('submit',function(e){e.preventDefault();var f=new FormData(this),c=f.get('cep');window.open('https://wa.me/'+this.dataset.wa+'?text='+encodeURIComponent('Olá! Quero acompanhar o pedido nº '+f.get('p')+(c?' (CEP '+c+')':'')+'.'),'_blank','noopener')});
</script>
<?php get_footer();
