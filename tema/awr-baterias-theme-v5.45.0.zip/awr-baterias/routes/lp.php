<?php
/**
 * /lp/{slug}/ — landing pages de campanha (porte de src/routes/lp.*.tsx).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$slug = awr_param_a();
$lps  = awr_lps();
if ( empty( $lps[ $slug ] ) ) { get_template_part( '404' ); return; }
$lp = $lps[ $slug ];
$c  = awr_company();

get_header();
?>
<section class="awr-lp-hero">
	<div class="awr-container">
		<p class="awr-hero__kicker"><?php echo esc_html( $lp['kicker'] ); ?></p>
		<h1 class="awr-page-title"><?php echo esc_html( $lp['h1'] ); ?></h1>
		<p class="awr-lead"><?php echo esc_html( $lp['sub'] ); ?></p>
		<p class="awr-hero__ctas">
			<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $lp['wa'] ) ); ?>">Chamar no WhatsApp agora</a>
			<a class="awr-btn awr-btn--outline awr-btn--xl" href="<?php echo esc_attr( $c['phone_href'] ); ?>">Ligar <?php echo esc_html( $c['phone'] ); ?></a>
		</p>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<div class="awr-container">
	<?php awr_part( 'search', array( 'titulo' => 'Veja o preço da bateria do seu carro' ) ); ?>

	<h2 class="awr-section-title">Por que a AWR</h2>
	<ul class="awr-benefits">
		<?php foreach ( $lp['beneficios'] as $b ) : ?>
			<li><strong><?php echo esc_html( $b[0] ); ?></strong><span><?php echo esc_html( $b[1] ); ?></span></li>
		<?php endforeach; ?>
	</ul>
</div>

<?php awr_part( 'prova-social' ); ?>

<section class="awr-finalcta">
	<div class="awr-container">
		<h2 class="awr-section-title"><?php echo esc_html( $lp['cta_titulo'] ); ?></h2>
		<p class="awr-hero__ctas">
			<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $lp['wa'] ) ); ?>">WhatsApp</a>
			<a class="awr-btn awr-btn--orange awr-btn--xl" href="<?php echo esc_url( home_url( '/buscar/' ) ); ?>">Ver preços</a>
		</p>
	</div>
</section>
<?php get_footer(); ?>
