<?php
/**
 * /widget-busca/ — widget isolado para embutir em iframe (sem header/footer).
 * Envia altura ao parent via postMessage (awr:height) e Web Vitals (awr:vitals).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<div class="awr-widget">
	<?php awr_part( 'search', array( 'autofocus' => false ) ); ?>
</div>
<?php get_footer(); ?>
