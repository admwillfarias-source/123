<?php
/**
 * /baterias-para/ — hub de modelos de veículo.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$modelos = awr_vc_models();

get_header();
?>
<div class="awr-container awr-hub">
	<?php
	awr_part( 'hero', array(
		'eyebrow' => 'Baterias por veículo',
		'h1'      => 'Bateria por veículo — encontre o modelo do seu carro',
		'lead'    => sprintf( 'Selecione o veículo para ver a bateria compatível, o preço atualizado e a entrega na sua cidade. São %s modelos atendidos.', number_format_i18n( count( $modelos ) ) ),
		'wa'      => 'Olá! Quero saber qual bateria é a certa para o meu carro.',
		'wa_label'=> 'Falar com um atendente',
		'atual'   => 'Baterias por veículo',
	) );
	?>

	<section class="awr-block">
		<h2 class="awr-section-title">Todos os modelos</h2>
		<ul class="awr-chips">
			<?php foreach ( $modelos as $m ) : ?>
				<li><a class="awr-chip" href="<?php echo esc_url( awr_vc_url( $m['slug'] ) ); ?>"><?php echo esc_html( awr_vc_label( $m ) ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</section>

	<?php awr_part( 'search', array( 'titulo' => 'Buscar a bateria do seu veículo' ) ); ?>
</div>
<?php
get_footer();
