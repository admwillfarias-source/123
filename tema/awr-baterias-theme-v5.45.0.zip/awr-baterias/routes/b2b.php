<?php
/**
 * /solucoes-b2b/ — hub de soluções corporativas.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$solucoes = awr_b2b();
$wa       = awr_wa( 'Olá! Represento uma empresa e quero um orçamento de baterias com nota em CNPJ.' );
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'atual' => 'Soluções B2B' ) ); ?>
		<h1 class="awr-hub-hero__title">Soluções B2B em baterias para empresas de Porto Alegre</h1>
		<p class="awr-hub-hero__lead">Fornecimento com contrato, nota fiscal em CNPJ, reposição programada e descarte regularizado. Do banco solar off-grid ao data center.</p>
		<div class="awr-hub-cta__wa-wrap" style="margin-top:1.5rem;">
			<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( $wa ); ?>">Solicitar proposta</a>
		</div>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Onde a AWR resolve</h2>
		<ul class="awr-app-reco">
			<?php foreach ( $solucoes as $s ) : ?>
				<li>
					<h3 class="awr-app-reco__modelo"><?php echo esc_html( $s['nome'] ); ?></h3>
					<p class="awr-app-reco__ideal"><strong>Desafio:</strong> <?php echo esc_html( $s['dor'] ); ?></p>
					<p class="awr-app-reco__ideal"><strong>Solução AWR:</strong> <?php echo esc_html( $s['solucao'] ); ?></p>
					<p class="awr-app-reco__note"><?php echo esc_html( $s['publico'] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Aplicações técnicas atendidas</h2>
		<ul class="awr-app-outras">
			<?php foreach ( awr_ramos() as $r ) : ?>
				<li>
					<a href="<?php echo esc_url( home_url( '/aplicacoes/' . $r['slug'] . '/' ) ); ?>">
						<div>
							<h3><?php echo esc_html( $r['nome'] ); ?></h3>
							<p><?php echo esc_html( $r['tagline'] ); ?></p>
						</div>
						<span class="awr-app-outras__arrow" aria-hidden="true">→</span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="awr-app-section">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Como funciona o atendimento corporativo</h2>
		<ul class="awr-app-benefits">
			<li><strong>1. Diagnóstico:</strong> levantamos o parque instalado, consumo e criticidade de cada equipamento.</li>
			<li><strong>2. Dimensionamento:</strong> indicamos tecnologia e capacidade corretas, com comparativo de custo por ciclo.</li>
			<li><strong>3. Fornecimento:</strong> entrega programada, instalação no local e nota fiscal em CNPJ.</li>
			<li><strong>4. Pós-venda:</strong> testes periódicos, troca preventiva e recolhimento das baterias usadas.</li>
		</ul>
		<div class="awr-hub-cta">
			<p>Monte sua proposta com o time comercial da AWR.</p>
			<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( $wa ); ?>">Falar com o comercial</a>
		</div>
	</div>
</section>

<?php awr_part( 'awr-frotas' ); ?>
<?php awr_part( 'prova-social' ); ?>
<?php get_footer(); ?>
