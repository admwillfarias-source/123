<?php
/**
 * /blog/{slug}/ — artigo, porte de src/routes/blog.$slug.tsx.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$p = awr_post_by_slug( awr_param_a() );
if ( ! $p ) { get_template_part( '404' ); get_footer(); return; }

$c   = awr_company();
$cta = awr_wa( 'Olá! Vi o artigo "' . ( $p['h1'] ?? $p['titulo'] ) . '" e preciso de bateria em ' . ( $p['cidadeAlvo'] ?? 'Porto Alegre' ) . '.' );

$relacionados = array();
foreach ( (array) ( $p['relacionados'] ?? array() ) as $slug ) {
	$rp = awr_post_by_slug( $slug );
	if ( $rp ) { $relacionados[] = $rp; }
}

$secoes = (array) ( $p['secoes'] ?? array() );
$meio   = (int) floor( count( $secoes ) / 2 );
?>
<main class="awr-post">
	<section class="awr-post-hero">
		<div class="awr-container awr-post-hero__inner">
			<?php awr_part( 'breadcrumb', array( 'trilha' => array( array( 'nome' => 'Blog', 'url' => home_url( '/blog/' ) ) ), 'atual' => $p['categoria'] ?? 'Guia' ) ); ?>

			<span class="awr-post-hero__badge"><span class="awr-post-hero__dot"></span> Conteúdo editorial · atualizado</span>

			<?php $awr_h1_lote = function_exists( 'awr_seo_lote_h1' ) ? awr_seo_lote_h1() : ''; ?>
			<h1 class="awr-post-hero__title"><?php echo esc_html( $awr_h1_lote ? $awr_h1_lote : ( $p['h1'] ?? $p['titulo'] ) ); ?></h1>

			<div class="awr-post-hero__meta">
				<span class="awr-post-hero__pill awr-post-hero__pill--gold"><?php echo esc_html( $p['categoria'] ?? '' ); ?></span>
				<span class="awr-post-hero__pill"><?php echo esc_html( $p['tempoLeitura'] ?? 5 ); ?> min de leitura</span>
				<span class="awr-post-hero__pill"><?php echo esc_html( $p['cidadeAlvo'] ?? '' ); ?></span>
			</div>
		</div>
	</section>

<?php awr_part( 'searchband' ); ?>


	<article class="awr-container awr-post-article">
		<div class="awr-post-prose">
			<?php if ( ! empty( $p['wp_id'] ) ) : ?>
				<div class="awr-post-wp"><?php echo apply_filters( 'the_content', get_post_field( 'post_content', (int) $p['wp_id'] ) ); // phpcs:ignore ?></div>
			<?php endif; ?>
			<?php foreach ( (array) ( $p['intro'] ?? array() ) as $i => $par ) : ?>
				<p class="<?php echo 0 === $i ? 'awr-post-prose__lead' : ''; ?>"><?php echo esc_html( $par ); ?></p>
			<?php endforeach; ?>

			<?php foreach ( $secoes as $i => $sec ) : ?>
				<div>
					<h2 class="awr-post-prose__h2"><?php echo esc_html( $sec['h2'] ?? ( $sec['titulo'] ?? '' ) ); ?></h2>
					<?php foreach ( (array) ( $sec['paragrafos'] ?? array() ) as $par ) : ?>
						<p><?php echo esc_html( $par ); ?></p>
					<?php endforeach; ?>
					<?php if ( ! empty( $sec['lista'] ) ) : ?>
						<ul class="awr-post-prose__list">
							<?php foreach ( (array) $sec['lista'] as $li ) : ?>
								<li><span class="awr-post-prose__check">✓</span><?php echo esc_html( $li ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>

					<?php if ( $i === $meio ) : ?>
						<div class="awr-post-cta">
							<p><strong>Precisa de bateria agora em <?php echo esc_html( $p['cidadeAlvo'] ?? 'Porto Alegre' ); ?>?</strong> Entrega e instalação em até 35 minutos.</p>
							<a class="awr-btn awr-btn--green" href="<?php echo esc_url( $cta ); ?>" target="_top" rel="noopener">Chamar no WhatsApp</a>
						</div>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>

			<?php if ( ! empty( $p['faq'] ) ) : ?>
				<div class="awr-post-faq">
					<span class="awr-post-faq__eyebrow">Tira-dúvidas</span>
					<h2 class="awr-post-prose__h2">Perguntas frequentes</h2>
					<div class="awr-accordion">
						<?php foreach ( $p['faq'] as $f ) : ?>
							<details class="awr-accordion__item">
								<summary><?php echo esc_html( $f['pergunta'] ); ?></summary>
								<p><?php echo esc_html( $f['resposta'] ); ?></p>
							</details>
						<?php endforeach; ?>
					</div>
					<?php
					awr_jsonld( array(
						'@context'   => 'https://schema.org',
						'@type'      => 'FAQPage',
						'mainEntity' => array_map( function ( $f ) {
							return array( '@type' => 'Question', 'name' => $f['pergunta'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f['resposta'] ) );
						}, $p['faq'] ),
					) );
					?>
				</div>
			<?php endif; ?>

			<div class="awr-post-cta awr-post-cta--final">
				<p><strong>Precisa de bateria agora em <?php echo esc_html( $p['cidadeAlvo'] ?? 'Porto Alegre' ); ?>?</strong> Entrega e instalação em até 35 minutos.</p>
				<a class="awr-btn awr-btn--green" href="<?php echo esc_url( $cta ); ?>" target="_top" rel="noopener">Chamar no WhatsApp</a>
				<a class="awr-btn awr-btn--outline" href="<?php echo esc_attr( $c['phone_href'] ); ?>">Ligar <?php echo esc_html( $c['phone'] ); ?></a>
			</div>
		</div>

		<?php
		awr_jsonld( array(
			'@context'         => 'https://schema.org',
			'@type'            => 'Article',
			'headline'         => $p['h1'] ?? $p['titulo'],
			'description'      => $p['descricao'] ?? '',
			'datePublished'    => $p['dataPublicacao'] ?? '',
			'dateModified'     => $p['dataAtualizacao'] ?? ( $p['dataPublicacao'] ?? '' ),
			'author'           => array( '@type' => 'Organization', 'name' => 'AWR Baterias' ),
			'publisher'        => array( '@type' => 'Organization', 'name' => 'AWR Baterias' ),
			'mainEntityOfPage' => home_url( '/blog/' . $p['slug'] . '/' ),
		) );
		?>

		<?php awr_part( 'links-internos', array( 'tipo' => 'conteudo', 'slug' => $p['slug'] ) ); ?>
	</article>

	<?php if ( $relacionados ) : ?>
		<section class="awr-post-related">
			<div class="awr-container">
				<div class="awr-post-related__head">
					<div>
						<span class="awr-post-faq__eyebrow">Leituras recomendadas</span>
						<h2>Continue lendo</h2>
					</div>
					<a class="awr-post-related__all" href="<?php echo esc_url( home_url( '/blog/' ) ); ?>">Ver todos →</a>
				</div>
				<ul class="awr-post-related__grid">
					<?php foreach ( $relacionados as $r ) : ?>
						<li>
							<a class="awr-post-related__card" href="<?php echo esc_url( home_url( '/blog/' . $r['slug'] . '/' ) ); ?>">
								<span class="awr-post-related__thumb" aria-hidden="true"></span>
								<div>
									<span class="awr-blog-badge"><?php echo esc_html( $r['categoria'] ?? '' ); ?></span>
									<h3><?php echo esc_html( $r['h1'] ?? $r['titulo'] ); ?></h3>
									<span class="awr-post-related__link">Ler artigo →</span>
								</div>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</section>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
