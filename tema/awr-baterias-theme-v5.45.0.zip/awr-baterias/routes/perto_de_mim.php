<?php
/**
 * /bateria-perto-de-mim/ — paridade com src/routes/bateria-perto-de-mim.tsx.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$c      = awr_company();
$cta_wa = awr_wa( 'Olá! Procurei bateria perto de mim. Qual unidade atende meu endereço?' );

$faq = array(
	array( 'q' => 'Como saber qual unidade fica mais perto?', 'r' => 'Veja a lista abaixo com as seis lojas e as cidades que cada uma atende. Se preferir, mande sua localização no WhatsApp e indicamos a unidade certa.' ),
	array( 'q' => 'Preciso ir até a loja?', 'r' => 'Não. Nas cidades atendidas pela entrega própria, a equipe leva a bateria e instala no seu endereço. Você também pode ser atendido na loja, se preferir.' ),
	array( 'q' => 'Vocês atendem fora da Grande Porto Alegre?', 'r' => 'Sim, por envio com rastreio para outras cidades do Rio Grande do Sul. Nesse caso não há instalação no local.' ),
);
?>
<main class="awr-parceiros">
	<div class="awr-container">
		<p class="awr-parceiros__crumbs">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Início</a> · Bateria perto de mim
		</p>

		<header class="awr-parceiros__hero">
			<span class="awr-parceiros__badge">Seis unidades na Grande Porto Alegre</span>
			<h1 class="awr-parceiros__title">Bateria de carro perto de mim: encontre a unidade AWR que atende seu endereço</h1>
			<p class="awr-parceiros__lead">
				Escolha a loja mais próxima para falar direto com a equipe da sua região, traçar a rota ou pedir a
				entrega e instalação no local. Teste de bateria e de alternador incluídos.
			</p>
			<div class="awr-parceiros__cta-buttons">
				<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( $cta_wa ); ?>">Falar no WhatsApp</a>
				<a class="awr-btn awr-btn--gold awr-btn--xl" href="<?php echo esc_attr( $c['phone_href'] ); ?>">Ligar <?php echo esc_html( $c['phone'] ); ?></a>
			</div>
		</header>

<?php awr_part( 'searchband' ); ?>

		<section class="awr-parceiros__benefits" aria-label="Unidades AWR Baterias">
			<?php foreach ( awr_stores() as $s ) : ?>
				<div class="awr-parceiros__card">
					<h2>AWR Baterias — <?php echo esc_html( $s['nome'] ); ?></h2>
					<p><?php echo esc_html( $s['enderecoCompleto'] ); ?></p>
					<p><?php echo esc_html( $s['horarios']['semana'] ); ?><?php echo ! empty( $s['horarios']['sabado'] ) ? ' · ' . esc_html( $s['horarios']['sabado'] ) : ''; ?></p>
					<p>Atende: <?php echo esc_html( implode( ', ', (array) $s['cidadesAtendidas'] ) ); ?></p>
					<p>
						<a href="<?php echo esc_attr( $s['telefoneHref'] ); ?>">Ligar <?php echo esc_html( $s['telefone'] ); ?></a> ·
						<a target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Vim pela busca de bateria perto de mim e estou em ' . $s['cidade'] . '.' ) ); ?>">WhatsApp</a> ·
						<a target="_blank" rel="noopener" href="<?php echo esc_url( $s['mapsUrl'] ); ?>">Traçar rota</a>
					</p>
					<p><a href="<?php echo esc_url( home_url( '/lojas/' . $s['slug'] . '/' ) ); ?>">Ver a página da unidade →</a></p>
				</div>
			<?php endforeach; ?>
		</section>

		<?php awr_part( 'faq', array( 'itens' => $faq, 'titulo' => 'Perguntas frequentes' ) ); ?>

		<section class="awr-parceiros__cta">
			<p>Não sabe qual unidade atende sua rua?</p>
			<div class="awr-parceiros__cta-buttons">
				<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( $cta_wa ); ?>">Mandar minha localização</a>
				<a class="awr-btn awr-btn--outline awr-btn--xl" href="<?php echo esc_url( home_url( '/lojas/' ) ); ?>">Ver todas as lojas</a>
			</div>
		</section>

		<?php awr_part( 'links-internos', array( 'tipo' => 'cidade' ) ); ?>
	</div>
</main>

<?php
awr_faq_jsonld( $faq, home_url( '/bateria-perto-de-mim/' ) . '#faq' );
?>
<?php get_footer(); ?>
