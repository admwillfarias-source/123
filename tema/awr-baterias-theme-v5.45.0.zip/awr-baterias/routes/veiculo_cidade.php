<?php
/**
 * /baterias-para/{marca-modelo}/{cidade}/ — página local do veículo.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$m    = awr_vc_model( awr_param_a() );
$city = awr_vc_cidade( awr_param_b() );
if ( ! $m || ! $city ) { get_template_part( '404' ); return; }

$ct       = awr_vc_content( $m, $city );
$label    = awr_vc_label( $m );
$cidade   = $city['c'];
$contato  = awr_contact();
$produtos = awr_products_by_skus( awr_vc_skus( $m ) );
$wa_msg   = "Olá! Preciso da bateria do meu {$label} em {$cidade['nome']}. Podem me passar preço e prazo?";
$compat_checkout = array();
foreach ( array_slice( $produtos, 0, 3 ) as $produto ) {
	$compat_checkout[] = array(
		'sku'      => (string) ( $produto['sku'] ?? '' ),
		'nome'     => (string) ( $produto['nome'] ?? $produto['name'] ?? $produto['sku'] ?? '' ),
		'preco'    => (float) ( $produto['price'] ?? $produto['preco'] ?? 0 ),
		'casco'    => (float) ( $produto['casco'] ?? 0 ),
		'image'    => (string) ( $produto['image'] ?? $produto['imagem'] ?? '' ),
		'garantia' => (string) ( $produto['garantia'] ?? '' ),
		'veiculo'  => $label,
	);
}

get_header();
?>
<div class="awr-container awr-veiculo awr-veiculo-cidade">
	<?php
	awr_part( 'hero', array(
		'eyebrow' => 'Bateria em ' . $cidade['nome'],
		'h1'      => $ct['h1'],
		'lead'    => $ct['intro'],
		'wa'      => $wa_msg,
		'trilha'  => array(
			array( 'nome' => 'Baterias por veículo', 'url' => home_url( '/baterias-para/' ) ),
			array( 'nome' => $label, 'url' => awr_vc_url( $m['slug'] ) ),
		),
		'atual'   => $ct['h1'],
	) );
	?>

	<?php if ( $produtos ) : ?>
		<script type="application/json" id="awr-static-compat"><?php echo wp_json_encode( $compat_checkout, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?></script>
		<section class="awr-results awr-results--static" aria-label="Baterias compatíveis">
			<div class="awr-results__head">
				<div class="awr-results__headtext">
					<h2 class="awr-results__title">Baterias para <?php echo esc_html( $label ); ?> <small>em <?php echo esc_html( $cidade['nome'] ); ?></small></h2>
				</div>
			</div>
			<div class="awr-cards">
				<?php foreach ( $produtos as $p ) { awr_part( 'card-bateria', array( 'produto' => $p, 'veiculo' => $label ) ); } ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="awr-block">
		<h2 class="awr-section-title">Bateria do <?php echo esc_html( $label ); ?> em <?php echo esc_html( $cidade['nome'] ); ?></h2>
		<?php foreach ( $ct['paragrafos'] as $par ) : ?>
			<p><?php echo esc_html( $par ); ?></p>
		<?php endforeach; ?>
		<p><b><?php echo esc_html( $ct['entrega'] ); ?></b></p>
	</section>

	<?php
	$itens = array();
	foreach ( $ct['faq'] as $f ) { $itens[] = array( 'q' => $f['pergunta'], 'r' => $f['resposta'] ); }
	awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes', 'itens' => $itens ) );
	?>

	<?php
	// Links internos automáticos com âncoras por palavra-chave (paridade com o app).
	$rel   = array();
	$conta = 0;
	foreach ( awr_cidades() as $oc ) {
		if ( $oc['slug'] === $cidade['slug'] || $conta >= 5 ) { continue; }
		$rel[] = array( 'label' => 'Bateria para ' . $label . ' em ' . $oc['nome'], 'url' => awr_vc_url( $m['slug'], $oc['slug'] ) );
		$conta++;
	}
	$irmaos = 0;
	foreach ( awr_vc_models() as $om ) {
		if ( $om['marca_slug'] !== $m['marca_slug'] || $om['slug'] === $m['slug'] || $irmaos >= 3 ) { continue; }
		$rel[] = array( 'label' => 'Bateria para ' . awr_vc_label( $om ) . ' em ' . $cidade['nome'], 'url' => awr_vc_url( $om['slug'], $cidade['slug'] ) );
		$irmaos++;
	}
	foreach ( array_slice( awr_vc_amperagens( $m ), 0, 2 ) as $ah ) {
		$rel[] = array( 'label' => 'Bateria ' . $ah . 'Ah em ' . $cidade['nome'], 'url' => home_url( '/baterias/amperagem/' . $ah . '/' ) );
	}
	$rel[] = array( 'label' => 'Bateria automotiva em ' . $cidade['nome'], 'url' => home_url( '/baterias-em/' . $cidade['slug'] . '/' ) );
	$rel[] = array( 'label' => 'Baterias ' . ucfirst( $m['marca'] ) . ' em ' . $cidade['nome'], 'url' => home_url( '/marca/' . $m['marca_slug'] . '/' ) );
	$rel = array_slice( $rel, 0, 12 );
	?>
	<section class="awr-block awr-links-rel">
		<h2 class="awr-section-title">Páginas relacionadas</h2>
		<ul class="awr-links-rel__grid">
			<?php foreach ( $rel as $r ) : ?>
				<li><a class="awr-links-rel__item" href="<?php echo esc_url( $r['url'] ); ?>"><span><?php echo esc_html( $r['label'] ); ?></span> <b aria-hidden="true">→</b></a></li>
			<?php endforeach; ?>
		</ul>
	</section>


	<?php awr_part( 'search', array( 'titulo' => 'Buscar a bateria de outro veículo' ) ); ?>
	<?php awr_product_item_list_schema( $produtos, 'Baterias para ' . $label . ' em ' . $cidade['nome'] ); ?>
</div>
<?php
get_footer();
