<?php
/**
 * /categorias/ — hub de tipos de bateria por tecnologia.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$cats = awr_categorias_seo();
$wa   = awr_wa( 'Olá! Quero ajuda para escolher o tipo de bateria certo.' );
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'atual' => 'Categorias' ) ); ?>
		<h1 class="awr-hub-hero__title">Tipos de bateria por tecnologia</h1>
		<p class="awr-hub-hero__lead">AGM, EFB Start-Stop, náutica, tracionária e comparativos de marca — com nota fiscal, garantia de fábrica e instalação em Porto Alegre e região metropolitana.</p>
		<div class="awr-hub-cta__wa-wrap" style="margin-top:1.5rem;">
			<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( $wa ); ?>">Falar com um especialista</a>
		</div>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<div class="awr-hub-body">
	<ul class="awr-app-outras">
		<?php foreach ( $cats as $c ) : ?>
			<li>
				<a href="<?php echo esc_url( home_url( '/categorias/' . $c['slug'] . '/' ) ); ?>">
					<div>
						<h2><?php echo esc_html( $c['h1'] ); ?></h2>
						<p><?php echo esc_html( $c['subtitulo'] ); ?></p>
					</div>
					<span class="awr-app-outras__arrow" aria-hidden="true">→</span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</div>

<?php awr_part( 'prova-social' ); ?>
<?php get_footer(); ?>
