<?php
/**
 * /{categoria}/{cidade}/{bairro}/ — página de categoria por bairro.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$seg = awr_segmento_by_base( awr_param_a() );
$cid = $seg ? awr_segmento_cidade_by_slug( awr_param_b(), $seg ) : null;
$bai = $cid ? awr_bairro_by_slug( $cid['slug'], awr_param_c() ) : null;
if ( ! $seg || ! $cid || ! $bai ) { get_template_part( '404' ); get_footer(); return; }

$dados  = (array) awr_segmento_conteudo_cidade( $seg, $cid['slug'] );
$local  = $bai['nome'] . ' — ' . $cid['nome'];
$wa     = awr_wa( $seg['nome'] . ' em ' . $local . ': olá! Preciso de orçamento e prazo de entrega para o meu endereço.' );
$lojas  = awr_stores_for_cidade( $cid['slug'] );
$viz    = awr_bairros_vizinhos( $cid['slug'], $bai['slug'], 12 );
?>
<?php
awr_part( 'segmento-hero', array(
	'seg'    => $seg,
	'h1'     => $seg['nome'] . ' em ' . $bai['nome'] . ', ' . $cid['nome'],
	'lead'   => 'Atendimento com entrega no bairro ' . $bai['nome'] . ', orçamento pelo WhatsApp, nota fiscal e recolhimento da bateria usada.',
	'trilha' => array(
		array( 'nome' => $seg['nome'], 'url' => awr_segmento_url( $seg ) ),
		array( 'nome' => $cid['nome'], 'url' => awr_segmento_url( $seg, $cid['slug'] ) ),
	),
	'atual'  => $bai['nome'],
	'wa'     => $wa,
	'local'  => $local,
) );
?>

<div class="awr-hub-body awr-hub-body--narrow">
	<p>Quem procura <?php echo esc_html( strtolower( $seg['nome'] ) ); ?> no bairro <?php echo esc_html( $bai['nome'] ); ?>, em <?php echo esc_html( $cid['nome'] ); ?>, é atendido pela AWR com o mesmo estoque e a mesma equipe do restante da cidade. Você manda o modelo ou a aplicação pelo WhatsApp, recebe o preço fechado com nota fiscal e combina a entrega no endereço.</p>
	<?php if ( ! empty( $dados['intro'] ) ) : ?><p><?php echo esc_html( $dados['intro'] ); ?></p><?php endif; ?>
</div>

<?php awr_part( 'segmento-corpo', array( 'seg' => $seg, 'cidade' => $cid['slug'] ) ); ?>

<section class="awr-app-section">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Entrega em <?php echo esc_html( $bai['nome'] ); ?></h2>
		<?php if ( $lojas ) : ?>
			<p>Loja responsável pelo atendimento:
				<?php foreach ( $lojas as $i => $l ) : ?>
					<?php echo $i ? ', ' : ''; ?><a href="<?php echo esc_url( home_url( '/lojas/' . $l['slug'] . '/' ) ); ?>"><?php echo esc_html( $l['nome'] ); ?></a>
				<?php endforeach; ?>.
			</p>
		<?php endif; ?>
		<p>Confirme disponibilidade e prazo para o seu endereço em <?php echo esc_html( $bai['nome'] ); ?> — o prazo de 35 minutos é uma estimativa para Porto Alegre e depende de trânsito e do modelo em estoque.</p>
		<p><a target="_top" rel="noopener" href="<?php echo esc_url( $wa ); ?>">Pedir orçamento no WhatsApp</a></p>

		<?php if ( $viz ) : ?>
			<h2 class="awr-app-section__title">Bairros vizinhos</h2>
			<ul class="awr-app-chips">
				<?php foreach ( $viz as $v ) : ?>
					<li><a href="<?php echo esc_url( awr_segmento_url( $seg, $cid['slug'] ) . $v['slug'] . '/' ); ?>"><?php echo esc_html( $v['nome'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<p style="margin-top:1rem;">Ver a página completa de <a href="<?php echo esc_url( awr_segmento_url( $seg, $cid['slug'] ) ); ?>"><?php echo esc_html( $seg['nome'] . ' em ' . $cid['nome'] ); ?></a> ou o hub de <a href="<?php echo esc_url( awr_segmento_url( $seg ) ); ?>"><?php echo esc_html( $seg['nome'] ); ?></a>.</p>
	</div>
</section>

<?php
if ( function_exists( 'awr_jsonld' ) ) {
	awr_jsonld( array(
		'@context'        => 'https://schema.org',
		'@type'           => 'BreadcrumbList',
		'itemListElement' => array(
			array( '@type' => 'ListItem', 'position' => 1, 'name' => $seg['nome'], 'item' => awr_segmento_url( $seg ) ),
			array( '@type' => 'ListItem', 'position' => 2, 'name' => $cid['nome'], 'item' => awr_segmento_url( $seg, $cid['slug'] ) ),
			array( '@type' => 'ListItem', 'position' => 3, 'name' => $bai['nome'], 'item' => awr_segmento_url( $seg, $cid['slug'] ) . $bai['slug'] . '/' ),
		),
	) );
}
get_footer();
