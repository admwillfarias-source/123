<?php
/**
 * /baterias/amperagem/{ah}/
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$ah       = (int) awr_param_a();
$entries  = awr_search_by_amperage( $ah, 60 );
$produtos = awr_products_by_skus( $entries );

// Complemento vindo direto do catálogo WooCommerce (72Ah, 180Ah, 220Ah etc.).
$vistos = array();
foreach ( $produtos as $p ) {
	if ( ! empty( $p['sku'] ) ) { $vistos[ strtoupper( $p['sku'] ) ] = true; }
}
if ( function_exists( 'awr_shop_products_by_amperage' ) ) {
	foreach ( awr_shop_products_by_amperage( $ah, 48 ) as $wp ) {
		$k = $wp['sku'] ? strtoupper( $wp['sku'] ) : 'ID' . $wp['id'];
		if ( isset( $vistos[ $k ] ) ) { continue; }
		$vistos[ $k ] = true;
		$produtos[]   = $wp;
	}
}

$waMsg    = 'Olá! Preciso de uma bateria ' . $ah . 'Ah. Podem me ajudar a escolher?';
$awr_veiculos_por_ah = array(
	50  => array( 'Gol', 'Onix', 'HB20', 'Argo' ),
	60  => array( 'Onix', 'Gol', 'HB20', 'Fiat Argo', 'Jeep Renegade', 'Honda Civic', 'Toyota Corolla' ),
	70  => array( 'Honda Civic', 'Toyota Corolla', 'Jeep Renegade', 'VW T-Cross' ),
	75  => array( 'Ford Ranger', 'Toyota Hilux' ),
	80  => array( 'Jeep Renegade', 'VW T-Cross', 'Ford Ranger', 'Toyota Hilux' ),
	100 => array( 'Ford Ranger', 'Toyota Hilux' ),
);
$awr_veiculos = $awr_veiculos_por_ah[ $ah ] ?? array();

?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'trilha' => array( array( 'nome' => 'Amperagens', 'url' => home_url( '/baterias/amperagem/' ) ) ), 'atual' => $ah . 'Ah' ) ); ?>
		<h1 class="awr-hub-hero__title">Bateria <?php echo esc_html( $ah ); ?>Ah (<?php echo esc_html( $ah ); ?> amperes): preços e modelos</h1>
		<p class="awr-hub-hero__lead">
			Compare bateria <?php echo esc_html( $ah ); ?>Ah Moura, Heliar, Zetta e Excell disponível no catálogo. Veja o preço real de cada modelo, condição no Pix e parcelamento antes de pedir a instalação.<?php if ( $awr_veiculos ) : ?> Entre os veículos pesquisados estão <?php echo esc_html( implode( ', ', $awr_veiculos ) ); ?>, sempre com confirmação pelo modelo e ano.<?php endif; ?>
		</p>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<div class="awr-hub-body">
	<section class="awr-block">
		<h2 class="awr-section-title">Quanto custa uma bateria <?php echo esc_html( $ah ); ?>Ah?</h2>
		<p>O valor da bateria <?php echo esc_html( $ah ); ?> amperes muda conforme marca, tecnologia e aplicação. Os cartões abaixo mostram o preço cadastrado de cada produto; quando ele não estiver disponível, confirme o valor e o estoque pelo WhatsApp.</p>
	</section>
	<?php if ( $produtos ) : ?>
		<section class="awr-hub-products">
			<?php foreach ( $produtos as $p ) { awr_part( 'card-bateria', array( 'produto' => $p ) ); } ?>
		</section>
	<?php else : ?>
		<p class="awr-hub-empty">Nenhum modelo listado para esta amperagem. Fale com a central pelo WhatsApp.</p>
	<?php endif; ?>

	<div class="awr-hub-cta">
		<p>Não sabe qual escolher para <?php echo esc_html( $ah ); ?>Ah? Envie a foto da sua bateria — a gente identifica.</p>
		<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $waMsg ) ); ?>">Falar no WhatsApp</a>
	</div>

	<?php awr_part( 'search', array( 'titulo' => 'Prefere buscar pelo modelo do carro?' ) ); ?>
	<?php awr_part( 'links-internos', array( 'tipo' => 'amperagem', 'ah' => $ah ) ); ?>
	<?php awr_product_item_list_schema( $produtos, 'Baterias ' . $ah . 'Ah' ); ?>
</div>
<?php get_footer(); ?>
