<?php
/**
 * /pedido-confirmado/?pedido=NNN — página de conversão (noindex) medida no GTM.
 * Com ?canal=whatsapp mostra a confirmação do pedido enviado pelo WhatsApp.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$pedido = sanitize_text_field( (string) get_query_var( 'pedido' ) );
if ( ! $pedido && isset( $_GET['pedido'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
	$pedido = sanitize_text_field( substr( (string) wp_unslash( $_GET['pedido'] ), 0, 32 ) ); // phpcs:ignore WordPress.Security.NonceVerification
}
$canal = isset( $_GET['canal'] ) ? sanitize_key( (string) wp_unslash( $_GET['canal'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$is_wa = 'whatsapp' === $canal;
$awr_c = awr_company();
?>
<?php
$awr_wa_txt = $is_wa
	? 'Olá! Enviei o pedido ' . ( $pedido ? '#' . $pedido : '' ) . ' pelo site e quero confirmar.'
	: 'Olá! Acabei de fazer o pedido ' . ( $pedido ? '#' . $pedido : '' ) . ' pelo site.';
?>
<div class="awr-container awr-confirm">
	<div class="awr-confirm__card">
		<div class="awr-confirm__top">
			<span class="awr-confirm__check" aria-hidden="true">
				<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
			</span>
			<h1 class="awr-confirm__title"><?php echo $is_wa ? 'Pedido enviado!' : 'Pedido confirmado!'; ?></h1>
			<?php if ( $pedido ) : ?>
				<p class="awr-confirm__badge">Pedido #<?php echo esc_html( $pedido ); ?></p>
			<?php endif; ?>
			<p class="awr-confirm__sub">Recebemos tudo o que precisávamos. Um consultor confirma os detalhes em instantes.</p>
		</div>

		<ol class="awr-confirm__steps">
			<li><strong>1. Pedido registrado</strong><span>Já está no nosso sistema, sem precisar de mais nada.</span></li>
			<li><strong>2. Bateria separada</strong><span>A loja mais próxima prepara o modelo certo para o seu carro.</span></li>
			<li><strong>3. Técnico a caminho</strong><span>Entrega e instalação em até 35 minutos, com teste elétrico grátis.</span></li>
		</ol>

		<div class="awr-confirm__actions">
			<a class="awr-wa-cta" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $awr_wa_txt ) ); ?>">
				<svg viewBox="0 0 32 32" width="24" height="24" fill="#fff" aria-hidden="true"><path d="M16 3C8.8 3 3 8.8 3 16c0 2.3.6 4.5 1.7 6.4L3 29l6.8-1.8c1.9 1 4 1.6 6.2 1.6 7.2 0 13-5.8 13-13S23.2 3 16 3zm0 23.6c-2 0-3.9-.5-5.6-1.5l-.4-.2-4 1 1.1-3.9-.3-.4a10.6 10.6 0 1119.2-6.2c0 5.9-4.8 11.2-10 11.2zm6-8c-.3-.2-1.9-1-2.2-1.1-.3-.1-.5-.2-.7.2-.2.3-.8 1-1 1.2-.2.2-.4.2-.7.1-1.8-.9-3-1.6-4.2-3.6-.3-.5.3-.5.9-1.6.1-.2 0-.4 0-.6l-1-2.3c-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4-1.2 1.2-1.2 2.9-.1 4.6 1.1 1.7 2.4 3.9 5.6 5.2 2.2.9 3 1 4.1.8.7-.1 1.9-.8 2.2-1.6.3-.8.3-1.4.2-1.6-.1-.1-.3-.2-.6-.3z"/></svg>
				Falar no WhatsApp
			</a>
			<div class="awr-confirm__row">
				<a class="awr-confirm__ghost" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">Ligar para a central</a>
				<a class="awr-confirm__ghost" href="<?php echo esc_url( home_url( '/' ) ); ?>">Voltar ao início</a>
			</div>
		</div>
	</div>

	<?php
	$awr_sku_ped = isset( $_GET['sku'] ) ? sanitize_text_field( substr( (string) wp_unslash( $_GET['sku'] ), 0, 40 ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$awr_prod_url = '';
	if ( $awr_sku_ped && function_exists( 'wc_get_product_id_by_sku' ) ) {
		$awr_pid = wc_get_product_id_by_sku( $awr_sku_ped );
		if ( $awr_pid ) { $awr_prod_url = add_query_arg( 'review', '1', get_permalink( $awr_pid ) ) . '#reviews'; }
	}
	?>
	<section class="awr-confirm__review">
		<h2>Depois da instalação, conta pra gente como foi?</h2>
		<p>Sua avaliação leva menos de um minuto e ajuda outros motoristas da região a escolherem com segurança.</p>
		<p>
			<a class="awr-btn awr-btn--primary awr-btn--xl" target="_blank" rel="noopener nofollow"
			   href="<?php echo esc_url( awr_google_review_url() ); ?>"
			   onclick="window.dataLayer&&window.dataLayer.push({event:'review_request_click',channel:'google'});">Avaliar no Google ⭐</a>
			<?php if ( $awr_prod_url ) : ?>
				<a class="awr-btn awr-btn--outline awr-btn--xl" href="<?php echo esc_url( $awr_prod_url ); ?>"
				   onclick="window.dataLayer&&window.dataLayer.push({event:'review_request_click',channel:'produto'});">Avaliar esta bateria</a>
			<?php endif; ?>
		</p>
	</section>
</div>


<script>
(function(){
  var pedido = <?php echo wp_json_encode( $pedido ); ?>;
  var canal  = <?php echo wp_json_encode( $is_wa ? 'whatsapp' : 'woocommerce' ); ?>;
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ event: 'purchase_confirm', transaction_id: pedido, channel: canal, page_path: '/pedido-confirmado' });
  if (typeof window.gtag === 'function') {
    window.gtag('event', 'purchase_confirm', { transaction_id: pedido, channel: canal });
  }
  try {
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: 'awr:conversion', event: 'purchase_confirm', pedido: pedido, channel: canal, path: '/pedido-confirmado' }, '*');
    }
  } catch (e) {}
})();
</script>
<?php awr_part( 'pos-venda' ); ?>
<?php get_footer(); ?>
