<?php
/**
 * /baterias-em/{cidade}/ — landing page local (paridade com src/routes/baterias-em.$cidade.tsx).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$slug     = awr_param_a();
$cidade   = awr_cidade_by_slug( $slug );
$nome     = $cidade ? $cidade['nome'] : ucwords( str_replace( '-', ' ', $slug ) );
$lojas    = awr_stores_for_cidade( $slug );
if ( ! $lojas ) { $lojas = awr_stores(); }
$loja_principal = $lojas[0];
// Só avaliações reais do Google (bloco prova-social); depoimentos manuais desativados.
$deps     = array();
$awr_c    = awr_company();
$min      = $cidade && ! empty( $cidade['tempoEntregaMin'] ) ? (int) $cidade['tempoEntregaMin'] : 0;
$bairros  = $cidade && ! empty( $cidade['bairros'] ) ? (array) $cidade['bairros'] : array();
$destaque = $cidade['modeloCarroDestaque'] ?? '';
$promessa = function_exists( 'awr_city_delivery_promise' ) ? awr_city_delivery_promise( $cidade ) : "em até {$min} minutos";
$badge_entrega = function_exists( 'awr_city_delivery_badge' ) ? awr_city_delivery_badge( $cidade ) : "Entrega em {$min} min";
$modo_ent = function_exists( 'awr_city_delivery_mode' ) ? awr_city_delivery_mode( $cidade ) : 'rapida';
$tempo_curto = ( 'rapida' === $modo_ent && $min ) ? $min . ' min' : ( 'dia-seguinte' === $modo_ent ? 'Dia seguinte' : 'Mesmo dia' );
$wa_msg   = "Olá, preciso de bateria em {$nome}. Podem confirmar a entrega {$promessa}?";

// Malha completa: todas as cidades de cobertura própria (35 min) entram na
// interligação local — inclusive Sapiranga, Estância Velha e Ivoti.
$outras_cidades = array();
foreach ( awr_cidades() as $oc ) {
	if ( isset( $oc['tempoEntregaMin'] ) && $oc['slug'] !== $slug ) {
		$outras_cidades[] = $oc;
	}
}

$telefone_href = 'tel:' . preg_replace( '/\D/', '', $loja_principal['telefone'] );
// Conteúdo próprio da cidade (paridade com src/data/cidadesConteudo.ts).
$ct = function_exists( 'awr_city_content_current' ) ? awr_city_content_current( $cidade ) : ( function_exists( 'awr_cidade_conteudo' ) ? awr_cidade_conteudo( $slug ) : null );
$bairros_foco  = $bairros ? implode( ' e ', array_slice( $bairros, 0, 2 ) ) : $nome;

$marcas_bloco = array(
	array(
		'slug' => 'moura',
		'nome' => 'Moura',
		'letra_cor' => 'awrc-brand--moura',
		'h3'   => "Bateria Moura em {$nome}: durabilidade e até 24 meses de garantia",
		'p1'   => "Se você busca pela Bateria Moura em {$nome}, a AWR é a sua melhor opção de distribuidor autorizado. A Moura é líder de mercado, fornecedora oficial de VW, Fiat, GM e Ford, e é a escolha ideal para quem não quer surpresas na hora da partida — com até 24 meses de garantia válida em todo o Brasil.",
		'p2'   => "Mantemos estoque ativo em {$nome} de toda a linha Moura (45Ah, 50Ah, 60Ah, 70Ah e AGM Start-Stop) pronta para envio" . ( ! empty( $cidade['rotaLoja'] ) ? ' ' . $cidade['rotaLoja'] : '' ) . ". Nosso técnico entrega {$promessa} nos bairros {$bairros_foco}" . ( ! empty( $cidade['pontoReferencia'] ) ? ' — ' . $cidade['pontoReferencia'] : '' ) . " — com nota fiscal e teste do alternador inclusos.",
		'p2_ct' => 'moura',
		'wa'   => "Olá, estou em {$nome} e vi a Bateria Moura 60Ah no site. Conseguem entregar agora?",
	),
	array(
		'slug' => 'heliar',
		'nome' => 'Heliar',
		'letra_cor' => 'awrc-brand--heliar',
		'h3'   => "Bateria Heliar em {$nome}: tecnologia Clarios para carros modernos",
		'p1'   => 'A Heliar é a marca premium da Clarios (ex-Johnson Controls), equipamento original de BMW, Audi, Mercedes e VW Premium. Se o seu carro é mais novo, tem muita eletrônica embarcada ou Start-Stop, a linha Heliar Free AGM é a indicação técnica certa em ' . $nome . '.',
		'p2'   => "Em {$nome} entregamos a linha Heliar Super (60Ah e 70Ah) e a Heliar AGM 80Ah Start-Stop nos bairros {$bairros_foco}" . ( ! empty( $cidade['pontoReferencia'] ) ? ', ' . $cidade['pontoReferencia'] : '' ) . ", com 15 a 24 meses de garantia de fábrica e olho mágico de carga integrado. Instalação grátis {$promessa}" . ( ! empty( $cidade['transitoContexto'] ) ? ', ' . $cidade['transitoContexto'] : '' ) . '.',
		'p2_ct' => 'heliar',
		'wa'   => "Olá, estou em {$nome} e vi a Bateria Heliar no site. Conseguem entregar agora?",
	),
	array(
		'slug' => 'zetta',
		'nome' => 'Zetta',
		'letra_cor' => 'awrc-brand--zetta',
		'h3'   => "Bateria Zetta em {$nome}: o custo-benefício para Uber, 99 e dia a dia",
		'p1'   => "A Zetta é fabricada pelo Grupo Moura, usando a mesma plataforma técnica da linha top, com posicionamento mais acessível. Em {$nome} é a mais vendida da AWR para motoristas de Uber, 99 e quem roda muito — equilibrando preço e durabilidade com 12 meses de garantia nacional.",
		'p2'   => "Temos pronta entrega em {$nome} das versões Zetta 50Ah, 60Ah e 70Ah, atendendo carros populares como Gol, Uno, Celta, Ka, Onix e HB20." . ( ! empty( $cidade['rotaLoja'] ) ? ' ' . ucfirst( $cidade['rotaLoja'] ) . ', entrega' : ' Entrega' ) . " e instalação grátis nos bairros {$bairros_foco} {$promessa}, com base de troca já incluída no preço.",
		'p2_ct' => 'zetta',
		'wa'   => "Olá, estou em {$nome} e vi a Bateria Zetta no site. Conseguem entregar agora?",
	),
);
if ( $ct ) {
	foreach ( $marcas_bloco as $i => $mb ) {
		if ( ! empty( $mb['p2_ct'] ) && ! empty( $ct['marcas'][ $mb['p2_ct'] ] ) ) {
			$marcas_bloco[ $i ]['p2'] = $ct['marcas'][ $mb['p2_ct'] ];
		}
	}
}
?>
<div class="awr-container">
	<?php
	awr_part( 'breadcrumb', array(
		'trilha' => array( array( 'nome' => 'Cidades atendidas', 'url' => home_url( '/baterias-em/' ) ) ),
		'atual'  => 'Bateria em ' . $nome,
	) );
	?>

	<section class="awrc-hero">
		<div class="awrc-hero__badge">
			<span class="awrc-hero__dot"></span> Plantão ativo · <?php echo esc_html( $nome ); ?>
		</div>

		<?php $awr_h1_lote = function_exists( 'awr_seo_lote_h1' ) ? awr_seo_lote_h1() : ''; ?>
		<?php if ( $awr_h1_lote ) : ?>
		<h1 class="awrc-hero__title"><?php echo esc_html( $awr_h1_lote ); ?></h1>
		<?php else : ?>
		<h1 class="awrc-hero__title"><?php echo esc_html( $ct ? $ct['h1'] : "Troca de bateria em {$nome} com instalação {$promessa}" ); ?></h1>
		<?php endif; ?>
		<p class="awrc-hero__sub">Baterias com pagamento em até 10x sem juros e instalação grátis. Peça agora a sua!</p>

		<ul class="awrc-selos">
			<li><?php echo esc_html( $badge_entrega ); ?></li>
			<li>Instalação gratuita</li>
			<li>10x sem juros</li>
		</ul>

		<div class="awrc-hero__ctas">
			<a class="awrc-btn awrc-btn--whats" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $wa_msg ) ); ?>">Pedir pelo WhatsApp</a>
			<a class="awrc-btn awrc-btn--outline awrc-btn--on-dark" href="<?php echo esc_attr( $telefone_href ); ?>">Ligar — <?php echo esc_html( $loja_principal['telefone'] ); ?></a>
		</div>
	</section>

<?php awr_part( 'emergencia', array( 'cidade' => $cidade['slug'] ?? '' ) ); awr_part( 'o-que-voce-recebe', array( 'cidade_nome' => $cidade['nome'] ?? '' ) ); ?>
<?php awr_part( 'searchband', array( 'tag' => 'Veja o preço na hora', 'nota' => 'Não sabe qual é a bateria? Digite o modelo do carro e confira.' ) ); ?>

	<?php awr_part( 'stats-strip', array( 'tempo' => $tempo_curto ) ); ?>

	<?php if ( $ct ) : ?>
	<section class="awr-block awrc-card-block">
		<h2 class="awr-section-title">Como a AWR atende <?php echo esc_html( $nome ); ?></h2>
		<p><?php echo esc_html( $ct['abertura'][0] ); ?></p>
		<p><?php echo esc_html( $ct['abertura'][1] ); ?></p>
		<h3>Por que a bateria falha mais em <?php echo esc_html( $nome ); ?></h3>
		<p class="awrc-muted"><?php echo esc_html( $ct['motivo'] ); ?></p>
		<p class="awrc-muted"><?php echo esc_html( $ct['prova'] ); ?></p>
	</section>
	<?php endif; ?>

	<?php
	$awr_sv = function_exists( 'awr_cidade_servicos' ) ? awr_cidade_servicos( $slug ) : null;
	if ( $awr_sv ) :
		?>
	<section class="awr-block awrc-card-block">
		<h2 class="awr-section-title">Serviços de bateria em <?php echo esc_html( $nome ); ?></h2>
		<h3>Bateria a domicílio em <?php echo esc_html( $nome ); ?></h3>
		<p class="awrc-muted"><?php echo esc_html( $awr_sv['domicilio'] ); ?></p>
		<h3>Troca de bateria em <?php echo esc_html( $nome ); ?></h3>
		<p class="awrc-muted"><?php echo esc_html( $awr_sv['troca'] ); ?></p>
		<h3>Socorro de bateria em <?php echo esc_html( $nome ); ?>: carro não liga</h3>
		<p class="awrc-muted"><?php echo esc_html( $awr_sv['socorro'] ); ?></p>
		<h3>Loja de bateria perto de mim em <?php echo esc_html( $nome ); ?></h3>
		<p class="awrc-muted"><?php echo esc_html( $awr_sv['pertoDeMim'] ); ?></p>
		<p>
			<a href="<?php echo esc_url( home_url( '/bateria-a-domicilio-porto-alegre/' ) ); ?>">Bateria a domicílio em Porto Alegre →</a> ·
			<a href="<?php echo esc_url( home_url( '/socorro-bateria/' ) ); ?>">Socorro de bateria →</a> ·
			<a href="<?php echo esc_url( home_url( '/bateria-perto-de-mim/' ) ); ?>">Ver a loja mais próxima →</a>
		</p>
	</section>
	<?php endif; ?>

	<section class="awr-block">
		<h2 class="awr-section-title">Encontre a bateria certa para o seu veículo em <?php echo esc_html( $nome ); ?></h2>
		<p class="awr-lead">Compare baterias convencionais, EFB e AGM das principais marcas, com garantia e atendimento <?php echo esc_html( $promessa ); ?>.</p>

		<div class="awrc-marcas">
			<?php foreach ( $marcas_bloco as $m ) : ?>
				<article class="awrc-marca-card">
					<div class="awrc-marca-card__head">
						<span class="awrc-marca-card__letra <?php echo esc_attr( $m['letra_cor'] ); ?>"><?php echo esc_html( mb_substr( $m['nome'], 0, 1 ) ); ?></span>
						<h3><?php echo esc_html( $m['h3'] ); ?></h3>
					</div>
					<p><?php echo esc_html( $m['p1'] ); ?></p>
					<p class="awrc-muted"><?php echo esc_html( $m['p2'] ); ?></p>
					<div class="awrc-marca-card__ctas">
						<a class="awrc-btn awrc-btn--whats awrc-btn--sm" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $m['wa'] ) ); ?>">Quero a <?php echo esc_html( $m['nome'] ); ?> 60Ah agora em <?php echo esc_html( $nome ); ?></a>
						<a class="awrc-btn awrc-btn--outline awrc-btn--sm" href="<?php echo esc_url( home_url( '/marca/' . $m['slug'] . '/' ) ); ?>">Ver linha <?php echo esc_html( $m['nome'] ); ?> completa →</a>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</section>

	<section class="awr-block">
		<h2 class="awr-section-title">Aplicação e amperagem das baterias mais vendidas em <?php echo esc_html( $nome ); ?></h2>
		<div class="awrc-table-wrap">
			<table class="awrc-table">
				<thead>
					<tr>
						<th scope="col">Bateria em <?php echo esc_html( $nome ); ?></th>
						<th scope="col">Modelo / Amperagem</th>
						<th scope="col">Carros indicados</th>
						<th scope="col">Garantia</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td class="awrc-table__bat">Moura 60Ah</td>
						<td>M60GD / M60GE</td>
						<td>Onix, HB20, Corolla, Gol, Fiat Uno</td>
						<td>até 24 meses</td>
					</tr>
					<tr>
						<td class="awrc-table__bat">Heliar 60Ah</td>
						<td>HF60DD</td>
						<td>Civic, Cruze, Renegade, Compass</td>
						<td>15 meses</td>
					</tr>
					<tr>
						<td class="awrc-table__bat">Zetta 60Ah</td>
						<td>Z60D</td>
						<td>Celta, Palio, Ka, Voyage</td>
						<td>12 meses</td>
					</tr>
					<tr>
						<td class="awrc-table__bat">Moura 70Ah</td>
						<td>M70RD</td>
						<td>Hilux, S10, Ranger, Compass Diesel</td>
						<td>até 24 meses</td>
					</tr>
				</tbody>
			</table>
		</div>
		<p class="awrc-note">Não achou o modelo do seu carro? Mande a placa ou o ano no WhatsApp — confirmamos a amperagem exata em <?php echo esc_html( $nome ); ?> antes de sair pra entrega.</p>
	</section>

	<?php $awr_populares = function_exists( 'awr_vc_populares' ) ? awr_vc_populares() : array(); ?>
	<?php if ( $awr_populares ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title">Bateria para o seu carro em <?php echo esc_html( $nome ); ?></h2>
			<p class="awrc-muted">Preço fechado, entrega e instalação grátis <?php echo esc_html( $promessa ); ?> para os modelos mais vendidos de <?php echo esc_html( $nome ); ?>:</p>
			<ul class="awr-chips">
				<?php foreach ( $awr_populares as $vm ) : ?>
					<li><a class="awr-chip" href="<?php echo esc_url( awr_vc_url( $vm['slug'], $slug ) ); ?>">Bateria <?php echo esc_html( awr_vc_label( $vm ) ); ?> em <?php echo esc_html( $nome ); ?></a></li>
				<?php endforeach; ?>
			</ul>
			<p class="awr-note"><a href="<?php echo esc_url( home_url( '/baterias-para/' ) ); ?>">Ver todos os modelos de carro →</a></p>
		</section>
	<?php endif; ?>

	<?php
	// Interligação com os segmentos (estacionária, caminhão, moto) da cidade —
	// acelera a descoberta das páginas segmento×cidade pelo rastreador.
	$awr_seg_links = array();
	foreach ( awr_segmentos() as $awr_sg ) {
		if ( awr_segmento_cidade_by_slug( $slug, $awr_sg ) ) {
			$awr_seg_links[] = array(
				'url'   => awr_segmento_url( $awr_sg, $slug ),
				'label' => $awr_sg['nome'] . ' em ' . $nome,
			);
		}
	}
	?>
	<?php if ( $awr_seg_links ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title">Outras soluções de bateria em <?php echo esc_html( $nome ); ?></h2>
			<ul class="awr-chips">
				<?php foreach ( $awr_seg_links as $awr_sl ) : ?>
					<li><a class="awr-chip" href="<?php echo esc_url( $awr_sl['url'] ); ?>"><?php echo esc_html( $awr_sl['label'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>

	<?php $awr_bairros_links = awr_bairros_cidade( $slug ); ?>
	<?php if ( $awr_bairros_links || $bairros ) : ?>
		<section class="awr-block awrc-card-block">
			<h2 class="awr-section-title">Bairros atendidos em <?php echo esc_html( $nome ); ?></h2>
			<?php if ( $ct ) : ?><p><?php echo esc_html( $ct['bairrosTexto'] ); ?></p><?php endif; ?>
			<p class="awrc-muted">Clique no seu bairro para ver preço, prazo e a loja responsável em <?php echo esc_html( $nome ); ?>:</p>
			<ul class="awr-chips">
				<?php if ( $awr_bairros_links ) : ?>
					<?php foreach ( $awr_bairros_links as $b ) : ?>
						<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-bairro/' . $slug . '/' . $b['slug'] . '/' ) ); ?>"><?php echo esc_html( $b['nome'] ); ?></a></li>
					<?php endforeach; ?>
				<?php else : ?>
					<?php foreach ( $bairros as $b ) : ?>
						<li><span class="awr-chip awr-chip--static"><?php echo esc_html( $b ); ?></span></li>
					<?php endforeach; ?>
				<?php endif; ?>
			</ul>
			<?php if ( $awr_bairros_links ) : ?>
				<p class="awr-note"><a href="<?php echo esc_url( home_url( '/baterias-bairro/' . $slug . '/' ) ); ?>">Ver todos os bairros de <?php echo esc_html( $nome ); ?> →</a></p>
			<?php endif; ?>
			<p class="awr-note">Não achou o seu bairro? Atendemos toda <?php echo esc_html( $nome ); ?> — chame no WhatsApp e confirmamos o prazo na hora.</p>
		</section>
	<?php endif; ?>

	<?php if ( $outras_cidades ) : ?>
		<section class="awr-block awrc-card-block">
			<h2 class="awr-section-title">Área de Atendimento — Região Metropolitana de Porto Alegre</h2>
			<p class="awrc-muted">Atendemos com agilidade em toda a região metropolitana. Veja a página da sua cidade para preços, bairros atendidos e tempo de entrega:</p>
			<ul class="awrc-cidades-pills">
				<?php foreach ( $outras_cidades as $oc ) : ?>
					<li><a class="awrc-pill" href="<?php echo esc_url( home_url( '/baterias-em/' . $oc['slug'] . '/' ) ); ?>">Baterias em <?php echo esc_html( $oc['nome'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>

	<?php if ( $lojas ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title"><?php echo count( $lojas ) > 1 ? 'Lojas que atendem' : 'Loja responsável por'; ?> <?php echo esc_html( $nome ); ?></h2>
			<ul class="awrc-lojas-grid">
				<?php foreach ( $lojas as $s ) : ?>
					<li class="awrc-loja-card">
						<p class="awrc-loja-card__nome">AWR <?php echo esc_html( $s['nome'] ); ?></p>
						<p class="awrc-muted"><?php echo esc_html( $s['enderecoCompleto'] ); ?></p>
						<p class="awrc-loja-card__horario"><?php echo esc_html( $s['horarios']['semana'] ); ?><?php echo ! empty( $s['horarios']['sabado'] ) ? ' · ' . esc_html( $s['horarios']['sabado'] ) : ''; ?></p>
						<a class="awrc-loja-card__tel" href="tel:<?php echo esc_attr( preg_replace( '/\D/', '', $s['telefone'] ) ); ?>"><?php echo esc_html( $s['telefone'] ); ?></a>
						<div>
							<a class="awrc-loja-card__link" href="<?php echo esc_url( $s['mapsUrl'] ?? '#' ); ?>" target="_top" rel="noopener">Como chegar →</a>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>

	<?php if ( $deps ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title">Clientes AWR em <?php echo esc_html( $nome ); ?></h2>
			<div class="awrc-depoimentos">
				<?php foreach ( array_slice( $deps, 0, 3 ) as $d ) :
					$nota = isset( $d['nota'] ) ? (int) $d['nota'] : 5;
					?>
					<div class="awrc-depoimento">
						<div class="awrc-depoimento__estrelas"><?php echo str_repeat( '★', max( 0, min( 5, $nota ) ) ); ?></div>
						<p class="awrc-depoimento__texto">"<?php echo esc_html( $d['texto'] ?? '' ); ?>"</p>
						<p class="awrc-depoimento__autor"><?php echo esc_html( $d['autor'] ?? 'Cliente AWR' ); ?></p>
						<p class="awrc-muted awrc-depoimento__meta"><?php echo esc_html( $d['bairro'] ?? '' ); ?><?php echo ! empty( $d['carro'] ) ? ' · ' . esc_html( $d['carro'] ) : ''; ?></p>
					</div>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="awr-block awrc-diferenciais">
		<div class="awrc-diferencial">
			<p class="awrc-diferencial__t">Instalação gratuita</p>
			<p class="awrc-diferencial__d">Técnico especializado no local.</p>
		</div>
		<div class="awrc-diferencial">
			<p class="awrc-diferencial__t">Garantia de fábrica</p>
			<p class="awrc-diferencial__d">12 a 24 meses pela marca.</p>
		</div>
		<div class="awrc-diferencial">
			<p class="awrc-diferencial__t">10x sem juros</p>
			<p class="awrc-diferencial__d">Pix com 3% de desconto.</p>
		</div>
		<div class="awrc-diferencial">
			<p class="awrc-diferencial__t"><?php echo esc_html( $badge_entrega ); ?></p>
			<p class="awrc-diferencial__d">Em <?php echo esc_html( $nome ); ?> e região.</p>
		</div>
	</section>

	<?php
	awr_part( 'faq', array(
		'titulo' => "Perguntas frequentes — bateria em {$nome}",
		'itens'  => awr_faq_cidade( $cidade ),
	) );
	?>

	<section class="awr-block">
		<h2 class="awr-section-title">Marcas disponíveis em <?php echo esc_html( $nome ); ?></h2>
		<ul class="awr-chips">
			<?php foreach ( awr_marcas() as $m ) : ?>
				<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/bateria/' . $m['slug'] . '/' . $slug . '/' ) ); ?>">Bateria <?php echo esc_html( $m['nome'] ); ?> em <?php echo esc_html( $nome ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</section>

	<?php awr_part( 'links-internos', array( 'tipo' => 'cidade', 'slug' => $slug ) ); ?>

</div>

<section class="awrc-final-cta">
	<div class="awr-container awrc-final-cta__inner">
		<h2>Bateria arriada em <?php echo esc_html( $nome ); ?>? A gente resolve agora.</h2>
		<p>Entrega, instalação e teste do alternador no local — sem custo extra.</p>
		<div class="awrc-final-cta__ctas">
			<a class="awrc-btn awrc-btn--gold" href="<?php echo esc_attr( $telefone_href ); ?>">Ligar — <?php echo esc_html( $loja_principal['telefone'] ); ?></a>
			<a class="awrc-btn awrc-btn--whats" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $wa_msg ) ); ?>">Chamar no WhatsApp</a>
		</div>
	</div>
</section>

<?php awr_part( 'prova-social', array( 'tempo' => $tempo_curto ) ); ?>
<?php get_footer(); ?>
