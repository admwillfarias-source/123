<?php
/**
 * /bateria-para/{aplicacao}/
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$a = awr_aplicacao_by_slug( awr_param_a() );
if ( ! $a ) { get_template_part( '404' ); get_footer(); return; }

$waMsg  = 'Olá! Preciso de bateria para ' . $a['nome'] . '. Pode me ajudar?';
$outras = array_values( array_filter( awr_aplicacoes(), function ( $x ) use ( $a ) { return $x['slug'] !== $a['slug']; } ) );
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'trilha' => array( array( 'nome' => 'Aplicações', 'url' => home_url( '/bateria-para/' ) ) ), 'atual' => $a['nome'] ) ); ?>
		<h1 class="awr-hub-hero__title"><?php echo esc_html( $a['h1'] ?? ( 'Bateria para ' . $a['nome'] ) ); ?></h1>
		<p class="awr-hub-hero__lead"><?php echo esc_html( $a['tagline'] ?? '' ); ?></p>
		<div class="awr-hub-cta__wa-wrap" style="margin-top:1.5rem;">
			<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $waMsg ) ); ?>">Pedir preço no WhatsApp</a>
		</div>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<?php if ( ! empty( $a['intro'] ) ) : ?>
	<div class="awr-hub-body awr-hub-body--narrow">
		<?php foreach ( (array) $a['intro'] as $par ) : ?>
			<p><?php echo esc_html( $par ); ?></p>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

<?php if ( ! empty( $a['porqueImporta'] ) ) : ?>
	<section class="awr-app-section awr-app-section--muted">
		<div class="awr-hub-body awr-hub-body--narrow">
			<h2 class="awr-app-section__title">Por que essa aplicação é diferente</h2>
			<ul class="awr-app-benefits">
				<?php foreach ( (array) $a['porqueImporta'] as $item ) : ?>
					<li><?php echo esc_html( $item ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<?php if ( ! empty( $a['recomendacoes'] ) ) : ?>
	<section class="awr-app-section">
		<div class="awr-hub-body">
			<h2 class="awr-app-section__title">Modelos recomendados para <?php echo esc_html( $a['nome'] ); ?></h2>
			<ul class="awr-app-reco">
				<?php foreach ( (array) $a['recomendacoes'] as $r ) : ?>
					<li>
						<span class="awr-app-reco__brand"><?php echo esc_html( $r['marca'] ?? '' ); ?></span>
						<h3 class="awr-app-reco__modelo"><?php echo esc_html( $r['modelo'] ?? '' ); ?></h3>
						<p class="awr-app-reco__amp"><?php echo esc_html( $r['amperagem'] ?? '' ); ?></p>
						<p class="awr-app-reco__ideal"><?php echo esc_html( $r['ideal'] ?? '' ); ?></p>
						<p class="awr-app-reco__preco"><?php echo esc_html( $r['preco'] ?? '' ); ?></p>
						<p class="awr-app-reco__note">a partir de · instalação grátis</p>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<?php if ( ! empty( $a['ondeAtende'] ) ) : ?>
	<section class="awr-app-section awr-app-section--muted awr-app-cobertura">
		<div class="awr-hub-body awr-hub-body--narrow">
			<h2 class="awr-app-section__title">Onde atendemos</h2>
			<p><?php echo esc_html( $a['ondeAtende'] ); ?></p>
		</div>
	</section>
<?php endif; ?>

<div class="awr-hub-body awr-hub-body--narrow">
	<div class="awr-hub-cta">
		<p>Descubra a bateria certa e o preço em segundos.</p>
		<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $waMsg ) ); ?>">Falar no WhatsApp</a>
	</div>
	<?php awr_part( 'search', array( 'titulo' => 'Descubra a bateria certa e o preço' ) ); ?>
</div>

<?php if ( ! empty( $a['faq'] ) ) : ?>
	<section class="awr-app-section">
		<div class="awr-hub-body awr-hub-body--narrow">
			<h2 class="awr-app-section__title">Perguntas frequentes</h2>
			<div class="awr-app-faq">
				<?php foreach ( (array) $a['faq'] as $f ) : ?>
					<details>
						<summary><?php echo esc_html( $f['pergunta'] ?? '' ); ?></summary>
						<p><?php echo esc_html( $f['resposta'] ?? '' ); ?></p>
					</details>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php if ( $outras ) : ?>
	<section class="awr-app-section awr-app-section--muted">
		<div class="awr-hub-body">
			<h2 class="awr-app-section__title">Outras aplicações</h2>
			<ul class="awr-app-outras">
				<?php foreach ( $outras as $o ) : ?>
					<li>
						<a href="<?php echo esc_url( home_url( '/bateria-para/' . $o['slug'] . '/' ) ); ?>">
							<div>
								<h3><?php echo esc_html( $o['nome'] ); ?></h3>
								<p><?php echo esc_html( $o['tagline'] ?? '' ); ?></p>
							</div>
							<span class="awr-app-outras__arrow" aria-hidden="true">→</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<div class="awr-hub-body">
	<?php awr_part( 'links-internos', array( 'tipo' => 'aplicacao', 'slug' => $a['slug'] ) ); ?>
</div>

<?php awr_part( 'prova-social' ); ?>
<?php get_footer(); ?>
