<?php
/**
 * /aplicacoes/ — hub de ramos de aplicação.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$ramos = awr_ramos();
$wa    = awr_wa( 'Olá! Quero saber qual bateria é indicada para a minha aplicação.' );
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'atual' => 'Aplicações' ) ); ?>
		<h1 class="awr-hub-hero__title">Baterias por aplicação: a tecnologia certa para cada uso</h1>
		<p class="awr-hub-hero__lead">Do carro popular à empilhadeira, do nobreak ao barco. Escolha a aplicação e veja tecnologia indicada e condições de atendimento em Porto Alegre e Grande POA.</p>
		<div class="awr-hub-cta__wa-wrap" style="margin-top:1.5rem;">
			<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( $wa ); ?>">Falar com um especialista</a>
		</div>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<div class="awr-hub-body">
	<ul class="awr-app-outras">
		<?php foreach ( $ramos as $r ) : ?>
			<li>
				<a href="<?php echo esc_url( home_url( '/aplicacoes/' . $r['slug'] . '/' ) ); ?>">
					<div>
						<p class="awr-app-reco__brand"><?php echo esc_html( $r['tecnologia'] ); ?></p>
						<h2><?php echo esc_html( $r['nome'] ); ?></h2>
						<p><?php echo esc_html( $r['tagline'] ); ?></p>
					</div>
					<span class="awr-app-outras__arrow" aria-hidden="true">→</span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>

	<div class="awr-hub-cta">
		<p>Empresa, frota ou fornecimento recorrente? Atendemos com contrato, nota em CNPJ e reposição programada.</p>
		<a class="awr-hub-cta__wa" href="<?php echo esc_url( home_url( '/solucoes-b2b/' ) ); ?>">Ver soluções B2B</a>
	</div>
</div>

<?php awr_part( 'prova-social' ); ?>
<?php get_footer(); ?>
