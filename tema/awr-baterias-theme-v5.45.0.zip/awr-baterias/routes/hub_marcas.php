<?php
/**
 * /marca/ — hub de marcas de bateria.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$awr_c = awr_company();
?>
<div class="awrm-page">
	<section class="awrm-hero awrm-hero--hub">
		<div class="awrm-container">
			<?php awr_part( 'breadcrumb', array( 'atual' => 'Marcas' ) ); ?>
			<h1 class="awrm-hero__title">Marcas de bateria automotiva que a AWR entrega e instala</h1>
			<p class="awrm-hero__tagline">
				Moura, Heliar e Zetta com nota fiscal, garantia de fábrica e instalação no local em Porto Alegre e Grande Porto Alegre.
			</p>
			<div class="awrm-hero__ctas">
				<a class="awrm-btn awrm-btn--wa" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Quero saber qual marca de bateria serve no meu carro.' ) ); ?>">Falar no WhatsApp</a>
				<a class="awrm-btn awrm-btn--light" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">Ligar agora</a>
			</div>
		</div>
	</section>

<?php awr_part( 'searchband' ); ?>


	<section class="awrm-section">
		<div class="awrm-container">
			<ul class="awrm-brand-grid">
				<?php foreach ( awr_marcas() as $m ) : ?>
					<li>
						<a class="awrm-brand-card" href="<?php echo esc_url( home_url( '/marca/' . $m['slug'] . '/' ) ); ?>">
							<h2 class="awrm-brand-card__title">Bateria <?php echo esc_html( $m['nome'] ); ?></h2>
							<p class="awrm-brand-card__tagline"><?php echo esc_html( $m['tagline'] ?? '' ); ?></p>
							<p class="awrm-brand-card__meta"><?php echo esc_html( implode( ' · ', array_filter( array( $m['faixaPreco'] ?? '', ! empty( $m['garantiaMeses'] ) ? $m['garantiaMeses'] . ' meses de garantia' : 'Garantia de fábrica' ) ) ) ); ?></p>
							<div class="awrm-brand-card__chips">
								<?php foreach ( array_slice( awr_cidades(), 0, 4 ) as $c ) : ?>
									<span class="awrm-pill"><?php echo esc_html( $c['nome'] ); ?></span>
								<?php endforeach; ?>
							</div>
							<span class="awrm-brand-card__cta">Ver detalhes da marca →</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>

	<?php awr_part( 'search', array( 'titulo' => 'Qual marca serve no seu carro?' ) ); ?>
	<div class="awrm-container">
		<?php awr_part( 'links-internos', array( 'tipo' => 'cidade' ) ); ?>
	</div>
</div>
<?php get_footer(); ?>
