<?php
/**
 * /socorro-bateria/ — paridade com src/routes/socorro-bateria.tsx.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$c      = awr_company();
$cta_wa = awr_wa( 'Socorro! Meu carro não liga. Preciso de bateria agora.' );

$sinais = array(
	array( 'titulo' => 'Motor gira devagar', 'texto' => 'O motor de arranque "arrasta" e o carro custa a pegar, principalmente de manhã.' ),
	array( 'titulo' => 'Só um clique ao dar partida', 'texto' => 'A chave gira, o painel acende, mas o motor não gira — clássico de bateria sem carga.' ),
	array( 'titulo' => 'Luzes fracas e painel piscando', 'texto' => 'Faróis e painel oscilam quando você tenta dar partida.' ),
	array( 'titulo' => 'Descarrega da noite para o dia', 'texto' => 'O carro liga com chupeta, mas amanhece morto de novo. Pode ser bateria ou alternador.' ),
);

$passos = array(
	array( 'titulo' => 'Chame pelo WhatsApp ou telefone', 'texto' => 'Informe onde o carro está, o modelo e o ano. Já confirmamos a bateria certa e o valor.' ),
	array( 'titulo' => 'Equipe a caminho', 'texto' => 'Na Grande Porto Alegre o atendimento costuma sair em até 35 minutos, conforme bairro, trânsito e horário.' ),
	array( 'titulo' => 'Teste de bateria e alternador no local', 'texto' => 'Confirmamos se o problema é a bateria antes de você trocar qualquer coisa.' ),
	array( 'titulo' => 'Bateria nova instalada', 'texto' => 'Nota fiscal, garantia de fábrica, retirada da bateria velha e pagamento só no fim.' ),
);

$faq = array(
	array( 'q' => 'Vocês atendem 24 horas?', 'r' => 'Não. O atendimento em Porto Alegre vai das 06:30 às 22h. As demais unidades atendem no horário comercial de cada loja.' ),
	array( 'q' => 'Meu carro está na rua, dá para atender?', 'r' => 'Sim. Atendemos em casa, no trabalho, no posto, no estacionamento e na via pública, desde que o local seja seguro para o técnico.' ),
	array( 'q' => 'E se o problema não for a bateria?', 'r' => 'Testamos bateria e alternador no local. Se a bateria estiver boa, avisamos antes de qualquer troca.' ),
	array( 'q' => 'Quanto custa o deslocamento?', 'r' => 'Nas cidades atendidas pela entrega própria, a ida até você e a instalação estão incluídas no preço da bateria.' ),
);
?>
<main class="awr-parceiros">
<?php awr_part( 'emergencia' ); ?>
	<div class="awr-container">
		<p class="awr-parceiros__crumbs">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Início</a> · Socorro de bateria
		</p>

		<header class="awr-parceiros__hero">
			<span class="awr-parceiros__badge">Carro não liga? Atendemos no local</span>
			<h1 class="awr-parceiros__title">Socorro de bateria em Porto Alegre e região: vamos até o seu carro</h1>
			<p class="awr-parceiros__lead">
				Teste de bateria e de alternador no local, bateria nova instalada na hora, nota fiscal e garantia de
				fábrica. Pagamento só depois que o carro estiver ligando.
			</p>
			<div class="awr-parceiros__cta-buttons">
				<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( $cta_wa ); ?>">Pedir socorro no WhatsApp</a>
				<a class="awr-btn awr-btn--gold awr-btn--xl" href="<?php echo esc_attr( $c['phone_href'] ); ?>">Ligar <?php echo esc_html( $c['phone'] ); ?></a>
			</div>
		</header>

		<section class="awr-parceiros__benefits" aria-label="Sinais de bateria descarregada">
			<?php foreach ( $sinais as $b ) : ?>
				<div class="awr-parceiros__card">
					<h2><?php echo esc_html( $b['titulo'] ); ?></h2>
					<p><?php echo esc_html( $b['texto'] ); ?></p>
				</div>
			<?php endforeach; ?>
		</section>

		<section class="awr-parceiros__steps" aria-label="Como funciona o socorro">
			<h2 class="awr-section-title">Como funciona o socorro</h2>
			<ol>
				<?php foreach ( $passos as $i => $s ) : ?>
					<li>
						<span class="awr-parceiros__step-num"><?php echo esc_html( $i + 1 ); ?></span>
						<div>
							<h3><?php echo esc_html( $s['titulo'] ); ?></h3>
							<p><?php echo esc_html( $s['texto'] ); ?></p>
						</div>
					</li>
				<?php endforeach; ?>
			</ol>
		</section>

		<section class="awr-parceiros__benefits" aria-label="Unidades de plantão">
			<?php foreach ( awr_stores() as $s ) : ?>
				<div class="awr-parceiros__card">
					<h2><?php echo esc_html( $s['nome'] ); ?></h2>
					<p><?php echo esc_html( $s['enderecoCompleto'] ); ?></p>
					<p><?php echo esc_html( $s['horarios']['semana'] ); ?></p>
					<p>
						<a href="<?php echo esc_attr( $s['telefoneHref'] ); ?>">Ligar <?php echo esc_html( $s['telefone'] ); ?></a> ·
						<a target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Socorro! Meu carro não liga em ' . $s['cidade'] . '.' ) ); ?>">WhatsApp</a>
					</p>
				</div>
			<?php endforeach; ?>
		</section>

		<?php awr_part( 'faq', array( 'itens' => $faq, 'titulo' => 'Perguntas frequentes' ) ); ?>

		<section class="awr-parceiros__cta">
			<p>Carro parado agora?</p>
			<div class="awr-parceiros__cta-buttons">
				<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( $cta_wa ); ?>">Chamar no WhatsApp</a>
				<a class="awr-btn awr-btn--outline awr-btn--xl" href="<?php echo esc_attr( $c['phone_href'] ); ?>">Ligar <?php echo esc_html( $c['phone'] ); ?></a>
			</div>
		</section>

		<?php awr_part( 'links-internos', array( 'tipo' => 'cidade' ) ); ?>
	</div>
</main>

<?php
awr_faq_jsonld( $faq, home_url( '/socorro-bateria/' ) . '#faq' );
?>
<?php get_footer(); ?>
