<?php
/**
 * /baterias/ e /baterias/page/{n}/ — hub paginado de todos os modelos (SKU).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$per_page = 60;
$page     = max( 1, (int) awr_param_a() );
$index    = awr_sku_index();
$total    = count( $index );
$pages    = max( 1, (int) ceil( $total / $per_page ) );
$page     = min( $page, $pages );
$slice    = array_slice( $index, ( $page - 1 ) * $per_page, $per_page );
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'atual' => 'Modelos de bateria' . ( $page > 1 ? " — página {$page}" : '' ) ) ); ?>
		<h1 class="awr-hub-hero__title">Todos os modelos de bateria<?php echo $page > 1 ? ' — página ' . esc_html( $page ) : ''; ?></h1>
		<p class="awr-hub-hero__lead">
			<?php echo esc_html( $total ); ?> modelos Moura, Heliar, Zetta e Excell com entrega e instalação
			em até 35 minutos em Porto Alegre e Grande Porto Alegre.
		</p>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<div class="awr-hub-body">
	<ul class="awr-hub-skugrid">
		<?php foreach ( $slice as $e ) : ?>
			<?php $ah = awr_extract_amperage( $e['sku'] ); ?>
			<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/bateria/' . strtolower( $e['sku'] ) . '/' ) ); ?>">
				<?php echo esc_html( $e['brand'] . ' ' . $e['sku'] . ( $ah ? " — {$ah}Ah" : '' ) ); ?>
			</a></li>
		<?php endforeach; ?>
	</ul>

	<?php if ( $pages > 1 ) : ?>
		<nav class="awr-pagination" aria-label="Paginação">
			<?php for ( $i = 1; $i <= $pages; $i++ ) : ?>
				<?php $url = 1 === $i ? home_url( '/baterias/' ) : home_url( '/baterias/page/' . $i . '/' ); ?>
				<?php if ( $i === $page ) : ?>
					<span class="awr-chip awr-chip--active" aria-current="page"><?php echo esc_html( $i ); ?></span>
				<?php else : ?>
					<a class="awr-chip" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $i ); ?></a>
				<?php endif; ?>
			<?php endfor; ?>
		</nav>
	<?php endif; ?>

	<?php awr_part( 'search', array( 'titulo' => 'Busque pelo modelo do carro' ) ); ?>
	<?php awr_part( 'links-internos', array( 'tipo' => 'amperagem' ) ); ?>
</div>
<?php get_footer(); ?>
