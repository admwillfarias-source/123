<?php
/**
 * /lojas/ — paridade com src/routes/lojas.index.tsx do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main class="awr-lojas">
	<section class="awr-lojas__hero">
		<div class="awr-container">
			<?php awr_part( 'breadcrumb', array( 'atual' => 'Lojas' ) ); ?>
			<h1 class="awr-lojas__title">Nossas Lojas em Porto Alegre e Grande POA</h1>
			<p class="awr-lojas__subtitle">6 unidades AWR Baterias com entrega e instalação em até 35 minutos. Encontre a loja mais próxima e ligue agora.</p>
		</div>
	</section>

<?php awr_part( 'searchband' ); ?>


	<section class="awr-lojas__grid-section">
		<div class="awr-container">
			<h2 class="awr-lojas__h2">Todas as unidades</h2>
			<div class="awr-lojas__grid">
				<?php foreach ( awr_stores() as $s ) :
					$g    = awr_place_data( $s );
					$tel  = preg_replace( '/\D/', '', $g['phone'] ? $g['phone'] : $s['telefone'] );
					$foto = awr_store_cover( $s, $g, 800 );
					// Só exibe nota quando o próprio perfil da unidade tiver avaliações reais.
					$nota = $g['rating'] ? number_format( (float) $g['rating'], 1, ',', '' ) : '';
					$avl  = $g['reviews'] ? (int) $g['reviews'] : 0;
					?>
					<article class="awr-lojacard">
						<a class="awr-lojacard__cover" href="<?php echo esc_url( home_url( '/lojas/' . $s['slug'] . '/' ) ); ?>" tabindex="-1" aria-hidden="true">
							<img src="<?php echo esc_url( $foto ); ?>" width="1200" height="750" loading="lazy" decoding="async"
								onerror="this.onerror=null;this.src='<?php echo esc_url( get_theme_file_uri( 'assets/img/lojas/cover.jpg' ) ); ?>'"
								alt="Loja AWR Baterias <?php echo esc_attr( $s['nome'] . ' em ' . $s['cidade'] ); ?>">
						</a>


						<div class="awr-lojacard__body">
							<div>
								<p class="awr-lojacard__eyebrow"><?php echo esc_html( $s['cidade'] . '/' . $s['estado'] ); ?></p>
								<h3 class="awr-lojacard__title">AWR Baterias — <?php echo esc_html( $s['nome'] ); ?></h3>
							</div>

							<?php if ( $nota && $avl ) : ?>
								<p class="awr-lojacard__rating"><span aria-hidden="true">★</span> <strong><?php echo esc_html( $nota ); ?></strong> <span>(<?php echo esc_html( number_format_i18n( $avl ) ); ?> avaliações no Google)</span></p>
							<?php endif; ?>

							<p class="awr-lojacard__line">
								<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
								<span><?php echo esc_html( $s['endereco'] . ' — ' . $s['bairro'] ); ?></span>
							</p>

							<p class="awr-lojacard__line">
								<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
								<span><?php echo esc_html( $s['horarios']['semana'] ); ?><?php echo ! empty( $s['horarios']['sabado'] ) ? ' · ' . esc_html( $s['horarios']['sabado'] ) : ''; ?></span>
							</p>

							<div class="awr-lojacard__ctas">
								<a class="awr-btn awr-btn--gold awr-lojacard__cta" href="tel:<?php echo esc_attr( $tel ); ?>">
									<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z"/></svg>
									Ligar
								</a>
								<a class="awr-btn awr-btn--green awr-lojacard__whats" target="_top" rel="noopener" aria-label="WhatsApp"
									href="<?php echo esc_url( awr_wa( "Olá! Quero falar com a loja {$s['nome']}." ) ); ?>">
									<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-12.6 7.3L3 21l2.2-5.3A8.4 8.4 0 1 1 21 11.5Z"/></svg>
								</a>
								<a class="awr-btn awr-btn--outline awr-lojacard__cta" href="<?php echo esc_url( home_url( '/lojas/' . $s['slug'] . '/' ) ); ?>">
									Ver detalhes
									<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
								</a>
							</div>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
</main>
<?php get_footer(); ?>
