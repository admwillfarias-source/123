<?php
/** /comparar/ — filtros técnicos e comparador (tabela oficial). @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$awr_lista = array();
foreach ( awr_tabela_baterias() as $sku => $e ) { $awr_lista[] = array( 'sku' => $sku, 'modelo' => $e['modelo'], 'ah' => $e['ah'], 'cca' => $e['cca'], 'gar' => $e['garantia'], 'peso' => $e['peso'], 'vista' => $e['vista'], 'sem' => $e['sem_troca'] ); }
usort( $awr_lista, function ( $a, $b ) { return $a['ah'] <=> $b['ah'] ?: $a['vista'] <=> $b['vista']; } );
$awr_c = awr_company();
?>
<main class="awr-app-section awr-cmp" data-wa="<?php echo esc_attr( $awr_c['whatsapp_number'] ); ?>"><div class="awr-hub-body">
 <h1>Compare baterias por especificação</h1>
 <p>Filtre pela tabela oficial AWR e escolha até 3 modelos. Preço à vista com a entrega da bateria usada.</p>
 <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(min(150px,100%),1fr))">
  <label>Ah mínimo<input data-f="ahmin" type="number" value="0" style="width:100%;padding:10px"></label>
  <label>Ah máximo<input data-f="ahmax" type="number" value="250" style="width:100%;padding:10px"></label>
  <label>CCA mínimo<input data-f="cca" type="number" value="0" style="width:100%;padding:10px"></label>
  <label>Garantia mínima<select data-f="gar" style="width:100%;padding:10px"><option value="0">Qualquer</option><option>12</option><option>15</option><option>18</option><option>24</option></select></label>
 </div>
 <div class="awr-cmp-tab" style="margin:16px 0;overflow-x:auto"></div>
 <p class="awr-cmp-n"></p>
 <ul class="awr-cmp-list" style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(min(240px,100%),1fr));list-style:none;padding:0"></ul>
</div></main>
<script>
(function(){var D=<?php echo wp_json_encode( $awr_lista ); ?>,s=document.querySelector('.awr-cmp'),sel=[];
function brl(n){return n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}
function v(k){return +s.querySelector('[data-f='+k+']').value||0}
function r(){var f=D.filter(function(b){return b.ah>=v('ahmin')&&b.ah<=(v('ahmax')||999)&&b.cca>=v('cca')&&b.gar>=v('gar')});
s.querySelector('.awr-cmp-n').textContent=f.length+' modelos · '+sel.length+'/3 selecionados';
s.querySelector('.awr-cmp-list').innerHTML=f.map(function(b){var on=sel.indexOf(b.sku)>-1;return '<li style="background:#fff;border-radius:12px;padding:14px"><small>'+b.sku+'</small><div><b>'+b.modelo+'</b></div><div>'+b.ah+' Ah · '+b.cca+' CCA · '+b.gar+' meses</div><div style="font-size:18px;font-weight:800;color:#1d4ed8">'+brl(b.vista)+'</div><label><input type="checkbox" data-sku="'+b.sku+'"'+(on?' checked':'')+(!on&&sel.length>=3?' disabled':'')+'> Comparar</label></li>'}).join('');
var e=sel.map(function(k){return D.find(function(b){return b.sku===k})}),t=s.querySelector('.awr-cmp-tab');
if(!e.length){t.innerHTML='';return}
var rows=[['Modelo','modelo'],['Amperagem','ah',' Ah'],['CCA','cca',' A'],['Garantia','gar',' meses'],['Peso','peso',' kg'],['À vista (com troca)','vista','$'],['Sem troca','sem','$']];
t.innerHTML='<h2>Comparação</h2><table style="width:100%;min-width:480px"><tr><th align="left">Especificação</th>'+e.map(function(b){return '<th align="left">'+b.sku+'</th>'}).join('')+'</tr>'+rows.map(function(x){return '<tr><td><b>'+x[0]+'</b></td>'+e.map(function(b){return '<td>'+(x[2]==='$'?brl(b[x[1]]):b[x[1]]+(x[2]||''))+'</td>'}).join('')+'</tr>'}).join('')+'</table><p><a class="awr-btn awr-btn--wa" target="_blank" rel="noopener" href="https://wa.me/'+s.dataset.wa+'?text='+encodeURIComponent('Olá! Estou comparando as baterias '+sel.join(', ')+'. Qual serve no meu carro?')+'">Tirar dúvida no WhatsApp</a></p>';}
s.addEventListener('input',function(ev){var k=ev.target.dataset.sku;if(k){var i=sel.indexOf(k);i>-1?sel.splice(i,1):sel.length<3&&sel.push(k)}r()});r();})();
</script>
<?php get_footer();
