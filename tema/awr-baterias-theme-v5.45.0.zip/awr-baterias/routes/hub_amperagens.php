<?php
/**
 * /baterias/amperagem/ — hub de amperagens disponíveis.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$ahs = awr_amperagens_disponiveis();
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'atual' => 'Amperagens' ) ); ?>
		<h1 class="awr-hub-hero__title">Baterias por amperagem — do 40Ah ao 150Ah</h1>
		<p class="awr-hub-hero__lead">
			Já sabe a amperagem da sua bateria? Escolha abaixo e veja os modelos compatíveis,
			com preço no Pix, 10x sem juros e instalação no local em até 35 minutos.
		</p>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<div class="awr-hub-body">
	<ul class="awr-hub-chipgrid">
		<?php foreach ( $ahs as $ah ) : ?>
			<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias/amperagem/' . $ah . '/' ) ); ?>">Baterias <?php echo esc_html( $ah ); ?>Ah</a></li>
		<?php endforeach; ?>
	</ul>

	<?php awr_part( 'search', array( 'titulo' => 'Não sabe a amperagem? Busque pelo carro' ) ); ?>
	<?php awr_part( 'links-internos', array( 'tipo' => 'marca' ) ); ?>
</div>
<?php get_footer(); ?>
