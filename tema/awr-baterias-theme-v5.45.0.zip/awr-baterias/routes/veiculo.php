<?php
/**
 * Caminhos de SEO da busca por veículo.
 *
 * /baterias/{marca}/                  → hub do fabricante
 * /baterias/{marca}/{modelo}/         → todos os anos do modelo
 * /baterias/{marca}/{modelo}/{ano}/   → página final com SKUs compatíveis
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$marca_slug  = awr_param_a();
$modelo_slug = awr_param_b();
$ano         = (int) awr_param_c();
$marca_nome  = awr_is_vehicle_brand( $marca_slug );

if ( ! $marca_nome ) { get_template_part( '404' ); return; }

$modelos = awr_vehicle_models( $marca_slug );
$variantes = $modelo_slug ? awr_vehicle_variants( $marca_slug, $modelo_slug, $ano ) : array();
$modelo_nome = ( $modelo_slug && isset( $modelos[ $modelo_slug ] ) ) ? $modelos[ $modelo_slug ]['nome'] : '';

if ( $modelo_slug && ! $modelo_nome ) { get_template_part( '404' ); return; }

$titulo = trim( $marca_nome . ' ' . $modelo_nome . ( $ano ? " {$ano}" : '' ) );
$produtos = $variantes ? awr_products_by_skus( awr_skus_from_items( $variantes ) ) : array();
$compat_checkout = array();
foreach ( array_slice( $produtos, 0, 3 ) as $produto ) {
	$compat_checkout[] = array(
		'sku'      => (string) ( $produto['sku'] ?? '' ),
		'nome'     => (string) ( $produto['nome'] ?? $produto['name'] ?? $produto['sku'] ?? '' ),
		'preco'    => (float) ( $produto['price'] ?? $produto['preco'] ?? 0 ),
		'casco'    => (float) ( $produto['casco'] ?? 0 ),
		'image'    => (string) ( $produto['image'] ?? $produto['imagem'] ?? '' ),
		'garantia' => (string) ( $produto['garantia'] ?? '' ),
		'veiculo'  => $titulo,
	);
}

get_header();
?>
<div class="awr-container awr-veiculo">
	<?php
	$trilha = array( array( 'nome' => 'Baterias', 'url' => home_url( '/baterias/' ) ) );
	if ( $modelo_nome ) {
		$trilha[] = array( 'nome' => $marca_nome, 'url' => home_url( '/baterias/' . $marca_slug . '/' ) );
	}
	if ( $ano ) {
		$trilha[] = array( 'nome' => $modelo_nome, 'url' => awr_vehicle_url( $marca_nome, $modelo_nome ) );
	}
	if ( $ano ) {
		$awr_lead = "Veja as baterias compatíveis com o {$titulo}, com preço à vista, 10x sem juros e instalação grátis no local em até 35 minutos em Porto Alegre e Grande Porto Alegre.";
	} elseif ( $modelo_nome ) {
		$awr_lead = "Escolha o ano do seu {$marca_nome} {$modelo_nome} e confira a bateria certa, o preço atualizado e a entrega com instalação no local.";
	} else {
		$awr_lead = "Todos os modelos {$marca_nome} atendidos pela AWR Baterias, com entrega e instalação em até 35 minutos.";
	}
	awr_part( 'hero', array(
		'eyebrow' => 'Baterias ' . $marca_nome,
		'h1'      => $modelo_nome ? "Bateria para {$titulo}" : "Bateria para {$marca_nome} — todos os modelos",
		'lead'    => $awr_lead,
		'wa'      => "Olá! Preciso da bateria do meu {$titulo}. Podem me passar o preço e a entrega?",
		'wa_label'=> 'Falar com um atendente',
		'trilha'  => $trilha,
		'atual'   => $modelo_nome ? "Bateria {$titulo}" : "Bateria {$marca_nome}",
		'badges'  => $ano ? array( '⏱ Instalação em até 35 min', '🛡 Garantia de fábrica', '💳 10x sem juros' ) : null,
	) );
	?>

	<?php if ( $ano && $produtos ) : ?>
		<script type="application/json" id="awr-static-compat"><?php echo wp_json_encode( $compat_checkout, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?></script>
		<section class="awr-results awr-results--static" aria-label="Baterias compatíveis">
			<div class="awr-results__head">
				<div class="awr-results__headtext">
					<span class="awr-results__badge"><i aria-hidden="true"></i>Compatíveis • em estoque</span>
					<h2 class="awr-results__title">Baterias recomendadas <small><?php echo esc_html( $titulo ); ?></small></h2>
				</div>
				<a class="awr-results__reset" href="<?php echo esc_url( home_url( '/buscar/' ) ); ?>">Trocar veículo</a>
			</div>
			<div class="awr-cards">
				<?php foreach ( $produtos as $p ) { awr_part( 'card-bateria', array( 'produto' => $p, 'veiculo' => $titulo ) ); } ?>
			</div>
		</section>
	<?php elseif ( $ano ) : ?>
		<div class="awr-results__empty">
			<p>Estamos atualizando os preços para o <b><?php echo esc_html( $titulo ); ?></b>. Fale com a gente — respondemos em 2 minutos com preço e entrega.</p>
			<a class="awr-btn awr-btn--green" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( "Olá! Preciso da bateria do meu {$titulo}. Podem me passar o preço e a entrega?" ) ); ?>">Falar no WhatsApp agora</a>
		</div>
	<?php endif; ?>

	<?php if ( $modelo_nome && ! $ano ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title">Escolha o ano do seu <?php echo esc_html( $modelo_nome ); ?></h2>
			<ul class="awr-chips">
				<?php foreach ( array_reverse( awr_vehicle_years( $marca_slug, $modelo_slug ) ) as $y ) : ?>
					<li><a class="awr-chip" href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $modelo_nome, $y ) ); ?>"><?php echo esc_html( $marca_nome . ' ' . $modelo_nome . ' ' . $y ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>

	<?php if ( $ano ) : ?>
		<details class="awr-block awr-link-disclosure">
			<summary>Outros anos do <?php echo esc_html( $modelo_nome ); ?></summary>
			<ul class="awr-chips">
				<?php foreach ( array_reverse( awr_vehicle_years( $marca_slug, $modelo_slug ) ) as $y ) : ?>
					<?php if ( $y === $ano ) { continue; } ?>
					<li><a class="awr-chip" href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $modelo_nome, $y ) ); ?>"><?php echo esc_html( $modelo_nome . ' ' . $y ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</details>
	<?php endif; ?>

	<details class="awr-block awr-link-disclosure">
		<summary>Modelos <?php echo esc_html( $marca_nome ); ?></summary>
		<ul class="awr-chips">
			<?php foreach ( $modelos as $ms => $m ) : ?>
				<?php if ( $ms === $modelo_slug ) { continue; } ?>
				<li><a class="awr-chip" href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $m['nome'] ) ); ?>"><?php echo esc_html( $marca_nome . ' ' . $m['nome'] ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</details>

	<?php awr_part( 'search', array( 'titulo' => 'Buscar a bateria de outro veículo' ) ); ?>

	<section class="awr-block awr-faq">
		<h2 class="awr-section-title">Perguntas frequentes</h2>
		<details><summary>Qual bateria usar no <?php echo esc_html( $titulo ?: $marca_nome ); ?>?</summary>
			<p>Indicamos os modelos compatíveis listados nesta página. Em caso de dúvida, o técnico confirma a aplicação no local antes da instalação, sem custo.</p></details>
		<details><summary>Em quanto tempo vocês entregam?</summary>
			<p>Em até 35 minutos em Porto Alegre e Grande Porto Alegre, com instalação grátis e teste do alternador.</p></details>
		<details><summary>Qual a garantia?</summary>
			<p>Garantia de fábrica de 24 meses (18 meses na linha Zetta), com nota fiscal.</p></details>
	</section>

	<?php awr_part( 'links-internos', array( 'tipo' => 'conteudo', 'slug' => $marca_slug ) ); ?>
</div>

<?php
$faq = array(
	'@context'   => 'https://schema.org',
	'@type'      => 'FAQPage',
	'mainEntity' => array(
		array(
			'@type'          => 'Question',
			'name'           => 'Qual bateria usar no ' . ( $titulo ?: $marca_nome ) . '?',
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => 'Os modelos compatíveis estão listados nesta página. O técnico confirma a aplicação no local antes da instalação.' ),
		),
		array(
			'@type'          => 'Question',
			'name'           => 'Em quanto tempo a bateria é entregue?',
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => 'Em até 35 minutos em Porto Alegre e Grande Porto Alegre, com instalação grátis.' ),
		),
	),
);
awr_jsonld( $faq );
if ( $ano && $produtos ) { awr_product_item_list_schema( $produtos, 'Baterias recomendadas para ' . $titulo ); }

get_footer();
