<?php
/**
 * /baterias-em/{cidade}/ — cidade fora da cobertura própria: venda com envio
 * por transportadora. Paridade com src/components/site/CidadeVendaPage.tsx.
 *
 * Estas páginas não recebem link interno: são descobertas apenas pelo sitemap.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$cv = awr_cidade_venda_by_slug( awr_param_a() );
if ( ! $cv ) { get_template_part( '404' ); get_footer(); return; }

$nome  = $cv['nome'];
$uf    = $cv['estado'];
$wa    = awr_wa( "Olá! Quero comprar uma bateria com envio para {$nome}/{$uf}. Podem cotar o frete?" );
$comp  = awr_company();
$lojas = awr_stores();
$loja  = $lojas ? $lojas[0] : null;
$tel   = $loja ? $loja['telefone'] : $comp['phone'];
$tel_h = 'tel:' . preg_replace( '/\D/', '', $tel );

$marcas_bloco = array(
	array( 'nome' => 'Moura',  'd' => 'Líder de mercado, com até 24 meses de garantia. Linha completa de 45Ah a 220Ah.' ),
	array( 'nome' => 'Heliar', 'd' => 'Tecnologia Clarios, indicada para importados e veículos Start-Stop.' ),
	array( 'nome' => 'Zetta',  'd' => 'Excelente custo-benefício para uso urbano, com garantia de fábrica.' ),
	array( 'nome' => 'Excell', 'd' => 'Linha econômica confiável para carros populares e frota.' ),
);

$passos = array(
	array( '1. Informe o veículo', 'Marca, modelo e ano — ou o código da bateria atual.' ),
	array( '2. Receba a cotação', "Preço da bateria e frete até {$nome} pelo WhatsApp." ),
	array( '3. Pague com nota fiscal', 'Pix, cartão em 10x sem juros ou faturamento em CNPJ.' ),
	array( '4. Envio e rastreio', 'Despacho por transportadora com embalagem reforçada e código de rastreio.' ),
);

$tabela = array(
	array( 'Moura 60Ah',  'M60GD / M60GE', 'Onix, HB20, Corolla, Gol, Fiat Uno', '18 meses' ),
	array( 'Heliar 60Ah', 'HF60DD',        'Civic, Cruze, Renegade, Compass',    '15 meses' ),
	array( 'Zetta 60Ah',  'Z60D',          'Celta, Palio, Ka, Voyage',           '12 meses' ),
	array( 'Moura 70Ah',  'M70RD',         'Hilux, S10, Ranger, Compass Diesel', '18 meses' ),
);

$faq = array(
	array( "Vocês entregam e instalam a bateria em {$nome}?", "Em {$nome} trabalhamos com venda e envio por transportadora. A entrega com instalação no local é exclusiva da região metropolitana de Porto Alegre." ),
	array( "Quanto custa o frete para {$nome}?", "O frete é cotado na hora conforme o peso da bateria e o CEP de entrega. Envie seu CEP no WhatsApp e respondemos com o valor fechado." ),
	array( 'A bateria vai com nota fiscal e garantia?', 'Sim. Emitimos nota fiscal em CNPJ ou CPF e a garantia de fábrica é de 12 a 24 meses conforme a marca, válida em toda a rede autorizada do país.' ),
	array( "Como pago a bateria enviada para {$nome}?", 'Pix com desconto, cartão em até 10x sem juros ou faturamento para empresas com CNPJ.' ),
	array( "Vocês vendem para frota e empresas em {$nome}?", 'Sim. Atendemos frotas, transportadoras e revendas com condição especial por volume.' ),
);
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'trilha' => array(), 'atual' => 'Bateria em ' . $nome ) ); ?>
		<p class="awr-hub-hero__eyebrow"><?php echo 'RS' === $uf ? 'ENTREGA EM 1 A 2 DIAS ÚTEIS' : 'ENVIO POR TRANSPORTADORA'; ?> · <?php echo esc_html( $nome . '/' . $uf ); ?></p>
		<h1 class="awr-hub-hero__title"><?php echo esc_html( $cv['h1'] ); ?></h1>
		<p class="awr-hub-hero__lead">Cote a sua bateria e receba na sua residência.</p>
		<ul class="awr-hub-hero__badges">
			<li><?php echo 'RS' === $uf ? 'Entrega em 1 a 2 dias úteis' : 'Envio por transportadora'; ?></li>
			<li>Nota fiscal em CNPJ ou CPF</li>
			<li>Garantia de fábrica até 24 meses</li>
			<li>10x sem juros</li>
			<li>Embalagem reforçada</li>
		</ul>
		<div class="awr-hub-cta__wa-wrap" style="margin-top:1.5rem;">
			<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( $wa ); ?>">Cotar frete para <?php echo esc_html( $nome ); ?></a>
			<a class="awr-hub-cta__tel" href="<?php echo esc_url( $tel_h ); ?>">Ligar — <?php echo esc_html( $tel ); ?></a>
		</div>
	</div>
</section>

<?php awr_part( 'envio-menu', array( 'cidade_nome' => $nome ) ); ?>
<?php awr_part( 'searchband' ); ?>


<div class="awr-hub-body awr-hub-body--narrow">
	<p><?php echo esc_html( $cv['intro'] ); ?></p>
</div>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Linha completa de baterias com despacho para <?php echo esc_html( $nome ); ?></h2>
		<div class="awr-app-marcas">
			<article><h3>Baterias automotivas convencionais</h3><p>Modelos para carros populares, utilitários e frotas.</p></article>
			<article><h3>Baterias EFB e AGM para Start-Stop</h3><p>Aplicação correta para veículos modernos e de alta demanda elétrica.</p></article>
			<article><h3>Baterias para motos e estacionárias</h3><p>Consulte disponibilidade, peso e condição segura de transporte.</p></article>
		</div>
	</div>
</section>

<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Como funciona a compra com envio para <?php echo esc_html( $nome ); ?></h2>
		<ol class="awr-app-passos">
			<?php foreach ( $passos as $p ) : ?>
				<li><h3><?php echo esc_html( $p[0] ); ?></h3><p><?php echo esc_html( $p[1] ); ?></p></li>
			<?php endforeach; ?>
		</ol>
		<p class="awr-app-nota">Em <?php echo esc_html( $nome ); ?> a AWR trabalha com venda e envio. A instalação fica por conta do cliente ou de uma oficina de confiança da cidade — a entrega e instalação no local são exclusivas da região metropolitana de Porto Alegre.</p>
	</div>
</section>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Marcas que enviamos para <?php echo esc_html( $nome ); ?></h2>
		<div class="awr-app-marcas">
			<?php foreach ( $marcas_bloco as $m ) : ?>
				<article>
					<h3>Bateria <?php echo esc_html( $m['nome'] ); ?> em <?php echo esc_html( $nome ); ?></h3>
					<p><?php echo esc_html( $m['d'] ); ?></p>
					<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( "Olá! Quero uma bateria {$m['nome']} com envio para {$nome}/{$uf}." ) ); ?>">Cotar <?php echo esc_html( $m['nome'] ); ?> para <?php echo esc_html( $nome ); ?></a>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Modelos mais pedidos com envio para <?php echo esc_html( $nome ); ?></h2>
		<div class="awr-tabela-wrap">
			<table class="awr-tabela">
				<thead><tr><th>Bateria</th><th>Modelo / Amperagem</th><th>Carros indicados</th><th>Garantia</th></tr></thead>
				<tbody>
					<?php foreach ( $tabela as $r ) : ?>
						<tr><td><strong><?php echo esc_html( $r[0] ); ?></strong></td><td><?php echo esc_html( $r[1] ); ?></td><td><?php echo esc_html( $r[2] ); ?></td><td><?php echo esc_html( $r[3] ); ?></td></tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
</section>

<?php $awr_populares = function_exists( 'awr_vc_populares' ) ? awr_vc_populares() : array(); ?>
<?php if ( $awr_populares ) : ?>
<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Bateria para o seu carro com envio para <?php echo esc_html( $nome ); ?></h2>
		<ul class="awr-chips">
			<?php foreach ( $awr_populares as $vm ) : ?>
				<li><a class="awr-chip" href="<?php echo esc_url( awr_vc_url( $vm['slug'], $cv['slug'] ) ); ?>">Bateria <?php echo esc_html( awr_vc_label( $vm ) ); ?> em <?php echo esc_html( $nome ); ?></a></li>
			<?php endforeach; ?>
		</ul>
		<p class="awr-note" style="margin-top:1rem;"><a href="<?php echo esc_url( home_url( '/baterias-para/' ) ); ?>">Ver todos os modelos de carro →</a></p>
	</div>
</section>
<?php endif; ?>

<?php
// Interligação com os segmentos desta cidade (estacionária, caminhão, moto).
$awr_seg_links = array();
foreach ( awr_segmentos() as $awr_sg ) {
	if ( awr_segmento_cidade_by_slug( $cv['slug'], $awr_sg ) ) {
		$awr_seg_links[] = array(
			'url'   => awr_segmento_url( $awr_sg, $cv['slug'] ),
			'label' => $awr_sg['nome'] . ' em ' . $nome,
		);
	}
}
?>
<?php if ( $awr_seg_links ) : ?>
<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Outras soluções de bateria em <?php echo esc_html( $nome ); ?></h2>
		<ul class="awr-chips">
			<?php foreach ( $awr_seg_links as $awr_sl ) : ?>
				<li><a class="awr-chip" href="<?php echo esc_url( $awr_sl['url'] ); ?>"><?php echo esc_html( $awr_sl['label'] ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
<?php endif; ?>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Perguntas frequentes — <?php echo esc_html( $nome ); ?></h2>
		<dl class="awr-faq-list">
			<?php foreach ( $faq as $f ) : ?>
				<dt><?php echo esc_html( $f[0] ); ?></dt>
				<dd><?php echo esc_html( $f[1] ); ?></dd>
			<?php endforeach; ?>
		</dl>
	</div>
</section>

<?php
if ( function_exists( 'awr_jsonld' ) ) {
	awr_jsonld( array(
		'@context'    => 'https://schema.org',
		'@type'       => 'Service',
		'name'        => 'Venda de baterias automotivas em ' . $nome,
		'serviceType' => 'Venda e envio de baterias automotivas',
		'url'         => home_url( '/baterias-em/' . $cv['slug'] . '/' ),
		'areaServed'  => array( '@type' => 'City', 'name' => $nome, 'address' => array( '@type' => 'PostalAddress', 'addressRegion' => $uf, 'addressCountry' => 'BR' ) ),
		'provider'    => array( '@type' => 'Organization', 'name' => 'AWR Baterias', 'url' => home_url( '/' ), 'telephone' => $comp['phone'] ),
		'offers'      => array( '@type' => 'Offer', 'priceCurrency' => 'BRL', 'availability' => 'https://schema.org/InStock' ),
	) );

	$faq_ld = array();
	foreach ( $faq as $f ) {
		$faq_ld[] = array( '@type' => 'Question', 'name' => $f[0], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f[1] ) );
	}
	awr_jsonld( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $faq_ld ) );
}
?>
<?php get_footer(); ?>
