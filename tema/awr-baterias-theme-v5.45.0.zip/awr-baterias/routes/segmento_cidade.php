<?php
/**
 * /{categoria}/{cidade}/ — página de categoria por cidade.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$seg = awr_segmento_by_base( awr_param_a() );
$cid = $seg ? awr_segmento_cidade_by_slug( awr_param_b(), $seg ) : null;
if ( ! $seg || ! $cid ) { get_template_part( '404' ); get_footer(); return; }
$envio = isset( $cid['modo'] ) && 'envio' === $cid['modo'];
$atendimento = isset( $cid['modo'] ) && 'atendimento' === $cid['modo'];
$dados  = awr_segmento_conteudo_cidade( $seg, $cid['slug'] );
$wa     = awr_wa( $dados['wa'] ?? $seg['wa'] );
$lojas  = $envio ? array() : awr_stores_for_cidade( $cid['slug'] );
$outras = array_slice( array_values( array_filter( awr_segmento_cidades( $seg ), function ( $c ) use ( $cid ) { return $c['slug'] !== $cid['slug']; } ) ), 0, 9 );
?>
<?php
// Proposta de valor por modo: urgência local ou envio positivo (paridade com o app).
$lead_modo = $envio
	? "Enviamos para {$cid['nome']} {$cid['estado']} por transportadora — cote o frete e o prazo no WhatsApp."
	: ( $atendimento
		? "Atendimento no local em {$cid['nome']}, com dimensionamento, disponibilidade e prazo confirmados no WhatsApp."
		: "Em {$cid['nome']}: atendimento no local " . ( function_exists( 'awr_city_delivery_promise' ) ? awr_city_delivery_promise( $cid ) : 'com prazo confirmado no WhatsApp' ) . '.' );
awr_part( 'segmento-hero', array(
	'seg'    => $seg,
	'h1'     => $dados['h1'],
	'lead'   => $lead_modo,
	'modo'   => isset( $cid['modo'] ) ? $cid['modo'] : '',
	'trilha' => array( array( 'nome' => $seg['nome'], 'url' => awr_segmento_url( $seg ) ) ),
	'atual'  => $cid['nome'],
	'wa'     => $wa,
	'local'  => $cid['nome'],
) );
?>

<div class="awr-hub-body awr-hub-body--narrow">
	<p><?php echo esc_html( $dados['intro'] ); ?></p>
	<?php if ( ! empty( $cid['textoIntro'] ) ) : ?><p><?php echo esc_html( $cid['textoIntro'] ); ?></p><?php endif; ?>
</div>

<?php awr_part( 'segmento-corpo', array( 'seg' => $seg, 'cidade' => $cid['slug'] ) ); ?>

<?php if ( $envio ) : ?>
<section class="awr-app-section">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Como funciona o envio para <?php echo esc_html( $cid['nome'] ); ?></h2>
		<p>Fechamos o pedido pelo WhatsApp, com dimensionamento do banco de baterias e nota fiscal em CNPJ ou CPF. O frete é cotado na hora por transportadora e a instalação fica por conta do cliente ou do integrador local.</p>
		<p>Precisa de ajuda para dimensionar? <a target="_top" rel="noopener" href="<?php echo esc_url( $wa ); ?>">Fale com a AWR no WhatsApp</a> e envie a carga em watts e a autonomia desejada.</p>
	</div>
</section>
<?php else : ?>
<section class="awr-app-section">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title"><?php echo $atendimento ? 'Atendimento de bateria estacionária em ' : 'Bairros atendidos em '; ?><?php echo esc_html( $cid['nome'] ); ?></h2>
		<?php $awr_bl = awr_bairros_cidade( $cid['slug'] ); ?>
		<?php if ( $awr_bl ) : ?>
			<ul class="awr-app-chips">
				<?php foreach ( $awr_bl as $awr_b ) : ?>
					<li><a href="<?php echo esc_url( awr_segmento_url( $seg, $cid['slug'] ) . $awr_b['slug'] . '/' ); ?>"><?php echo esc_html( $awr_b['nome'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		<?php else : ?>
			<p><?php echo $atendimento ? 'Atendimento no endereço mediante confirmação de disponibilidade, dimensionamento e prazo pelo WhatsApp.' : esc_html( implode( ' · ', (array) $cid['bairros'] ) ); ?></p>
		<?php endif; ?>
		<?php if ( $lojas ) : ?>
			<p>Loja responsável:
				<?php foreach ( $lojas as $i => $l ) : ?>
					<?php echo $i > 0 ? ' e ' : ''; ?><a href="<?php echo esc_url( home_url( '/lojas/' . $l['slug'] . '/' ) ); ?>"><?php echo esc_html( $l['nome'] ); ?></a>
				<?php endforeach; ?>.
			</p>
		<?php endif; ?>
		<p>Também atendemos baterias automotivas em <?php echo esc_html( $cid['nome'] ); ?>: <a href="<?php echo esc_url( home_url( '/baterias-em/' . $cid['slug'] . '/' ) ); ?>">bateria de carro em <?php echo esc_html( $cid['nome'] ); ?></a>.</p>
	</div>
</section>
<?php endif; ?>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title"><?php echo esc_html( $seg['nome'] ); ?> em outras cidades</h2>
		<ul class="awr-app-outras">
			<?php foreach ( $outras as $c ) : ?>
				<li>
					<a href="<?php echo esc_url( awr_segmento_url( $seg, $c['slug'] ) ); ?>">
						<div><h3><?php echo esc_html( $c['nome'] ); ?></h3></div>
						<span class="awr-app-outras__arrow" aria-hidden="true">→</span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
		<p style="margin-top:1rem;"><a href="<?php echo esc_url( awr_segmento_url( $seg ) ); ?>">Ver todas as cidades</a></p>
	</div>
</section>

<?php if ( 'caminhao' === $seg['key'] ) : ?>
<section class="awr-app-section">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Atendimento a frotas em <?php echo esc_html( $cid['nome'] ); ?></h2>
		<p>Transportadora, distribuidora ou frota própria: fazemos a troca no pátio, com baterias de 150Ah a 220Ah para diesel leve e pesado, teste do alternador e nota fiscal em CNPJ.</p>
		<ul class="awr-app-benefits">
			<li>Troca no pátio ou na garagem, sem tirar o veículo de operação</li>
			<li>Reposição programada com histórico por placa</li>
			<li>Recolhimento do casco velho com abatimento no valor</li>
			<li>Cotação formal e nota fiscal em CNPJ</li>
		</ul>
		<p><a target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Preciso de bateria de caminhão para a frota em ' . $cid['nome'] . '. Podem cotar?' ) ); ?>">Cotar bateria para frota no WhatsApp</a></p>
	</div>
</section>
<?php endif; ?>

<?php
if ( function_exists( 'awr_jsonld' ) ) {
	$awr_c_company = awr_company();
	// Caminhão e estacionária são compra de peça/equipamento: AutoPartsStore
	// descreve melhor o negócio do que o LocalBusiness genérico.
	$awr_prov_tipo = in_array( $seg['key'], array( 'caminhao', 'moto' ), true ) ? 'AutoPartsStore' : 'LocalBusiness';
	awr_jsonld( array(
		'@context'    => 'https://schema.org',
		'@type'       => 'Service',
		'name'        => $seg['nome'] . ' em ' . $cid['nome'],
		'serviceType' => $seg['nome'],
		'provider'    => array( '@type' => $awr_prov_tipo, 'name' => 'AWR Baterias', 'telephone' => $awr_c_company['phone'], 'url' => home_url( '/' ) ),
		'areaServed'  => array( '@type' => 'City', 'name' => $cid['nome'] ),
		'url'         => awr_segmento_url( $seg, $cid['slug'] ),
	) );
}
?>

<?php if ( 'moto' === $seg['key'] ) : ?>
	<div class="awr-hub-body">
		<?php awr_part( 'moto-blocos', array( 'cidade' => $cid['slug'], 'cidade_nome' => $cid['nome'] ) ); ?>
		<?php awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes sobre bateria de moto', 'itens' => awr_moto_faq() ) ); ?>
	</div>
<?php endif; ?>
<?php awr_part( 'prova-social' ); ?>
<?php get_footer(); ?>
