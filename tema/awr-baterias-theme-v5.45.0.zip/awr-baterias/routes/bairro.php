<?php
/**
 * /baterias-bairro/{cidade}/{bairro}/ — paridade com
 * src/routes/baterias-bairro.$cidade.$bairro.tsx do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$cslug  = awr_param_a();
$bslug  = awr_param_b();
$cidade = awr_cidade_by_slug( $cslug );
$bairro = awr_bairro_by_slug( $cslug, $bslug );
if ( ! $cidade || ! $bairro ) { get_template_part( '404' ); get_footer(); return; }

$loja  = awr_loja_do_bairro( $cslug );
$min   = ! empty( $cidade['tempoEntregaMin'] ) ? (int) $cidade['tempoEntregaMin'] : 35;
$rota  = $cidade['rotaLoja'] ?? '';
$tran  = $cidade['transitoContexto'] ?? '';
$tel   = preg_replace( '/\D/', '', $loja['telefone'] );
$wamsg = "Olá! Preciso de bateria no bairro {$bairro['nome']}, {$cidade['nome']}. Confirmam entrega em {$min} minutos?";
$viz   = awr_bairros_vizinhos( $cslug, $bslug, 12 );

$faq = array(
	array(
		'q' => "Vocês entregam bateria no {$bairro['nome']}?",
		'a' => "Sim. Atendemos o bairro {$bairro['nome']} em {$cidade['nome']} com entrega e instalação no local em até {$min} minutos" . ( $rota ? ", {$rota}" : '' ) . '.',
	),
	array(
		'q' => "Quanto custa uma bateria no {$bairro['nome']}?",
		'a' => 'A partir de R$ 329 (60Ah Eletra), com instalação gratuita, 10x sem juros no cartão e desconto no Pix.',
	),
	array(
		'q' => 'Atendem à noite?',
		'a' => awr_texto_horarios(),
	),
	array(
		'q' => 'A bateria tem garantia?',
		'a' => 'Sim. Garantia de fábrica de 12 a 24 meses conforme a linha escolhida, com nota fiscal.',
	),
);
?>
<div class="awr-container">
	<?php
	awr_part( 'breadcrumb', array(
		'trilha' => array(
			array( 'nome' => 'Bateria em ' . $cidade['nome'], 'url' => home_url( '/baterias-em/' . $cslug . '/' ) ),
			array( 'nome' => 'Bairros de ' . $cidade['nome'], 'url' => home_url( '/baterias-bairro/' . $cslug . '/' ) ),
		),
		'atual'  => $bairro['nome'],
	) );
	?>

	<section class="awrc-hero">
		<div class="awrc-hero__badge">
			<span class="awrc-hero__dot"></span> Plantão ativo · <?php echo esc_html( $bairro['nome'] ); ?>
		</div>

		<h1 class="awrc-hero__title">Bateria no <span class="awrc-hero__gold"><?php echo esc_html( $bairro['nome'] ); ?></span> — <?php echo esc_html( $cidade['nome'] ); ?></h1>
		<p class="awrc-hero__sub">O carro não liga? Chegamos no <?php echo esc_html( $bairro['nome'] ); ?> em até <strong><?php echo (int) $min; ?> minutos</strong> com instalação grátis.</p>
		<p class="awrc-hero__intro">Atendemos o bairro <?php echo esc_html( $bairro['nome'] ); ?><?php echo $rota ? ' ' . esc_html( $rota ) : ''; ?><?php echo $tran ? ', ' . esc_html( $tran ) : ''; ?>. Bateria nova a partir de R$ 329 (60Ah Eletra), com teste de alternador gratuito e pagamento só depois de tudo instalado.</p>

		<ul class="awrc-selos">
			<li>Entrega em <?php echo (int) $min; ?> min</li>
			<li>Instalação gratuita</li>
			<li>Pagamento na entrega</li>
			<li>10x sem juros</li>
			<li>Garantia de fábrica</li>
		</ul>

		<div class="awrc-hero__ctas">
			<a class="awrc-btn awrc-btn--gold" href="tel:<?php echo esc_attr( $tel ); ?>">Ligar — <?php echo esc_html( $loja['telefone'] ); ?></a>
			<a class="awrc-btn awrc-btn--whats" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $wamsg ) ); ?>">WhatsApp (<?php echo (int) $min; ?> min)</a>
		</div>
	</section>

<?php awr_part( 'searchband' ); ?>


	<?php awr_part( 'search', array( 'titulo' => "Veja o preço da bateria do seu carro no {$bairro['nome']}" ) ); ?>
	<?php awr_part( 'stats-strip' ); ?>

	<section class="awr-block awrc-card-block">
		<h2 class="awr-section-title">Loja que atende o <?php echo esc_html( $bairro['nome'] ); ?></h2>
		<p class="awr-lead"><strong>AWR Baterias — <?php echo esc_html( $loja['nome'] ); ?></strong> · <?php echo esc_html( $loja['cidade'] . '/' . $loja['estado'] ); ?></p>
		<p class="awr-note">📍 <?php echo esc_html( $loja['enderecoCompleto'] ); ?></p>
		<p class="awr-note">🕒 <?php echo esc_html( $loja['horarios']['semana'] ); ?><?php echo ! empty( $loja['horarios']['sabado'] ) ? ' · ' . esc_html( $loja['horarios']['sabado'] ) : ''; ?></p>
		<div class="awrc-hero__ctas">
			<a class="awrc-btn awrc-btn--gold" href="tel:<?php echo esc_attr( $tel ); ?>">Ligar</a>
			<a class="awrc-btn awrc-btn--whats" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $wamsg ) ); ?>">WhatsApp</a>
			<a class="awr-btn awr-btn--outline" href="<?php echo esc_url( home_url( '/lojas/' . $loja['slug'] . '/' ) ); ?>">Ver detalhes da loja</a>
		</div>
	</section>

	<?php
	$faq_itens = array();
	foreach ( $faq as $f ) { $faq_itens[] = array( 'q' => $f['q'], 'r' => $f['a'] ); }
	awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes — ' . $bairro['nome'], 'itens' => $faq_itens ) );
	?>

	<section class="awr-block awrc-card-block">
		<h2 class="awr-section-title">Outros bairros que atendemos em <?php echo esc_html( $cidade['nome'] ); ?></h2>
		<ul class="awr-chips">
			<?php foreach ( $viz as $v ) : ?>
				<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-bairro/' . $cslug . '/' . $v['slug'] . '/' ) ); ?>"><?php echo esc_html( $v['nome'] ); ?></a></li>
			<?php endforeach; ?>
		</ul>
		<p class="awr-note"><a href="<?php echo esc_url( home_url( '/baterias-bairro/' . $cslug . '/' ) ); ?>">Ver todos os bairros de <?php echo esc_html( $cidade['nome'] ); ?> →</a></p>
	</section>
</div>

<?php
$url = home_url( '/baterias-bairro/' . $cslug . '/' . $bslug . '/' );
$awr_bairro_ld = array(
	'@context'        => 'https://schema.org',
	'@type'           => 'LocalBusiness',
	'@id'             => $url . '#localbusiness',
	'name'            => 'AWR Baterias — ' . $bairro['nome'] . ', ' . $cidade['nome'],
	'url'             => $url,
	'priceRange'      => 'R$ 329 - R$ 3.200',
	'telephone'       => $loja['telefone'],
	'address'         => array(
		'@type'           => 'PostalAddress',
		'streetAddress'   => $loja['endereco'],
		'addressLocality' => $loja['cidade'],
		'addressRegion'   => $loja['estado'],
		'addressCountry'  => 'BR',
	),
	'geo'             => array( '@type' => 'GeoCoordinates', 'latitude' => $loja['geo']['lat'], 'longitude' => $loja['geo']['lng'] ),
	'areaServed'      => array(
		'@type'             => 'Place',
		'name'              => $bairro['nome'] . ', ' . $cidade['nome'] . ' - ' . $cidade['estado'],
		'containedInPlace'  => array( '@type' => 'City', 'name' => $cidade['nome'] ),
	),
	);

// v5.15.0: a nota 4,9/1935 (operação inteira) estava copiada em todas as páginas de bairro.
// Agora só entra a nota do perfil da loja que atende, quando ele tiver avaliações próprias.
$awr_g_bairro = function_exists( 'awr_place_data' ) ? awr_place_data( $loja ) : array();
if ( ! empty( $awr_g_bairro['rating'] ) && ! empty( $awr_g_bairro['reviews'] ) ) {
	$awr_bairro_ld['aggregateRating'] = array(
		'@type'       => 'AggregateRating',
		'ratingValue' => (float) $awr_g_bairro['rating'],
		'reviewCount' => (int) $awr_g_bairro['reviews'],
	);
}
awr_jsonld( $awr_bairro_ld );

awr_jsonld( array(
	'@context'        => 'https://schema.org',
	'@type'           => 'BreadcrumbList',
	'itemListElement' => array(
		array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Início', 'item' => home_url( '/' ) ),
		array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Bateria em ' . $cidade['nome'], 'item' => home_url( '/baterias-em/' . $cslug . '/' ) ),
		array( '@type' => 'ListItem', 'position' => 3, 'name' => 'Bairros de ' . $cidade['nome'], 'item' => home_url( '/baterias-bairro/' . $cslug . '/' ) ),
		array( '@type' => 'ListItem', 'position' => 4, 'name' => $bairro['nome'], 'item' => $url ),
	),
) );

$faq_ld = array();
foreach ( $faq as $f ) {
	$faq_ld[] = array(
		'@type'          => 'Question',
		'name'           => $f['q'],
		'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f['a'] ),
	);
}
awr_jsonld( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $faq_ld ) );
?>
<?php get_footer(); ?>
