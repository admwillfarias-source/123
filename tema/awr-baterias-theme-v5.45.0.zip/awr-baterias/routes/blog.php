<?php
/**
 * /blog/ — índice editorial dos guias, porte de src/routes/blog.tsx.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$posts    = awr_posts_data();
$featured = $posts ? $posts[0] : null;
$rest     = $posts ? array_slice( $posts, 1 ) : array();
?>
<main class="awr-blog">
	<section class="awr-blog-hero">
		<div class="awr-container awr-blog-hero__inner">
			<nav class="awr-blog-hero__crumbs" aria-label="Você está aqui">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Início</a>
				<span>›</span>
				<span>Blog</span>
			</nav>

			<span class="awr-blog-hero__badge"><span class="awr-blog-hero__dot"></span> Conteúdo editorial · atualizado semanal</span>

			<h1 class="awr-blog-hero__title">Blog <span>AWR Baterias</span></h1>
			<p class="awr-blog-hero__lead">Dicas práticas e guias rápidos sobre bateria automotiva, escritos por quem atende Porto Alegre, Canoas, Gravataí, São Leopoldo e Novo Hamburgo todo dia.</p>

			<ul class="awr-blog-hero__stats">
				<li><strong><?php echo esc_html( count( $posts ) ); ?></strong> artigos</li>
				<li>Foco regional</li>
				<li>Leitura rápida</li>
			</ul>
		</div>
	</section>

<?php awr_part( 'searchband' ); ?>


	<section class="awr-blog-body">
		<div class="awr-container">
			<?php if ( $featured ) : ?>
				<a class="awr-blog-featured" href="<?php echo esc_url( home_url( '/blog/' . $featured['slug'] . '/' ) ); ?>">
					<div class="awr-blog-featured__media">
						<span class="awr-blog-featured__tag"><span></span> Em destaque</span>
					</div>
					<div class="awr-blog-featured__body">
						<div class="awr-blog-featured__meta">
							<span class="awr-blog-badge"><?php echo esc_html( $featured['categoria'] ?? '' ); ?></span>
							<span><?php echo esc_html( $featured['tempoLeitura'] ?? 5 ); ?> min</span>
						</div>
						<h2><?php echo esc_html( $featured['h1'] ?? $featured['titulo'] ); ?></h2>
						<p><?php echo esc_html( $featured['descricao'] ?? '' ); ?></p>
						<div class="awr-blog-featured__footer">
							<span class="awr-blog-featured__city"><?php echo esc_html( $featured['cidadeAlvo'] ?? '' ); ?></span>
							<span class="awr-blog-featured__cta">Ler artigo →</span>
						</div>
					</div>
				</a>
			<?php endif; ?>

			<div class="awr-blog-body__head">
				<h2>Últimos <span>artigos</span></h2>
				<span class="awr-blog-body__count"><?php echo esc_html( count( $rest ) ); ?> publicações</span>
			</div>

			<ul class="awr-blog-grid">
				<?php foreach ( $rest as $idx => $p ) : ?>
					<li>
						<a class="awr-blog-card" href="<?php echo esc_url( home_url( '/blog/' . $p['slug'] . '/' ) ); ?>">
							<div class="awr-blog-card__media">
								<span class="awr-blog-card__badge"><?php echo esc_html( $p['categoria'] ?? '' ); ?></span>
								<span class="awr-blog-card__index"><?php echo esc_html( str_pad( (string) ( $idx + 2 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
							</div>
							<div class="awr-blog-card__body">
								<span class="awr-blog-card__time"><?php echo esc_html( $p['tempoLeitura'] ?? 5 ); ?> min de leitura</span>
								<h3><?php echo esc_html( $p['h1'] ?? $p['titulo'] ); ?></h3>
								<p><?php echo esc_html( $p['descricao'] ?? '' ); ?></p>
								<div class="awr-blog-card__footer">
									<span class="awr-blog-card__city"><?php echo esc_html( $p['cidadeAlvo'] ?? '' ); ?></span>
									<span class="awr-blog-card__link">Ler artigo →</span>
								</div>
							</div>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
</main>
<?php get_footer(); ?>
