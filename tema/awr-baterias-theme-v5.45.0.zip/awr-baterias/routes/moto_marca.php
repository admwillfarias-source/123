<?php
/**
 * /baterias-para-moto/marca/{marca}/ — LP de marca de moto.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$marca = awr_moto_brand( awr_param_a() );
if ( ! $marca ) { get_template_part( '404' ); return; }

$modelos = awr_moto_models_by_brand( $marca['slug'] );
$contato = awr_contact();
$wa_msg  = "Olá! Preciso de bateria para minha moto {$marca['nome']}. Podem me passar preço?";

get_header();
?>
<div class="awr-container awr-moto-marca">
	<?php
	awr_part( 'hero', array(
		'eyebrow' => 'Baterias para moto',
		'h1'      => 'Bateria para moto ' . $marca['nome'],
		'lead'    => sprintf( '%d modelos %s atendidos, com bateria selada, AGM ou gel na amperagem correta, nota fiscal e garantia de fábrica. Entrega e instalação no local em Porto Alegre e região.', count( $modelos ), $marca['nome'] ),
		'badges'  => array( 'Selada, AGM ou gel', 'Instalação no local', 'Nota fiscal e garantia', 'Atendimento imediato' ),
		'wa'      => $wa_msg,
		'wa_label'=> 'Falar com um especialista',
		'trilha'  => array( array( 'nome' => 'Baterias para moto', 'url' => home_url( '/baterias-para-moto/' ) ) ),
		'atual'   => 'Moto ' . $marca['nome'],
	) );
	?>

	<?php awr_part( 'moto-blocos', array( 'cidade' => '', 'cidade_nome' => '' ) ); ?>

	<section class="awr-block">
		<h2 class="awr-section-title">Modelos <?php echo esc_html( $marca['nome'] ); ?> atendidos</h2>
		<ul class="awr-links-rel__grid">
			<?php foreach ( $modelos as $m ) : ?>
				<li>
					<a class="awr-links-rel__item" href="<?php echo esc_url( awr_vc_url( $m['slug'] ) ); ?>">
						<span>
							Bateria para <?php echo esc_html( $m['label'] ); ?>
							<small><?php echo esc_html( awr_moto_ah_range( $m['ahs'] ) . ' · ' . ( $m['de'] === $m['ate'] ? $m['de'] : $m['de'] . '–' . $m['ate'] ) ); ?></small>
						</span>
						<b aria-hidden="true">→</b>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</section>

	<section class="awr-block">
		<h2 class="awr-section-title">Bateria de moto <?php echo esc_html( $marca['nome'] ); ?> na sua cidade</h2>
		<ul class="awr-chips">
			<?php foreach ( awr_cidades() as $c ) : ?>
				<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-para-moto/' . $c['slug'] . '/' ) ); ?>">Bateria de moto em <?php echo esc_html( $c['nome'] ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</section>

	<?php awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes', 'itens' => awr_moto_faq() ) ); ?>
	<?php awr_part( 'prova-social' ); ?>
	<?php
	$faq_ld = array();
	foreach ( awr_moto_faq() as $f ) {
		$faq_ld[] = array(
			'@type'          => 'Question',
			'name'           => $f['q'],
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f['r'] ),
		);
	}
	awr_jsonld( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $faq_ld ) );
	?>
</div>
<?php
get_footer();
