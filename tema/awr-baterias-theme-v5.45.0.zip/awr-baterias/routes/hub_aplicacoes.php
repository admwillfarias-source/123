<?php
/**
 * /bateria-para/ — hub de aplicações (tipos de uso e veículo).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'atual' => 'Aplicações' ) ); ?>
		<h1 class="awr-hub-hero__title">Bateria por tipo de veículo e de uso</h1>
		<p class="awr-hub-hero__lead">
			Carro de passeio, utilitário, caminhonete, aplicativo, som automotivo ou start-stop:
			veja a especificação recomendada e o preço com entrega em até 35 minutos.
		</p>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<div class="awr-hub-body">
	<ul class="awr-hub-grid">
		<?php foreach ( awr_aplicacoes() as $a ) : ?>
			<li class="awr-hub-card">
				<h2 class="awr-hub-card__title"><a href="<?php echo esc_url( home_url( '/bateria-para/' . $a['slug'] . '/' ) ); ?>">Bateria para <?php echo esc_html( $a['nome'] ); ?></a></h2>
				<p class="awr-hub-card__meta"><?php echo esc_html( $a['tagline'] ?? '' ); ?></p>
			</li>
		<?php endforeach; ?>
	</ul>

	<?php awr_part( 'search', array( 'titulo' => 'Busque pelo modelo do seu veículo' ) ); ?>
	<?php awr_part( 'links-internos', array( 'tipo' => 'marca' ) ); ?>
</div>
<?php get_footer(); ?>
