<?php
/** Página-mãe de baterias automotivas (paridade com src/routes/baterias-de-carro.tsx). @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
awr_part( 'hero', array(
	'eyebrow' => 'CONVENCIONAL · EFB · AGM',
	'h1'      => 'Baterias de carro com preço real e instalação no local',
	'gold'    => '',
	'lead'    => 'Informe modelo e ano para comparar Moura, Heliar, Zetta e Excell compatíveis com o seu veículo.',
	'crumb'   => 'Baterias de carro',
	'search'  => true,
) );
awr_part( 'mais-vendidos', array( 'segmento' => 'carro' ) );

// Menor preço de tabela (com troca) por faixa automotiva.
$awr_tab    = function_exists( 'awr_tabela_baterias' ) ? (array) awr_tabela_baterias() : array();
$awr_faixas = array(
	array( '40Ah a 50Ah', 40, 50, 'Carros 1.0 e compactos antigos' ),
	array( '60Ah', 55, 65, 'Gol, Onix, HB20, Sandero, Strada' ),
	array( '70Ah a 75Ah', 66, 79, 'Sedãs, Civic, Corolla, Creta' ),
	array( '80Ah a 95Ah', 80, 95, 'SUVs, Start-Stop e caminhonetes médias' ),
	array( '100Ah', 96, 105, 'Hilux, S10, Ranger e utilitários' ),
);
$awr_marcas_c = array(
	'moura'  => array( 'Moura', 'Garantia de até 24 meses, conforme o modelo.' ),
	'heliar' => array( 'Heliar', 'Garantia de 15 a 24 meses, conforme o modelo.' ),
	'zetta'  => array( 'Zetta', 'Custo-benefício do Grupo Moura.' ),
	'excell' => array( 'Excell', 'Opção de entrada com nota fiscal e garantia.' ),
);
$awr_faq_c = array(
	array( 'pergunta' => 'Como sei qual bateria serve no meu carro?', 'resposta' => 'Digite o modelo e o ano na busca acima. Mostramos as baterias compatíveis pela aplicação da montadora; se tiver dúvida, confirmamos pelo WhatsApp.' ),
	array( 'pergunta' => 'O preço já inclui a instalação?', 'resposta' => 'Sim. Entrega, instalação no local e teste do alternador estão incluídos. O preço de tabela considera a troca pela bateria usada.' ),
	array( 'pergunta' => 'Qual o prazo de entrega?', 'resposta' => 'Até 35 minutos em Porto Alegre e nas cidades com atendimento rápido. Nas demais cidades o prazo aparece na página de cada uma.' ),
	array( 'pergunta' => 'Quais as formas de pagamento?', 'resposta' => 'Pix com 3% de desconto, débito ou crédito em até 10x sem juros, pagos no local.' ),
);
?>
<section class="awr-app-section"><div class="awr-hub-body">
	<h2 class="awr-app-section__title">Preços por amperagem</h2>
	<p class="awr-app-section__lead">Preço de tabela com a troca da bateria usada, entrega e instalação inclusas.</p>
	<ul class="awr-app-reco">
		<?php foreach ( $awr_faixas as $f ) :
			$precos = array();
			foreach ( $awr_tab as $b ) {
				$ah = (float) ( $b['ah'] ?? 0 ); $mod = (string) ( $b['modelo'] ?? '' ); $pb = (float) ( $b['base'] ?? 0 );
				if ( $ah >= $f[1] && $ah <= $f[2] && $pb > 0 && ! preg_match( '/\bDF\d|FREEDOM|ESTAC|NOBREAK|MVA|^HT|^MT|^MB/i', $mod ) ) { $precos[] = $pb; }
			}
			if ( ! $precos ) { continue; }
			?>
			<li><h3 class="awr-app-reco__modelo"><a href="<?php echo esc_url( home_url( '/baterias/amperagem/' ) ); ?>">Bateria <?php echo esc_html( $f[0] ); ?></a></h3>
				<p class="awr-app-reco__ideal"><?php echo esc_html( $f[3] ); ?> · a partir de <strong>R$ <?php echo esc_html( number_format( min( $precos ), 2, ',', '.' ) ); ?></strong></p></li>
		<?php endforeach; ?>
	</ul>
</div></section>
<section class="awr-app-section"><div class="awr-hub-body">
	<h2 class="awr-app-section__title">Escolha pela tecnologia do veículo</h2>
	<ul class="awr-app-reco">
		<li><h3 class="awr-app-reco__modelo"><a href="<?php echo esc_url( home_url( '/baterias/amperagem/' ) ); ?>">Bateria convencional</a></h3><p class="awr-app-reco__ideal">Para veículos sem Start-Stop, com ampla variedade de amperagens.</p></li>
		<li><h3 class="awr-app-reco__modelo"><a href="<?php echo esc_url( home_url( '/categorias/baterias-efb-start-stop/' ) ); ?>">Bateria EFB</a></h3><p class="awr-app-reco__ideal">Para sistemas Start-Stop de entrada e maior ciclagem.</p></li>
		<li><h3 class="awr-app-reco__modelo"><a href="<?php echo esc_url( home_url( '/categorias/baterias-agm/' ) ); ?>">Bateria AGM</a></h3><p class="awr-app-reco__ideal">Para Start-Stop avançado, alta demanda elétrica e veículos premium.</p></li>
	</ul>
</div></section>
<section class="awr-app-section"><div class="awr-hub-body">
	<h2 class="awr-app-section__title">Marcas que trabalhamos</h2>
	<ul class="awr-app-reco">
		<?php foreach ( $awr_marcas_c as $slug => $m ) : ?>
			<li><h3 class="awr-app-reco__modelo"><a href="<?php echo esc_url( home_url( '/marca/' . $slug . '/' ) ); ?>">Bateria <?php echo esc_html( $m[0] ); ?></a></h3><p class="awr-app-reco__ideal"><?php echo esc_html( $m[1] ); ?></p></li>
		<?php endforeach; ?>
	</ul>
</div></section>
<section class="awr-app-section awr-app-section--muted"><div class="awr-hub-body"><h2 class="awr-app-section__title">O que está incluído</h2><ul class="awr-app-benefits"><li>Compatibilidade conferida pelo carro e ano</li><li>Preço real antes do pedido</li><li>Teste da bateria e do alternador</li><li>Instalação no local e nota fiscal</li></ul></div></section>
<section class="awr-app-section"><div class="awr-hub-body">
	<h2 class="awr-app-section__title">Bateria de carro na sua cidade</h2>
	<ul class="awr-chips">
		<?php foreach ( (array) awr_cidades() as $c ) : ?>
			<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-em/' . $c['slug'] . '/' ) ); ?>">Bateria em <?php echo esc_html( $c['nome'] ); ?> · <?php echo esc_html( function_exists( 'awr_city_delivery_badge' ) ? awr_city_delivery_badge( $c ) : '' ); ?></a></li>
		<?php endforeach; ?>
	</ul>
</div></section>
<div class="awr-container">
<?php awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes — baterias de carro', 'itens' => $awr_faq_c ) ); ?>
</div>
<?php awr_part( 'prova-social' ); get_footer(); ?>
