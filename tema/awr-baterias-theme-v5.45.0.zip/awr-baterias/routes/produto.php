<?php
/**
 * Página de produto (WooCommerce) enxuta: apenas o produto e a descrição.
 * Sem paginação de páginas/posts, sem relacionados, upsell, abas ou avaliações.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$awr_pid = get_queried_object_id();
$awr_wc  = function_exists( 'wc_get_product' ) ? wc_get_product( $awr_pid ) : null;
if ( ! $awr_wc ) { get_template_part( '404' ); return; }

$sku = strtoupper( (string) $awr_wc->get_sku() );
$p   = $sku ? awr_product_by_sku( $sku ) : null;
if ( ! $p ) {
	$img = get_the_post_thumbnail_url( $awr_pid, 'medium_large' );
	$p   = array(
		'sku'       => $sku,
		'name'      => $awr_wc->get_name(),
		'price'     => (float) $awr_wc->get_price(),
		'image'     => $img ? $img : '',
		'permalink' => get_permalink( $awr_pid ),
		'amperagem' => awr_extract_amperage( $sku, $awr_wc->get_name() ),
		'brand'     => '',
	);
}
// v4.2.0 — resolve pela cadeia completa (índice, GTIN, taxonomia, nome, prefixo
// de fábrica), nunca só pelo catálogo automotivo, e nunca com a marca da loja.
$p['brand'] = trim( (string) ( $p['brand'] ?? '' ) );
if ( '' === $p['brand'] || 0 === stripos( $p['brand'], 'AWR' ) ) {
	$p['brand'] = awr_resolve_brand( $sku, $awr_wc->get_name(), $awr_wc );
}
$ah         = (int) ( $p['amperagem'] ?? 0 );

// Veículos compatíveis agrupados por marca (sem repetir faixas de ano item a item).
$compat = $sku ? awr_product_compat_grouped( $sku ) : array();
$faq    = $sku ? awr_product_faq( $sku, $p['name'], $p['brand'], $ah ) : array();

// Categoria WooCommerce para a trilha (mesma da trilha estruturada da loja).
$awr_cat_nome = '';
$awr_cat_url  = '';
$awr_terms    = get_the_terms( $awr_pid, 'product_cat' );
if ( $awr_terms && ! is_wp_error( $awr_terms ) ) {
	$awr_cat_nome = $awr_terms[0]->name;
	$awr_cat_url  = function_exists( 'awr_shop_url' ) ? awr_shop_url( $awr_terms[0]->slug, 1, '' ) : home_url( '/loja/' );
}

$descricao = apply_filters( 'the_content', $awr_wc->get_description() );
$resumo    = wp_strip_all_tags( (string) $awr_wc->get_short_description() );

get_header();
// Hooks do WooCommerce: extensões (Google for WooCommerce, pixels, etc.)
// injetam o código delas aqui.
if ( function_exists( 'awr_produto_hooks_woo' ) ) { awr_produto_hooks_woo( 'antes', $awr_wc ); }
$GLOBALS['awr_product_mobile_offer'] = array(
	'sku' => $p['sku'], 'nome' => $p['name'], 'price' => (float) $p['price'],
	'pid' => (int) ( $p['id'] ?? $awr_pid ), 'casco' => awr_valor_casco( $sku, $p['name'] ),
);
?>
<div class="awr-container awr-produto">
	<?php
	$awr_trilha = array( array( 'nome' => 'Loja', 'url' => home_url( '/loja/' ) ) );
	if ( $awr_cat_nome ) { $awr_trilha[] = array( 'nome' => $awr_cat_nome, 'url' => $awr_cat_url ); }
	awr_part( 'breadcrumb', array( 'trilha' => $awr_trilha, 'atual' => $awr_wc->get_name() ) );
	?>
	<section class="awr-product-offer" aria-label="Comprar bateria">
		<div class="awr-product-offer__media">
			<?php if ( ! empty( $p['image'] ) ) : ?><img src="<?php echo esc_url( $p['image'] ); ?>" alt="<?php echo esc_attr( $p['name'] ); ?>" width="600" height="600"><?php else : ?><span aria-hidden="true">🔋</span><?php endif; ?>
		</div>
		<div class="awr-product-offer__buy">
			<p class="awr-product-offer__stock">● Compatível · disponível</p>
			<?php $awr_h1_lote = function_exists( 'awr_seo_lote_h1' ) ? awr_seo_lote_h1() : ''; ?>
			<h1><?php echo esc_html( $awr_h1_lote ? $awr_h1_lote : awr_product_seo_name( $sku, $awr_wc->get_name(), $p['brand'], $ah ) . ' – Entrega e Instalação em Porto Alegre e Região' ); ?></h1>
			<p class="awr-product-offer__lead">Entrega e instalação em até 35 minutos em Porto Alegre e cidades vizinhas; veja abaixo o prazo de cada cidade.</p>
			<?php if ( $p['price'] ) : ?>
				<p class="awr-product-offer__label">Preço à vista</p>
				<p class="awr-product-offer__price"><?php echo esc_html( awr_brl( (float) $p['price'] ) ); ?></p>
				<p class="awr-product-offer__installment">10× <?php echo esc_html( awr_brl( (float) $p['price'] / 10 ) ); ?> sem juros</p>
				<p class="awr-product-offer__fine">Preço à vista válido com a devolução do casco (bateria usada) no ato da entrega.</p>
				<?php $awr_casco_v = (float) awr_valor_casco( $sku, $p['name'] ); if ( $awr_casco_v > 0 ) : ?>
					<p class="awr-product-offer__fine"><strong>Sem a bateria usada na troca:</strong> <?php echo esc_html( awr_brl( (float) $p['price'] + $awr_casco_v ) ); ?></p>
				<?php endif; ?>
			<?php else : ?><p class="awr-product-offer__price">Preço sob consulta</p><?php endif; ?>
			<ul class="awr-product-offer__benefits"><li>⏱ Instalação rápida</li><li>🛡 Garantia de fábrica</li><li>✓ Aplicação correta conforme a montadora</li><li>R$ Preço com e sem a bateria usada na troca</li></ul>
			<button type="button" class="awr-btn awr-btn--install awr-product-offer__cta" data-awr-checkout data-sku="<?php echo esc_attr( $p['sku'] ); ?>" data-nome="<?php echo esc_attr( $p['name'] ); ?>" data-preco="<?php echo esc_attr( $p['price'] ); ?>" data-pid="<?php echo esc_attr( $p['id'] ?? $awr_pid ); ?>" data-casco="<?php echo esc_attr( awr_valor_casco( $sku, $p['name'] ) ); ?>">⚡ Comprar agora com instalação</button>
			<a class="awr-product-offer__wa" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Quero comprar a bateria ' . $awr_wc->get_name() . ' com instalação grátis.' ) ); ?>">Falar no WhatsApp</a>
		</div>
	</section>

	<?php awr_part( 'ficha-tecnica', array( 'sku' => $sku ) ); ?>
	<?php awr_part( 'produto-seo', array( 'sku' => $sku, 'marca' => $p['brand'], 'ah' => $ah ) ); ?>

	<?php awr_part( 'searchband', array( 'tag' => 'Buscar outra bateria', 'nota' => 'Confirme outro veículo ou modelo sem sair desta página.' ) ); ?>

	<section class="awr-block awr-produto__info">
		<h2 class="awr-section-title">Por que escolher esta bateria?</h2>
		<div class="awr-produto__infogrid">
			<div>
				<h3>Receba e instale no local</h3>
				<p>Em Porto Alegre e nas cidades da cobertura própria: entrega com instalação grátis conforme o prazo local. Em Caxias do Sul e demais cidades de envio: transportadora com rastreio, sem instalação local.</p>
			</div>
			<div>
				<h3>Formas de pagamento</h3>
				<p>Pague apenas na entrega: Pix, crédito em até 10x sem juros ou débito. Fora das cidades atendidas, o pagamento é por Pix antecipado.</p>
			</div>
			<div>
				<h3>Teste gratuito, garantia e nota fiscal</h3>
				<p>Bateria nova com garantia de fábrica e nota fiscal em todos os pedidos. Teste de alternador grátis no momento da instalação.</p>
			</div>
		</div>
	</section>

	<section class="awr-block awr-produto__desc">
		<h2 class="awr-section-title">Descrição</h2>
		<div class="awr-prose">
			<p><strong>Bateria entregue e instalada em até 35 minutos.</strong> Peça de onde estiver e pague na entrega.</p>
			<?php
			$awr_desc_html = awr_product_desc_html( $awr_wc->get_description() ?: $awr_wc->get_short_description() );
			echo $awr_desc_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</div>
	</section>

	<?php if ( $compat ) : ?>
		<section class="awr-block awr-compat">
			<h2 class="awr-section-title">Descubra se a bateria <?php echo esc_html( $sku ); ?> serve no seu carro</h2>
			<?php awr_part( 'compat-marcas', array( 'grupos' => $compat ) ); ?>
		</section>
	<?php endif; ?>
	<?php awr_part( 'faq', array( 'titulo' => 'Perguntas sobre esta bateria', 'itens' => $faq ) ); ?>
	<?php $schema = awr_product_schema( $p, $awr_wc ); if ( $schema ) { awr_jsonld( $schema ); } ?>
	<?php awr_product_faq_schema( $faq ); ?>
</div>
<?php
if ( function_exists( 'awr_produto_hooks_woo' ) ) { awr_produto_hooks_woo( 'depois', $awr_wc ); }
get_footer();
?>
