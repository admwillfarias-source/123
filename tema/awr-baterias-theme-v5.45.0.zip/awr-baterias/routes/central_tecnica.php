<?php
/** /central-tecnica/ — hub de guias e ferramentas. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$awr_posts = (array) awr_posts_data();
$awr_cats  = array();
foreach ( $awr_posts as $p ) { $awr_cats[ $p['categoria'] ?? 'Guias' ][] = $p; }
?>
<main class="awr-app-section"><div class="awr-hub-body">
 <h1>Central Técnica AWR</h1>
 <p>A empresa que entende de baterias: guias e ferramentas para escolher, dimensionar e cuidar da sua bateria.</p>
 <h2>Ferramentas</h2>
 <p><a class="awr-btn" href="<?php echo esc_url( home_url( '/comparar/' ) ); ?>">Comparar baterias</a> <a class="awr-btn" href="<?php echo esc_url( home_url( '/baterias-estacionarias/#calculadora' ) ); ?>">Calculadora de banco de baterias</a> <a class="awr-btn" href="<?php echo esc_url( home_url( '/diagnostico/' ) ); ?>">Diagnóstico: carro não liga</a></p>
 <?php foreach ( $awr_cats as $cat => $lista ) : ?>
  <h2><?php echo esc_html( $cat ); ?></h2>
  <ul><?php foreach ( $lista as $p ) : ?><li><a href="<?php echo esc_url( home_url( '/blog/' . $p['slug'] . '/' ) ); ?>"><?php echo esc_html( $p['titulo'] ?? $p['slug'] ); ?></a></li><?php endforeach; ?></ul>
 <?php endforeach; ?>
</div></main>
<?php get_footer();
