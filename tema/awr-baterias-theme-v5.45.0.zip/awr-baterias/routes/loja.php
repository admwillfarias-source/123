<?php
/**
 * /lojas/{slug}/ — paridade 1:1 com src/routes/lojas.$slug.tsx do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$s = awr_store_by_slug( awr_param_a() );
if ( ! $s ) { get_template_part( '404' ); get_footer(); return; }

$g     = awr_place_data( $s );
$lat   = $g['lat'] ?: ( $s['geo']['lat'] ?? 0 );
$lng   = $g['lng'] ?: ( $s['geo']['lng'] ?? 0 );
$tel   = preg_replace( '/\D/', '', $g['phone'] ? $g['phone'] : $s['telefone'] );
$embed = awr_store_map_embed( $s, $g );
// Nota apenas quando o perfil desta unidade tiver avaliações próprias (a nota da
// operação inteira fica restrita à home — não é avaliação de loja individual).
$nota  = $g['rating'] ? number_format( (float) $g['rating'], 1, ',', '' ) : '';
$avl   = $g['reviews'] ? (int) $g['reviews'] : 0;
$maps  = awr_store_maps_link( $s, $g );
$horas = $g['hours'] ? (array) $g['hours'] : array_values( array_filter( array( $s['horarios']['semana'] ?? '', $s['horarios']['sabado'] ?? '' ) ) );
?>
<main class="awr-store">
	<div class="awr-container">
		<?php
		awr_part( 'hero', array(
			'eyebrow' => 'Loja AWR — ' . $s['cidade'] . '/' . $s['estado'],
			'h1'      => 'AWR Baterias — ' . $s['nome'],
			'h1_tag'  => 'h2',
			'lead'    => $s['enderecoCompleto'] . ' · Entrega e instalação de bateria no local, com nota fiscal e garantia de fábrica.',
			'badges'  => array( 'Atendimento na loja e no local', 'Teste de bateria e alternador grátis', 'Nota fiscal e garantia', 'Pix, débito e crédito em 10x' ),
			'wa'      => 'Olá! Quero atendimento na unidade ' . $s['nome'] . '.',
			'wa_label'=> 'Falar com a unidade',
			'trilha'  => array( array( 'nome' => 'Lojas', 'url' => home_url( '/lojas/' ) ) ),
			'atual'   => $s['nome'],
		) );
		?>

		<div class="awr-store__grid">
			<!-- Capa: foto + mapa da unidade -->
			<div class="awr-store__media">
				<?php
				$awr_foto = awr_store_cover( $s, $g, 1200 );
				?>
				<img class="awr-store__photo" src="<?php echo esc_url( $awr_foto ); ?>" width="1200" height="750" loading="lazy" decoding="async"
					onerror="this.onerror=null;this.src='<?php echo esc_url( get_theme_file_uri( 'assets/img/lojas/cover.jpg' ) ); ?>'"
					alt="Loja AWR Baterias <?php echo esc_attr( $s['nome'] . ' em ' . $s['cidade'] ); ?>">
			<div class="awr-store__cover">
				<?php if ( $embed ) : ?>
					<iframe src="<?php echo esc_url( $embed ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
						title="Mapa da loja AWR Baterias <?php echo esc_attr( $s['nome'] ); ?>"></iframe>
				<?php else : ?>
					<span class="awr-store__coverph" aria-hidden="true">📍</span>
				<?php endif; ?>
			</div>
			</div>

			<!-- Painel de informações -->
			<div class="awr-store__panel">
				<p class="awr-store__eyebrow"><?php echo esc_html( $s['cidade'] . '/' . $s['estado'] ); ?></p>
				<h1 class="awr-store__title">AWR Baterias — <?php echo esc_html( $s['nome'] ); ?></h1>
				<?php if ( $nota && $avl ) : ?>
					<p class="awr-store__rating"><span aria-hidden="true">★</span> <strong><?php echo esc_html( $nota ); ?></strong> <span>(<?php echo esc_html( number_format_i18n( $avl ) ); ?> avaliações no Google)</span></p>
				<?php endif; ?>

				<div class="awr-store__box">
					<p class="awr-store__addr"><span aria-hidden="true">📍</span> <?php echo esc_html( $s['enderecoCompleto'] ); ?></p>
					<a class="awr-store__maps" target="_blank" rel="noopener" href="<?php echo esc_url( $maps ); ?>">Traçar rota no Google Maps →</a>
				</div>

				<div class="awr-store__ctas">
					<a class="awr-btn awr-btn--gold awr-btn--xl" href="tel:<?php echo esc_attr( $tel ); ?>">
						<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2Z"/></svg>
						Ligar <?php echo esc_html( $s['telefone'] ); ?>
					</a>
					<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener"
						<?php
						$awr_wa_msg = "Olá! Vim pela página da loja {$s['nome']} ({$s['cidade']}) e preciso de uma bateria.";
						$awr_wa_num = ! empty( $s['whatsappNumber'] ) ? preg_replace( '/\D+/', '', $s['whatsappNumber'] ) : '';
						$awr_wa_url = $awr_wa_num ? 'https://wa.me/' . $awr_wa_num . '?text=' . rawurlencode( $awr_wa_msg ) : awr_wa( $awr_wa_msg );
						?>
						href="<?php echo esc_url( $awr_wa_url ); ?>">
						<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-12.6 7.3L3 21l2.2-5.3A8.4 8.4 0 1 1 21 11.5Z"/></svg>
						WhatsApp
					</a>
				</div>

				<div class="awr-store__box">
					<p class="awr-store__boxtitle"><span aria-hidden="true">🕒</span> Horário de funcionamento</p>
					<ul class="awr-store__hours">
						<?php foreach ( $horas as $h ) : ?>
							<li><?php echo esc_html( $h ); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
		</div>

		<div class="awr-store__box awr-store__cities">
			<h2 class="awr-store__h2">Cidades atendidas por esta loja</h2>
			<ul class="awr-chips">
				<?php foreach ( (array) $s['cidadesAtendidasSlugs'] as $i => $slug ) : ?>
					<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-em/' . $slug . '/' ) ); ?>"><?php echo esc_html( $s['cidadesAtendidas'][ $i ] ?? $slug ); ?></a></li>
				<?php endforeach; ?>
			</ul>
			<p class="awr-lead">Entrega e instalação profissional a partir de 35 minutos. Pagamento só depois de tudo pronto.</p>
		</div>

		<?php awr_part( 'search', array( 'titulo' => 'Ver preço da bateria do seu carro' ) ); ?>

		<p class="awr-store__back"><a href="<?php echo esc_url( home_url( '/lojas/' ) ); ?>">← Ver todas as lojas</a></p>
	</div>
</main>

<?php
$awr_store_schema = array(
	'@context'   => 'https://schema.org',
	'@type'      => 'AutoPartsStore',
	'@id'        => home_url( '/lojas/' . $s['slug'] . '/' ),
	'name'       => 'AWR Baterias — ' . $s['nome'],
	'url'        => home_url( '/lojas/' . $s['slug'] . '/' ),
	'telephone'  => $g['phone'] ? $g['phone'] : $s['telefone'],
	'image'      => awr_store_cover( $s, $g, 1200 ),
	'address'    => array(
		'@type'           => 'PostalAddress',
		'streetAddress'   => $s['endereco'],
		'addressLocality' => $s['cidade'],
		'addressRegion'   => $s['estado'],
		'addressCountry'  => 'BR',
	),
	'geo'        => array( '@type' => 'GeoCoordinates', 'latitude' => $lat, 'longitude' => $lng ),
	'areaServed' => array_values( (array) $s['cidadesAtendidas'] ),
);

// A nota agregada da operação (home) não pertence a cada unidade: só entra aqui
// quando o perfil desta loja no Google tiver avaliações próprias.
if ( ! empty( $g['rating'] ) && ! empty( $g['reviews'] ) ) {
	$awr_store_schema['aggregateRating'] = array(
		'@type'       => 'AggregateRating',
		'ratingValue' => (float) $g['rating'],
		'reviewCount' => (int) $g['reviews'],
	);
}

awr_jsonld( $awr_store_schema );
?>
<?php get_footer(); ?>
