<?php
/**
 * /baterias-porto-alegre/{zona}/ — zonas de Porto Alegre e Av. Protásio Alves.
 * Paridade com src/routes/baterias-porto-alegre.$zona.tsx. Dados: assets/data/zonas-poa.json.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$zona   = awr_zona_poa( awr_param_a() );
$cidade = awr_cidade_by_slug( 'porto-alegre' );
if ( ! $zona || ! $cidade ) { status_header( 404 ); get_header(); get_template_part( '404' ); get_footer(); return; }
get_header();

$loja = awr_loja_do_bairro( 'porto-alegre' );
$min  = ! empty( $cidade['tempoEntregaMin'] ) ? (int) $cidade['tempoEntregaMin'] : 35;
$onde = 'na ' . $zona['nome'];
?>
<main class="awr-lojas">
	<section class="awr-lojas__hero">
		<div class="awr-container">
			<p class="awr-breadcrumb">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Início</a> /
				<a href="<?php echo esc_url( home_url( '/baterias-em/porto-alegre/' ) ); ?>">Porto Alegre</a> /
				<span><?php echo esc_html( $zona['curto'] ); ?></span>
			</p>
			<h1 class="awr-lojas__title">Bateria <?php echo esc_html( $onde ); ?></h1>
			<p class="awr-lojas__subtitle">Entrega e instalação de bateria no local em até <?php echo (int) $min; ?> minutos. <?php echo esc_html( $zona['resumo'] ); ?></p>
		</div>
	</section>

<?php awr_part( 'searchband' ); ?>

	<section class="awr-lojas__grid-section">
		<div class="awr-container">
			<h2 class="awr-lojas__h2"><?php echo 'avenida' === $zona['tipo'] ? 'Bairros ao longo da Protásio Alves' : esc_html( 'Bairros atendidos ' . $onde ); ?></h2>
			<ul class="awr-chips">
				<?php foreach ( $zona['bairros'] as $b ) : ?>
					<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-bairro/porto-alegre/' . $b['slug'] . '/' ) ); ?>">Bateria no <?php echo esc_html( $b['nome'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>

			<h2 class="awr-lojas__h2">Como funciona o atendimento</h2>
			<ul class="awr-lead">
				<li>Você informa o carro e o endereço pelo WhatsApp ou telefone.</li>
				<li>O técnico leva a bateria, testa o sistema de carga e instala no local.</li>
				<li>Entrega em até <?php echo (int) $min; ?> minutos, plantão das 06:30 às 22h, inclusive feriados.</li>
				<li>Nota fiscal e garantia de fábrica; a bateria usada é recolhida.</li>
			</ul>

			<?php if ( $loja ) : ?>
				<p class="awr-lead">Loja responsável: <strong>AWR Baterias — <?php echo esc_html( $loja['nome'] ); ?></strong>, <?php echo esc_html( $loja['enderecoCompleto'] ); ?>.</p>
			<?php endif; ?>

			<h2 class="awr-lojas__h2">Outras regiões de Porto Alegre</h2>
			<ul class="awr-chips">
				<?php foreach ( (array) awr_data( 'zonas-poa' ) as $z ) : if ( $z['slug'] === $zona['slug'] ) { continue; } ?>
					<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-porto-alegre/' . $z['slug'] . '/' ) ); ?>"><?php echo esc_html( $z['curto'] ); ?></a></li>
				<?php endforeach; ?>
				<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-bairro/porto-alegre/' ) ); ?>">Todos os bairros</a></li>
			</ul>

			<?php awr_part( 'search', array( 'titulo' => 'Ver preço da bateria do seu carro' ) ); ?>
		</div>
	</section>
</main>
<?php
$items = array();
foreach ( $zona['bairros'] as $i => $b ) { $items[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $b['nome'], 'url' => home_url( '/baterias-bairro/porto-alegre/' . $b['slug'] . '/' ) ); }
awr_jsonld( array( '@context' => 'https://schema.org', '@type' => 'ItemList', 'name' => 'Bairros atendidos ' . $onde, 'itemListElement' => $items ) );
awr_jsonld( array(
	'@context'        => 'https://schema.org',
	'@type'           => 'BreadcrumbList',
	'itemListElement' => array(
		array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Início', 'item' => home_url( '/' ) ),
		array( '@type' => 'ListItem', 'position' => 2, 'name' => 'Bateria em Porto Alegre', 'item' => home_url( '/baterias-em/porto-alegre/' ) ),
		array( '@type' => 'ListItem', 'position' => 3, 'name' => $zona['curto'], 'item' => home_url( '/baterias-porto-alegre/' . $zona['slug'] . '/' ) ),
	),
) );
get_footer();
