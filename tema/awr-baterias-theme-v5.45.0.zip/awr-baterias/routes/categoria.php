<?php
/**
 * /categorias/{slug}/ — página de categoria/tecnologia (AGM, EFB, náutica…).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$cat = awr_categoria_seo_by_slug( awr_param_a() );
if ( ! $cat ) { get_template_part( '404' ); get_footer(); return; }

$wa     = awr_wa( $cat['waMsg'] );
$c      = awr_contact();
$outras = array_values( array_filter( awr_categorias_seo(), function ( $x ) use ( $cat ) { return $x['slug'] !== $cat['slug']; } ) );
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'trilha' => array( array( 'nome' => 'Categorias', 'url' => home_url( '/categorias/' ) ) ), 'atual' => $cat['h1'] ) ); ?>
		<h1 class="awr-hub-hero__title"><?php echo esc_html( $cat['h1'] ); ?></h1>
		<p class="awr-hub-hero__lead"><?php echo esc_html( $cat['subtitulo'] ); ?></p>

		<ul class="awr-cat-selos">
			<?php foreach ( (array) $cat['selos'] as $s ) : ?>
				<li><?php echo esc_html( $s ); ?></li>
			<?php endforeach; ?>
		</ul>

		<div class="awr-hub-cta__wa-wrap" style="margin-top:1.25rem;">
			<a class="awr-hub-cta__wa" target="_top" rel="noopener" href="<?php echo esc_url( $wa ); ?>">Pedir preço no WhatsApp</a>
			<a class="awr-btn awr-btn--navy awr-btn--xl" href="<?php echo esc_attr( $c['phone_href'] ); ?>">Ligar <?php echo esc_html( $c['phone'] ); ?></a>
		</div>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<div class="awr-hub-body awr-hub-body--narrow">
	<p><?php echo esc_html( $cat['intro'] ); ?></p>
</div>

<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Descubra a bateria certa para o seu veículo</h2>
		<?php awr_part( 'search' ); ?>
	</div>
</section>

<?php foreach ( (array) $cat['blocos'] as $b ) : ?>
	<section class="awr-app-section awr-app-section--muted">
		<div class="awr-hub-body awr-hub-body--narrow">
			<h2 class="awr-app-section__title"><?php echo esc_html( $b['h2'] ); ?></h2>
			<p><?php echo esc_html( $b['p'] ); ?></p>
		</div>
	</section>
<?php endforeach; ?>

<?php if ( ! empty( $cat['modelos'] ) ) : ?>
	<section class="awr-app-section">
		<div class="awr-hub-body">
			<h2 class="awr-app-section__title">Modelos que trabalhamos</h2>
			<ul class="awr-app-reco">
				<?php foreach ( (array) $cat['modelos'] as $m ) : ?>
					<li>
						<h3 class="awr-app-reco__modelo"><?php echo esc_html( $m['nome'] ); ?></h3>
						<p class="awr-app-reco__brand"><?php echo esc_html( $m['spec'] ); ?></p>
						<p class="awr-app-reco__ideal"><?php echo esc_html( $m['aplicacao'] ); ?></p>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Perguntas frequentes</h2>
		<div class="awr-app-faq">
			<?php foreach ( (array) $cat['faq'] as $f ) : ?>
				<details>
					<summary><?php echo esc_html( $f['p'] ); ?></summary>
					<p><?php echo esc_html( $f['r'] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php if ( $outras ) : ?>
	<section class="awr-app-section">
		<div class="awr-hub-body">
			<h2 class="awr-app-section__title">Veja também</h2>
			<ul class="awr-app-outras">
				<?php foreach ( $outras as $o ) : ?>
					<li>
						<a href="<?php echo esc_url( home_url( '/categorias/' . $o['slug'] . '/' ) ); ?>">
							<div>
								<h3><?php echo esc_html( $o['h1'] ); ?></h3>
								<p><?php echo esc_html( $o['subtitulo'] ); ?></p>
							</div>
							<span class="awr-app-outras__arrow" aria-hidden="true">→</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<?php awr_part( 'prova-social' ); ?>
<?php get_footer(); ?>
