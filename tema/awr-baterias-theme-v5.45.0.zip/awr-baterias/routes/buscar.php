<?php
/**
 * /buscar/ — resultados de busca (server-side, com hidratação pelo JS).
 * Paridade 1:1 com o bloco de resultados do BatterySearch do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$veiculo  = sanitize_title( (string) get_query_var( 'veiculo' ) );
$ano      = (int) get_query_var( 'ano' );
$q        = sanitize_text_field( (string) get_query_var( 'q' ) );
$items    = $veiculo ? awr_vehicle_by_slug( $veiculo, $ano ) : array();
$produtos = $items ? awr_products_by_skus( awr_skus_from_items( $items ) ) : array();
$marca    = $items ? $items[0]['ma'] : '';
$modelo   = $items ? $items[0]['mo'] : '';
$titulo   = $items ? trim( $marca . ' ' . $modelo . ( $ano ? " {$ano}" : '' ) ) : '';
?>
<div class="awr-container awr-buscar">
	<?php
	awr_part( 'hero', array(
		'eyebrow' => $titulo ? 'Baterias compatíveis' : 'Busca de baterias',
		'h1'      => $titulo ? "Baterias para {$titulo}" : 'Buscar bateria pelo modelo do veículo',
		'lead'    => $titulo
			? 'Preço final com instalação grátis no local, em até 35 minutos em Porto Alegre e Grande Porto Alegre.'
			: 'Informe o veículo, o código da bateria ou a amperagem e veja na hora o modelo certo, o preço atualizado e o prazo de entrega.',
		'wa'      => $titulo ? "Olá! Preciso da bateria do meu {$titulo}. Podem me passar o preço?" : 'Olá! Preciso de ajuda para encontrar a bateria certa do meu veículo.',
		'wa_label'=> 'Falar com um atendente',
		'atual'   => $titulo ? "Baterias para {$titulo}" : 'Buscar bateria',
	) );
	?>

	<?php awr_part( 'search', array( 'autofocus' => ! $titulo ) ); ?>

	<?php if ( $titulo ) : ?>
		<section class="awr-results awr-results--static" aria-label="Baterias compatíveis">
			<div class="awr-results__head">
				<div class="awr-results__headtext">
					<span class="awr-results__badge"><i aria-hidden="true"></i>Compatíveis • em estoque</span>
					<h2 class="awr-results__title">Baterias recomendadas <small><?php echo esc_html( $titulo ); ?></small></h2>
				</div>
				<a class="awr-results__reset" href="<?php echo esc_url( home_url( '/buscar/' ) ); ?>">
					<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>
					Trocar veículo
				</a>
			</div>

			<?php if ( $produtos ) : ?>
				<div class="awr-cards">
					<?php foreach ( $produtos as $p ) { awr_part( 'card-bateria', array( 'produto' => $p, 'veiculo' => $titulo ) ); } ?>
				</div>
			<?php else : ?>
				<div class="awr-results__empty">
					<p>Não conseguimos carregar os preços agora para <b><?php echo esc_html( $titulo ); ?></b>. Fale com a gente — respondemos em 2 minutos com o preço e a entrega.</p>
					<a class="awr-btn awr-btn--green" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( "Olá! Preciso da bateria do meu {$titulo}. Podem me passar o preço e a entrega?" ) ); ?>">Falar no WhatsApp agora</a>
				</div>
			<?php endif; ?>
		</section>
	<?php endif; ?>
	<?php if ( $titulo ) { awr_product_item_list_schema( $produtos, 'Baterias recomendadas para ' . $titulo ); } ?>
</div>

<?php awr_part( 'como-funciona' ); ?>
<?php get_footer(); ?>
