<?php
/**
 * /marca/{marca}/
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$m = awr_marca_by_slug( awr_param_a() );
if ( ! $m ) { get_template_part( '404' ); get_footer(); return; }

$awr_c   = awr_company();
$outras  = array_values( array_filter( awr_marcas(), function ( $it ) use ( $m ) { return $it['slug'] !== $m['slug']; } ) );
$wa_msg  = 'Olá! Quero comprar uma bateria ' . $m['nome'] . '. Pode me passar o preço?';
$carros  = array();
foreach ( (array) ( $m['modelosPopulares'] ?? array() ) as $mp ) {
	foreach ( (array) ( $mp['carrosCompatveis'] ?? array() ) as $car ) {
		if ( ! in_array( $car, $carros, true ) ) { $carros[] = $car; }
	}
}
$carros = array_slice( $carros, 0, 12 );
?>
<div class="awrm-page">
	<section class="awrm-hero">
		<div class="awrm-container">
			<?php awr_part( 'breadcrumb', array( 'trilha' => array( array( 'nome' => 'Marcas', 'url' => home_url( '/marca/' ) ) ), 'atual' => $m['nome'] ) ); ?>

			<span class="awrm-hero__badge">Revendedor autorizado</span>
			<h1 class="awrm-hero__title"><?php echo esc_html( $m['h1'] ?? ( 'Bateria ' . $m['nome'] ) ); ?></h1>
			<p class="awrm-hero__tagline"><?php echo esc_html( $m['tagline'] ?? '' ); ?></p>

			<div class="awrm-hero__ctas">
				<a class="awrm-btn awrm-btn--wa" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $wa_msg ) ); ?>">Pedir preço no WhatsApp</a>
				<a class="awrm-btn awrm-btn--light" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">Ligar agora</a>
			</div>
		</div>
	</section>

<?php awr_part( 'searchband' ); ?>


	<?php if ( ! empty( $m['introParagrafos'] ) ) : ?>
		<section class="awrm-section">
			<div class="awrm-container awrm-container--narrow">
				<?php foreach ( (array) $m['introParagrafos'] as $par ) : ?>
					<p class="awrm-p"><?php echo esc_html( $par ); ?></p>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( ! empty( $m['beneficios'] ) ) : ?>
		<section class="awrm-section awrm-section--muted">
			<div class="awrm-container">
				<h2 class="awrm-h2">Por que escolher <?php echo esc_html( $m['nomeCompleto'] ?? $m['nome'] ); ?></h2>
				<ul class="awrm-benefits">
					<?php foreach ( $m['beneficios'] as $b ) : ?>
						<li class="awrm-benefit-card">
							<span class="awrm-benefit-card__icon" aria-hidden="true">✓</span>
							<h3 class="awrm-benefit-card__title"><?php echo esc_html( $b['titulo'] ); ?></h3>
							<p class="awrm-benefit-card__desc"><?php echo esc_html( $b['descricao'] ); ?></p>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( ! empty( $m['modelosPopulares'] ) ) : ?>
		<section class="awrm-section">
			<div class="awrm-container">
				<h2 class="awrm-h2">Modelos <?php echo esc_html( $m['nome'] ); ?> mais vendidos</h2>
				<div class="awrm-table-wrap">
					<table class="awrm-table">
						<thead>
							<tr>
								<th>Modelo</th>
								<th>Amperagem</th>
								<th>Carros compatíveis</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $m['modelosPopulares'] as $mp ) : ?>
								<tr>
									<td class="awrm-table__linha"><?php echo esc_html( $mp['linha'] ); ?></td>
									<td><?php echo esc_html( $mp['amperagem'] ); ?></td>
									<td><?php echo esc_html( implode( ', ', (array) $mp['carrosCompatveis'] ) ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>

				<?php if ( $carros ) : ?>
					<p class="awrm-p awrm-p--small">
						A linha <?php echo esc_html( $m['nomeCompleto'] ?? $m['nome'] ); ?> é compatível com <?php echo esc_html( implode( ', ', $carros ) ); ?>
						e outros modelos. Não achou seu carro? Mande a placa ou o modelo/ano no WhatsApp — confirmamos a amperagem exata antes de sair para a entrega.
					</p>
				<?php endif; ?>

				<?php if ( ! empty( $m['posicionamento'] ) ) : ?>
					<p class="awrm-meta-line"><strong>Posicionamento:</strong> <?php echo esc_html( $m['posicionamento'] ); ?></p>
				<?php endif; ?>
				<?php if ( ! empty( $m['ondeEUsada'] ) ) : ?>
					<p class="awrm-meta-line">
						<strong>Ideal para:</strong>
						<?php foreach ( (array) $m['ondeEUsada'] as $u ) : ?>
							<span class="awrm-pill"><?php echo esc_html( $u ); ?></span>
						<?php endforeach; ?>
					</p>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( ! empty( $m['linhas'] ) ) : ?>
		<section class="awrm-section">
			<div class="awrm-container">
				<h2 class="awrm-h2">Linhas <?php echo esc_html( $m['nome'] ); ?>: qual serve para você</h2>
				<div class="awrm-table-wrap">
					<table class="awrm-table">
						<thead>
							<tr>
								<th>Linha</th>
								<th>Indicada para</th>
								<th>Amperagens</th>
								<th>Por que escolher</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( (array) $m['linhas'] as $ln ) : ?>
								<tr>
									<td class="awrm-table__linha"><?php echo esc_html( $ln['nome'] ); ?></td>
									<td><?php echo esc_html( $ln['uso'] ); ?></td>
									<td><?php echo esc_html( $ln['amperagens'] ); ?></td>
									<td><?php echo esc_html( $ln['destaque'] ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<p class="awrm-p awrm-p--small">Não sabe qual linha o seu veículo usa? Mande a placa ou o modelo/ano no WhatsApp — confirmamos a amperagem e o preço antes de sair para a entrega.</p>
			</div>
		</section>
	<?php endif; ?>


	<?php
	$awrm_vp = array(); $awrm_ah = array();
	foreach ( (array) awr_data( 'veiculos-prioritarios' ) as $vp ) {
		$vm = awr_vc_model( $vp['slug'] );
		if ( ! $vm ) { continue; }
		$sk = array();
		foreach ( awr_vc_skus( $vm ) as $s ) {
			if ( $s['brand'] !== $m['nome'] ) { continue; }
			$sk[] = $s['sku'];
			$ah = awr_extract_amperage( $s['sku'] );
			if ( $ah ) { $awrm_ah[ (int) $ah ] = (int) $ah; }
		}
		if ( $sk ) { $awrm_vp[] = array( 'slug' => $vp['slug'], 'nome' => $vp['nome'], 'skus' => array_values( array_unique( $sk ) ) ); }
	}
	sort( $awrm_ah );
	?>
	<?php if ( $awrm_vp ) : ?>
	<section class="awrm-section awrm-carros">
		<div class="awrm-container">
			<h2 class="awrm-h2">Bateria <?php echo esc_html( $m['nome'] ); ?> para os carros mais buscados</h2>
			<p class="awrm-p awrm-p--lead">Modelos <?php echo esc_html( $m['nome'] ); ?> indicados no catálogo de compatibilidade para cada veículo. Abra a página do carro para ver a versão e o ano.</p>
			<ul class="awrm-city-grid">
				<?php foreach ( $awrm_vp as $vp ) : ?>
					<li><a class="awrm-city-chip" href="<?php echo esc_url( awr_vc_url( $vp['slug'] ) ); ?>">
						<span>Bateria <?php echo esc_html( $m['nome'] . ' para ' . $vp['nome'] ); ?><small style="display:block;font-weight:500"><?php echo esc_html( implode( ' · ', $vp['skus'] ) ); ?></small></span>
						<span class="awrm-city-chip__arrow" aria-hidden="true">→</span>
					</a></li>
				<?php endforeach; ?>
			</ul>
			<?php if ( $awrm_ah ) : ?>
				<h3 class="awrm-h3">Bateria <?php echo esc_html( $m['nome'] ); ?> por amperagem</h3>
				<ul class="awrm-carros__list">
					<?php foreach ( $awrm_ah as $ah ) : ?>
						<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias/amperagem/' . $ah . '/' ) ); ?>">Bateria <?php echo (int) $ah; ?>Ah</a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php if ( ! empty( $m['cidadePages'] ) ) : ?>
	<section class="awrm-section awrm-section--muted">
		<div class="awrm-container">
			<h2 class="awrm-h2"><?php echo esc_html( $m['nomeCompleto'] ?? $m['nome'] ); ?> nas cidades atendidas</h2>
			<p class="awrm-p awrm-p--lead">
				Entregamos e instalamos <?php echo esc_html( $m['nomeCompleto'] ?? $m['nome'] ); ?> em toda a região metropolitana de Porto Alegre. Veja a cidade mais próxima de você:
			</p>
			<ul class="awrm-city-grid">
				<?php foreach ( awr_cidades() as $c ) : ?>
					<li>
						<a class="awrm-city-chip" href="<?php echo esc_url( home_url( '/bateria/' . $m['slug'] . '/' . $c['slug'] . '/' ) ); ?>">
							<span>Bateria <?php echo esc_html( $m['nome'] ); ?> em <?php echo esc_html( $c['nome'] ); ?></span>
							<span class="awrm-city-chip__arrow" aria-hidden="true">→</span>
						</a>
					</li>
				<?php endforeach; ?>
				<?php foreach ( awr_marca_cidades_envio() as $awr_ce ) :
					$cv = awr_cidade_venda_by_slug( $awr_ce );
					if ( ! $cv ) { continue; }
					?>
					<li>
						<a class="awrm-city-chip" href="<?php echo esc_url( home_url( '/bateria/' . $m['slug'] . '/' . $cv['slug'] . '/' ) ); ?>">
							<span>Bateria <?php echo esc_html( $m['nome'] ); ?> em <?php echo esc_html( $cv['nome'] ); ?></span>
							<span class="awrm-city-chip__arrow" aria-hidden="true">→</span>
						</a>
					</li>
					<li>
						<a class="awrm-city-chip" href="<?php echo esc_url( home_url( '/baterias-em/' . $cv['slug'] . '/' ) ); ?>">
							<span>Todas as baterias em <?php echo esc_html( $cv['nome'] ); ?> (envio com rastreio)</span>
							<span class="awrm-city-chip__arrow" aria-hidden="true">→</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>

		</div>
	</section>
	<?php endif; ?>

	<section class="awrm-container awrm-container--narrow awrm-cta-wrap">
		<div class="awrm-cta">
			<h3 class="awrm-cta__title">Fale agora com a AWR Baterias</h3>
			<p class="awrm-cta__text">Atendimento rápido em Porto Alegre e região — preço na hora, entrega e instalação no local.</p>
			<div class="awrm-hero__ctas">
				<a class="awrm-btn awrm-btn--wa" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $wa_msg ) ); ?>">Pedir no WhatsApp</a>
				<a class="awrm-btn awrm-btn--outline" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">Ligar agora</a>
			</div>
		</div>
	</section>

	<?php
	$awrm_faq_itens = array();
	foreach ( (array) ( $m['faq'] ?? array() ) as $f ) {
		$awrm_faq_itens[] = array( 'q' => $f['pergunta'], 'r' => $f['resposta'] );
	}
	awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes sobre ' . $m['nome'], 'itens' => $awrm_faq_itens ) );
	?>

	<?php if ( $outras ) : ?>
		<section class="awrm-section awrm-section--muted">
			<div class="awrm-container">
				<h2 class="awrm-h2 awrm-h2--sm">Compare com outras marcas</h2>
				<ul class="awrm-compare-grid">
					<?php foreach ( $outras as $o ) : ?>
						<li>
							<a class="awrm-compare-card" href="<?php echo esc_url( home_url( '/marca/' . $o['slug'] . '/' ) ); ?>">
								<div>
									<h3 class="awrm-compare-card__title"><?php echo esc_html( $o['nomeCompleto'] ?? $o['nome'] ); ?></h3>
									<p class="awrm-compare-card__tagline"><?php echo esc_html( $o['tagline'] ?? '' ); ?></p>
									<p class="awrm-compare-card__meta"><?php echo esc_html( implode( ' · ', array_filter( array( $o['faixaPreco'] ?? '', ! empty( $o['garantiaMeses'] ) ? $o['garantiaMeses'] . ' meses' : '' ) ) ) ); ?></p>
								</div>
								<span class="awrm-compare-card__arrow" aria-hidden="true">→</span>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</section>
	<?php endif; ?>

	<div class="awrm-container">
		<?php awr_blog_guias_bloco( 'Guias sobre bateria ' . $m['nome'], awr_blog_chips_por( 'porMarca', $m['slug'] ) ); ?>
		<?php awr_part( 'links-internos', array( 'tipo' => 'marca', 'slug' => $m['slug'] ) ); ?>
	</div>
</div>
<?php get_footer(); ?>
