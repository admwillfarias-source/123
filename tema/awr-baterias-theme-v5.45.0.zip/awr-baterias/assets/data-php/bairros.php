<?php
/** Gerado de assets/data/bairros.json — não editar. */
return array(
	array(
		'cidadeSlug' => 'porto-alegre',
		'bairros' => array(
			array(
				'slug' => 'centro-historico',
				'nome' => 'Centro Histórico',
			),
			array(
				'slug' => 'cidade-baixa',
				'nome' => 'Cidade Baixa',
			),
			array(
				'slug' => 'bom-fim',
				'nome' => 'Bom Fim',
			),
			array(
				'slug' => 'farroupilha',
				'nome' => 'Farroupilha',
			),
			array(
				'slug' => 'independencia',
				'nome' => 'Independência',
			),
			array(
				'slug' => 'moinhos-de-vento',
				'nome' => 'Moinhos de Vento',
			),
			array(
				'slug' => 'auxiliadora',
				'nome' => 'Auxiliadora',
			),
			array(
				'slug' => 'montserrat',
				'nome' => 'Mont\'Serrat',
			),
			array(
				'slug' => 'rio-branco',
				'nome' => 'Rio Branco',
			),
			array(
				'slug' => 'petropolis',
				'nome' => 'Petrópolis',
			),
			array(
				'slug' => 'bela-vista',
				'nome' => 'Bela Vista',
			),
			array(
				'slug' => 'santana',
				'nome' => 'Santana',
			),
			array(
				'slug' => 'santa-cecilia',
				'nome' => 'Santa Cecília',
			),
			array(
				'slug' => 'azenha',
				'nome' => 'Azenha',
			),
			array(
				'slug' => 'menino-deus',
				'nome' => 'Menino Deus',
			),
			array(
				'slug' => 'praia-de-belas',
				'nome' => 'Praia de Belas',
			),
			array(
				'slug' => 'cristal',
				'nome' => 'Cristal',
			),
			array(
				'slug' => 'camaqua',
				'nome' => 'Camaquã',
			),
			array(
				'slug' => 'nonoai',
				'nome' => 'Nonoai',
			),
			array(
				'slug' => 'teresopolis',
				'nome' => 'Teresópolis',
			),
			array(
				'slug' => 'medianeira',
				'nome' => 'Medianeira',
			),
			array(
				'slug' => 'gloria',
				'nome' => 'Glória',
			),
			array(
				'slug' => 'partenon',
				'nome' => 'Partenon',
			),
			array(
				'slug' => 'santo-antonio',
				'nome' => 'Santo Antônio',
			),
			array(
				'slug' => 'jardim-botanico',
				'nome' => 'Jardim Botânico',
			),
			array(
				'slug' => 'vila-jardim',
				'nome' => 'Vila Jardim',
			),
			array(
				'slug' => 'higienopolis',
				'nome' => 'Higienópolis',
			),
			array(
				'slug' => 'sao-joao',
				'nome' => 'São João',
			),
			array(
				'slug' => 'navegantes',
				'nome' => 'Navegantes',
			),
			array(
				'slug' => 'humaita',
				'nome' => 'Humaitá',
			),
			array(
				'slug' => 'sarandi',
				'nome' => 'Sarandi',
			),
			array(
				'slug' => 'passo-das-pedras',
				'nome' => 'Passo das Pedras',
			),
			array(
				'slug' => 'rubem-berta',
				'nome' => 'Rubem Berta',
			),
			array(
				'slug' => 'jardim-itu',
				'nome' => 'Jardim Itu',
			),
			array(
				'slug' => 'cavalhada',
				'nome' => 'Cavalhada',
			),
			array(
				'slug' => 'tristeza',
				'nome' => 'Tristeza',
			),
			array(
				'slug' => 'ipanema',
				'nome' => 'Ipanema',
			),
			array(
				'slug' => 'vila-assuncao',
				'nome' => 'Vila Assunção',
			),
			array(
				'slug' => 'espirito-santo',
				'nome' => 'Espírito Santo',
			),
			array(
				'slug' => 'belem-novo',
				'nome' => 'Belém Novo',
			),
			array(
				'slug' => 'restinga',
				'nome' => 'Restinga',
			),
			array(
				'slug' => 'jardim-lindoia',
				'nome' => 'Jardim Lindóia',
			),
			array(
				'slug' => 'boa-vista',
				'nome' => 'Boa Vista',
			),
			array(
				'slug' => 'chacara-das-pedras',
				'nome' => 'Chácara das Pedras',
			),
			array(
				'slug' => 'tres-figueiras',
				'nome' => 'Três Figueiras',
			),
			array(
				'slug' => 'vila-ipiranga',
				'nome' => 'Vila Ipiranga',
			),
			array(
				'slug' => 'jardim-carvalho',
				'nome' => 'Jardim Carvalho',
			),
			array(
				'slug' => 'lomba-do-pinheiro',
				'nome' => 'Lomba do Pinheiro',
			),
		),
	),
	array(
		'cidadeSlug' => 'canoas',
		'bairros' => array(
			array(
				'slug' => 'centro',
				'nome' => 'Centro',
			),
			array(
				'slug' => 'fatima',
				'nome' => 'Fátima',
			),
			array(
				'slug' => 'niteroi',
				'nome' => 'Niterói',
			),
			array(
				'slug' => 'marechal-rondon',
				'nome' => 'Marechal Rondon',
			),
			array(
				'slug' => 'igara',
				'nome' => 'Igara',
			),
			array(
				'slug' => 'mathias-velho',
				'nome' => 'Mathias Velho',
			),
			array(
				'slug' => 'harmonia',
				'nome' => 'Harmonia',
			),
			array(
				'slug' => 'sao-luis',
				'nome' => 'São Luís',
			),
			array(
				'slug' => 'guajuviras',
				'nome' => 'Guajuviras',
			),
			array(
				'slug' => 'olaria',
				'nome' => 'Olaria',
			),
			array(
				'slug' => 'nossa-senhora-das-gracas',
				'nome' => 'Nossa Senhora das Graças',
			),
			array(
				'slug' => 'rio-branco',
				'nome' => 'Rio Branco',
			),
			array(
				'slug' => 'industrial',
				'nome' => 'Industrial',
			),
			array(
				'slug' => 'sao-jose',
				'nome' => 'São José',
			),
			array(
				'slug' => 'estancia-velha',
				'nome' => 'Estância Velha',
			),
			array(
				'slug' => 'brigadeira',
				'nome' => 'Brigadeira',
			),
		),
	),
	array(
		'cidadeSlug' => 'gravatai',
		'bairros' => array(
			array(
				'slug' => 'centro',
				'nome' => 'Centro',
			),
			array(
				'slug' => 'bom-principio',
				'nome' => 'Bom Princípio',
			),
			array(
				'slug' => 'parque-dos-anjos',
				'nome' => 'Parque dos Anjos',
			),
			array(
				'slug' => 'barnabe',
				'nome' => 'Barnabé',
			),
			array(
				'slug' => 'sao-vicente',
				'nome' => 'São Vicente',
			),
			array(
				'slug' => 'cohab-b',
				'nome' => 'Cohab B',
			),
			array(
				'slug' => 'salgado-filho',
				'nome' => 'Salgado Filho',
			),
			array(
				'slug' => 'neopolis',
				'nome' => 'Neópolis',
			),
			array(
				'slug' => 'ipiranga',
				'nome' => 'Ipiranga',
			),
			array(
				'slug' => 'morada-do-vale',
				'nome' => 'Morada do Vale',
			),
			array(
				'slug' => 'vila-branca',
				'nome' => 'Vila Branca',
			),
			array(
				'slug' => 'passo-das-pedras',
				'nome' => 'Passo das Pedras',
			),
			array(
				'slug' => 'santa-fe',
				'nome' => 'Santa Fé',
			),
			array(
				'slug' => 'jardim-do-cedro',
				'nome' => 'Jardim do Cedro',
			),
			array(
				'slug' => 'parque-florido',
				'nome' => 'Parque Florido',
			),
		),
	),
	array(
		'cidadeSlug' => 'sao-leopoldo',
		'bairros' => array(
			array(
				'slug' => 'centro',
				'nome' => 'Centro',
			),
			array(
				'slug' => 'sao-jose',
				'nome' => 'São José',
			),
			array(
				'slug' => 'rio-dos-sinos',
				'nome' => 'Rio dos Sinos',
			),
			array(
				'slug' => 'cristo-rei',
				'nome' => 'Cristo Rei',
			),
			array(
				'slug' => 'feitoria',
				'nome' => 'Feitoria',
			),
			array(
				'slug' => 'campina',
				'nome' => 'Campina',
			),
			array(
				'slug' => 'scharlau',
				'nome' => 'Scharlau',
			),
			array(
				'slug' => 'boa-vista',
				'nome' => 'Boa Vista',
			),
			array(
				'slug' => 'vicentina',
				'nome' => 'Vicentina',
			),
			array(
				'slug' => 'fiao',
				'nome' => 'Fião',
			),
			array(
				'slug' => 'padre-reus',
				'nome' => 'Padre Reus',
			),
			array(
				'slug' => 'santos-dumont',
				'nome' => 'Santos Dumont',
			),
			array(
				'slug' => 'arroio-da-manteiga',
				'nome' => 'Arroio da Manteiga',
			),
			array(
				'slug' => 'duque-de-caxias',
				'nome' => 'Duque de Caxias',
			),
			array(
				'slug' => 'jardim-america',
				'nome' => 'Jardim América',
			),
			array(
				'slug' => 'pinheiro',
				'nome' => 'Pinheiro',
			),
		),
	),
	array(
		'cidadeSlug' => 'novo-hamburgo',
		'bairros' => array(
			array(
				'slug' => 'centro',
				'nome' => 'Centro',
			),
			array(
				'slug' => 'hamburgo-velho',
				'nome' => 'Hamburgo Velho',
			),
			array(
				'slug' => 'rondonia',
				'nome' => 'Rondônia',
			),
			array(
				'slug' => 'canudos',
				'nome' => 'Canudos',
			),
			array(
				'slug' => 'rio-branco',
				'nome' => 'Rio Branco',
			),
			array(
				'slug' => 'ideal',
				'nome' => 'Ideal',
			),
			array(
				'slug' => 'primavera',
				'nome' => 'Primavera',
			),
			array(
				'slug' => 'santo-afonso',
				'nome' => 'Santo Afonso',
			),
			array(
				'slug' => 'vila-nova',
				'nome' => 'Vila Nova',
			),
			array(
				'slug' => 'guarani',
				'nome' => 'Guarani',
			),
			array(
				'slug' => 'operario',
				'nome' => 'Operário',
			),
			array(
				'slug' => 'industrial',
				'nome' => 'Industrial',
			),
			array(
				'slug' => 'boa-saude',
				'nome' => 'Boa Saúde',
			),
			array(
				'slug' => 'sao-jose',
				'nome' => 'São José',
			),
			array(
				'slug' => 'liberdade',
				'nome' => 'Liberdade',
			),
			array(
				'slug' => 'roselandia',
				'nome' => 'Roselândia',
			),
			array(
				'slug' => 'lomba-grande',
				'nome' => 'Lomba Grande',
			),
			array(
				'slug' => 'petropolis',
				'nome' => 'Petrópolis',
			),
			array(
				'slug' => 'diehl',
				'nome' => 'Diehl',
			),
			array(
				'slug' => 'patria-nova',
				'nome' => 'Pátria Nova',
			),
		),
	),
	array(
		'cidadeSlug' => 'campo-bom',
		'bairros' => array(
			array(
				'slug' => 'centro',
				'nome' => 'Centro',
			),
			array(
				'slug' => 'sao-jose',
				'nome' => 'São José',
			),
			array(
				'slug' => 'imigrante',
				'nome' => 'Imigrante',
			),
			array(
				'slug' => 'genecir',
				'nome' => 'Genecir',
			),
			array(
				'slug' => 'santa-lucia',
				'nome' => 'Santa Lúcia',
			),
			array(
				'slug' => 'bom-pastor',
				'nome' => 'Bom Pastor',
			),
			array(
				'slug' => 'wallau',
				'nome' => 'Wallau',
			),
			array(
				'slug' => 'batista-ely',
				'nome' => 'Batista Ely',
			),
			array(
				'slug' => 'sete-de-setembro',
				'nome' => 'Sete de Setembro',
			),
			array(
				'slug' => 'jardim-america',
				'nome' => 'Jardim América',
			),
			array(
				'slug' => 'rincao',
				'nome' => 'Rincão',
			),
		),
	),
	array(
		'cidadeSlug' => 'viamao',
		'bairros' => array(
			array(
				'slug' => 'centro',
				'nome' => 'Centro',
			),
			array(
				'slug' => 'taruma',
				'nome' => 'Tarumã',
			),
			array(
				'slug' => 'augusta',
				'nome' => 'Augusta',
			),
			array(
				'slug' => 'santa-cecilia',
				'nome' => 'Santa Cecília',
			),
			array(
				'slug' => 'jardim-krahe',
				'nome' => 'Jardim Krahe',
			),
			array(
				'slug' => 'vila-augusta',
				'nome' => 'Vila Augusta',
			),
			array(
				'slug' => 'itapua',
				'nome' => 'Itapuã',
			),
			array(
				'slug' => 'viamopolis',
				'nome' => 'Viamópolis',
			),
			array(
				'slug' => 'espirito-santo',
				'nome' => 'Espírito Santo',
			),
			array(
				'slug' => 'aguas-claras',
				'nome' => 'Águas Claras',
			),
			array(
				'slug' => 'passo-do-sabao',
				'nome' => 'Passo do Sabão',
			),
			array(
				'slug' => 'jardim-universitario',
				'nome' => 'Jardim Universitário',
			),
			array(
				'slug' => 'santa-isabel',
				'nome' => 'Santa Isabel',
			),
			array(
				'slug' => 'cantegril',
				'nome' => 'Cantegril',
			),
			array(
				'slug' => 'sitio-grande',
				'nome' => 'Sítio Grande',
			),
		),
	),
	array(
		'cidadeSlug' => 'alvorada',
		'bairros' => array(
			array(
				'slug' => 'centro',
				'nome' => 'Centro',
			),
			array(
				'slug' => 'bela-vista',
				'nome' => 'Bela Vista',
			),
			array(
				'slug' => 'maringa',
				'nome' => 'Maringá',
			),
			array(
				'slug' => 'algarve',
				'nome' => 'Algarve',
			),
			array(
				'slug' => 'sumare',
				'nome' => 'Sumaré',
			),
			array(
				'slug' => 'jardim-algarve',
				'nome' => 'Jardim Algarve',
			),
			array(
				'slug' => 'formoza',
				'nome' => 'Formoza',
			),
			array(
				'slug' => 'piratini',
				'nome' => 'Piratini',
			),
			array(
				'slug' => 'americana',
				'nome' => 'Americana',
			),
			array(
				'slug' => 'umbu',
				'nome' => 'Umbu',
			),
			array(
				'slug' => 'nova-alvorada',
				'nome' => 'Nova Alvorada',
			),
			array(
				'slug' => 'intersul',
				'nome' => 'Intersul',
			),
			array(
				'slug' => 'salome',
				'nome' => 'Salomé',
			),
			array(
				'slug' => 'campos-verdes',
				'nome' => 'Campos Verdes',
			),
			array(
				'slug' => 'sao-jorge',
				'nome' => 'São Jorge',
			),
		),
	),
	array(
		'cidadeSlug' => 'esteio',
		'bairros' => array(
			array(
				'slug' => 'centro',
				'nome' => 'Centro',
			),
			array(
				'slug' => 'olimpica',
				'nome' => 'Olímpica',
			),
			array(
				'slug' => 'parque-amador',
				'nome' => 'Parque Amador',
			),
			array(
				'slug' => 'tamandare',
				'nome' => 'Tamandaré',
			),
			array(
				'slug' => 'liberdade',
				'nome' => 'Liberdade',
			),
			array(
				'slug' => 'novo-esteio',
				'nome' => 'Novo Esteio',
			),
			array(
				'slug' => 'primavera',
				'nome' => 'Primavera',
			),
			array(
				'slug' => 'centenario',
				'nome' => 'Centenário',
			),
			array(
				'slug' => 'jardim-planalto',
				'nome' => 'Jardim Planalto',
			),
			array(
				'slug' => 'tres-portos',
				'nome' => 'Três Portos',
			),
			array(
				'slug' => 'vila-rica',
				'nome' => 'Vila Rica',
			),
		),
	),
	array(
		'cidadeSlug' => 'cachoeirinha',
		'bairros' => array(
			array(
				'slug' => 'centro',
				'nome' => 'Centro',
			),
			array(
				'slug' => 'vila-imbui',
				'nome' => 'Vila Imbuí',
			),
			array(
				'slug' => 'vila-por-do-sol',
				'nome' => 'Vila Pôr do Sol',
			),
			array(
				'slug' => 'parque-granja-esperanca',
				'nome' => 'Parque Granja Esperança',
			),
			array(
				'slug' => 'vila-princesa',
				'nome' => 'Vila Princesa',
			),
			array(
				'slug' => 'vila-bom-principio',
				'nome' => 'Vila Bom Princípio',
			),
			array(
				'slug' => 'vista-alegre',
				'nome' => 'Vista Alegre',
			),
			array(
				'slug' => 'parque-marechal-rondon',
				'nome' => 'Parque Marechal Rondon',
			),
			array(
				'slug' => 'chacara',
				'nome' => 'Chácara',
			),
			array(
				'slug' => 'vila-fatima',
				'nome' => 'Vila Fátima',
			),
			array(
				'slug' => 'parque-espirito-santo',
				'nome' => 'Parque Espírito Santo',
			),
		),
	),
	array(
		'cidadeSlug' => 'sapucaia-do-sul',
		'bairros' => array(
			array(
				'slug' => 'centro',
				'nome' => 'Centro',
			),
			array(
				'slug' => 'sao-jose',
				'nome' => 'São José',
			),
			array(
				'slug' => 'boa-vista',
				'nome' => 'Boa Vista',
			),
			array(
				'slug' => 'vargas',
				'nome' => 'Vargas',
			),
			array(
				'slug' => 'santa-catarina',
				'nome' => 'Santa Catarina',
			),
			array(
				'slug' => 'pasqualini',
				'nome' => 'Pasqualini',
			),
			array(
				'slug' => 'cohab',
				'nome' => 'COHAB',
			),
			array(
				'slug' => 'camboim',
				'nome' => 'Camboim',
			),
			array(
				'slug' => 'jardim-america',
				'nome' => 'Jardim América',
			),
			array(
				'slug' => 'nova-sapucaia',
				'nome' => 'Nova Sapucaia',
			),
			array(
				'slug' => 'piratini',
				'nome' => 'Piratini',
			),
			array(
				'slug' => 'lomba-da-palmeira',
				'nome' => 'Lomba da Palmeira',
			),
		),
	),
);
