<?php
/** Gerado de assets/data/ramos.json — não editar. */
return array(
	array(
		'slug' => 'automotivo',
		'nome' => 'Automotivo leve e pesado',
		'titulo' => 'Baterias Automotivas em Porto Alegre | Carros, Caminhões e Ônibus',
		'descricao' => 'Baterias chumbo-ácido, EFB e AGM Start-Stop para carros, caminhões, ônibus e frotas em Porto Alegre e Grande POA. Entrega e instalação no local em até 35 minutos.',
		'h1' => 'Baterias automotivas: do carro popular à frota pesada',
		'tagline' => 'Chumbo-ácido, EFB e AGM Start-Stop com instalação no local',
		'tecnologia' => 'Chumbo-ácido convencional, EFB e AGM (Start-Stop)',
		'intro' => array(
			'O segmento automotivo é o coração da AWR Baterias. Atendemos desde o carro popular 1.0 até caminhões, ônibus e frotas comerciais, sempre com a amperagem e a tecnologia exatas que o fabricante do veículo especifica.',
			'Nossos técnicos testam alternador e sistema de carga antes de instalar, para garantir que o problema é mesmo a bateria — e não um defeito elétrico que voltaria a descarregar a peça nova.',
		),
		'aplicacoes' => array(
			'Carros de passeio, SUVs e picapes',
			'Veículos com sistema Start-Stop (EFB/AGM)',
			'Caminhões, ônibus e vans',
			'Frotas comerciais e locadoras',
			'Motoristas de aplicativo (Uber, 99, InDrive)',
		),
		'beneficios' => array(
			array(
				'titulo' => 'Instalação no local',
				'descricao' => 'Levamos a bateria até o veículo em até 35 minutos na capital e região, sem custo de instalação.',
			),
			array(
				'titulo' => 'Reset de ECU incluso',
				'descricao' => 'Em veículos Start-Stop fazemos o registro da bateria nova no BCM/BSI, evitando erro no painel.',
			),
			array(
				'titulo' => 'Até 24 meses de garantia',
				'descricao' => 'Moura e Heliar com nota fiscal e cobertura de fábrica válida em toda a rede nacional.',
			),
			array(
				'titulo' => 'Base de troca abatida',
				'descricao' => 'A bateria velha é recolhida com descarte ambientalmente correto e abatida do valor final.',
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Vocês atendem frota com nota em CNPJ?',
				'resposta' => 'Sim. Emitimos nota fiscal em CNPJ, com condições de pagamento estendidas e visitas programadas para frotas a partir de 5 veículos.',
			),
			array(
				'pergunta' => 'Qual o preço da bateria automotiva?',
				'resposta' => 'A partir de R$ 329 (60Ah Eletra). Parcele em até 10x sem juros nos cartões.',
			),
			array(
				'pergunta' => 'Bateria comum serve em carro Start-Stop?',
				'resposta' => 'Não. Start-Stop exige EFB ou AGM. Bateria comum dura poucos meses e pode desativar a função no painel.',
			),
		),
	),
	array(
		'slug' => 'motocicletas',
		'nome' => 'Motocicletas',
		'titulo' => 'Bateria de Moto em Porto Alegre | VRLA e AGM Seladas',
		'descricao' => 'Bateria de moto VRLA/AGM selada em Porto Alegre e Grande POA. Modelos para scooters, motos de trabalho e alta cilindrada, com instalação e teste de carga.',
		'h1' => 'Bateria de moto: VRLA e AGM seladas, sem manutenção',
		'tagline' => 'Selada, livre de manutenção e pronta para uso',
		'tecnologia' => 'VRLA / AGM selada (livre de manutenção)',
		'intro' => array(
			'Motos usam baterias seladas VRLA ou AGM, compactas e livres de manutenção — não precisam de reposição de água e podem trabalhar em qualquer posição de instalação.',
			'Trabalhamos com as amperagens mais usadas em scooters, motos de trabalho, motos de aplicativo e alta cilindrada, incluindo modelos com injeção eletrônica e partida elétrica exigente.',
		),
		'aplicacoes' => array(
			'Scooters e ciclomotores',
			'Motos de trabalho e delivery',
			'Motos de alta cilindrada e trail',
			'Quadriciclos e UTVs',
			'Motos com injeção eletrônica e ABS',
		),
		'beneficios' => array(
			array(
				'titulo' => 'Selada e sem manutenção',
				'descricao' => 'Tecnologia VRLA/AGM que não vaza e dispensa reposição de água ao longo da vida útil.',
			),
			array(
				'titulo' => 'Alta corrente de partida',
				'descricao' => 'Ideal para motos com injeção eletrônica, que exigem tensão estável já na primeira partida.',
			),
			array(
				'titulo' => 'Teste do sistema de carga',
				'descricao' => 'Verificamos regulador e retificador antes de entregar, evitando queima da bateria nova.',
			),
			array(
				'titulo' => 'Pronta entrega',
				'descricao' => 'Estoque das amperagens mais comuns nas 6 lojas AWR da Grande Porto Alegre.',
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Bateria de moto precisa de manutenção?',
				'resposta' => 'Não. As baterias VRLA/AGM que trabalhamos são seladas e livres de manutenção — basta manter os terminais limpos e o sistema de carga em ordem.',
			),
			array(
				'pergunta' => 'Vocês instalam bateria de moto no local?',
				'resposta' => 'Sim, em toda a Grande Porto Alegre, com teste de carga e do regulador de tensão incluídos.',
			),
			array(
				'pergunta' => 'Minha moto fica parada muitos dias. E aí?',
				'resposta' => 'Recomendamos um carregador mantenedor. Motos paradas por semanas descarregam a bateria e reduzem bastante a vida útil.',
			),
		),
	),
	array(
		'slug' => 'mobilidade-eletrica',
		'nome' => 'Mobilidade elétrica',
		'titulo' => 'Baterias para Mobilidade Elétrica em Porto Alegre | Cadeiras, Bikes e Carrinhos',
		'descricao' => 'Baterias de ciclo profundo VRLA para cadeiras de rodas motorizadas, bicicletas elétricas, scooters de mobilidade e carrinhos de golfe, com atendimento no local em Porto Alegre e região e em todas as cidades do RS, SC, PR e São Paulo.',
		'h1' => 'Mobilidade elétrica: baterias de ciclo profundo que aguentam o uso diário',
		'tagline' => 'Cadeiras de rodas, bikes, scooters e carrinhos de golfe',
		'tecnologia' => 'VRLA de ciclo profundo (deep cycle)',
		'intro' => array(
			'Equipamentos de mobilidade elétrica descarregam e recarregam a bateria todos os dias. Isso exige tecnologia de ciclo profundo — uma bateria automotiva comum perderia capacidade em poucos meses nesse regime.',
			'A AWR fornece baterias VRLA deep cycle para cadeiras de rodas motorizadas, scooters de mobilidade, bicicletas elétricas e carrinhos de golfe, com orientação sobre carregador e rotina de carga.',
		),
		'aplicacoes' => array(
			'Cadeiras de rodas motorizadas',
			'Scooters de mobilidade para idosos',
			'Bicicletas elétricas',
			'Carrinhos de golfe',
			'Plataformas e equipamentos de acessibilidade',
		),
		'beneficios' => array(
			array(
				'titulo' => 'Projetada para ciclagem diária',
				'descricao' => 'Placas mais espessas suportam centenas de ciclos de carga e descarga sem perder autonomia.',
			),
			array(
				'titulo' => 'Selada e segura',
				'descricao' => 'VRLA não vaza eletrólito, podendo ser usada dentro de casa e em ambientes fechados.',
			),
			array(
				'titulo' => 'Autonomia previsível',
				'descricao' => 'Dimensionamos o par de baterias conforme o peso do usuário e o trajeto diário do equipamento.',
			),
			array(
				'titulo' => 'Substituição em par',
				'descricao' => 'Trocamos sempre o conjunto completo, evitando desbalanceamento que mata a bateria nova.',
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Posso usar bateria de carro na cadeira de rodas?',
				'resposta' => 'Não é indicado. A bateria automotiva é feita para uma descarga curta e forte; a cadeira exige descarga profunda diária, o que a destrói rapidamente.',
			),
			array(
				'pergunta' => 'Quanto dura uma bateria de ciclo profundo?',
				'resposta' => 'Entre 18 e 36 meses, dependendo da profundidade de descarga diária e da qualidade do carregador utilizado.',
			),
			array(
				'pergunta' => 'Vocês entregam em domicílio?',
				'resposta' => 'Sim, entregamos e trocamos no domicílio em Porto Alegre e região metropolitana.',
			),
		),
	),
	array(
		'slug' => 'seguranca-e-ti',
		'nome' => 'Segurança e TI',
		'titulo' => 'Baterias para Nobreak, Alarme e CFTV em Porto Alegre | VRLA',
		'descricao' => 'Baterias VRLA seladas para nobreak, alarmes, CFTV, centrais telefônicas e controle de acesso em Porto Alegre. Reposição programada para empresas e condomínios.',
		'h1' => 'Segurança e TI: energia de reserva que não pode falhar',
		'tagline' => 'Nobreak, alarme, CFTV, portões e controle de acesso',
		'tecnologia' => 'VRLA selada estacionária (12V 7Ah a 100Ah)',
		'intro' => array(
			'Sistemas de segurança e TI dependem de baterias estacionárias VRLA para manter operação durante quedas de energia. A falha aparece justamente na hora crítica — quando o fornecimento cai.',
			'A AWR fornece baterias seladas de 7Ah a 100Ah para nobreaks, centrais de alarme, CFTV, portões automáticos, controle de acesso e centrais telefônicas, com plano de reposição programada para empresas e condomínios.',
		),
		'aplicacoes' => array(
			'Nobreaks e no-breaks de rack',
			'Centrais de alarme e CFTV',
			'Portões automáticos e cancelas',
			'Controle de acesso e interfonia',
			'Centrais telefônicas e PABX',
		),
		'beneficios' => array(
			array(
				'titulo' => 'Selada e sem gases',
				'descricao' => 'VRLA pode ser instalada em racks, salas técnicas e ambientes fechados com segurança.',
			),
			array(
				'titulo' => 'Reposição programada',
				'descricao' => 'Montamos calendário de troca preventiva para evitar falha do sistema em plena queda de energia.',
			),
			array(
				'titulo' => 'Estoque de 7Ah a 100Ah',
				'descricao' => 'As capacidades mais usadas em pronta entrega, incluindo bancos com várias unidades.',
			),
			array(
				'titulo' => 'Nota fiscal em CNPJ',
				'descricao' => 'Faturamento para empresas, condomínios e integradores, com condições comerciais dedicadas.',
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'De quanto em quanto tempo trocar a bateria do nobreak?',
				'resposta' => 'Em média a cada 24 a 36 meses, ou antes disso se o equipamento acusar autonomia reduzida nos testes.',
			),
			array(
				'pergunta' => 'Vocês atendem condomínios e empresas?',
				'resposta' => 'Sim. Fazemos contrato de reposição programada com nota fiscal em CNPJ e visitas agendadas.',
			),
			array(
				'pergunta' => 'É possível montar banco de baterias?',
				'resposta' => 'Sim, dimensionamos bancos em série e paralelo conforme a autonomia desejada e o equipamento instalado.',
			),
		),
	),
	array(
		'slug' => 'tracionario-industrial',
		'nome' => 'Tracionário e industrial',
		'titulo' => 'Baterias Tracionárias e GEL em Porto Alegre | Empilhadeira e Plataforma',
		'descricao' => 'Baterias tracionárias e de GEL para empilhadeiras, paleteiras, plataformas elevatórias e lavadoras de piso em Porto Alegre e Grande POA. Atendimento industrial com CNPJ.',
		'h1' => 'Tracionário e industrial: energia para operar o turno inteiro',
		'tagline' => 'Empilhadeira, paleteira, plataforma e lavadora de piso',
		'tecnologia' => 'Tracionária de placa tubular e GEL de ciclo profundo',
		'intro' => array(
			'Equipamentos industriais trabalham em regime de descarga profunda contínua e precisam de baterias tracionárias ou GEL, capazes de entregar corrente estável durante todo o turno de operação.',
			'A AWR atende indústrias, centros de distribuição, supermercados e prestadores de serviço na Grande Porto Alegre, com fornecimento, troca no local e orientação de rotina de carga.',
		),
		'aplicacoes' => array(
			'Empilhadeiras elétricas',
			'Paleteiras e transpaleteiras',
			'Plataformas elevatórias e tesouras',
			'Lavadoras e varredeiras de piso',
			'Rebocadores e veículos internos de fábrica',
		),
		'beneficios' => array(
			array(
				'titulo' => 'Placa tubular resistente',
				'descricao' => 'Construção pensada para milhares de ciclos profundos sem perda relevante de capacidade.',
			),
			array(
				'titulo' => 'GEL livre de manutenção',
				'descricao' => 'Opção sem reposição de água, indicada para operações em ambiente de alimentos e farmacêutico.',
			),
			array(
				'titulo' => 'Troca no local',
				'descricao' => 'Levamos equipe e equipamento até a planta, com descarte regularizado da bateria antiga.',
			),
			array(
				'titulo' => 'Contrato de fornecimento',
				'descricao' => 'Preço fechado e reposição programada para operações com vários equipamentos.',
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Qual a diferença entre tracionária e GEL?',
				'resposta' => 'A tracionária de placa tubular entrega mais ciclos e é o padrão em empilhadeira; o GEL é selado, livre de manutenção e indicado quando não há sala de carga adequada.',
			),
			array(
				'pergunta' => 'Vocês fazem descarte da bateria antiga?',
				'resposta' => 'Sim, com recolhimento e destinação ambientalmente correta, incluindo documentação para a empresa.',
			),
			array(
				'pergunta' => 'Atendem fora de Porto Alegre?',
				'resposta' => 'Atendemos toda a região metropolitana e, para contratos industriais, avaliamos atendimento no interior do RS.',
			),
		),
	),
	array(
		'slug' => 'nautico',
		'nome' => 'Náutico',
		'titulo' => 'Baterias Náuticas em Porto Alegre | Lanchas, Barcos e Jet-Ski',
		'descricao' => 'Baterias náuticas de ciclo profundo para lanchas, barcos, veleiros e jet-ski em Porto Alegre. Partida do motor e alimentação de eletrônicos de bordo.',
		'h1' => 'Náutico: partida garantida e energia de bordo estável',
		'tagline' => 'Lanchas, barcos, veleiros e jet-ski',
		'tecnologia' => 'Ciclo profundo / dual purpose (partida + serviço)',
		'intro' => array(
			'Embarcações precisam de dois perfis de bateria: a de partida, que entrega corrente alta e curta para o motor, e a de serviço, de ciclo profundo, que alimenta sonda, rádio, luzes e geladeira de bordo por horas.',
			'A AWR fornece as duas linhas e ajuda a dimensionar o banco correto para o seu barco, evitando o erro comum de usar uma bateria automotiva comum como bateria de serviço.',
		),
		'aplicacoes' => array(
			'Lanchas e barcos de passeio',
			'Veleiros com eletrônica de bordo',
			'Jet-ski e motos aquáticas',
			'Barcos de pesca com motor de popa',
			'Bancos de serviço para eletrônicos de bordo',
		),
		'beneficios' => array(
			array(
				'titulo' => 'Resistência à vibração',
				'descricao' => 'Construção reforçada para o balanço constante da embarcação, que destrói baterias comuns.',
			),
			array(
				'titulo' => 'Ciclo profundo real',
				'descricao' => 'Alimenta sonda, rádio, luzes e geladeira por horas sem comprometer a partida do motor.',
			),
			array(
				'titulo' => 'Selada e segura',
				'descricao' => 'Opções VRLA sem vazamento de ácido, adequadas ao compartimento fechado do barco.',
			),
			array(
				'titulo' => 'Dimensionamento sob medida',
				'descricao' => 'Calculamos o banco pelo consumo real dos equipamentos de bordo e pelo tempo de navegação.',
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Posso usar bateria de carro no barco?',
				'resposta' => 'Para partida até funciona por um tempo, mas a vibração e a descarga profunda a destroem rápido. Para alimentar eletrônicos, é preciso ciclo profundo.',
			),
			array(
				'pergunta' => 'Preciso de duas baterias na embarcação?',
				'resposta' => 'Na maioria dos casos sim: uma dedicada à partida e outra (ou um banco) para serviço, isoladas por chave seletora.',
			),
			array(
				'pergunta' => 'Vocês entregam em marinas?',
				'resposta' => 'Sim, entregamos em marinas e garagens náuticas da Grande Porto Alegre, com instalação no local.',
			),
		),
	),
);
