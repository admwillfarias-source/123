<?php
/** Gerado de assets/data/marcas.json — não editar. */
return array(
	array(
		'slug' => 'moura',
		'nome' => 'Moura',
		'nomeCompleto' => 'Bateria Moura',
		'titulo' => 'Bateria Moura em Porto Alegre | Instalação Grátis',
		'descricao' => 'Bateria Moura original a partir de R$ 425, entregue e instalada de graça em até 35 min. Até 24 meses de garantia, nota fiscal e 10x sem juros.',
		'h1' => 'Bateria Moura: a líder do mercado brasileiro com garantia de fábrica',
		'tagline' => 'Líder em montadoras, até 24 meses de garantia',
		'introParagrafos' => array(
			'A Moura é a marca de bateria automotiva mais vendida do Brasil e fornecedora oficial de montadoras como Volkswagen, Fiat, Chevrolet e Ford. É a escolha mais segura para quem busca durabilidade comprovada e revenda fácil.',
			'Na AWR Baterias somos revendedor autorizado Moura em toda a região metropolitana de Porto Alegre. Para quem pesquisa bateria Moura, bateria Moura 60 amperes ou valor da bateria Moura, mostramos o preço real de cada modelo antes do pedido. Entregamos e instalamos no local, com garantia ativada na nota fiscal e troca em qualquer ponto da rede nacional.',
		),
		'destaqueCor' => 'from-blue-600 to-blue-800',
		'posicionamento' => 'Premium — primeira linha',
		'garantiaMeses' => 24,
		'faixaPreco' => 'R$ 425 a R$ 3.245',
		'origemFabrica' => 'Belo Jardim/PE',
		'segmento' => 'automotiva',
		'cidadePages' => true,
		'beneficios' => array(
			array(
				'titulo' => 'Fornecedora oficial de montadoras',
				'descricao' => 'Equipamento original de fábrica em VW, Fiat, GM e Ford — encaixe perfeito e validação ECU sem surpresas.',
			),
			array(
				'titulo' => 'Até 24 meses de garantia nacional',
				'descricao' => 'Cobertura aceita em qualquer revendedor autorizado Moura no Brasil, não só em Porto Alegre.',
			),
			array(
				'titulo' => 'Tecnologia VRLA / EFB / AGM',
				'descricao' => 'Linha completa, do carro popular ao Start-Stop premium, sem precisar trocar de fabricante.',
			),
			array(
				'titulo' => 'Maior liquidez na hora de revender',
				'descricao' => 'Sucata de Moura é a mais valorizada do mercado — você recupera parte do investimento no descarte.',
			),
		),
		'modelosPopulares' => array(
			array(
				'linha' => 'Moura 60Ah',
				'amperagem' => '60 Ah',
				'carrosCompatveis' => array(
					'VW Gol',
					'Fiat Mobi',
					'Renault Kwid',
					'Chevrolet Onix 1.0',
				),
			),
			array(
				'linha' => 'Moura 70Ah',
				'amperagem' => '70 Ah',
				'carrosCompatveis' => array(
					'Toyota Corolla',
					'Honda Civic',
					'Hyundai HB20S',
					'Jeep Renegade',
				),
			),
			array(
				'linha' => 'Moura AGM 80Ah Start-Stop',
				'amperagem' => '80 Ah AGM',
				'carrosCompatveis' => array(
					'Jeep Compass',
					'VW T-Cross',
					'Audi A3',
					'BMW Série 1',
				),
			),
		),
		'linhas' => array(
			array(
				'nome' => 'Moura Preventiva',
				'uso' => 'Carros de passeio e utilitários do dia a dia',
				'amperagens' => '40Ah a 100Ah',
				'destaque' => 'Livre de manutenção, é a linha mais vendida: sai da nossa van carregada e testada.',
			),
			array(
				'nome' => 'Moura AGM Start-Stop',
				'uso' => 'Carros com desliga-liga automático (Compass, T-Cross, Corolla Cross)',
				'amperagens' => '60Ah a 95Ah AGM',
				'destaque' => 'Aguenta as paradas e partidas do Start-Stop sem perder carga; a linha comum não substitui.',
			),
			array(
				'nome' => 'Moura EFB',
				'uso' => 'Start-Stop de entrada e carros com muito acessório',
				'amperagens' => '60Ah a 80Ah',
				'destaque' => 'Meio-termo entre a comum e a AGM, indicada pela própria montadora em vários modelos.',
			),
			array(
				'nome' => 'Moura Log',
				'uso' => 'Caminhões, ônibus, tratores e frotas',
				'amperagens' => '100Ah a 220Ah',
				'destaque' => 'Feita para vibração e partida pesada; atendemos frota no pátio, sem parar o serviço.',
			),
			array(
				'nome' => 'Moura Moto',
				'uso' => 'CG, Titan, Biz, Fazer, XRE e big trails',
				'amperagens' => '5Ah a 12Ah',
				'destaque' => 'Instalação na moto, no local, em poucos minutos.',
			),
			array(
				'nome' => 'Moura Clean (12MVA)',
				'uso' => 'Nobreak, UPS, alarme, CFTV e energia de backup',
				'amperagens' => '7Ah a 220Ah',
				'destaque' => 'Estacionária selada: trocamos o banco inteiro no local e levamos as usadas.',
			),
		),
		'ondeEUsada' => array(
			'Carros de passeio',
			'SUVs',
			'Caminhonetes leves',
			'Veículos Start-Stop',
		),
		'faq' => array(
			array(
				'pergunta' => 'A Moura realmente dá até 24 meses de garantia?',
				'resposta' => 'Sim. Toda bateria Moura vendida pela AWR sai com nota fiscal e até 24 meses contados a partir da data de instalação. A garantia cobre defeitos de fabricação e pode ser acionada em qualquer revendedor autorizado do Brasil.',
			),
			array(
				'pergunta' => 'Qual a diferença entre Moura e Heliar?',
				'resposta' => 'Ambas são primeira linha. Moura é líder de mercado e dá até 24 meses de garantia. Heliar usa tecnologia Clarios, indicada para importados e Start-Stop. Nosso técnico confere seu carro antes de instalar.',
			),
			array(
				'pergunta' => 'A bateria Moura serve para carros Start-Stop?',
				'resposta' => 'Sim, mas precisa ser a linha AGM ou EFB específica para Start-Stop — nunca a linha comum. Confirme com a gente o modelo do seu carro antes de comprar.',
			),
			array(
				'pergunta' => 'Vocês fazem entrega e instalação grátis em Porto Alegre?',
				'resposta' => 'Sim. Entrega e instalação no local são grátis em Porto Alegre, Canoas, Gravataí, Cachoeirinha, Alvorada, Viamão, São Leopoldo e Novo Hamburgo. Tempo médio: 35 a 50 min.',
			),
			array(
				'pergunta' => 'A Moura tem bateria de moto?',
				'resposta' => 'Sim — a linha Moura Moto (12MVA) atende CG, Titan, Biz, Fazer, XRE e big trails, em versões de 5Ah a 12Ah. Entregamos e instalamos na moto, no local.',
			),
			array(
				'pergunta' => 'Qual bateria Moura AGM o meu carro usa?',
				'resposta' => 'Depende do modelo e do ano: os Start-Stop mais comuns pedem AGM de 60Ah, 70Ah ou 80Ah. Mande o modelo, o ano ou a placa no WhatsApp que confirmamos a amperagem certa antes de sair para a entrega.',
			),
			array(
				'pergunta' => 'Quanto custa uma bateria Moura?',
				'resposta' => 'A linha Moura na AWR vai de R$ 425 a R$ 3.245, conforme a amperagem e a tecnologia (comum, EFB, AGM ou estacionária). O preço à vista no Pix sai com desconto e o parcelamento é em até 10x sem juros.',
			),
			array(
				'pergunta' => 'Vocês entregam bateria Moura fora da Grande Porto Alegre?',
				'resposta' => 'Sim. Na Grande Porto Alegre a entrega e a instalação são no local, em até 35 minutos. Para cidades como Caxias do Sul enviamos por transportadora, com rastreio, nota fiscal e a mesma garantia de fábrica.',
			),
			array(
				'pergunta' => 'A Moura tem bateria para nobreak?',
				'resposta' => 'Tem: a linha estacionária 12MVA, de 7Ah a 220Ah, usada em nobreak, UPS, alarme e CFTV. Trocamos o banco completo no local e recolhemos as baterias usadas.',
			),
		),
	),
	array(
		'slug' => 'heliar',
		'nome' => 'Heliar',
		'nomeCompleto' => 'Bateria Heliar',
		'titulo' => 'Bateria Heliar em Porto Alegre | Entrega Grátis Hoje',
		'descricao' => 'Bateria Heliar original com 15 meses de garantia, entrega e instalação grátis em até 35 min em Porto Alegre e região. Peça hoje pelo WhatsApp.',
		'h1' => 'Bateria Heliar: tecnologia global da Clarios para o seu carro',
		'tagline' => 'Tecnologia Clarios, líder mundial em baterias',
		'introParagrafos' => array(
			'A Heliar é a marca premium da Clarios (ex-Johnson Controls), líder mundial em baterias automotivas. Equipa de fábrica diversos modelos importados e nacionais, com destaque para veículos com tecnologia Start-Stop.',
			'Na AWR Baterias trabalhamos com bateria Heliar 60 amperes, linha Super e Free AGM para Start-Stop. Você confere o preço real do modelo indicado antes da compra, com entrega e instalação grátis em toda a região metropolitana de Porto Alegre.',
		),
		'destaqueCor' => 'from-amber-500 to-amber-700',
		'posicionamento' => 'Premium — alta tecnologia',
		'garantiaMeses' => 24,
		'faixaPreco' => 'R$ 409 a R$ 2.625',
		'origemFabrica' => 'Sorocaba/SP',
		'segmento' => 'automotiva',
		'cidadePages' => true,
		'beneficios' => array(
			array(
				'titulo' => 'Tecnologia mundial Clarios',
				'descricao' => 'Mesma engenharia usada em baterias OEM de BMW, Audi, Mercedes-Benz e Volkswagen na Europa.',
			),
			array(
				'titulo' => 'Linha AGM Free para Start-Stop',
				'descricao' => 'Suporta os ciclos extras de carga e descarga do Start-Stop sem perder capacidade nos primeiros anos.',
			),
			array(
				'titulo' => '15 meses de garantia',
				'descricao' => 'Cobertura ampla com acionamento em rede autorizada nacional.',
			),
			array(
				'titulo' => 'Indicador visual de carga',
				'descricao' => 'Olho mágico integrado mostra o estado da bateria — verde, escuro ou claro — sem precisar de aparelho.',
			),
		),
		'modelosPopulares' => array(
			array(
				'linha' => 'Heliar Super 60Ah',
				'amperagem' => '60 Ah',
				'carrosCompatveis' => array(
					'Fiat Argo',
					'Chevrolet Onix',
					'Hyundai HB20',
					'Renault Sandero',
				),
			),
			array(
				'linha' => 'Heliar Super 70Ah',
				'amperagem' => '70 Ah',
				'carrosCompatveis' => array(
					'VW Polo 1.6',
					'Toyota Yaris',
					'Nissan Kicks',
					'Jeep Renegade',
				),
			),
			array(
				'linha' => 'Heliar Free AGM 80Ah',
				'amperagem' => '80 Ah AGM',
				'carrosCompatveis' => array(
					'BMW X1',
					'Audi Q3',
					'Mercedes Classe A',
					'VW Tiguan Start-Stop',
				),
			),
		),
		'ondeEUsada' => array(
			'Carros importados',
			'SUVs premium',
			'Veículos Start-Stop',
			'Carros com muita eletrônica',
		),
		'faq' => array(
			array(
				'pergunta' => 'Heliar é boa para carro importado?',
				'resposta' => 'Sim — a Heliar é justamente a linha mais usada por importadoras europeias no Brasil. A versão AGM atende perfeitamente Audi, BMW, Mercedes e VW Premium.',
			),
			array(
				'pergunta' => 'Posso trocar Moura por Heliar?',
				'resposta' => 'Sim, desde que a amperagem (Ah), polaridade e dimensões sejam compatíveis. Nosso técnico confere isso antes da instalação, sem custo.',
			),
			array(
				'pergunta' => 'O que é o olho mágico da Heliar?',
				'resposta' => 'É um indicador visual no topo da bateria. Verde = carga boa, escuro = precisa carregar, claro = trocar. Útil para diagnóstico rápido sem multímetro.',
			),
			array(
				'pergunta' => 'Vocês entregam Heliar em Canoas e São Leopoldo?',
				'resposta' => 'Sim. Entrega e instalação grátis em até 50 min em toda a região metropolitana, incluindo Canoas, Esteio, São Leopoldo, Novo Hamburgo, Gravataí e Cachoeirinha.',
			),
			array(
				'pergunta' => 'Quanto custa uma bateria Heliar 60 amperes?',
				'resposta' => 'O valor depende do código, da polaridade e da tecnologia exigida pelo veículo. Consulte o preço atualizado nos modelos disponíveis ou envie modelo e ano pelo WhatsApp para receber o valor correto antes da instalação.',
			),
		),
	),
	array(
		'slug' => 'zetta',
		'nome' => 'Zetta',
		'nomeCompleto' => 'Bateria Zetta',
		'titulo' => 'Bateria Zetta em Porto Alegre | Troca Grátis em 35 min',
		'descricao' => 'Bateria Zetta com 12 meses de garantia e preço justo para Uber, 99 e uso diário. Entrega e instalação grátis em 35 min em Porto Alegre. Peça já.',
		'h1' => 'Bateria Zetta: o custo-benefício certo para carros do dia a dia',
		'tagline' => 'Da mesma fábrica da Moura, com preço menor',
		'introParagrafos' => array(
			'A Zetta é fabricada pelo Grupo Moura e usa a mesma plataforma técnica das baterias top de linha — só que com posicionamento mais acessível. É a escolha ideal para quem roda muito (Uber, 99, entregas) e precisa equilibrar durabilidade e preço.',
			'Na AWR Baterias a Zetta é uma das mais vendidas para motoristas de aplicativo e frota leve em Porto Alegre. Quem procura bateria Zetta 60 amperes encontra o preço real no catálogo antes do pedido, com entrega e instalação grátis em toda a região metropolitana.',
		),
		'destaqueCor' => 'from-emerald-600 to-emerald-800',
		'posicionamento' => 'Custo-benefício — segunda linha do grupo Moura',
		'garantiaMeses' => 18,
		'faixaPreco' => 'R$ 379 a R$ 1.150',
		'origemFabrica' => 'Belo Jardim/PE (Grupo Moura)',
		'segmento' => 'automotiva',
		'cidadePages' => true,
		'beneficios' => array(
			array(
				'titulo' => 'Mesma fábrica da Moura',
				'descricao' => 'Plataforma técnica e processo produtivo do Grupo Moura, com posicionamento de preço mais acessível.',
			),
			array(
				'titulo' => '12 meses de garantia integral',
				'descricao' => 'Cobertura nacional contra defeito de fabricação, acionável em rede autorizada.',
			),
			array(
				'titulo' => 'Ideal para Uber e 99',
				'descricao' => 'Resistência alta a ciclos de partida frequentes — perfeita para quem trabalha rodando o dia inteiro.',
			),
			array(
				'titulo' => 'Pronta entrega na região',
				'descricao' => 'Estoque rotativo nas 6 lojas AWR. Tipicamente entregue e instalada em até 35 minutos em POA.',
			),
		),
		'modelosPopulares' => array(
			array(
				'linha' => 'Zetta 50Ah',
				'amperagem' => '50 Ah',
				'carrosCompatveis' => array(
					'VW Gol 1.0',
					'Fiat Uno',
					'Chevrolet Celta',
					'Ford Ka 1.0',
				),
			),
			array(
				'linha' => 'Zetta 60Ah',
				'amperagem' => '60 Ah',
				'carrosCompatveis' => array(
					'VW Voyage',
					'Fiat Cronos',
					'Renault Logan',
					'Chevrolet Prisma',
				),
			),
			array(
				'linha' => 'Zetta 70Ah',
				'amperagem' => '70 Ah',
				'carrosCompatveis' => array(
					'Toyota Etios',
					'Hyundai HB20S',
					'Nissan Versa',
					'VW Polo 1.6',
				),
			),
		),
		'ondeEUsada' => array(
			'Carros populares 1.0/1.4',
			'Uber e 99',
			'Frota leve',
			'Carro de passeio sem Start-Stop',
		),
		'faq' => array(
			array(
				'pergunta' => 'Zetta é da Moura mesmo?',
				'resposta' => 'Sim — é fabricada pelo Grupo Moura na mesma planta de Belo Jardim/PE. A diferença está no posicionamento comercial e em alguns componentes, mas a engenharia base é a mesma.',
			),
			array(
				'pergunta' => 'Zetta serve para motorista de aplicativo?',
				'resposta' => 'É a opção mais recomendada da AWR para Uber e 99. O alto número de partidas diárias é justamente o cenário em que ela performa melhor pelo preço.',
			),
			array(
				'pergunta' => 'Quantos meses dura uma Zetta na prática?',
				'resposta' => 'Em uso típico de Uber em Porto Alegre, clientes nossos relatam entre 20 e 30 meses de vida útil. Com manutenção (terminal limpo, alternador testado), passa de 30 meses.',
			),
			array(
				'pergunta' => 'Posso usar Zetta em SUV ou caminhonete?',
				'resposta' => 'Para SUV pequena (Renegade, Kicks, Creta) sim, na 70Ah. Para caminhonete grande (Hilux, S10, Ranger) recomendamos Moura ou Heliar pela amperagem maior e exigência de partida a frio.',
			),
			array(
				'pergunta' => 'Qual o valor da bateria Zetta 60 amperes?',
				'resposta' => 'O valor varia conforme código, polaridade e veículo. Consulte o preço atualizado no catálogo ou envie modelo e ano pelo WhatsApp para confirmarmos a Zetta compatível e o valor final.',
			),
		),
	),
	array(
		'slug' => 'excell',
		'nome' => 'Excell',
		'nomeCompleto' => 'Bateria Excell',
		'titulo' => 'Bateria Excell em Porto Alegre | Instalação Grátis',
		'descricao' => 'Bateria Excell para carro, utilitário e caminhão com garantia de fábrica, entregue e instalada em até 35 min em Porto Alegre. Peça pelo WhatsApp.',
		'h1' => 'Bateria Excell: linha completa para carro, utilitário e caminhão',
		'tagline' => 'Marca nacional com ótimo custo-benefício',
		'introParagrafos' => array(
			'A Excell é uma marca brasileira de baterias com linha completa para veículos de passeio, utilitários, caminhonetes e caminhões. É uma das opções de melhor custo-benefício para quem precisa de uma bateria confiável sem pagar pelo posicionamento premium.',
			'Na AWR Baterias você encontra bateria Excell 60 amperes para carro e linhas de maior amperagem para utilitário e caminhão. O catálogo mostra o preço real disponível; nosso técnico confirma amperagem, polaridade e dimensões antes da instalação em Porto Alegre e região metropolitana.',
		),
		'destaqueCor' => 'from-red-600 to-red-800',
		'posicionamento' => 'Custo-benefício — linha nacional',
		'origemFabrica' => 'Brasil',
		'segmento' => 'automotiva',
		'cidadePages' => true,
		'beneficios' => array(
			array(
				'titulo' => 'Linha completa carro e caminhão',
				'descricao' => 'Do hatch 1.0 ao caminhão 24V — uma única marca para toda a garagem ou frota.',
			),
			array(
				'titulo' => 'Custo-benefício',
				'descricao' => 'Preço abaixo das marcas premium mantendo procedência, nota fiscal e garantia de fábrica.',
			),
			array(
				'titulo' => 'Boa opção para frota e trabalho',
				'descricao' => 'Indicada para veículos de uso intenso, utilitários e frotas que trocam bateria por ciclo de vida.',
			),
			array(
				'titulo' => 'Conferência antes da instalação',
				'descricao' => 'Validamos amperagem, polaridade e dimensões do seu veículo antes de sair para a entrega.',
			),
		),
		'modelosPopulares' => array(
			array(
				'linha' => 'Excell 60Ah',
				'amperagem' => '60 Ah',
				'carrosCompatveis' => array(
					'VW Gol',
					'Fiat Argo',
					'Chevrolet Onix',
					'Hyundai HB20',
				),
			),
			array(
				'linha' => 'Excell 75Ah',
				'amperagem' => '75 Ah',
				'carrosCompatveis' => array(
					'Toyota Hilux',
					'Ford Ranger',
					'VW Amarok',
					'Chevrolet S10',
				),
			),
			array(
				'linha' => 'Excell 150Ah / 220Ah',
				'amperagem' => '150–220 Ah',
				'carrosCompatveis' => array(
					'Caminhão 3/4 e toco',
					'Carreta 24V (jogo)',
					'Ônibus urbano',
					'Máquinas agrícolas',
				),
			),
		),
		'ondeEUsada' => array(
			'Carros de passeio',
			'Caminhonetes e utilitários',
			'Caminhões 12V e 24V',
			'Frotas e veículos de trabalho',
		),
		'faq' => array(
			array(
				'pergunta' => 'Bateria Excell é confiável?',
				'resposta' => 'Sim. É uma marca nacional com linha completa e garantia de fábrica, vendida com nota fiscal. É uma das opções de melhor custo-benefício do nosso catálogo.',
			),
			array(
				'pergunta' => 'Excell tem bateria para caminhão?',
				'resposta' => 'Sim — a linha pesada cobre de 100Ah a 220Ah, incluindo o jogo de 24V para caminhão e carreta. Fazemos a troca em par no pátio ou na estrada dentro da área de cobertura.',
			),
			array(
				'pergunta' => 'Qual a garantia da bateria Excell?',
				'resposta' => 'A garantia é de fábrica e varia conforme a linha. Confirmamos o prazo exato do modelo escolhido na nota fiscal, antes da instalação.',
			),
			array(
				'pergunta' => 'Vocês entregam Excell na minha cidade?',
				'resposta' => 'Entregamos e instalamos grátis em Porto Alegre, Canoas, Gravataí, Cachoeirinha, Alvorada, Viamão, Esteio, Sapucaia do Sul, São Leopoldo, Campo Bom, Novo Hamburgo, Sapiranga, Estância Velha e Ivoti.',
			),
			array(
				'pergunta' => 'Quanto custa uma bateria Excell 60 amperes?',
				'resposta' => 'O preço depende do código e da polaridade compatível com o carro. Veja os valores atualizados no catálogo ou informe modelo e ano no WhatsApp para receber o preço final antes da entrega.',
			),
		),
	),
	array(
		'slug' => 'optima',
		'nome' => 'Optima',
		'nomeCompleto' => 'Bateria Optima',
		'titulo' => 'Bateria Optima AGM em Porto Alegre | Pronta Entrega',
		'descricao' => 'Bateria Optima AGM SpiralCell para som automotivo, 4x4 e off-road, com instalação em Porto Alegre. Fale com a AWR e confira disponibilidade.',
		'h1' => 'Bateria Optima: alta performance AGM para usos extremos',
		'tagline' => 'AGM SpiralCell — a referência mundial em alta performance',
		'introParagrafos' => array(
			'A Optima é a referência mundial em baterias de alta performance. Sua tecnologia AGM SpiralCell (placas enroladas em espiral) entrega corrente de partida muito alta, resistência extrema a vibração e aceitação de carga muito rápida — por isso é a escolha clássica de carros preparados, som automotivo de alta potência, 4x4 e off-road.',
			'Por ser uma linha importada de nicho, a disponibilidade é sob consulta. Fale com a AWR pelo WhatsApp para confirmar modelo (YellowTop, RedTop ou BlueTop), prazo e preço para a sua aplicação.',
		),
		'destaqueCor' => 'from-yellow-500 to-orange-600',
		'posicionamento' => 'Alta performance — importada',
		'origemFabrica' => 'Importada (Clarios)',
		'segmento' => 'automotiva',
		'beneficios' => array(
			array(
				'titulo' => 'Tecnologia AGM SpiralCell',
				'descricao' => 'Placas enroladas em espiral: mais corrente de partida, recarga rápida e resistência a vibração muito acima das baterias convencionais.',
			),
			array(
				'titulo' => 'Zero manutenção e vazamento',
				'descricao' => 'Construção selada permite instalação em posições variadas, sem risco de derramamento de ácido.',
			),
			array(
				'titulo' => 'Linhas por aplicação',
				'descricao' => 'YellowTop (ciclo profundo + partida), RedTop (partida pura) e BlueTop (náutica/RV) — escolhemos pela sua aplicação.',
			),
			array(
				'titulo' => 'Uso extremo',
				'descricao' => 'A escolha tradicional para som automotivo de alta potência, off-road, trilha, competição e veículos que ficam parados por longos períodos.',
			),
		),
		'modelosPopulares' => array(
			array(
				'linha' => 'Optima YellowTop',
				'amperagem' => '55–75 Ah (conforme modelo)',
				'carrosCompatveis' => array(
					'Carros com som de alta potência',
					'4x4 e off-road',
					'Veículos com winch/guincho elétrico',
				),
			),
			array(
				'linha' => 'Optima RedTop',
				'amperagem' => '50 Ah (conforme modelo)',
				'carrosCompatveis' => array(
					'Carros preparados',
					'Muscle cars e clássicos',
					'Uso em competição',
				),
			),
			array(
				'linha' => 'Optima BlueTop',
				'amperagem' => '55–75 Ah (conforme modelo)',
				'carrosCompatveis' => array(
					'Barcos e jet skis',
					'Motorhomes e trailers',
					'Sistemas auxiliares 12V',
				),
			),
		),
		'ondeEUsada' => array(
			'Som automotivo de alta potência',
			'Off-road e trilha',
			'Carros preparados e clássicos',
			'Náutica e RV',
		),
		'faq' => array(
			array(
				'pergunta' => 'Para que serve a bateria Optima?',
				'resposta' => 'Para aplicações que exigem muito da bateria: som automotivo de alta potência, off-road com guincho, carros preparados e veículos que ficam parados por semanas. A SpiralCell entrega partida forte mesmo depois de longo período sem uso.',
			),
			array(
				'pergunta' => 'Qual a diferença entre YellowTop, RedTop e BlueTop?',
				'resposta' => 'RedTop é focada em partida; YellowTop combina partida e ciclo profundo (acessórios ligados com o motor desligado); BlueTop é a versão náutica/RV. Conte pra gente a sua aplicação que indicamos o modelo.',
			),
			array(
				'pergunta' => 'Vale a pena para carro comum do dia a dia?',
				'resposta' => 'Na maioria dos casos não — uma Moura ou Heliar de linha atende melhor e custa muito menos. A Optima faz sentido quando o uso é realmente severo ou o carro fica muito tempo parado.',
			),
			array(
				'pergunta' => 'Vocês têm Optima em estoque?',
				'resposta' => 'A disponibilidade varia por ser linha importada de nicho. Chame no WhatsApp com o modelo desejado que confirmamos estoque, prazo e preço na hora.',
			),
		),
	),
	array(
		'slug' => 'motobatt',
		'nome' => 'Motobatt',
		'nomeCompleto' => 'Bateria Motobatt',
		'titulo' => 'Bateria Motobatt de Moto em POA | Troca no Local',
		'descricao' => 'Bateria Motobatt AGM selada para CG, Titan, Fazer, XRE e big trail, com troca no local em Porto Alegre e região. Peça agora pelo WhatsApp.',
		'h1' => 'Bateria Motobatt: AGM de alta performance para a sua moto',
		'tagline' => 'AGM selada, pronta para instalar',
		'introParagrafos' => array(
			'A Motobatt é especialista em baterias para motocicletas. Suas baterias AGM seladas saem de fábrica ativadas, aguentam melhor a vibração do dia a dia e têm alta corrente de partida — ideal para quem usa a moto todos os dias ou depende dela para trabalhar.',
			'Na AWR você encontra bateria Motobatt para as motos mais rodadas da região — CG, Fan, Titan, Biz, Factor, Fazer, Twister, CB, XRE e big trails — com entrega e instalação no local em Porto Alegre e região metropolitana. Também trabalhamos com a linha Moura Moto.',
		),
		'destaqueCor' => 'from-orange-500 to-red-700',
		'posicionamento' => 'Especialista em motos',
		'origemFabrica' => 'Importada',
		'segmento' => 'moto',
		'beneficios' => array(
			array(
				'titulo' => 'AGM selada de fábrica',
				'descricao' => 'Sem manuseio de ácido e sem manutenção: chega ativada, pronta para instalar.',
			),
			array(
				'titulo' => 'Alta corrente de partida',
				'descricao' => 'Partida mais firme, inclusive em motos que ficam alguns dias paradas.',
			),
			array(
				'titulo' => 'Resistência a vibração',
				'descricao' => 'Construção AGM segura as placas contra a vibração constante do uso urbano e de estrada de terra.',
			),
			array(
				'titulo' => 'Cobertura ampla de modelos',
				'descricao' => 'Linha que atende da 125 de trabalho à big trail de viagem, com medidas e polaridades corretas.',
			),
		),
		'modelosPopulares' => array(
			array(
				'linha' => 'Motobatt 5Ah–7Ah',
				'amperagem' => '12V · 5–7 Ah',
				'carrosCompatveis' => array(
					'Honda CG/Fan/Titan',
					'Honda Biz/Pop',
					'Yamaha Factor/Fazer 150',
				),
			),
			array(
				'linha' => 'Motobatt 8Ah–9Ah',
				'amperagem' => '12V · 8–9 Ah',
				'carrosCompatveis' => array(
					'Yamaha Fazer 250',
					'Honda CB Twister',
					'Honda XRE 300',
					'Yamaha Lander',
				),
			),
			array(
				'linha' => 'Motobatt big trail',
				'amperagem' => '12V · 10–14 Ah',
				'carrosCompatveis' => array(
					'BMW GS',
					'Honda CB 500X',
					'Yamaha Ténéré',
					'Suzuki V-Strom',
				),
			),
		),
		'ondeEUsada' => array(
			'Motos 125–160cc de uso diário',
			'Motos de entrega',
			'250–300cc',
			'Big trail e estrada',
		),
		'faq' => array(
			array(
				'pergunta' => 'Motobatt ou Moura para moto?',
				'resposta' => 'As duas são ótimas opções. A Motobatt é especialista em motos e vem ativada de fábrica; a Moura Moto tem a maior rede de garantia do país. Confirmamos o modelo exato pela sua moto e ano.',
			),
			array(
				'pergunta' => 'A bateria Motobatt precisa de carga antes de instalar?',
				'resposta' => 'Não. As Motobatt são AGM seladas e já saem de fábrica ativadas — é instalar e usar.',
			),
			array(
				'pergunta' => 'Vocês instalam a bateria na moto?',
				'resposta' => 'Sim. Levamos a bateria até onde a moto estiver, instalamos e testamos o sistema de carga na mesma visita, em Porto Alegre e região metropolitana.',
			),
			array(
				'pergunta' => 'Qual Motobatt serve na minha moto?',
				'resposta' => 'Depende do modelo e do ano. Mande a moto e o ano pelo WhatsApp que confirmamos amperagem, medidas e polaridade antes da entrega.',
			),
		),
	),
	array(
		'slug' => 'freedom',
		'nome' => 'Freedom',
		'nomeCompleto' => 'Bateria Freedom',
		'titulo' => 'Bateria Freedom Nobreak e Solar | Pronta Entrega',
		'descricao' => 'Bateria Freedom VRLA para nobreak, solar, CFTV e telecom com pronta entrega em Porto Alegre. Trocamos o banco no local — solicite seu orçamento.',
		'h1' => 'Bateria Freedom: a estacionária para nobreak, solar e segurança',
		'tagline' => 'VRLA selada para flutuação e ciclo',
		'introParagrafos' => array(
			'A Freedom é uma das marcas mais usadas em baterias estacionárias no Brasil. A linha DF cobre de 4,5Ah a 220Ah em 12V, atendendo de nobreaks pequenos a bancos solares off-grid de grande autonomia.',
			'A AWR fornece baterias Freedom com nota fiscal para empresas, condomínios e integradores, com entrega e troca do banco no local em Porto Alegre e região metropolitana — e envio por transportadora para todo o RS, Santa Catarina, Paraná e São Paulo.',
		),
		'destaqueCor' => 'from-sky-600 to-indigo-800',
		'posicionamento' => 'Estacionária — referência nacional',
		'origemFabrica' => 'Brasil',
		'segmento' => 'estacionaria',
		'beneficios' => array(
			array(
				'titulo' => 'Linha DF completa',
				'descricao' => 'De 12V 4,5Ah (alarme e CFTV) a 12V 220Ah (bancos solares e telecom de longa autonomia).',
			),
			array(
				'titulo' => 'VRLA selada',
				'descricao' => 'Operação em ambiente interno sem manutenção de água e sem emissão de gases em uso normal.',
			),
			array(
				'titulo' => 'Flutuação e ciclo',
				'descricao' => 'Modelos próprios para ficar em flutuação no nobreak e versões de ciclo para uso solar diário.',
			),
			array(
				'titulo' => 'Troca do banco no local',
				'descricao' => 'Levamos as baterias novas, trocamos o banco e recolhemos as usadas para descarte correto.',
			),
		),
		'modelosPopulares' => array(
			array(
				'linha' => 'Freedom DF500',
				'amperagem' => '12V · 40 Ah',
				'carrosCompatveis' => array(
					'Nobreak pequeno',
					'CFTV e alarme',
					'Portão automático',
				),
			),
			array(
				'linha' => 'Freedom DF1000',
				'amperagem' => '12V · 55 Ah',
				'carrosCompatveis' => array(
					'Nobreak de rack',
					'Telecom',
					'Solar de pequeno porte',
				),
			),
			array(
				'linha' => 'Freedom DF2000',
				'amperagem' => '12V · 105 Ah',
				'carrosCompatveis' => array(
					'Banco solar off-grid',
					'Backup de longa autonomia',
					'Centrais telefônicas',
				),
			),
		),
		'ondeEUsada' => array(
			'Nobreak e UPS',
			'Energia solar off-grid',
			'CFTV, alarme e cerca elétrica',
			'Telecom e centrais telefônicas',
		),
		'faq' => array(
			array(
				'pergunta' => 'Qual Freedom usar no nobreak?',
				'resposta' => 'Depende da potência do nobreak e da autonomia desejada. Nobreaks de rack costumam usar 12V 40Ah a 55Ah; para autonomia longa, bancos com 105Ah ou mais. Dimensionamos pela carga em watts.',
			),
			array(
				'pergunta' => 'Freedom serve para energia solar?',
				'resposta' => 'Sim, em sistemas off-grid e híbridos com banco de baterias. Para uso solar diário indicamos as versões de ciclo, que aguentam mais descargas profundas.',
			),
			array(
				'pergunta' => 'Posso misturar bateria nova com usada no banco?',
				'resposta' => 'Não recomendamos. A bateria mais fraca derruba o conjunto. O correto é trocar o banco completo com unidades do mesmo modelo e idade.',
			),
			array(
				'pergunta' => 'Vocês enviam Freedom para outras cidades?',
				'resposta' => 'Sim. Enviamos por transportadora para todo o RS, SC, PR e SP, com nota fiscal e frete cotado na hora pelo WhatsApp. Pagamento via Pix.',
			),
		),
	),
	array(
		'slug' => 'global',
		'nome' => 'Global',
		'nomeCompleto' => 'Bateria Global',
		'titulo' => 'Bateria Global Estacionária em POA | Pronta Entrega',
		'descricao' => 'Bateria Global estacionária para nobreak, solar, telecom e segurança em Porto Alegre. Entrega e troca do banco no local. Peça seu orçamento.',
		'h1' => 'Bateria Global: estacionária de grande autonomia para empresas',
		'tagline' => 'Bancos de 12V para backup profissional',
		'introParagrafos' => array(
			'A Global é presença constante em bancos de baterias de médio e grande porte: nobreaks de rack, centrais telefônicas, sistemas de segurança e bancos solares. As versões de 12V em 150Ah e 220Ah são referência quando a autonomia precisa ser longa.',
			'A AWR fornece baterias Global com nota fiscal para empresas, condomínios e integradores em Porto Alegre e região metropolitana, com entrega e troca do banco no local — e envio por transportadora para todo o Sul e Sudeste.',
		),
		'destaqueCor' => 'from-slate-600 to-slate-800',
		'posicionamento' => 'Estacionária — grande autonomia',
		'origemFabrica' => 'Brasil',
		'segmento' => 'estacionaria',
		'beneficios' => array(
			array(
				'titulo' => 'Altas amperagens',
				'descricao' => 'Versões de 12V 150Ah e 220Ah para bancos de longa autonomia em telecom, indústria e solar.',
			),
			array(
				'titulo' => 'Construção VRLA',
				'descricao' => 'Seladas, próprias para sala técnica e ambiente interno, sem manutenção de água.',
			),
			array(
				'titulo' => 'Projeto de banco completo',
				'descricao' => 'Dimensionamos o banco pela carga e autonomia, incluindo ligação em série/paralelo e recolhimento das usadas.',
			),
			array(
				'titulo' => 'Condições para empresa',
				'descricao' => 'Nota fiscal em CNPJ, preço por volume e condições para compra recorrente de integradores.',
			),
		),
		'modelosPopulares' => array(
			array(
				'linha' => 'Global 12V 150Ah',
				'amperagem' => '12V · 150 Ah',
				'carrosCompatveis' => array(
					'Telecom e centrais telefônicas',
					'Banco solar médio',
					'Nobreak de longa autonomia',
				),
			),
			array(
				'linha' => 'Global 12V 220Ah',
				'amperagem' => '12V · 220 Ah',
				'carrosCompatveis' => array(
					'Banco solar off-grid grande',
					'Indústria e utilidades',
					'Backup de infraestrutura',
				),
			),
		),
		'ondeEUsada' => array(
			'Telecom e centrais telefônicas',
			'Energia solar off-grid',
			'Nobreaks de longa autonomia',
			'Segurança eletrônica',
		),
		'faq' => array(
			array(
				'pergunta' => 'Quando escolher Global 150Ah ou 220Ah?',
				'resposta' => 'Quando a autonomia exigida é alta: telecom, solar off-grid e backup de horas. Calculamos a quantidade de baterias pela carga em watts e pelo tempo de backup desejado.',
			),
			array(
				'pergunta' => 'Bateria de 220Ah é pesada — como é a entrega?',
				'resposta' => 'São baterias de mais de 60 kg. Na região metropolitana nossa equipe leva, posiciona e monta o banco. Para outras cidades, o envio é por transportadora com embalagem normatizada.',
			),
			array(
				'pergunta' => 'Vocês recolhem o banco usado?',
				'resposta' => 'Sim. Recolhemos as baterias usadas na troca e encaminhamos para reciclagem em destinação ambientalmente correta.',
			),
			array(
				'pergunta' => 'Atendem integrador e revenda?',
				'resposta' => 'Sim. Trabalhamos com integradores de solar, segurança e TI com nota em CNPJ e condições para compra recorrente.',
			),
		),
	),
	array(
		'slug' => 'moura-nobreak',
		'nome' => 'Moura Nobreak',
		'nomeCompleto' => 'Bateria Moura para Nobreak',
		'titulo' => 'Bateria Moura Nobreak em POA | Troca no Local',
		'descricao' => 'Nobreak apitando? Bateria Moura 12MVA (7Ah a 18Ah) trocada no local em Porto Alegre, com nota fiscal, garantia e recolhimento das usadas. Peça a cotação.',
		'h1' => 'Bateria Moura para nobreak: backup com a maior rede do país',
		'tagline' => 'Estacionárias 12MVA com garantia Moura',
		'introParagrafos' => array(
			'A linha estacionária Moura (12MVA, VRLA/AGM) leva para o nobreak a mesma confiabilidade que fez da Moura a líder em baterias automotivas. Cobre as amperagens mais usadas em UPS, alarme, CFTV e portão automático — de 7Ah a 18Ah.',
			'A AWR entrega e troca baterias Moura para nobreak no local em Porto Alegre e região metropolitana, com nota fiscal e recolhimento das usadas — e envia por transportadora para todo o Sul e Sudeste.',
		),
		'destaqueCor' => 'from-blue-700 to-indigo-900',
		'posicionamento' => 'Estacionária — rede nacional',
		'origemFabrica' => 'Belo Jardim/PE',
		'segmento' => 'estacionaria',
		'beneficios' => array(
			array(
				'titulo' => 'Marca de rede nacional',
				'descricao' => 'Garantia acionável na maior rede de revendedores do Brasil — segurança para empresa com filiais.',
			),
			array(
				'titulo' => 'Linha 12MVA VRLA/AGM',
				'descricao' => '12V 7Ah, 9Ah, 12Ah e 18Ah — as amperagens mais usadas em nobreak, alarme e CFTV.',
			),
			array(
				'titulo' => 'Jogos completos',
				'descricao' => 'Fornecemos jogos com 2, 4 ou mais unidades do mesmo lote para nobreaks de 24V, 36V e 48V.',
			),
			array(
				'titulo' => 'Troca com recolhimento',
				'descricao' => 'Substituímos as baterias do nobreak no local e levamos as usadas para descarte correto.',
			),
		),
		'modelosPopulares' => array(
			array(
				'linha' => 'Moura 12MVA-7',
				'amperagem' => '12V · 7 Ah',
				'carrosCompatveis' => array(
					'Nobreak doméstico',
					'Alarme residencial',
					'CFTV pequeno',
				),
			),
			array(
				'linha' => 'Moura 12MVA-9',
				'amperagem' => '12V · 9 Ah',
				'carrosCompatveis' => array(
					'Nobreak de escritório',
					'Central de alarme',
					'Portão automático',
				),
			),
			array(
				'linha' => 'Moura 12MVA-18',
				'amperagem' => '12V · 18 Ah',
				'carrosCompatveis' => array(
					'Nobreak de rack pequeno',
					'UPS de maior autonomia',
					'Segurança eletrônica',
				),
			),
		),
		'linhas' => array(
			array(
				'nome' => 'Moura 12MVA 7Ah e 9Ah',
				'uso' => 'Nobreak doméstico, alarme, portão e CFTV pequeno',
				'amperagens' => '12V · 7Ah e 9Ah',
				'destaque' => 'As duas amperagens que saem mais — normalmente entregamos no mesmo dia.',
			),
			array(
				'nome' => 'Moura 12MVA 12Ah e 18Ah',
				'uso' => 'Nobreak de rack, UPS de maior autonomia e segurança eletrônica',
				'amperagens' => '12V · 12Ah e 18Ah',
				'destaque' => 'Mais tempo de autonomia sem trocar o equipamento.',
			),
			array(
				'nome' => 'Jogos em série (24V, 36V e 48V)',
				'uso' => 'Nobreak e UPS com banco de 2, 4 ou mais baterias',
				'amperagens' => 'Conforme o equipamento',
				'destaque' => 'Fornecemos unidades do mesmo lote e trocamos o banco inteiro no local.',
			),
		),
		'ondeEUsada' => array(
			'Nobreak e UPS',
			'Alarme e CFTV',
			'Portão automático',
			'Iluminação de emergência',
		),
		'faq' => array(
			array(
				'pergunta' => 'Qual bateria Moura usar no meu nobreak?',
				'resposta' => 'Abra o compartimento e confira a amperagem atual (7Ah, 9Ah, 12Ah ou 18Ah) e quantas unidades o nobreak usa. Mande uma foto pelo WhatsApp que identificamos o modelo certo.',
			),
			array(
				'pergunta' => 'Meu nobreak usa 2 ou 4 baterias — vocês vendem o jogo?',
				'resposta' => 'Sim. Fornecemos jogos com 2, 4 ou mais unidades do mesmo lote, que é o correto para nobreaks de 24V, 36V e 48V.',
			),
			array(
				'pergunta' => 'Posso trocar só uma bateria do nobreak?',
				'resposta' => 'Não recomendamos. Em banco em série, a unidade mais fraca sobrecarrega as novas. O ideal é trocar o jogo completo.',
			),
			array(
				'pergunta' => 'Vocês trocam a bateria no local?',
				'resposta' => 'Sim, em Porto Alegre e região metropolitana trocamos no local e recolhemos as usadas. Para outras cidades, enviamos por transportadora com nota fiscal.',
			),
			array(
				'pergunta' => 'Emitem nota fiscal em CNPJ para empresa?',
				'resposta' => 'Sim. Emitimos nota fiscal em CNPJ ou CPF e enviamos cotação formal por e-mail ou WhatsApp, com prazo de entrega e condição de pagamento.',
			),
		),
	),
);
