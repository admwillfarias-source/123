<?php
/** Gerado de assets/data/google-reviews.json — não editar. */
return array(
	'rating' => array(
		'averageRating' => 4.9,
		'totalReviews' => 1935,
	),
	'reviews' => array(
		array(
			'author' => 'Paulo Ricardo Maurina Müller',
			'rating' => 5,
			'date' => 'há 2 dias',
			'text' => 'Fui hoje meio dia e fui muito bem atendido e rapidamente pelo Renan (se nao me engano era esse o nome) honestidade e servico bem feito. Recomendo',
		),
		array(
			'author' => 'Conrado Gerber',
			'rating' => 5,
			'date' => 'há 1 semana',
			'text' => 'Muito Bom Atendimento, rápido e fácil! Montador teve toda paciência e experiência em desmontar o local da BMW que não era de fácil acesso! Nota 10',
		),
		array(
			'author' => 'Elisete Braga',
			'rating' => 5,
			'date' => 'há 2 semanas',
			'text' => 'Retorno rápido pelo watts, isso já vale as 5 estrelas! 😄 Precisei várias vezes e em todas o atendimento realizado foi muito satisfatório. Super recomendo! 🙌',
		),
	),
);
