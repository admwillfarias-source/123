<?php
/** Gerado de assets/data/categorias-seo.json — não editar. */
return array(
	array(
		'slug' => 'baterias-agm',
		'titulo' => 'Bateria AGM 60Ah, 70Ah, 80Ah e 92Ah | AWR Baterias',
		'descricao' => 'Bateria AGM Moura e Heliar de 60Ah, 70Ah, 80Ah e 92Ah para carros Start-Stop. Preço com nota fiscal, garantia de fábrica e entrega com instalação em Porto Alegre e região.',
		'h1' => 'Bateria AGM: 60Ah, 70Ah, 80Ah e 92Ah para carros Start-Stop',
		'subtitulo' => 'AGM Moura e Heliar com nota fiscal, garantia de fábrica e instalação no local.',
		'intro' => 'A bateria AGM (Absorbent Glass Mat) é a tecnologia indicada para veículos com Start-Stop, freio regenerativo e muita eletrônica embarcada. Ela suporta ciclos de carga e descarga muito mais agressivos que uma bateria comum e não pode ser substituída por uma chumbo-ácido convencional sem perder o sistema Start-Stop. Na AWR você encontra bateria AGM 60Ah, AGM 70, AGM 80Ah e AGM 92Ah das linhas Moura e Heliar, com preço à vista no Pix, 10x sem juros e entrega com instalação em Porto Alegre e região metropolitana.',
		'keywords' => array(
			'bateria agm',
			'bateria agm 60ah',
			'bateria agm 60 amperes',
			'bateria agm 60 heliar',
			'bateria agm 60 creta',
			'bateria agm 60 creta preço',
			'bateria agm 70',
			'bateria agm 80',
			'bateria agm 80ah',
			'bateria agm 80ah heliar',
			'bateria agm 92ah',
			'bateria agm60l-din',
			'bateria moura agm',
			'bateria moura agm 60ah',
			'bateria moura agm 60 amperes',
			'bateria heliar agm 60ah',
			'bateria heliar agm 70ah - hagm70pd',
			'bateria heliar agm 80ah - hagm80kd',
			'bateria heliar ag80kd',
		),
		'selos' => array(
			'Start-Stop original',
			'Garantia de fábrica',
			'Instalação no local',
			'10x sem juros',
		),
		'blocos' => array(
			array(
				'h2' => 'Quando o carro exige bateria AGM',
				'p' => 'Se o seu veículo desliga o motor no semáforo e religa sozinho, ele usa AGM ou EFB de fábrica. Carros como Hyundai Creta, Jeep Compass e Renegade Start-Stop, Fiat Toro, Argo e Cronos Start-Stop, Duster 2021/2022 e a maioria dos importados exigem AGM quando saíram assim de fábrica. Instalar uma bateria comum nesses carros reduz a vida útil da peça e pode acender luz de falha no painel.',
			),
			array(
				'h2' => 'AGM 60Ah, 70Ah, 80Ah ou 92Ah: qual escolher',
				'p' => 'A escolha segue a ficha do fabricante do veículo, não o preço. A AGM 60Ah atende hatches e SUVs compactos Start-Stop (Creta, Argo, Renegade). A AGM 70Ah cobre SUVs médios e picapes. A AGM 80Ah é a mais pedida para Compass, Toro e importados com muitos acessórios. A AGM 92Ah atende utilitários e veículos com som, inversor ou equipamento embarcado.',
			),
			array(
				'h2' => 'Preço da bateria AGM e forma de pagamento',
				'p' => 'O preço da AGM varia conforme amperagem e marca. Trabalhamos com Pix à vista com desconto, cartão em 10x sem juros e desconto na entrega da bateria velha (base de troca). Todas saem com nota fiscal em CPF ou CNPJ e garantia de fábrica.',
			),
		),
		'modelos' => array(
			array(
				'nome' => 'Heliar AGM 60Ah (HAGM60HD)',
				'spec' => '60Ah · AGM · Start-Stop',
				'aplicacao' => 'Creta, Argo, Cronos, Renegade Start-Stop',
			),
			array(
				'nome' => 'Heliar AGM 70Ah (HAGM70PD)',
				'spec' => '70Ah · AGM · Start-Stop',
				'aplicacao' => 'SUVs médios e picapes',
			),
			array(
				'nome' => 'Heliar AGM 80Ah (HAGM80KD)',
				'spec' => '80Ah · AGM · Start-Stop',
				'aplicacao' => 'Compass, Toro, importados',
			),
			array(
				'nome' => 'Moura AGM 60Ah',
				'spec' => '60Ah · AGM · Start-Stop',
				'aplicacao' => 'Linha nacional Start-Stop',
			),
			array(
				'nome' => 'AGM 92Ah',
				'spec' => '92Ah · AGM',
				'aplicacao' => 'Utilitários e veículos com acessórios',
			),
		),
		'faq' => array(
			array(
				'p' => 'Posso trocar a bateria AGM por uma comum?',
				'r' => 'Não é recomendado. O carro Start-Stop faz muito mais ciclos de partida e a bateria comum se degrada em poucos meses, além de o sistema Start-Stop parar de funcionar. O correto é manter AGM (ou EFB, quando for o original).',
			),
			array(
				'p' => 'Qual a diferença entre AGM e EFB?',
				'r' => 'A EFB é uma bateria de chumbo-ácido reforçada, indicada para Start-Stop de entrada. A AGM tem eletrólito absorvido em manta de fibra de vidro, aguenta mais ciclos e é usada em Start-Stop com freio regenerativo. Um carro que veio com AGM não pode usar EFB; um carro que veio com EFB pode receber AGM.',
			),
			array(
				'p' => 'Qual o preço da bateria AGM 60 para o Creta?',
				'r' => 'Depende da marca e da versão do Creta. Envie a placa ou o ano do veículo pelo WhatsApp que devolvemos o preço fechado, já com instalação e desconto na base de troca.',
			),
			array(
				'p' => 'A AGM precisa de programação após a troca?',
				'r' => 'Em vários modelos sim: o módulo precisa reconhecer a bateria nova. Nossa equipe faz o reset/registro quando o veículo exige.',
			),
		),
		'waMsg' => 'Olá! Quero preço de bateria AGM. Meu carro é:',
	),
	array(
		'slug' => 'baterias-efb-start-stop',
		'titulo' => 'Bateria EFB Start-Stop 50Ah, 60Ah, 72Ah e 80Ah | AWR',
		'descricao' => 'Bateria EFB Start-Stop Moura e Heliar: 50Ah, 60Ah, 72Ah (HFB72PD) e 80Ah (MF80CD). Preço com nota fiscal, garantia e instalação em Porto Alegre e região.',
		'h1' => 'Bateria EFB Start-Stop: 50Ah, 60Ah, 72Ah e 80Ah',
		'subtitulo' => 'Moura EFB e Heliar EFB com garantia de fábrica e instalação grátis na região metropolitana.',
		'intro' => 'A bateria EFB (Enhanced Flooded Battery) é a versão reforçada da bateria convencional, desenvolvida para veículos com sistema Start-Stop de entrada. Ela aguenta cerca de três vezes mais ciclos que uma bateria comum e é o item original de carros como Fiat Toro, Argo e Cronos Start-Stop, Jeep Renegade, Compass, Hyundai Creta e Renault Duster. Aqui você encontra EFB 50Ah, EFB 60Ah, EFB 72Ah e EFB 80Ah das linhas Moura e Heliar, com nota fiscal, garantia de fábrica e instalação feita por técnico.',
		'keywords' => array(
			'bateria efb',
			'bateria efb preço',
			'bateria efb 50ah',
			'bateria efb 60ah',
			'bateria efb 60ah preço',
			'bateria efb 60ah moura',
			'bateria efb 60ah heliar',
			'bateria efb 80ah',
			'bateria efb 80 amperes',
			'bateria efb 80ah start stop',
			'bateria efb moura start stop 12v 80ah mf80cd',
			'bateria efb heliar start stop 12v 72ah hfb72pd',
			'bateria moura efb',
			'bateria moura efb 50ah',
			'bateria moura efb 60ah',
			'bateria moura efb 80ah',
			'bateria heliar efb 50ah',
			'bateria heliar efb 60ah - hefb60hd',
			'bateria hefb60hd',
			'bateria mf80cd',
			'bateria moura 72a start stop/efb mf72ld',
			'bateria start stop toro',
			'bateria para toro start stop',
			'bateria renegade start stop',
			'bateria renegade start stop preço',
			'bateria jeep renegade start stop',
			'bateria jeep compass start stop',
			'bateria fiat argo start stop',
			'bateria argo start stop',
			'bateria fiat cronos start stop',
			'bateria creta 1.6 start stop preço',
			'bateria duster 2021 start stop',
			'bateria duster 2022 start stop',
			'bateria heliar start stop',
			'bateria moura 80 amperes start stop preço',
		),
		'selos' => array(
			'Original de fábrica',
			'3x mais ciclos',
			'Instalação no local',
			'Nota fiscal',
		),
		'blocos' => array(
			array(
				'h2' => 'Quais carros usam bateria EFB',
				'p' => 'Fiat Toro, Argo, Cronos e Pulse Start-Stop, Jeep Renegade e Compass, Hyundai Creta, Renault Duster 2021 e 2022, Chevrolet Onix Plus Start-Stop e boa parte dos SUVs nacionais saem de fábrica com EFB. Nesses veículos a EFB é o mínimo aceitável: colocar uma bateria comum derruba o Start-Stop e reduz a vida útil da peça.',
			),
			array(
				'h2' => 'Modelos EFB mais vendidos',
				'p' => 'A Heliar EFB 60Ah (HEFB60HD) e a Heliar EFB 72Ah (HFB72PD) cobrem a maior parte dos SUVs Start-Stop. A Moura EFB 60Ah atende Argo, Cronos e Creta, e a Moura EFB 80Ah (MF80CD) é a indicada para Compass, Toro diesel e utilitários com muita eletrônica. A Moura MF72LD atende os 72A Start-Stop.',
			),
			array(
				'h2' => 'Instalação e registro do módulo',
				'p' => 'Em carro Start-Stop a troca não termina no aperto do terminal: o módulo precisa reconhecer a bateria nova para gerenciar a carga corretamente. Fazemos a instalação com manutenção de memória e o registro quando o veículo exige, tudo incluso no serviço.',
			),
		),
		'modelos' => array(
			array(
				'nome' => 'Heliar EFB 60Ah (HEFB60HD)',
				'spec' => '60Ah · EFB',
				'aplicacao' => 'Creta, Argo, Cronos, Onix Plus',
			),
			array(
				'nome' => 'Heliar EFB 72Ah (HFB72PD)',
				'spec' => '72Ah · EFB',
				'aplicacao' => 'SUVs e picapes Start-Stop',
			),
			array(
				'nome' => 'Moura EFB 60Ah',
				'spec' => '60Ah · EFB',
				'aplicacao' => 'Linha nacional Start-Stop',
			),
			array(
				'nome' => 'Moura MF72LD',
				'spec' => '72Ah · EFB',
				'aplicacao' => 'Start-Stop 72A',
			),
			array(
				'nome' => 'Moura MF80CD',
				'spec' => '80Ah · EFB',
				'aplicacao' => 'Compass, Toro diesel, utilitários',
			),
			array(
				'nome' => 'Heliar EFB 50Ah',
				'spec' => '50Ah · EFB',
				'aplicacao' => 'Hatches Start-Stop de entrada',
			),
		),
		'faq' => array(
			array(
				'p' => 'Qual o preço da bateria EFB 60Ah?',
				'r' => 'Varia conforme a marca (Moura ou Heliar) e o veículo. Envie o modelo e o ano pelo WhatsApp que devolvemos o valor fechado com instalação e desconto na base de troca.',
			),
			array(
				'p' => 'Posso colocar EFB no lugar de AGM?',
				'r' => 'Não. O caminho só funciona no sentido contrário: quem usa EFB pode receber AGM, mas quem veio com AGM não deve receber EFB.',
			),
			array(
				'p' => 'A bateria EFB dura mais que a comum?',
				'r' => 'Sim. A EFB é projetada para cerca de três vezes mais ciclos de partida, justamente porque o Start-Stop liga e desliga o motor dezenas de vezes por dia.',
			),
			array(
				'p' => 'Vocês instalam bateria de Start-Stop no local?',
				'r' => 'Sim, em Porto Alegre e região metropolitana a instalação é feita por técnico no endereço do cliente, sem custo adicional.',
			),
		),
		'waMsg' => 'Olá! Meu carro é Start-Stop e preciso de bateria EFB. Modelo:',
	),
	array(
		'slug' => 'baterias-nauticas',
		'titulo' => 'Bateria Náutica Moura Boat 100Ah, 150Ah e 220Ah | AWR',
		'descricao' => 'Bateria náutica Moura Boat de 100Ah, 150Ah e 220Ah para barcos, lanchas e motores de popa. Nota fiscal, garantia de fábrica e envio para todo o Sul.',
		'h1' => 'Bateria náutica Moura Boat: 100Ah, 150Ah e 220Ah',
		'subtitulo' => 'Para barcos, lanchas, motores de popa e motor elétrico de arrasto.',
		'intro' => 'A bateria náutica é construída para dois trabalhos diferentes do carro: dar partida no motor de popa e sustentar horas de consumo com sonar, rádio, luzes e motor elétrico. A linha Moura Boat usa placas mais grossas e maior resistência à vibração e à umidade, condição normal em barco. Trabalhamos com bateria náutica 100Ah, 150Ah e 220Ah, com nota fiscal, garantia de fábrica e envio por transportadora para o Rio Grande do Sul, Santa Catarina, Paraná e São Paulo.',
		'keywords' => array(
			'bateria nautica',
			'bateria náutica',
			'bateria nautica 100ah',
			'bateria náutica 100ah',
			'bateria nautica 150ah',
			'bateria nautica moura',
			'bateria náutica moura',
			'bateria moura nautica',
			'bateria moura nautica 150 amperes',
			'bateria moura boat',
			'bateria moura boat 150ah',
			'bateria moura boat 220ah',
		),
		'selos' => array(
			'Linha Moura Boat',
			'Alta resistência à vibração',
			'Nota fiscal',
			'Envio para todo o Sul',
		),
		'blocos' => array(
			array(
				'h2' => 'Qual amperagem escolher para o seu barco',
				'p' => 'A 100Ah atende barcos de pesca com motor de popa e consumo leve (sonar e luzes). A 150Ah é a escolha mais comum para lanchas e para quem usa motor elétrico de arrasto por várias horas. A 220Ah é indicada para embarcações maiores, som, geladeira de bordo e uso de dia inteiro sem recarga.',
			),
			array(
				'h2' => 'Bateria náutica x bateria automotiva',
				'p' => 'A automotiva é feita para entregar uma corrente alta por poucos segundos e voltar a ser carregada pelo alternador. Em barco, a bateria passa horas descarregando devagar. A náutica tem placas mais espessas para suportar esse ciclo profundo e separadores reforçados para vibração — usar automotiva em barco derruba a vida útil rapidamente.',
			),
			array(
				'h2' => 'Cuidados que dobram a vida útil',
				'p' => 'Mantenha os terminais limpos e protegidos contra maresia, recarregue após cada uso prolongado e evite deixar a bateria descarregada durante o inverno. Se a embarcação fica parada, um carregador flutuante mantém a carga e evita sulfatação.',
			),
		),
		'modelos' => array(
			array(
				'nome' => 'Moura Boat 100Ah',
				'spec' => '12V · 100Ah · ciclo profundo',
				'aplicacao' => 'Barcos de pesca, sonar e luzes',
			),
			array(
				'nome' => 'Moura Boat 150Ah',
				'spec' => '12V · 150Ah · ciclo profundo',
				'aplicacao' => 'Lanchas e motor elétrico de arrasto',
			),
			array(
				'nome' => 'Moura Boat 220Ah',
				'spec' => '12V · 220Ah · ciclo profundo',
				'aplicacao' => 'Embarcações maiores e consumo alto',
			),
		),
		'faq' => array(
			array(
				'p' => 'Vocês entregam bateria náutica fora de Porto Alegre?',
				'r' => 'Sim. Enviamos por transportadora para RS, SC, PR e SP, com nota fiscal e garantia de fábrica. O frete é cotado na hora pelo WhatsApp conforme o CEP.',
			),
			array(
				'p' => 'Qual a garantia da bateria náutica Moura?',
				'r' => 'Garantia de fábrica Moura, válida em rede nacional. O prazo exato varia por modelo e é informado na nota fiscal.',
			),
			array(
				'p' => 'Posso usar a náutica também para dar partida?',
				'r' => 'Sim, a linha Moura Boat é dual: entrega corrente de partida para o motor de popa e sustenta consumo contínuo de acessórios.',
			),
		),
		'waMsg' => 'Olá! Quero preço de bateria náutica Moura Boat. Amperagem:',
	),
	array(
		'slug' => 'baterias-tracionarias',
		'titulo' => 'Bateria Tracionária 6V e 12V 130Ah | AWR Baterias',
		'descricao' => 'Bateria tracionária 6V e 12V 130Ah para empilhadeira, plataforma elevatória, carrinho de golfe e máquinas de limpeza. Nota fiscal, garantia e envio para todo o Sul.',
		'h1' => 'Bateria tracionária 6V e 12V 130Ah',
		'subtitulo' => 'Ciclo profundo para empilhadeira, plataforma elevatória, carrinho de golfe e lavadora industrial.',
		'intro' => 'A bateria tracionária foi feita para descarregar fundo e recarregar todos os dias, jornada típica de empilhadeira, transpaleteira, plataforma elevatória, carrinho de golfe e máquina de limpeza industrial. Diferente da automotiva, ela tem placas planas espessas e suporta centenas de ciclos profundos sem perder capacidade. Trabalhamos com tracionária 6V para bancos em série e 12V 130Ah para equipamentos compactos, com nota fiscal em CNPJ, garantia de fábrica e condição especial para frota.',
		'keywords' => array(
			'bateria tracionaria',
			'bateria tracionaria 6v',
			'bateria tracionaria 12v 130ah',
		),
		'selos' => array(
			'Ciclo profundo',
			'Nota fiscal em CNPJ',
			'Condição para frota',
			'Garantia de fábrica',
		),
		'blocos' => array(
			array(
				'h2' => '6V em banco ou 12V direto',
				'p' => 'Empilhadeiras e plataformas de maior porte usam vários blocos de 6V ligados em série, formando 24V, 36V ou 48V. Equipamentos compactos, carrinhos e algumas lavadoras trabalham com módulos de 12V 130Ah. Informe a tensão do equipamento e a caixa disponível que indicamos a montagem correta.',
			),
			array(
				'h2' => 'Por que não usar bateria automotiva',
				'p' => 'A automotiva perde capacidade em poucas semanas quando descarregada abaixo de 50% todos os dias. A tracionária é construída para exatamente esse regime, com placas espessas e liga de chumbo-antimônio que resiste ao ciclo diário.',
			),
			array(
				'h2' => 'Manutenção e carregador correto',
				'p' => 'Use carregador dimensionado para a tensão do banco, complete o nível com água desmineralizada quando o modelo exigir e evite recargas parciais frequentes. Manutenção correta é o que separa dois anos de cinco anos de uso.',
			),
		),
		'modelos' => array(
			array(
				'nome' => 'Tracionária 6V',
				'spec' => '6V · ciclo profundo',
				'aplicacao' => 'Bancos 24V, 36V e 48V de empilhadeira',
			),
			array(
				'nome' => 'Tracionária 12V 130Ah',
				'spec' => '12V · 130Ah · ciclo profundo',
				'aplicacao' => 'Plataformas, carrinhos e lavadoras',
			),
		),
		'faq' => array(
			array(
				'p' => 'Vocês vendem para empresa com nota em CNPJ?',
				'r' => 'Sim. Emitimos nota fiscal em CNPJ, atendemos frota e fazemos condição especial para reposição de banco completo.',
			),
			array(
				'p' => 'Qual a diferença entre tracionária e estacionária?',
				'r' => 'A estacionária fica em flutuação e só entrega energia quando falta luz (nobreak, solar). A tracionária é descarregada profundamente todos os dias e recarregada à noite.',
			),
			array(
				'p' => 'Entregam fora de Porto Alegre?',
				'r' => 'Sim, enviamos por transportadora para RS, SC, PR e SP, com frete cotado conforme o peso do banco.',
			),
		),
		'waMsg' => 'Olá! Preciso de bateria tracionária. Equipamento e tensão:',
	),
	array(
		'slug' => 'bateria-perto-de-mim',
		'titulo' => 'Bateria de Carro Perto de Mim, Aberto Agora | AWR POA',
		'descricao' => 'Bateria automotiva perto de você com entrega e instalação hoje em Porto Alegre e região. Plantão até as 22h, pagamento na entrega e garantia de fábrica.',
		'h1' => 'Bateria de carro perto de mim, com entrega agora',
		'subtitulo' => 'Carro parado? Chegamos com a bateria e instalamos no local, em Porto Alegre e região metropolitana.',
		'intro' => 'Quando o carro não liga, o que resolve não é procurar loja aberta e sim ter a bateria chegando até você. A AWR entrega e instala bateria automotiva em Porto Alegre, Canoas, São Leopoldo, Novo Hamburgo, Gravataí, Cachoeirinha, Alvorada, Viamão, Esteio e Sapucaia do Sul, com técnico que faz o teste do alternador na hora e pagamento feito na entrega. Em Porto Alegre há plantão das 06:30 às 22h, inclusive fins de semana e feriados.',
		'keywords' => array(
			'bateria perto de mim',
			'bateria perto de mim abertos agora',
			'bateria de carro perto de mim',
			'bateria de carro perto de mim abertos agora',
			'bateria carro perto de mim',
			'bateria automotiva perto de mim',
			'bateria automotiva por perto',
			'bateria de carro por perto',
			'bateria moura perto de mim',
			'bateria agora',
			'bateria entrega rapida',
			'bateria 24 horas',
			'bateria moura 24 horas',
			'bateria moto 24 horas',
			'bateria 60 amperes perto de mim',
		),
		'selos' => array(
			'Chegamos até você',
			'Plantão até 22h em POA',
			'Instalação grátis',
			'Pague na entrega',
		),
		'blocos' => array(
			array(
				'h2' => 'Como funciona o atendimento de urgência',
				'p' => 'Você manda o modelo e o ano do carro pelo WhatsApp (ou a placa), confirmamos a bateria certa e o preço fechado, e o técnico sai com a peça. Em Porto Alegre a chegada é em cerca de 35 minutos; nas cidades vizinhas o prazo varia de 40 a 60 minutos conforme a distância da loja.',
			),
			array(
				'h2' => 'Horários e plantão',
				'p' => 'As lojas atendem em horário comercial. Em Porto Alegre há plantão das 06:30 às 22h todos os dias, incluindo fins de semana e feriados, com taxa de R$ 60 nos horários de plantão (06:30–08:30 e 18:01–22:00). Das 08:31 às 18h a entrega é grátis.',
			),
			array(
				'h2' => 'O que já vem incluso',
				'p' => 'Instalação feita por técnico, teste do alternador e do sistema de carga, descarte correto da bateria velha com desconto na base de troca, nota fiscal e garantia de fábrica de 12 a 24 meses conforme a linha.',
			),
		),
		'modelos' => array(),
		'faq' => array(
			array(
				'p' => 'Vocês têm loja aberta agora perto de mim?',
				'r' => 'Mais rápido que ir até a loja é receber em casa: em Porto Alegre entregamos e instalamos com plantão das 06:30 às 22h, todos os dias. Se preferir retirar, temos unidades em Porto Alegre (Medianeira e Petrópolis), Canoas, Gravataí, São Leopoldo e Novo Hamburgo.',
			),
			array(
				'p' => 'Quanto tempo demora para chegar?',
				'r' => 'Cerca de 35 minutos em Porto Alegre e de 40 a 60 minutos nas demais cidades da região metropolitana, dentro do horário de atendimento.',
			),
			array(
				'p' => 'Posso pagar na entrega?',
				'r' => 'Sim. Aceitamos Pix (com desconto), cartão em até 10x sem juros e dinheiro, tudo no momento da instalação.',
			),
			array(
				'p' => 'Atendem bateria de moto também?',
				'r' => 'Sim, trabalhamos com a linha de moto Moura e Heliar, incluindo modelos selados como MTX9A e HTZ5L.',
			),
		),
		'waMsg' => 'Olá! Meu carro está parado e preciso de bateria agora. Estou em:',
	),
	array(
		'slug' => 'moura-ou-heliar',
		'titulo' => 'Moura ou Heliar: Qual a Melhor Bateria? | AWR Baterias',
		'descricao' => 'Comparativo Moura x Heliar x Zetta x Excell: garantia, preço, tecnologia e para qual carro cada marca é indicada. Guia da AWR Baterias, distribuidora oficial.',
		'h1' => 'Moura ou Heliar: qual bateria escolher para o seu carro',
		'subtitulo' => 'Comparativo honesto de garantia, tecnologia e preço entre Moura, Heliar, Zetta e Excell.',
		'intro' => 'Moura e Heliar são as duas marcas líderes do mercado brasileiro e as duas são primeira linha — a diferença está no tipo de carro e no tipo de uso. Como distribuidora oficial das duas, a AWR não tem preferência comercial: recomendamos a que combina com o seu veículo. Abaixo você vê garantia, tecnologia, indicação por perfil de uso e onde entram as linhas de custo-benefício Zetta e Excell.',
		'keywords' => array(
			'bateria heliar ou moura',
			'bateria moura valor',
			'bateria moura preço',
			'bateria heliar preço',
			'bateria excell é boa',
			'bateria excell preço',
			'bateria global é boa',
			'bateria global',
			'bateria heliar original',
			'bateria alta performance',
			'bateria zetta',
			'bateria eletran',
		),
		'selos' => array(
			'Distribuidora oficial',
			'Garantia de fábrica',
			'Comparativo técnico',
			'Melhor preço da região',
		),
		'blocos' => array(
			array(
				'h2' => 'Moura: líder de mercado e maior garantia',
				'p' => 'A Moura é fornecedora original de VW, Fiat, GM e Ford, tem a maior rede de atendimento do país e chega a 24 meses de garantia nas linhas superiores. É a escolha mais segura para carro nacional, uso urbano pesado e quem quer tranquilidade de assistência em viagem.',
			),
			array(
				'h2' => 'Heliar: tecnologia Clarios para carro moderno',
				'p' => 'A Heliar é da Clarios (ex-Johnson Controls), original de BMW, Audi, Mercedes e VW Premium. Tem o melhor portfólio AGM e EFB do país e é a indicação técnica para importados, veículos com muita eletrônica e Start-Stop. Garantia típica de 15 a 18 meses conforme a linha.',
			),
			array(
				'h2' => 'Zetta e Excell: quando o custo-benefício faz sentido',
				'p' => 'A Zetta é fabricada pelo Grupo Moura na mesma plataforma da linha top, com preço menor e 12 meses de garantia — é a mais vendida para Uber e 99. A Excell atende quem precisa do menor preço com nota fiscal e garantia, em carro popular de uso leve. Em nenhum dos dois casos indicamos essas linhas para Start-Stop.',
			),
			array(
				'h2' => 'Resumo rápido por perfil',
				'p' => 'Carro nacional de uso diário: Moura. Importado, Start-Stop ou muita eletrônica: Heliar AGM/EFB. Aplicativo e alta quilometragem com orçamento apertado: Zetta. Carro popular de uso leve: Excell. Em todos os casos a instalação e o teste do alternador são feitos por técnico.',
			),
		),
		'modelos' => array(
			array(
				'nome' => 'Moura',
				'spec' => 'Até 24 meses de garantia',
				'aplicacao' => 'Carro nacional, uso urbano pesado',
			),
			array(
				'nome' => 'Heliar',
				'spec' => 'Tecnologia Clarios · AGM e EFB',
				'aplicacao' => 'Importados e Start-Stop',
			),
			array(
				'nome' => 'Zetta',
				'spec' => '12 meses · Grupo Moura',
				'aplicacao' => 'Uber, 99 e alta rodagem',
			),
			array(
				'nome' => 'Excell',
				'spec' => 'Linha de entrada com NF',
				'aplicacao' => 'Carro popular de uso leve',
			),
		),
		'faq' => array(
			array(
				'p' => 'Qual bateria dura mais, Moura ou Heliar?',
				'r' => 'Nas mesmas condições de uso a durabilidade é equivalente. O que muda é a garantia (Moura chega a 24 meses) e a adequação técnica: Heliar tem portfólio AGM/EFB mais amplo para Start-Stop e importados.',
			),
			array(
				'p' => 'A bateria Excell é boa?',
				'r' => 'É uma linha de entrada com nota fiscal e garantia, adequada para carro popular de uso leve. Para Start-Stop, uso intenso de aplicativo ou carro com muita eletrônica, indicamos Moura, Heliar ou Zetta.',
			),
			array(
				'p' => 'A bateria Global é boa?',
				'r' => 'Não trabalhamos com essa linha. Nosso portfólio é Moura, Heliar, Zetta, Excell e Eletran, todas com nota fiscal e garantia de fábrica rastreável.',
			),
			array(
				'p' => 'Qual o valor da bateria Moura hoje?',
				'r' => 'O preço depende da amperagem e do modelo do carro. A partir de R$ 329 (60Ah Eletra) na linha de entrada; para o valor exato da Moura do seu veículo, envie modelo e ano pelo WhatsApp.',
			),
		),
		'waMsg' => 'Olá! Quero ajuda para escolher entre Moura e Heliar. Meu carro é:',
	),
);
