<?php
/** Gerado de assets/data/aplicacoes.json — não editar. */
return array(
	array(
		'slug' => 'uber',
		'nome' => 'Uber e 99',
		'titulo' => 'Bateria para Uber e 99 em Porto Alegre | Troca em 35 min',
		'descricao' => 'Bateria para motorista de Uber e 99 em Porto Alegre. Modelos resistentes a partidas frequentes, 12-18 meses de garantia, entrega no local em 35 min.',
		'h1' => 'Bateria para Uber e 99: rode tranquilo, sem perder corrida',
		'tagline' => 'Aguenta a rotina de quem roda 10h por dia',
		'intro' => array(
			'Quem roda de Uber ou 99 sabe: a bateria de carro de aplicativo sofre muito mais que a de uso particular. São dezenas de partidas por dia, ar-condicionado ligado direto, GPS, carregador de celular, sistema de som — tudo isso desgasta a bateria em ritmo acelerado.',
			'A AWR Baterias atende motoristas de aplicativo em Porto Alegre todos os dias. Selecionamos abaixo os modelos que melhor performam nessa rotina, com troca em até 35 minutos no local onde o carro estiver.',
		),
		'porqueImporta' => array(
			'Mais de 60 partidas por dia (vs. 4-6 de um carro particular)',
			'Ar-condicionado ligado em quase 100% das corridas',
			'Carregador USB de celular puxando energia o tempo todo',
			'Tempo parado em fila de aeroporto / shopping com motor desligado',
			'Vida útil real cai para 18-24 meses (vs. 36-48 do uso normal)',
		),
		'recomendacoes' => array(
			array(
				'marca' => 'Zetta',
				'modelo' => 'Zetta 60Ah',
				'amperagem' => '60 Ah',
				'preco' => 'R$ 429',
				'ideal' => 'Gol, Onix, HB20, Argo — uso intenso, melhor custo-benefício',
			),
			array(
				'marca' => 'Moura',
				'modelo' => 'Moura 60Ah M60GD',
				'amperagem' => '60 Ah',
				'preco' => 'R$ 515',
				'ideal' => 'Quem quer 18 meses de garantia e revenda fácil',
			),
			array(
				'marca' => 'Moura',
				'modelo' => 'Moura 70Ah',
				'amperagem' => '70 Ah',
				'preco' => 'R$ 775',
				'ideal' => 'Corolla, Civic, Cronos — sedan médio rodando muito',
			),
		),
		'ondeAtende' => 'Atendemos Uber e 99 em Porto Alegre, Canoas, Gravataí, Cachoeirinha, Alvorada, Viamão, São Leopoldo e Novo Hamburgo. Vamos até onde o carro está — incluindo aeroporto Salgado Filho, rodoviária e principais corredores da cidade.',
		'faq' => array(
			array(
				'pergunta' => 'Qual a melhor bateria para Uber em 2026?',
				'resposta' => 'Para carro popular (Gol, Onix, HB20), a Zetta 60Ah oferece o melhor custo-benefício. Para quem quer mais garantia e revenda fácil, a Moura 60Ah é a escolha mais segura — paga R$ 86 a mais e leva meses extras de cobertura.',
			),
			array(
				'pergunta' => 'Quantos meses dura uma bateria de motorista de app?',
				'resposta' => 'Em uso típico de Uber/99 em Porto Alegre, a vida útil cai para 18 a 24 meses (a metade do uso particular). É efeito direto do número de partidas e do ar-condicionado ligado.',
			),
			array(
				'pergunta' => 'Posso pagar parcelado se estou rodando hoje?',
				'resposta' => 'Sim. Aceitamos cartão em até 10x sem juros e Pix com 3% de desconto. A instalação é imediata, você pode voltar a rodar em poucos minutos.',
			),
			array(
				'pergunta' => 'Vocês atendem em aeroporto e zonas de espera?',
				'resposta' => 'Sim, atendemos no aeroporto Salgado Filho, rodoviária, e em qualquer ponto da cidade. Basta nos passar a localização pelo WhatsApp.',
			),
		),
	),
	array(
		'slug' => 'caminhonete',
		'nome' => 'Caminhonete e SUV grande',
		'titulo' => 'Bateria para Caminhonete e SUV em Porto Alegre | Hilux, S10, Ranger',
		'descricao' => 'Bateria para Hilux, S10, Ranger, Frontier, Amarok e SUVs grandes em Porto Alegre. Alta amperagem para partida a frio, entrega e instalação no local.',
		'h1' => 'Bateria para caminhonete e SUV: força para partir no frio gaúcho',
		'tagline' => 'Amperagem alta para Hilux, S10, Ranger e SUV grande',
		'intro' => array(
			'Caminhonete e SUV grande precisam de bateria com amperagem mais alta — geralmente 70Ah a 100Ah — para vencer a alta compressão do motor diesel ou flex 2.0+. No inverno gaúcho, essa folga vira a diferença entre dar partida ou ficar parado.',
			'Na AWR Baterias temos estoque permanente das amperagens mais usadas para Hilux, S10, Ranger, Frontier, Amarok, Trailblazer, Pajero, SW4, Compass diesel e similares. Entrega e instalação grátis na região metropolitana de Porto Alegre.',
		),
		'porqueImporta' => array(
			'Motor diesel exige até 3x mais corrente de partida que um motor 1.0 flex',
			'Inverno gaúcho com temperaturas próximas a 0°C aumenta ainda mais essa exigência',
			'Eletrônica embarcada (multimídia, câmera 360°, ADAS) consome com motor desligado',
			'Subdimensionar a bateria reduz vida útil pela metade e estressa o alternador',
		),
		'recomendacoes' => array(
			array(
				'marca' => 'Moura',
				'modelo' => 'Moura 80Ah',
				'amperagem' => '80 Ah',
				'preco' => 'R$ 955',
				'ideal' => 'Hilux 2.7 flex, S10 2.5 flex, Ranger 2.5',
			),
			array(
				'marca' => 'Moura',
				'modelo' => 'Moura 100Ah Diesel',
				'amperagem' => '100 Ah',
				'preco' => 'R$ 985',
				'ideal' => 'Hilux 2.8 diesel, Ranger 3.2, Amarok V6, Frontier 2.3',
			),
			array(
				'marca' => 'Heliar',
				'modelo' => 'Heliar Super 90Ah',
				'amperagem' => '90 Ah',
				'preco' => 'R$ 875',
				'ideal' => 'Trailblazer, SW4, Pajero Sport, Compass diesel',
			),
		),
		'ondeAtende' => 'Atendemos caminhonete e SUV em toda a região metropolitana — Porto Alegre, Canoas, Gravataí, São Leopoldo, Novo Hamburgo. Para frota de empresa fazemos visita programada com nota fiscal em CNPJ.',
		'faq' => array(
			array(
				'pergunta' => 'Qual bateria a Hilux 2.8 diesel usa?',
				'resposta' => 'A Hilux 2.8 diesel exige bateria de 100Ah para garantir partida confiável, especialmente no inverno. Recomendamos a Moura 100Ah ou Heliar 100Ah Diesel — ambas com 18 meses de garantia.',
			),
			array(
				'pergunta' => 'Posso colocar 70Ah na minha S10?',
				'resposta' => 'Não recomendamos. A S10 sai de fábrica com 80-90Ah por um motivo: a partida do motor diesel exige essa corrente. Subdimensionar reduz a vida útil pela metade e pode falhar em manhãs frias.',
			),
			array(
				'pergunta' => 'Vocês entregam bateria de 100Ah no local?',
				'resposta' => 'Sim. A entrega e instalação no local é grátis em Porto Alegre e região, independentemente do peso ou amperagem. Levamos chave de torque adequada e descartamos a bateria velha.',
			),
			array(
				'pergunta' => 'Atendem frota de empresa com nota em CNPJ?',
				'resposta' => 'Sim. Trabalhamos com nota fiscal em CNPJ, condições de pagamento estendidas e visitas programadas para frotas de 5+ veículos. Fale com a gente pelo WhatsApp.',
			),
		),
	),
	array(
		'slug' => 'carro-popular',
		'nome' => 'Carro popular 1.0',
		'titulo' => 'Bateria para Carro Popular 1.0 em Porto Alegre | Gol, Onix, HB20',
		'descricao' => 'Bateria para Gol, Onix, HB20, Mobi, Kwid e outros 1.0 em Porto Alegre. A partir de R$ 389 com 12 meses de garantia. Entrega grátis em 35 min.',
		'h1' => 'Bateria para carro popular 1.0: o melhor preço sem perder garantia',
		'tagline' => 'Para Gol, Onix, HB20, Mobi, Kwid e Uno',
		'intro' => array(
			'Carro popular 1.0 usa bateria de 45Ah a 60Ah — o segmento mais disputado e com maior variedade de preço do mercado. A escolha entre uma Zetta de R$ 389 e uma Moura de R$ 515 pode parecer pequena, mas a diferença está na garantia (12 vs 18 meses) e na revenda no fim da vida útil.',
			'A AWR Baterias atende todos os modelos populares em Porto Alegre com entrega e instalação grátis no local. Abaixo, as opções por melhor custo-benefício.',
		),
		'porqueImporta' => array(
			'Carro popular tem alternador menos potente — bateria fraca acelera o desgaste',
			'Som potente e farol pós-venda exigem amperagem maior que a original',
			'Trocar por bateria muito barata no posto custa caro em 10-12 meses',
			'Garantia de 12+ meses cobre o pior cenário (defeito de fábrica)',
		),
		'recomendacoes' => array(
			array(
				'marca' => 'Zetta',
				'modelo' => 'Zetta 50Ah',
				'amperagem' => '50 Ah',
				'preco' => 'R$ 389',
				'ideal' => 'Gol 1.0, Mobi, Kwid, Uno 1.0 — uso casual',
			),
			array(
				'marca' => 'Zetta',
				'modelo' => 'Zetta 60Ah',
				'amperagem' => '60 Ah',
				'preco' => 'R$ 429',
				'ideal' => 'Onix, HB20, Argo, Sandero — uso diário',
			),
			array(
				'marca' => 'Moura',
				'modelo' => 'Moura 60Ah M60GD',
				'amperagem' => '60 Ah',
				'preco' => 'R$ 515',
				'ideal' => 'Quem quer 18 meses e revenda fácil',
			),
		),
		'ondeAtende' => 'Atendemos toda a região metropolitana de Porto Alegre. Carro popular é o que mais sai da AWR — temos estoque permanente das 6 lojas, entrega típica em 35 min em POA e 40-50 min em Canoas, Gravataí, São Leopoldo e Novo Hamburgo.',
		'faq' => array(
			array(
				'pergunta' => 'Qual bateria o Onix 1.0 usa?',
				'resposta' => 'O Onix 1.0 turbo usa 60Ah. Para a versão aspirada antiga (até 2019) a 50Ah resolve, mas recomendamos 60Ah para folga em dia frio e som potente.',
			),
			array(
				'pergunta' => 'Bateria de R$ 320 do posto vale a pena?',
				'resposta' => 'Em geral não. São baterias remanufaturadas ou de marca sem garantia regional. Em 8-12 meses estão fora — você gasta mais somando as duas trocas do que comprando uma Zetta de R$ 389 com 12 meses de cobertura.',
			),
			array(
				'pergunta' => 'Quanto custa a bateria do Gol 1.0?',
				'resposta' => 'Para Gol 1.0 até 2023, a Zetta 50Ah sai por R$ 389 com instalação grátis no local. Para Gol 1.0 MSI (mais novo) recomendamos 60Ah — R$ 429 na Zetta ou R$ 515 na Moura.',
			),
			array(
				'pergunta' => 'Vocês trocam no local mesmo para carro popular?',
				'resposta' => 'Sim. Mesmo para o modelo mais simples, a entrega e instalação são grátis em qualquer lugar da região metropolitana — casa, trabalho, escola, supermercado. Atendimento 24h em casos de emergência.',
			),
		),
	),
	array(
		'slug' => 'start-stop',
		'nome' => 'Carro Start-Stop',
		'titulo' => 'Bateria AGM Start-Stop em Porto Alegre | Compass, T-Cross, BMW',
		'descricao' => 'Bateria AGM para carros Start-Stop em Porto Alegre. Jeep Compass, VW T-Cross, BMW, Audi. Instalação com reset ECU, garantia de fábrica, entrega no local.',
		'h1' => 'Bateria AGM para Start-Stop: a única tecnologia compatível',
		'tagline' => 'AGM original com reset ECU — sem improviso',
		'intro' => array(
			'Carro com tecnologia Start-Stop não aceita bateria comum. A função desliga e religa o motor dezenas de vezes por hora em trânsito urbano — uma bateria convencional pifaria em poucos meses. A solução técnica é AGM (Absorbed Glass Mat) ou EFB, projetadas para esses ciclos.',
			'A AWR Baterias trabalha com a linha completa AGM Moura e Heliar Free, com o equipamento de programação correto para fazer o reset da ECU após a troca — etapa que muitos lugares pulam e causa erro no painel.',
		),
		'porqueImporta' => array(
			'Bateria comum dura 6-8 meses em carro Start-Stop (vs. 36-48 da AGM)',
			'Sistema desliga o motor 30-80 vezes por hora em trânsito de POA',
			'ECU precisa de RESET após troca (BSI/BCM relearning), senão dá erro no painel',
			'Garantia do carro pode ser perdida se for instalada bateria fora de especificação',
		),
		'recomendacoes' => array(
			array(
				'marca' => 'Moura',
				'modelo' => 'Moura AGM 70Ah',
				'amperagem' => '70 Ah AGM',
				'preco' => 'R$ 1.129',
				'ideal' => 'VW T-Cross, Polo TSI, Jeep Renegade Start-Stop',
			),
			array(
				'marca' => 'Moura',
				'modelo' => 'Moura AGM 80Ah',
				'amperagem' => '80 Ah AGM',
				'preco' => 'R$ 2.040',
				'ideal' => 'Jeep Compass, Audi A3, BMW Série 1, Toro',
			),
			array(
				'marca' => 'Heliar',
				'modelo' => 'Heliar Free AGM 95Ah',
				'amperagem' => '95 Ah AGM',
				'preco' => 'R$ 2.550',
				'ideal' => 'BMW X3, Audi Q5, Mercedes GLA, VW Tiguan',
			),
		),
		'ondeAtende' => 'Atendemos Start-Stop em toda a região metropolitana de POA. Levamos scanner para reset da ECU, chave de torque calibrada e protocolo correto para cada montadora. Atendimento residencial, em concessionária ou onde o carro estiver.',
		'faq' => array(
			array(
				'pergunta' => 'Posso colocar bateria comum no meu Compass Start-Stop?',
				'resposta' => 'Não recomendamos. A bateria comum não suporta o ciclo de carga/descarga do Start-Stop e pifa em 6-8 meses. Além disso, alguns modelos travam a função Start-Stop ou acendem erro no painel se identificarem bateria fora de especificação.',
			),
			array(
				'pergunta' => 'É obrigatório fazer reset da ECU após trocar bateria AGM?',
				'resposta' => 'Sim, na maioria dos carros modernos com Start-Stop. O BCM/BSI precisa registrar a bateria nova para calibrar a carga corretamente. Sem o reset você pode ter erro no painel, função Start-Stop desativada e até consumo errado de combustível. Já fazemos isso incluso na instalação.',
			),
			array(
				'pergunta' => 'Qual a diferença entre AGM e EFB?',
				'resposta' => 'EFB é uma evolução da bateria comum, suporta Start-Stop básico. AGM é o nível premium, suporta Start-Stop com recuperação de energia em frenagem (regenerative braking). Sempre seguimos a especificação original do carro.',
			),
			array(
				'pergunta' => 'Vocês trocam bateria de BMW e Audi em casa?',
				'resposta' => 'Sim. Atendemos BMW, Audi, Mercedes, Volvo, Mini e Volkswagen Premium na região metropolitana de POA, com scanner para reset da ECU e protocolo correto da montadora. Sem necessidade de levar à concessionária.',
			),
		),
	),
);
