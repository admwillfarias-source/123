<?php
/** Gerado de assets/data/categorias.json — não editar. */
return array(
	array(
		'slug' => 'populares',
		'nome' => 'Populares 1.0 / 1.4',
		'exemplos' => 'Onix, HB20, Gol, Uno, Ka, Mobi',
		'descricao' => 'Bateria 50–60 Ah para carros de uso urbano e flex.',
		'precoBase' => 339,
		'parcelas' => 10,
	),
	array(
		'slug' => 'sedans-suv-medios',
		'nome' => 'Sedãs e SUVs médios',
		'exemplos' => 'Corolla, Civic, Compass, Renegade, Tracker',
		'descricao' => 'Bateria 60–70 Ah com mais carga para acessórios eletrônicos.',
		'precoBase' => 499,
		'parcelas' => 10,
	),
	array(
		'slug' => 'suv-grandes-picapes',
		'nome' => 'SUVs grandes e Picapes',
		'exemplos' => 'Hilux, S10, Ranger, Trailblazer, Pajero',
		'descricao' => 'Bateria 75–100 Ah para motores diesel e uso pesado.',
		'precoBase' => 600,
		'parcelas' => 10,
	),
	array(
		'slug' => 'start-stop',
		'nome' => 'Start-Stop (EFB / AGM)',
		'exemplos' => 'T-Cross, Polo Highline, BMW, Audi, Mercedes',
		'descricao' => 'Tecnologia EFB ou AGM para carros com sistema Start-Stop.',
		'precoBase' => 499,
		'parcelas' => 10,
	),
);
