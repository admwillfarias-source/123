<?php
/** Gerado de assets/data/posts.json — não editar. */
return array(
	array(
		'slug' => 'como-saber-se-bateria-do-carro-esta-fraca-porto-alegre',
		'titulo' => 'Bateria Fraca? 7 Sinais Antes do Carro Não Ligar',
		'h1' => 'Como saber se a bateria do carro está fraca: 7 sinais claros',
		'descricao' => 'Carro pesado pra ligar? Veja os 7 sinais de bateria fraca antes de parar na rua. Teste de alternador grátis em Porto Alegre e região.',
		'categoria' => 'Diagnóstico',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'sinais bateria fraca',
		'dataPublicacao' => '2025-03-10',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/bateria-fraca.webp',
		'imagemAlt' => 'Bateria de carro com cabos de chupeta vermelho e preto conectados',
		'intro' => array(
			'Quase ninguém olha para a bateria do carro até o dia em que ela não liga mais — geralmente de manhã, com pressa pra sair. Em Porto Alegre, com o calor do verão e o frio rigoroso do inverno gaúcho, a vida útil de uma bateria automotiva fica entre 2 e 3 anos.',
			'A boa notícia é que ela quase sempre avisa antes de descarregar de vez. Reunimos os 7 sinais mais comuns que os clientes da AWR descrevem nos minutos antes de pedir socorro 24h. Se você notar dois ou mais, é hora de testar — ou trocar.',
		),
		'secoes' => array(
			array(
				'h2' => '1. Partida lenta ou difícil pela manhã',
				'paragrafos' => array(
					'É o sinal número 1. Quando você gira a chave e o motor demora alguns segundos a mais para pegar, ou faz aquele barulho "rrr-rrr-rrr" antes de funcionar, a bateria já não tem corrente suficiente para acionar o motor de partida com folga.',
					'Em dias frios em Porto Alegre, é normal partir um pouco mais devagar — mas se isso virou rotina, a bateria está pedindo socorro.',
				),
			),
			array(
				'h2' => '2. Faróis fracos com o motor desligado',
				'paragrafos' => array(
					'Acenda os faróis com o carro parado e desligado. Se a luz parecer amarelada ou fraca, e ficar mais forte quando você dá partida, é a bateria que não está mais segurando a carga.',
				),
			),
			array(
				'h2' => '3. Luz da bateria acesa no painel',
				'paragrafos' => array(
					'Aquele desenho de bateria vermelho no painel é um aviso direto. Ele pode indicar bateria fraca, alternador com problema ou correia frouxa. Em qualquer caso, leve para um diagnóstico em até 48 horas.',
				),
			),
			array(
				'h2' => '4. Vidro elétrico subindo devagar',
				'paragrafos' => array(
					'Acessórios que dependem de corrente — vidros elétricos, retrovisores, banco elétrico — começam a funcionar mais lentamente quando a bateria está perto do fim. Se o vidro do motorista demora mais que o normal para fechar, é hora de testar.',
				),
			),
			array(
				'h2' => '5. Som do rádio falhando ou resetando',
				'paragrafos' => array(
					'Rádio que reseta sozinho ao dar partida, relógio que volta pro zero, central multimídia que reinicia: tudo isso é sintoma de queda de tensão da bateria.',
				),
			),
			array(
				'h2' => '6. Cheiro de enxofre ou bateria "inchada"',
				'paragrafos' => array(
					'Abra o capô e observe. Se a carcaça da bateria estiver estufada, vazando líquido ou exalando cheiro de ovo podre (enxofre), pare de usar o carro e chame o socorro 24h. Bateria nesse estado pode até explodir.',
				),
			),
			array(
				'h2' => '7. O carro só pega com chupeta',
				'paragrafos' => array(
					'Se você já precisou de chupeta uma vez essa semana, vai precisar de novo. Bateria que descarrega sozinha do dia pra noite está no fim — não tem reparo, só troca.',
				),
			),
			array(
				'h2' => 'Quanto tempo dura uma bateria de carro em Porto Alegre?',
				'paragrafos' => array(
					'Aqui na região metropolitana, uma bateria Moura, Heliar ou Zetta dura em média de 2 a 3 anos. Carros que ficam parados muito tempo, fazem trajetos curtos ou têm muitos acessórios (som potente, alarme, vidros) tendem a desgastar a bateria mais rápido.',
					'Se a sua bateria tem mais de 2 anos e apresentou qualquer um dos 7 sinais, vale fazer um teste gratuito antes de ser pego de surpresa.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Vocês fazem teste de bateria grátis em Porto Alegre?',
				'resposta' => 'Sim. O teste é gratuito tanto na loja (Medianeira ou Petrópolis) quanto no local — basta chamar no WhatsApp e nosso motoboy técnico vai até você.',
			),
			array(
				'pergunta' => 'Em quanto tempo a AWR entrega bateria em Porto Alegre?',
				'resposta' => 'Em até 35 minutos da confirmação do pedido, dentro do horário comercial. Atendemos do Centro Histórico à Zona Sul, incluindo Petrópolis, Menino Deus, Cidade Baixa, Moinhos de Vento e Sarandi.',
			),
			array(
				'pergunta' => 'Posso parcelar a bateria nova?',
				'resposta' => 'Sim, em até 10x sem juros no cartão. Aceitamos Pix, débito e crédito.',
			),
		),
		'relacionados' => array(
			'bateria-ou-alternador-como-saber-porto-alegre',
			'carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
			'aplicacaoSlug' => 'carro-popular',
		),
	),
	array(
		'slug' => 'bateria-de-carro-descarregou-o-que-fazer-canoas',
		'titulo' => 'Bateria Descarregou em Canoas? Resolva em 35 min',
		'h1' => 'Bateria do carro descarregou: o que fazer agora (Canoas e região)',
		'descricao' => 'Bateria descarregou em Canoas? Veja o que fazer agora e peça socorro no local em até 40 min, sem burocracia e com nota fiscal.',
		'categoria' => 'Socorro 24h',
		'cidadeAlvo' => 'Canoas',
		'cidadeSlug' => 'canoas',
		'palavraChave' => 'bateria descarregou o que fazer',
		'dataPublicacao' => '2025-03-12',
		'tempoLeitura' => 5,
		'imagemCapa' => 'assets/img/blog/carro-parado-noite.webp',
		'imagemAlt' => 'Carro parado na rua à noite com pisca-alerta ligado',
		'intro' => array(
			'Você girou a chave e nada. Só aquele "clic" seco no painel. Se está em Canoas, Esteio ou na BR-116, a primeira reação é pensar em chupeta — mas nem sempre é a melhor saída.',
			'Esse guia rápido mostra os 5 passos que você deve seguir antes (e depois) de tentar resolver sozinho, mais o número direto pra chamar socorro AWR se o problema for grave.',
		),
		'secoes' => array(
			array(
				'h2' => 'Passo 1: Confirme que é mesmo a bateria',
				'paragrafos' => array(
					'Antes de chamar guincho, faça esse teste de 10 segundos: gire a chave para a primeira posição (sem dar partida) e veja se as luzes do painel acendem normalmente.',
				),
				'lista' => array(
					'Painel apagado / luz fraca → bateria descarregada',
					'Painel acende normal mas motor não gira → motor de partida ou bateria descarregada',
					'Painel acende e motor gira mas não pega → problema no combustível ou ignição (não é bateria)',
				),
			),
			array(
				'h2' => 'Passo 2: Tire a carga inútil',
				'paragrafos' => array(
					'Desligue ar-condicionado, rádio, faróis, luzes internas e qualquer acessório antes de tentar dar partida de novo. Em alguns casos isso libera corrente suficiente para uma última partida.',
				),
			),
			array(
				'h2' => 'Passo 3: Chupeta — só se você sabe fazer certo',
				'paragrafos' => array(
					'Chupeta é seguro só se: (1) o cabo for de boa qualidade, (2) os carros NÃO se tocarem, (3) a ordem das pinças for respeitada (vermelho no polo positivo dos dois, preto no negativo do carro auxiliar e no chassi do carro descarregado — nunca no polo negativo da bateria descarregada).',
					'Ligar errado pode soltar faísca, queimar o módulo de injeção do carro novo (prejuízo de R$ 2.000+) ou até causar pequena explosão. Em carros com sistema start-stop ou híbridos, NUNCA dê chupeta — só socorro especializado.',
				),
			),
			array(
				'h2' => 'Passo 4: Se pegou com chupeta, NÃO desligue o carro',
				'paragrafos' => array(
					'Erro clássico: deu chupeta, o carro pegou, você foi para casa, desligou e foi dormir. Na manhã seguinte, mesmo problema.',
					'Uma bateria que precisou de chupeta já não segura mais carga normal. Vá direto a uma loja para teste ou troca — em Canoas, nossa unidade na Av. Guilherme Schell (Fátima) faz o teste em 5 minutos.',
				),
			),
			array(
				'h2' => 'Passo 5: Quando chamar socorro AWR',
				'paragrafos' => array(
					'Chame o socorro 24h da AWR Baterias em vez de tentar chupeta se:',
				),
				'lista' => array(
					'Carro é híbrido, elétrico ou tem sistema start-stop',
					'Você não tem cabo de chupeta ou outro carro por perto',
					'Está em local de risco (acostamento da BR-116, área isolada à noite)',
					'Já tentou chupeta e o carro não pegou',
					'Bateria está inchada, vazando ou exalando cheiro de enxofre',
				),
			),
			array(
				'h2' => 'Tempo médio de atendimento em Canoas',
				'paragrafos' => array(
					'Nossa equipe sai da unidade de Canoas-Fátima e chega em até 40 minutos em qualquer bairro da cidade — Centro, Niterói, Marechal Rondon, Mathias Velho, Igara, Harmonia. Para BR-116 e proximidades da ULBRA, geralmente em menos de 30 minutos.',
					'Você paga só a bateria nova (a partir de R$ 329, em até 10x sem juros). Instalação no local é gratuita e a bateria velha é recolhida pra reciclagem.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto custa o socorro 24h da AWR em Canoas?',
				'resposta' => 'O deslocamento e a instalação são gratuitos. Você paga apenas o valor da bateria nova, com nota fiscal e garantia de fábrica.',
			),
			array(
				'pergunta' => 'Atendem na BR-116 madrugada?',
				'resposta' => 'Sim, 24 horas, 7 dias por semana. Ligue ou chame no WhatsApp informando seu KM aproximado da BR-116 e enviamos o motoboy técnico mais próximo.',
			),
			array(
				'pergunta' => 'E se o problema não for a bateria?',
				'resposta' => 'Nosso técnico faz o teste no local. Se for alternador ou motor de partida, indicamos um mecânico parceiro de confiança em Canoas — sem cobrar pela visita.',
			),
		),
		'relacionados' => array(
			'carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser',
			'bateria-ou-alternador-como-saber-porto-alegre',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
			'aplicacaoSlug' => 'uber',
		),
	),
	array(
		'slug' => 'quanto-custa-trocar-bateria-do-carro-gravatai',
		'titulo' => 'Quanto Custa Trocar Bateria em Gravataí? Preços',
		'h1' => 'Quanto custa trocar a bateria do carro em Gravataí (tabela atualizada)',
		'descricao' => 'Trocar bateria em Gravataí custa de R$ 329 a R$ 2.100. Veja a tabela por amperagem, marcas Moura e Heliar, e entrega em até 40 min.',
		'categoria' => 'Preços',
		'cidadeAlvo' => 'Gravataí',
		'cidadeSlug' => 'gravatai',
		'palavraChave' => 'preço bateria automotiva',
		'dataPublicacao' => '2025-03-15',
		'tempoLeitura' => 7,
		'imagemCapa' => 'assets/img/blog/mecanico-instalando.webp',
		'imagemAlt' => 'Mecânico de uniforme azul instalando bateria nova no motor do carro',
		'intro' => array(
			'Trocar a bateria do carro em Gravataí custa, em 2025, entre R$ 329 e R$ 2.100 — depende da amperagem, da marca e se você precisa de bateria comum, EFB (start-stop) ou AGM (carros mais novos).',
			'Esse guia mostra preço médio por tipo de carro, o que está incluído (entrega, instalação, recolhimento da velha) e como evitar o golpe da bateria "recondicionada".',
		),
		'secoes' => array(
			array(
				'h2' => 'Tabela de preços por amperagem (Gravataí, 2025)',
				'paragrafos' => array(
					'Estes são valores de referência da AWR Baterias em Gravataí, com entrega e instalação inclusas no preço. Variam ±10% conforme estoque:',
				),
				'lista' => array(
					'Bateria 50Ah (carros 1.0 antigos): R$ 329 — R$ 485',
					'Bateria 60Ah (Gol, Onix, HB20, Strada): R$ 329 — R$ 515',
					'Bateria 70Ah (Civic, Corolla, Hilux antiga): R$ 499 — R$ 775',
					'Bateria 90Ah (caminhonetes, SUVs grandes): R$ 875 — R$ 975',
					'Bateria 100Ah (Hilux, S10, Ranger nova): R$ 639 — R$ 985',
					'Bateria EFB / AGM (start-stop): R$ 599 — R$ 2.575',
				),
			),
			array(
				'h2' => 'Quanto custa por marca',
				'paragrafos' => array(
					'Trabalhamos com as 4 marcas mais confiáveis do mercado. Todas têm nota fiscal e garantia de fábrica:',
				),
				'lista' => array(
					'Moura — referência nacional, garantia 18 meses',
					'Heliar — usada de fábrica em quase todo carro novo, garantia 18 meses',
					'Zetta — boa relação custo-benefício, garantia 12 meses',
					'Excell — entrada de linha, garantia 12 meses',
				),
			),
			array(
				'h2' => 'O que está incluso no preço',
				'paragrafos' => array(
					'Quando a AWR informa o preço, ele JÁ inclui:',
				),
				'lista' => array(
					'Entrega no seu endereço em Gravataí (até 40 minutos)',
					'Instalação feita por motoboy técnico',
					'Recolhimento da bateria velha (descarte ambiental correto)',
					'Reset dos códigos do carro quando necessário',
					'Nota fiscal eletrônica e garantia ativada',
				),
			),
			array(
				'h2' => 'Cuidado com o golpe da bateria recondicionada',
				'paragrafos' => array(
					'Em Gravataí, é comum ver oferta de bateria "recondicionada" por R$ 150–200. NÃO compre. Bateria recondicionada é uma bateria velha lavada por fora — ela dura 1–3 meses no máximo e pode danificar o alternador do seu carro.',
					'Toda bateria da AWR é nova, lacrada, com etiqueta de fabricação recente (importante: peça pra ver a data de fabricação, deve ter menos de 6 meses).',
				),
			),
			array(
				'h2' => 'Formas de pagamento aceitas',
				'paragrafos' => array(
					'Em até 10x sem juros no cartão de crédito, Pix com 5% de desconto, débito ou dinheiro. Aceitamos todas as bandeiras.',
				),
			),
			array(
				'h2' => 'Qual bateria é a melhor pro meu carro?',
				'paragrafos' => array(
					'A resposta certa está no manual do proprietário ou na etiqueta da bateria atual. Se você não tem essa informação, basta nos chamar no WhatsApp informando marca, modelo e ano — em 1 minuto dizemos a amperagem certa e a faixa de preço.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Tem entrega grátis em Gravataí?',
				'resposta' => 'Sim. Entrega + instalação são gratuitas em toda Gravataí, Cachoeirinha, Alvorada e Viamão. Você paga só o valor da bateria.',
			),
			array(
				'pergunta' => 'Quanto tempo demora pra trocar no local?',
				'resposta' => 'O motoboy técnico chega em até 40 minutos. A troca em si leva de 5 a 15 minutos, dependendo do modelo do carro.',
			),
			array(
				'pergunta' => 'A bateria tem garantia?',
				'resposta' => 'Sim, 12 a 18 meses de garantia de fábrica conforme a marca. Em caso de defeito, basta trazer a nota fiscal — trocamos sem custo.',
			),
		),
		'relacionados' => array(
			'garantia-bateria-moura-quanto-tempo-dura',
			'bateria-ou-alternador-como-saber-porto-alegre',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'heliar',
			'aplicacaoSlug' => 'caminhonete',
		),
	),
	array(
		'slug' => 'bateria-de-carro-no-inverno-gaucho-cuidados',
		'titulo' => 'Bateria no Inverno Gaúcho: 6 Cuidados Essenciais',
		'h1' => 'Bateria do carro no inverno gaúcho: 6 cuidados que evitam o aperto',
		'descricao' => 'O frio do RS é o pior inimigo da bateria automotiva. Veja 6 cuidados práticos pra não ficar a pé numa manhã gelada em Porto Alegre ou região.',
		'categoria' => 'Manutenção',
		'cidadeAlvo' => 'Região Metropolitana de Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria carro frio inverno',
		'dataPublicacao' => '2025-03-18',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/inverno-gaucho.webp',
		'imagemAlt' => 'Para-brisa de carro coberto de geada numa manhã de inverno no Rio Grande do Sul',
		'intro' => array(
			'Toda manhã de junho a agosto no Rio Grande do Sul, motoristas em Porto Alegre, Canoas, Gravataí e Viamão giram a chave e... nada. O frio é o principal motivo de chamado para socorro 24h da AWR no inverno.',
			'Em temperaturas abaixo de 5 °C, a bateria perde até 35% da sua capacidade de partida. Esses 6 cuidados simples reduzem em quase 100% a chance de você ficar a pé no frio.',
		),
		'secoes' => array(
			array(
				'h2' => '1. Teste a bateria antes do inverno chegar',
				'paragrafos' => array(
					'Em abril ou maio, leve o carro a uma loja AWR (qualquer unidade da região metropolitana) para um teste gratuito de carga e tensão. Bateria com mais de 2 anos é forte candidata a falhar no primeiro frio.',
				),
			),
			array(
				'h2' => '2. Evite percursos muito curtos',
				'paragrafos' => array(
					'Trajetos de menos de 10 minutos não dão tempo para o alternador recarregar a bateria. No inverno, com farol, desembaçador e ar quente ligados, isso acelera a descarga.',
					'Se você só usa o carro pra ir até o mercado e voltar, faça pelo menos um trajeto longo (30+ minutos) por semana para recarregar.',
				),
			),
			array(
				'h2' => '3. Desligue TUDO antes de dar partida no frio',
				'paragrafos' => array(
					'Antes de girar a chave numa manhã gelada, desligue ar, rádio, faróis, desembaçador. Dê a partida e só depois ligue os acessórios. Isso reduz a carga inicial sobre a bateria fria.',
				),
			),
			array(
				'h2' => '4. Não deixe o carro parado por mais de 5 dias',
				'paragrafos' => array(
					'Carro parado consome bateria mesmo desligado (alarme, computador de bordo, módulos). No frio, isso descarrega ainda mais rápido. Se vai viajar e deixar o carro parado, peça pra alguém ligar pelo menos 1 vez por semana e deixar funcionando 15 minutos.',
				),
			),
			array(
				'h2' => '5. Mantenha os polos limpos',
				'paragrafos' => array(
					'Aquela crosta branca/esverdeada nos polos da bateria é sulfato. Ela cria resistência elétrica e dificulta a partida no frio. Limpeza com escova de aço e bicarbonato resolve — ou peça ao técnico AWR na próxima visita (sem custo).',
				),
			),
			array(
				'h2' => '6. Tenha o número do socorro 24h salvo no celular',
				'paragrafos' => array(
					'Mesmo com todos os cuidados, bateria velha vai falhar uma hora. Salve o WhatsApp da AWR antes do inverno: (51) 99319-9486. Atendemos 24h em toda Porto Alegre, Canoas, Gravataí, Viamão, Cachoeirinha, Alvorada e Esteio.',
				),
			),
			array(
				'h2' => 'Por que o frio mata bateria de carro?',
				'paragrafos' => array(
					'A bateria automotiva funciona por reação química entre placas de chumbo e ácido sulfúrico. No frio, essa reação fica mais lenta — em 0 °C, a bateria entrega apenas 65% da corrente que entregaria a 25 °C.',
					'Ao mesmo tempo, o motor frio precisa de MAIS corrente para dar partida (óleo mais grosso, atrito maior). Resultado: bateria entregando menos, motor pedindo mais. Resultado prático: "clic" seco e atraso pro trabalho.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto tempo dura uma bateria nova no inverno gaúcho?',
				'resposta' => 'Em média 2 a 3 anos. Carros com cuidado preventivo (teste anual, trajetos longos) chegam até 4 anos. Sem cuidado, bateria de qualidade duvidosa pode falhar em menos de 1 inverno.',
			),
			array(
				'pergunta' => 'Vocês fazem manutenção preventiva de bateria?',
				'resposta' => 'Sim, sem custo. Limpeza de polos, teste de carga e teste de alternador são feitos gratuitamente em qualquer loja AWR ou no local pelo motoboy técnico.',
			),
			array(
				'pergunta' => 'Bateria pode estourar no frio?',
				'resposta' => 'Sim, embora seja raro. Bateria muito velha, com gelo dentro (água do eletrólito congelada) ou com curto interno pode estourar ao receber chupeta. Por isso, no inverno, prefira sempre socorro especializado a chupeta improvisada.',
			),
		),
		'relacionados' => array(
			'garantia-bateria-moura-quanto-tempo-dura',
			'carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
			'aplicacaoSlug' => 'start-stop',
		),
	),
	array(
		'slug' => 'bateria-ou-alternador-como-saber-porto-alegre',
		'titulo' => 'Bateria ou Alternador? Descubra em 1 Minuto',
		'h1' => 'Como saber se o problema é na bateria ou no alternador do carro',
		'descricao' => 'Carro não liga e painel fraco? Aprenda em 1 minuto a diferenciar problema de bateria de problema de alternador — e evite gastar dinheiro à toa.',
		'categoria' => 'Diagnóstico',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria ou alternador',
		'dataPublicacao' => '2025-04-02',
		'tempoLeitura' => 5,
		'imagemCapa' => 'assets/img/blog/bateria-fraca.webp',
		'imagemAlt' => 'Bateria de carro com cabos de teste — diagnóstico bateria ou alternador',
		'intro' => array(
			'O carro não liga e o painel acende fraco. Na maioria das vezes, o motorista culpa a bateria de imediato, mas o verdadeiro vilão pode ser o alternador — a peça responsável por carregar a bateria enquanto o motor funciona.',
			'Para não gastar dinheiro à toa trocando a peça errada, veja como identificar o problema em segundos antes de chamar o socorro.',
		),
		'secoes' => array(
			array(
				'h2' => 'Sinal de que o problema é na BATERIA',
				'paragrafos' => array(
					'Se você tenta dar a partida e o motor faz aquele barulho pesado e arrastado ("uém-uém-uém"), ou se o carro liga apenas com chupeta e, depois de desligado, não liga mais, a sua bateria provavelmente chegou ao fim da vida útil.',
				),
				'lista' => array(
					'Partida arrastada de manhã, principalmente no frio',
					'Painel acende fraco ou luzes amareladas com motor desligado',
					'Só pega com chupeta — e descarrega em poucas horas',
					'Bateria com mais de 2 anos de uso',
				),
			),
			array(
				'h2' => 'Sinal de que o problema é no ALTERNADOR',
				'paragrafos' => array(
					'Se você conseguiu dar a partida no carro, mas enquanto estava dirigindo ele começou a perder força, os faróis ficaram fracos e uma luz vermelha em formato de bateria acendeu no painel, o alternador não está conseguindo enviar carga.',
					'Nesse caso, mesmo que você compre uma bateria nova, ela vai descarregar em poucos quilômetros — porque o problema não é a bateria, é a peça que deveria carregá-la.',
				),
				'lista' => array(
					'Luz vermelha de bateria acesa no painel COM o motor funcionando',
					'Faróis que enfraquecem em marcha lenta e fortalecem ao acelerar',
					'Cheiro de queimado ou correia frouxa',
					'Bateria nova que descarregou em poucos dias',
				),
			),
			array(
				'h2' => 'Dica de ouro: teste com multímetro resolve o mistério',
				'paragrafos' => array(
					'Na dúvida, não tente adivinhar. O teste de voltagem com multímetro profissional dá a resposta em 30 segundos: com motor desligado, bateria saudável marca 12,4–12,7 V. Com motor ligado, alternador saudável marca 13,8–14,4 V. Fora dessa faixa, está na hora de trocar a peça certa.',
					'Nosso motoboy técnico AWR leva o multímetro em toda visita e faz o teste gratuito no local antes de você decidir comprar a bateria nova.',
				),
			),
			array(
				'h2' => 'Onde testar bateria e alternador grátis em Porto Alegre',
				'paragrafos' => array(
					'Atendemos toda a capital — Centro, Petrópolis, Menino Deus, Medianeira, Cidade Baixa, Moinhos de Vento, Sarandi, Zona Sul — em até 35 minutos. O teste é 100% gratuito e sem compromisso: se o problema não for bateria, indicamos um mecânico parceiro de confiança e você não paga nada pela visita.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Vocês testam alternador no local em Porto Alegre?',
				'resposta' => 'Sim, sem custo. O motoboy técnico leva multímetro e faz o teste de bateria + alternador no local antes da troca. Se o problema for alternador, indicamos mecânico parceiro de confiança.',
			),
			array(
				'pergunta' => 'Quanto custa trocar o alternador?',
				'resposta' => 'A AWR é especializada em baterias, não troca alternador. Mas o teste é grátis e, se for esse o caso, indicamos parceiro que cobra em média R$ 400–800 dependendo do modelo.',
			),
			array(
				'pergunta' => 'E se eu trocar a bateria e ainda assim o carro não pegar?',
				'resposta' => 'Por isso o teste antes da venda é fundamental. Nossa equipe NÃO vende bateria sem antes confirmar que ela é o problema. Garantia total de satisfação.',
			),
		),
		'relacionados' => array(
			'como-saber-se-bateria-do-carro-esta-fraca-porto-alegre',
			'carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
			'aplicacaoSlug' => 'carro-popular',
		),
	),
	array(
		'slug' => 'garantia-bateria-moura-quanto-tempo-dura',
		'titulo' => 'Garantia da Bateria Moura: Quanto Tempo Dura',
		'h1' => 'Quanto tempo dura a garantia de uma bateria Moura?',
		'descricao' => 'Garantia Moura 2025: 24 meses automotiva, 24 meses AGM/EFB start-stop, 6 meses moto, 15 meses linha pesada. Veja como acionar em Porto Alegre.',
		'categoria' => 'Garantia',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'garantia bateria moura',
		'dataPublicacao' => '2025-04-05',
		'tempoLeitura' => 5,
		'imagemCapa' => 'assets/img/blog/mecanico-instalando.webp',
		'imagemAlt' => 'Instalação de bateria Moura nova com certificado de garantia',
		'intro' => array(
			'A Moura é a marca líder de mercado no Brasil, conhecida pela alta durabilidade e tecnologia embarcada. Se você comprou — ou está pensando em comprar — uma bateria Moura, é fundamental entender como funciona o prazo de garantia para proteger o seu investimento.',
			'O tempo de garantia varia conforme o modelo da bateria e o tipo de veículo. Veja abaixo o prazo oficial de fábrica em 2025.',
		),
		'secoes' => array(
			array(
				'h2' => 'Linha Automotiva Convencional (até 75Ah)',
				'paragrafos' => array(
					'Os modelos mais comuns para carros de passeio — 45Ah, 50Ah, 60Ah, 70Ah — possuem 24 meses (2 anos) de garantia de fábrica. Inclui as linhas Moura Eficiência e Moura Original, presentes em quase todo Gol, Onix, HB20, Strada, Palio e similares.',
				),
			),
			array(
				'h2' => 'Linha Moura AGM e EFB (sistema Start-Stop)',
				'paragrafos' => array(
					'As baterias tecnológicas desenvolvidas para veículos que desligam sozinhos no semáforo (start-stop) também contam com 24 meses (2 anos) de garantia. São as linhas Moura AGM e Moura EFB — comuns em Jeep Renegade, Compass, VW T-Cross, Nivus, Polo e BMW Série 1.',
				),
			),
			array(
				'h2' => 'Linha Moto (Moura Moto)',
				'paragrafos' => array(
					'Baterias para motocicletas possuem 6 meses de garantia. Aplicável a Honda CG, Biz, CB, Yamaha Factor, Fazer e similares.',
				),
			),
			array(
				'h2' => 'Linha Pesada (caminhões e ônibus acima de 100Ah)',
				'paragrafos' => array(
					'Baterias para frota pesada contam com 15 meses de garantia. Aplicável a caminhões Mercedes, Volvo, Scania, ônibus urbanos e caminhões leves acima de 100Ah.',
				),
			),
			array(
				'h2' => 'Como acionar a garantia Moura em Porto Alegre',
				'paragrafos' => array(
					'Para acionar a garantia em qualquer revendedor oficial, você precisa apresentar o certificado que vem junto com a bateria no momento da compra. Guarde sempre no porta-luvas do carro!',
					'Na AWR Baterias, o processo é simples: traga a bateria + nota fiscal/certificado em qualquer uma das 6 lojas (Medianeira, Petrópolis, Canoas, Gravataí, Viamão, Cachoeirinha). Fazemos o teste e, confirmado o defeito de fábrica, trocamos por uma nova SEM custo — no mesmo dia.',
				),
			),
			array(
				'h2' => 'O que NÃO é coberto pela garantia',
				'paragrafos' => array(
					'Importante saber para não ter surpresa:',
				),
				'lista' => array(
					'Bateria descarregada por luzes esquecidas (uso indevido)',
					'Bateria danificada por alternador defeituoso (problema no carro)',
					'Bateria com terminais oxidados por falta de manutenção',
					'Bateria sem o certificado de garantia original',
					'Reparos feitos por terceiros não autorizados',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'A AWR é revendedora oficial Moura?',
				'resposta' => 'Sim. Somos revendedora oficial autorizada Moura em Porto Alegre e região metropolitana. Toda bateria sai com certificado de garantia ativado em seu nome.',
			),
			array(
				'pergunta' => 'Posso acionar garantia se comprei a bateria em outra loja?',
				'resposta' => 'Sim, qualquer revendedora oficial Moura aceita o certificado de garantia. Basta apresentar a nota fiscal original e o certificado. Fazemos o teste no local.',
			),
			array(
				'pergunta' => 'Quanto tempo demora a troca em garantia?',
				'resposta' => 'Em geral, no mesmo dia. O teste leva 5 minutos e, confirmado o defeito, trocamos imediatamente por uma bateria nova zero quilômetro.',
			),
		),
		'relacionados' => array(
			'quanto-custa-trocar-bateria-do-carro-gravatai',
			'bateria-ou-alternador-como-saber-porto-alegre',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
			'aplicacaoSlug' => 'start-stop',
		),
	),
	array(
		'slug' => 'carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser',
		'titulo' => 'Carro Não Liga e Faz Estalo? Resolva Hoje Mesmo',
		'h1' => 'Carro não liga e faz barulho de estalo: o que pode ser',
		'descricao' => 'O estalo ao girar a chave quase sempre é bateria descarregada. Veja como confirmar e receba bateria nova instalada no local em até 35 min.',
		'categoria' => 'Socorro 24h',
		'cidadeAlvo' => 'Canoas',
		'cidadeSlug' => 'canoas',
		'palavraChave' => 'carro nao liga estalo tec tec',
		'dataPublicacao' => '2025-04-08',
		'tempoLeitura' => 4,
		'imagemCapa' => 'assets/img/blog/carro-parado-noite.webp',
		'imagemAlt' => 'Carro parado com problema de partida e estalo no motor',
		'intro' => array(
			'Você gira a chave ou aperta o botão de partida, o motor nem ameaça girar e tudo o que você escuta é um clique seco ou uma sequência de estalos ("tec-tec-tec"). O que está acontecendo?',
			'Esse barulho é o sintoma mais clássico de bateria fraca ou totalmente descarregada — e tem solução rápida, sem precisar guinchar o carro.',
		),
		'secoes' => array(
			array(
				'h2' => 'De onde vem o barulho de "tec-tec"',
				'paragrafos' => array(
					'O som do estalo vem do motor de partida (ou motor de arranque). Ele está tentando acionar o motor do carro, mas a quantidade de energia que sai da bateria é tão baixa que a peça não tem força para girar — resultando apenas no barulho metálico do relé batendo repetidamente.',
					'É um som metálico, rápido, parecido com um "clique" forte ou uma sequência "tec-tec-tec". Não confunda com o som arrastado "uém-uém-uém" (esse é bateria fraca mas ainda com alguma carga).',
				),
			),
			array(
				'h2' => 'Principais motivos para isso acontecer',
				'paragrafos' => array(
					'Em 9 de cada 10 casos, é um destes 3 motivos:',
				),
				'lista' => array(
					'Você esqueceu uma luz interna, farol, rádio ou porta entreaberta durante a noite',
					'O carro ficou muitos dias parado sem dar a partida (5+ dias)',
					'A vida útil da sua bateria acabou — em geral entre 2 e 3 anos',
				),
			),
			array(
				'h2' => 'O que NÃO fazer ao ouvir o estalo',
				'paragrafos' => array(
					'Erro número 1: ficar forçando a chave na ignição. Isso pode danificar o motor de arranque (peça que custa R$ 600 a R$ 1.500 para trocar) e o problema continua o mesmo — bateria sem carga.',
					'Erro número 2: tentar empurrar carros automáticos ou com câmbio CVT. Pode danificar o câmbio. Empurrar só funciona em câmbio manual — e mesmo assim não recarrega a bateria de verdade.',
				),
			),
			array(
				'h2' => 'Solução em até 35 minutos em Canoas',
				'paragrafos' => array(
					'Se você está em Canoas, Esteio, Sapucaia, BR-116 ou Mathias Velho, a equipe AWR vai até você em até 35 minutos com a bateria certa para o seu carro. Atendemos 24 horas — inclusive madrugada e fins de semana.',
					'Levamos bateria nova zero quilômetro, instalamos no local sem custo e recolhemos a velha para descarte ambiental correto. Você paga só a bateria, em até 10x sem juros no cartão ou Pix com desconto.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Atendem na madrugada em Canoas?',
				'resposta' => 'Sim, 24 horas por dia, 7 dias por semana — inclusive feriados. Basta chamar no WhatsApp informando o endereço e em até 35 minutos o motoboy técnico chega com bateria nova.',
			),
			array(
				'pergunta' => 'E se o problema não for a bateria?',
				'resposta' => 'Fazemos o teste no local antes da venda. Se for motor de arranque, alternador ou outro componente, indicamos um mecânico parceiro de confiança em Canoas — e você não paga nada pela visita.',
			),
			array(
				'pergunta' => 'Posso parcelar a bateria nova mesmo de madrugada?',
				'resposta' => 'Sim. Aceitamos cartão (até 10x sem juros), Pix (5% de desconto), débito e dinheiro. Maquininha móvel disponível em qualquer atendimento.',
			),
		),
		'relacionados' => array(
			'bateria-de-carro-descarregou-o-que-fazer-canoas',
			'bateria-ou-alternador-como-saber-porto-alegre',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
			'aplicacaoSlug' => 'uber',
		),
	),
	array(
		'slug' => 'quando-trocar-bateria-do-onix',
		'titulo' => 'Quando Trocar a Bateria do Onix: Sinais e Preço',
		'h1' => 'Quando trocar a bateria do Chevrolet Onix',
		'descricao' => 'Vida útil real, sinais de troca e preço da bateria do Onix 1.0 e 1.4 em Porto Alegre. Guia direto feito por quem instala todo dia.',
		'categoria' => 'Modelos',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'quando trocar bateria onix',
		'dataPublicacao' => '2026-06-10',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/mecanico-instalando.webp',
		'imagemAlt' => 'Bateria nova sendo instalada em um Chevrolet Onix',
		'intro' => array(
			'A bateria do Chevrolet Onix dura, em média, 2 a 3 anos em Porto Alegre e região metropolitana. O calor do verão e o frio do inverno gaúcho derrubam essa média se a bateria for de linha econômica ou se o carro ficar parado muitos dias.',
			'Se você está com Onix 1.0, 1.4 ou Onix Plus turbo e desconfia que a bateria está no fim, este guia mostra os sinais, a especificação correta de fábrica e quanto custa a troca em 2026.',
		),
		'secoes' => array(
			array(
				'h2' => 'Vida útil real da bateria do Onix em Porto Alegre',
				'paragrafos' => array(
					'Pelos atendimentos da AWR, 70% das trocas de bateria de Onix acontecem entre 24 e 36 meses. Carros 2017–2019 que ainda estão com a bateria original raramente passam dos 3 anos sem dar sinal.',
					'O Onix Plus Turbo 200 (linha 2020+) consome um pouco mais por causa do start-stop e da central multimídia MyLink — nesses casos, a recomendação é trocar aos 24 meses, antes de ficar na mão.',
				),
			),
			array(
				'h2' => 'Sinais de que a bateria do Onix está no fim',
				'paragrafos' => array(
					'Se você marcar dois ou mais destes itens, é hora de testar:',
				),
				'lista' => array(
					'Partida lenta de manhã, principalmente em dia frio',
					'Luz da bateria piscando no painel',
					'Vidros elétricos subindo mais devagar',
					'Multimídia MyLink reiniciando sozinha',
					'Faróis amarelados com motor desligado',
					'Carro fica difícil de ligar depois de 2–3 dias parado',
				),
			),
			array(
				'h2' => 'Especificação técnica: qual bateria comprar para o Onix',
				'paragrafos' => array(
					'Onix 1.0 e 1.4 flex (todas as linhas até 2019): bateria 50 Ah ou 60 Ah, polaridade direita.',
					'Onix Plus Turbo 200 e linha 2020+: bateria 60 Ah, terminal polo direito, idealmente EFB se o carro tiver start-stop ativo.',
					'Marcas recomendadas pela AWR para Onix: Moura 60Ah (mais vendida, 18 meses de garantia) e Heliar Free 60Ah (15 meses, olho mágico de carga).',
				),
			),
			array(
				'h2' => 'Preço da bateria do Onix em 2026',
				'paragrafos' => array(
					'A partir de R$ 429 (Zetta 60Ah) e até R$ 529 (Heliar 60Ah). Moura 60Ah fica em R$ 515. Todos os preços já incluem instalação no local, base de troca e nota fiscal.',
					'Em 10x sem juros no cartão a parcela fica em aproximadamente R$ 42,90 na Zetta e R$ 52,90 na Heliar.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto tempo dura a bateria do Onix 1.0?',
				'resposta' => 'Entre 2 e 3 anos em uso urbano em Porto Alegre. Carros que rodam pouco (menos de 5 km por dia) ou ficam parados a maior parte da semana podem precisar trocar antes, por volta dos 20 meses.',
			),
			array(
				'pergunta' => 'Qual a bateria original do Onix?',
				'resposta' => 'A GM equipa o Onix de fábrica com baterias 50 ou 60 Ah da ACDelco. Na troca, recomendamos manter os 60 Ah para ter folga de carga para multimídia, faróis e som — especialmente em motoristas de app.',
			),
			array(
				'pergunta' => 'Onix Plus Turbo precisa de bateria EFB?',
				'resposta' => 'Se o seu Onix Plus Turbo 200 tem o sistema start-stop ativo, sim — bateria comum encurta a vida útil pela metade. Confirmamos a especificação correta no momento da instalação, sem custo.',
			),
			array(
				'pergunta' => 'Vocês entregam bateria de Onix no mesmo dia em Porto Alegre?',
				'resposta' => 'Sim. Pedidos confirmados até 17h em Porto Alegre, Canoas, Gravataí, São Leopoldo ou Novo Hamburgo são entregues e instalados em até 35 minutos, sem custo de visita.',
			),
		),
		'relacionados' => array(
			'como-saber-se-bateria-do-carro-esta-fraca-porto-alegre',
			'bateria-descarregada-o-que-fazer',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'quanto-dura-bateria-do-corolla',
		'titulo' => 'Quanto Dura a Bateria do Corolla? Troca em 35 min',
		'h1' => 'Quanto dura a bateria do Toyota Corolla',
		'descricao' => 'Durabilidade real, sinais de troca e preço da bateria do Corolla 1.8, 2.0 e Híbrido. Troque hoje com entrega e instalação grátis em Porto Alegre.',
		'categoria' => 'Modelos',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria corolla quantos anos dura',
		'dataPublicacao' => '2026-06-12',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/mecanico-instalando.webp',
		'imagemAlt' => 'Bateria automotiva nova ao lado de um Toyota Corolla',
		'intro' => array(
			'A bateria do Toyota Corolla é uma das mais duráveis do mercado — em média 3 a 4 anos em Porto Alegre, o que é cerca de 30% acima da média de carros populares. Mesmo assim, ela avisa antes de parar.',
			'Se você tem Corolla 1.8, 2.0 GLi/XEi/Altis ou o Híbrido Flex, este guia mostra a especificação correta, sinais de fim de vida e o preço em 2026.',
		),
		'secoes' => array(
			array(
				'h2' => 'Quanto dura, de verdade, a bateria do Corolla',
				'paragrafos' => array(
					'Pelos atendimentos da AWR em Porto Alegre, Canoas e Novo Hamburgo, 60% das trocas acontecem entre 36 e 48 meses. O Corolla é um carro que cuida bem da própria bateria — alternador robusto, gestão eletrônica eficiente e baixo consumo parasita.',
					'Corolla Híbrido Flex (linha 2020+) tem duas baterias: a de partida 12V (que tratamos aqui) e a bateria híbrida de alta tensão. A 12V dura em torno de 3 anos e quando descarrega o carro simplesmente não dá partida — mesmo com a híbrida cheia.',
				),
			),
			array(
				'h2' => 'Sinais de que a bateria do Corolla está chegando ao fim',
				'paragrafos' => array(
					'Procure por estes sintomas, especialmente no inverno gaúcho:',
				),
				'lista' => array(
					'Mensagem "verificar bateria" no painel multimídia',
					'Partida lenta após 3 dias parado',
					'Sistema de áudio reiniciando após desligar o carro',
					'Vidros, retrovisores ou bancos elétricos lentos',
					'Aviso de bateria fraca da chave presencial Smart Entry',
				),
			),
			array(
				'h2' => 'Qual bateria comprar para o Corolla',
				'paragrafos' => array(
					'Corolla 1.8 GLi e XEi flex (2014–2019): bateria 60 Ah, polo direito.',
					'Corolla 2.0 XEi/Altis (2020+): bateria 60 Ah EFB, polo direito — a Toyota recomenda EFB para preservar a central de injeção direta.',
					'Corolla Híbrido Flex: bateria 12V 45 Ah AGM específica (Heliar AGM 45 ou Moura AGM 45). Modelos genéricos podem causar erro no módulo híbrido.',
					'Marcas recomendadas: Heliar AGM (original para Híbrido), Moura EFB (linha 2020+) e Moura M60GD (linha 2014–2019).',
				),
			),
			array(
				'h2' => 'Preço da bateria do Corolla em 2026',
				'paragrafos' => array(
					'Corolla flex: a partir de R$ 515 (Moura M60GD 60Ah) até R$ 529 (Heliar 60Ah). Linha 2020+ EFB: a partir de R$ 745. Corolla Híbrido AGM: a partir de R$ 1.129.',
					'Todos os preços com instalação no local, base de troca, nota fiscal e teste do alternador inclusos. 10x sem juros no cartão.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Posso trocar a bateria do Corolla Híbrido em casa?',
				'resposta' => 'Não recomendamos. O Corolla Híbrido precisa de procedimento específico para não disparar erros no módulo híbrido e na central multimídia. Nossa equipe tem scanner Toyota para reset pós-troca, sem custo adicional.',
			),
			array(
				'pergunta' => 'Pode colocar bateria comum no Corolla 2022?',
				'resposta' => 'Pode, mas a vida útil cai pela metade. A linha 2020+ tem injeção direta e gestão de carga mais exigente — a Toyota especifica EFB para evitar pane na central. Recomendamos Moura EFB ou Heliar EFB 60Ah.',
			),
			array(
				'pergunta' => 'Bateria do Corolla original é melhor?',
				'resposta' => 'A original de fábrica é boa, mas Moura e Heliar são fornecedoras OEM da Toyota e dão mais garantia (18 e 15 meses contra 12 meses da original em peça avulsa). Por isso são nossa indicação técnica.',
			),
			array(
				'pergunta' => 'Atendem Corolla em Canoas e Novo Hamburgo?',
				'resposta' => 'Sim. A AWR atende toda a região metropolitana de Porto Alegre com bateria original para Corolla — incluindo a versão Híbrida AGM 45 — em até 40 minutos em Canoas e 40 minutos em Novo Hamburgo.',
			),
		),
		'relacionados' => array(
			'como-saber-se-bateria-do-carro-esta-fraca-porto-alegre',
			'bateria-do-hb20-qual-comprar',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'heliar',
		),
	),
	array(
		'slug' => 'bateria-descarregada-o-que-fazer',
		'titulo' => 'Bateria Descarregada: O Que Fazer Agora (24h)',
		'h1' => 'Bateria descarregada: o que fazer agora',
		'descricao' => 'Carro não liga porque a bateria descarregou? Passo a passo seguro, quando chamar socorro 24h e o que não fazer para não estragar o carro.',
		'categoria' => 'Socorro 24h',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria descarregada o que fazer',
		'dataPublicacao' => '2026-06-13',
		'tempoLeitura' => 5,
		'imagemCapa' => 'assets/img/blog/carro-parado-noite.webp',
		'imagemAlt' => 'Motorista olhando o motor de um carro com bateria descarregada à noite',
		'intro' => array(
			'Bateria descarregada é o problema número 1 que atendemos na AWR. A boa notícia: tem solução rápida — e na maioria dos casos, sem guincho. A má: muita gente piora o problema tentando "dar um jeito".',
			'Este guia rápido mostra o passo a passo seguro, o que não fazer e quando chamar socorro 24h em Porto Alegre, Canoas, Gravataí, São Leopoldo ou Novo Hamburgo.',
		),
		'secoes' => array(
			array(
				'h2' => 'Como saber se é a bateria mesmo',
				'paragrafos' => array(
					'O sintoma clássico de bateria descarregada é:',
				),
				'lista' => array(
					'Ao girar a chave, escuta só um "clique" seco ou "tec-tec-tec" rápido',
					'Painel acende fraco e apaga quando você gira a chave',
					'Faróis muito amarelados ou nem acendem',
					'Vidros elétricos não respondem',
					'Carro nem tenta dar partida (sem o "uém-uém")',
				),
			),
			array(
				'h2' => 'Passo a passo seguro nos primeiros 5 minutos',
				'paragrafos' => array(
					'1) Tire a chave da ignição e espere 1 minuto. Ligue luzes internas — se acenderem fortes, pode ser apenas o motor de partida.',
					'2) Confira se ficou farol, luz interna ou porta aberta a noite toda. Se sim, é descarga simples e a chupeta + 30 min de motor ligado podem resolver.',
					'3) Se a bateria tem mais de 2 anos e o sintoma se repete, a chupeta vai funcionar só por algumas horas — a bateria já não segura carga.',
				),
			),
			array(
				'h2' => 'O que NÃO fazer (erros que custam caro)',
				'paragrafos' => array(
					'Estes três erros aparecem toda semana nos nossos atendimentos:',
				),
				'lista' => array(
					'Ficar forçando a chave: pode queimar o motor de arranque (R$ 600 a R$ 1.500)',
					'Empurrar carro automático ou CVT: pode danificar o câmbio',
					'Fazer chupeta com cabos finos ou polaridade trocada: pode queimar a central eletrônica',
					'Tentar carregar bateria selada em casa sem carregador inteligente',
				),
			),
			array(
				'h2' => 'Quando chamar socorro 24h',
				'paragrafos' => array(
					'Chame socorro se: o carro está em local de risco (rua movimentada, BR, garagem trancada), você tentou chupeta e o carro não pega, ou se a bateria tem mais de 2 anos e o problema é recorrente.',
					'A AWR atende 24 horas em Porto Alegre, Canoas, Gravataí, Cachoeirinha, São Leopoldo, Novo Hamburgo e RMPA — moto-técnico chega em até 35 minutos com bateria nova, instala no local, troca o casco usado e emite nota fiscal. Pagamento em cartão (10x), Pix ou dinheiro.',
				),
			),
			array(
				'h2' => 'Depois de recuperar: a bateria ainda serve?',
				'paragrafos' => array(
					'Carro que pegou na chupeta não significa bateria boa. Depois de recuperar a partida, rode pelo menos 30 minutos seguidos e, no dia seguinte, meça a tensão em repouso: acima de 12,5 V a bateria ainda tem chance; abaixo de 12,2 V ela já perdeu capacidade.',
					'Se a bateria tem mais de 2 anos, ou se você já precisou de chupeta duas vezes no mesmo mês, o caminho mais barato é trocar. Cada descarga profunda sulfata as placas e a próxima parada tende a acontecer em um lugar pior — de madrugada, na chuva ou longe de casa.',
				),
				'lista' => array(
					'Mais de 2 anos de uso + descarga = troque.',
					'Duas chupetas no mesmo mês = troque.',
					'Bateria estufada, vazando ou com polo corroído = troque imediatamente.',
					'Descarregou com o carro parado por semanas = teste de carga antes de decidir.',
					'Descarrega mesmo rodando todo dia = investigue alternador e fuga de corrente.',
				),
			),
			array(
				'h2' => 'Como evitar que aconteça de novo',
				'paragrafos' => array(
					'A maioria das descargas que atendemos tem causa simples e evitável: luz interna acesa, farol esquecido, porta mal fechada, acessório mal instalado ou carro parado tempo demais. Antes de sair do veículo, confira faróis, luz de cortesia e porta-malas.',
					'Se o carro fica parado durante a semana, ligue e deixe funcionando 15 minutos a cada 7 dias — só girar a chave e desligar piora a situação, porque a partida consome mais do que o alternador devolve em poucos segundos.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Posso dar chupeta sem riscos?',
				'resposta' => 'Pode, desde que: use cabos grossos (16 mm² ou mais), conecte vermelho-vermelho (positivo), preto-preto (negativo), e nunca cruze a polaridade. Polaridade trocada queima ECU e fusíveis. Em caso de dúvida, chame um técnico — a visita custa menos que um fusível.',
			),
			array(
				'pergunta' => 'Quanto custa o socorro 24h?',
				'resposta' => 'Na AWR não cobramos taxa de visita — você paga só a bateria nova, com instalação inclusa. Se for caso de chupeta apenas (sem trocar bateria), cobramos uma taxa simbólica de deslocamento que é abatida se você optar pela troca em até 30 dias.',
			),
			array(
				'pergunta' => 'Bateria descarregada estraga?',
				'resposta' => 'Descarga profunda (abaixo de 10,5 V) reduz drasticamente a vida útil. Se a bateria tem mais de 18 meses e ficou totalmente descarregada por mais de 24h, na prática ela já era — recarregar resolve no curto prazo, mas vai descarregar de novo em poucos dias.',
			),
			array(
				'pergunta' => 'Depois da chupeta, quanto tempo preciso rodar para carregar?',
				'resposta' => 'No mínimo 30 minutos em movimento, de preferência em via com velocidade constante. Trajetos curtos de 5 a 10 minutos não recuperam o que a partida consumiu e a bateria descarrega de novo.',
			),
			array(
				'pergunta' => 'Minha bateria descarrega sozinha durante a noite. O que pode ser?',
				'resposta' => 'Normalmente é fuga de corrente por acessório mal instalado (som, alarme, rastreador), luz que não apaga ou bateria já sem capacidade. Um teste de fuga com multímetro identifica a causa em poucos minutos — fazemos isso na visita.',
			),
			array(
				'pergunta' => 'Vocês atendem madrugada e fim de semana?',
				'resposta' => 'Sim, 24 horas, todos os dias, inclusive feriados. Basta chamar no WhatsApp informando endereço, modelo e ano do carro. Resposta em até 2 minutos.',
			),
		),
		'relacionados' => array(
			'carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser',
			'quando-trocar-bateria-do-onix',
			'quanto-tempo-dura-uma-bateria-de-carro',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'bateria-do-hb20-qual-comprar',
		'titulo' => 'Bateria do HB20: Qual Comprar e Quanto Custa',
		'h1' => 'Bateria do Hyundai HB20: qual comprar em 2026',
		'descricao' => 'Comparativo direto: Moura, Heliar ou Zetta para HB20 1.0 e 1.6, Comfort, Vision e Premium. Especificação, preço e garantia.',
		'categoria' => 'Modelos',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria hb20 qual comprar',
		'dataPublicacao' => '2026-06-14',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/mecanico-instalando.webp',
		'imagemAlt' => 'Bateria nova ao lado de um Hyundai HB20',
		'intro' => array(
			'A bateria do Hyundai HB20 dura, em média, 2,5 a 3 anos em Porto Alegre. O HB20 é um carro que castiga um pouco a bateria — alternador conservador e central multimídia consumindo mesmo desligado nas versões mais novas.',
			'Se o seu HB20 está pedindo bateria nova, este guia compara as três marcas mais vendidas na AWR (Moura, Heliar e Zetta) com preço, garantia e melhor encaixe por versão do carro.',
		),
		'secoes' => array(
			array(
				'h2' => 'Qual a especificação da bateria do HB20',
				'paragrafos' => array(
					'HB20 1.0 e 1.6 Comfort/Vision (2013–2019): bateria 50 Ah ou 60 Ah, polo esquerdo (atenção, ao contrário da maioria dos populares).',
					'HB20 Sense/Vision/Limited 1.0 turbo (2020+): bateria 60 Ah, polo esquerdo, recomendação EFB para versões com start-stop ativo.',
					'HB20S Premium e HB20 Platinum: bateria 60 Ah EFB obrigatória — bateria comum pode causar erro na central de injeção.',
				),
			),
			array(
				'h2' => 'Moura, Heliar ou Zetta: qual escolher',
				'paragrafos' => array(
					'Resposta direta, baseada nos atendimentos da AWR em Porto Alegre:',
				),
				'lista' => array(
					'Moura M60GE 60Ah — escolha equilibrada, 18 meses de garantia, indicada para uso diário, escola, trabalho. R$ 515.',
					'Heliar Free 60Ah — premium, 15 meses de garantia, com olho mágico de carga, indicada para HB20 Premium e Platinum. R$ 529.',
					'Zetta Z60D 60Ah — opção custo-benefício, mesma fábrica da Moura, 12 meses de garantia, ótima para HB20 1.0 base. R$ 429.',
					'Para versões com start-stop (Limited, Platinum 2020+): Moura EFB 60Ah, R$ 745.',
				),
			),
			array(
				'h2' => 'Erro comum: polaridade trocada no HB20',
				'paragrafos' => array(
					'O HB20 tem polaridade esquerda — o polo positivo fica do lado esquerdo da bateria, olhando de frente. A maioria dos populares brasileiros tem polo direito.',
					'Cliente que compra bateria errada na internet, ou em loja que não confere o modelo, descobre o erro só quando os cabos não alcançam. Na AWR confirmamos a polaridade pela placa antes de sair para instalar — sem custo extra.',
				),
			),
			array(
				'h2' => 'Quanto custa trocar a bateria do HB20 em 2026',
				'paragrafos' => array(
					'Em Porto Alegre, Canoas, Gravataí, São Leopoldo e Novo Hamburgo, a partir de R$ 429 (Zetta), R$ 515 (Moura) ou R$ 529 (Heliar). EFB para Start-Stop a partir de R$ 745. Todos os preços com instalação no local, base de troca e nota fiscal.',
					'10x sem juros no cartão. A parcela na Moura 60Ah fica em R$ 51,50. Pix com 3% de desconto à vista.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Bateria do HB20 1.0 e 1.6 é a mesma?',
				'resposta' => 'Sim, a especificação é a mesma — 60 Ah polo esquerdo. O que muda é o ano e a presença ou não de start-stop. Versões com start-stop pedem EFB.',
			),
			array(
				'pergunta' => 'Quanto tempo a bateria do HB20 segura?',
				'resposta' => 'Em Porto Alegre, em uso urbano normal, entre 2,5 e 3 anos. Motoristas de Uber e 99 com HB20 costumam trocar entre 18 e 24 meses pelo alto número de partidas curtas.',
			),
			array(
				'pergunta' => 'Pode colocar bateria do Onix no HB20?',
				'resposta' => 'Não. A capacidade (60 Ah) é a mesma, mas a polaridade é diferente — Onix é polo direito, HB20 é polo esquerdo. Os cabos não alcançam e forçar pode danificar a chicote.',
			),
			array(
				'pergunta' => 'Vocês instalam bateria no HB20 em casa ou no trabalho?',
				'resposta' => 'Sim, e é o que mais fazemos. Confirme o pedido pelo WhatsApp informando placa ou ano do carro — o moto-técnico AWR chega em até 35 min em Porto Alegre e instala na rua, garagem, trabalho ou estacionamento.',
			),
		),
		'relacionados' => array(
			'quando-trocar-bateria-do-onix',
			'como-saber-se-bateria-do-carro-esta-fraca-porto-alegre',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'moura-vs-heliar',
		'titulo' => 'Moura ou Heliar? Qual Vale Mais a Pena em 2026',
		'h1' => 'Moura ou Heliar: qual bateria comprar em Porto Alegre e Região',
		'descricao' => 'Comparativo direto entre Moura e Heliar: garantia, desempenho no inverno gaúcho, preço e para quem cada marca vale mais a pena. Guia AWR 2026.',
		'categoria' => 'Comparativos',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria moura ou heliar',
		'dataPublicacao' => '2026-07-20',
		'tempoLeitura' => 7,
		'imagemCapa' => 'assets/img/blog/mecanico-instalando.webp',
		'imagemAlt' => 'Baterias Moura e Heliar lado a lado prontas para instalação',
		'intro' => array(
			'Moura e Heliar são as duas marcas mais vendidas de bateria automotiva no Rio Grande do Sul — e também as duas dúvidas mais frequentes na AWR Baterias. Ambas oferecem 24 meses de garantia, ambas são fabricadas no Brasil e ambas seguram bem o inverno gaúcho. Então qual comprar?',
			'Neste guia comparamos as duas de forma direta, com base em milhares de instalações feitas em Porto Alegre, Canoas, Gravataí, Alvorada e Viamão. Sem torcida, sem marketing — só o que importa na hora de escolher.',
		),
		'secoes' => array(
			array(
				'h2' => 'Garantia: 24 meses nas duas, mas com diferenças',
				'paragrafos' => array(
					'Tanto Moura quanto Heliar oferecem 24 meses de garantia de fábrica nas linhas atuais vendidas pela AWR. A diferença está em como cada rede opera o acionamento.',
					'A Moura tem a maior rede autorizada do Brasil — mais de 3.000 pontos —, o que facilita se você viajar. A Heliar (grupo Clarios, ex-Johnson Controls) tem rede menor, porém com processo digital de garantia por app, o que agiliza laudos em Porto Alegre.',
				),
				'lista' => array(
					'Moura: 24 meses, rede física ampla, laudo presencial em qualquer autorizado.',
					'Heliar: 24 meses, rede menor, laudo digital via app do fabricante (mais rápido em POA).',
					'AWR intermedia a garantia dos dois casos — você não precisa correr atrás.',
				),
			),
			array(
				'h2' => 'Desempenho no inverno gaúcho e no calor do verão',
				'paragrafos' => array(
					'O clima do RS é o maior teste que uma bateria enfrenta: manhãs de 2 °C em julho em Porto Alegre, tardes de 38 °C em janeiro em Canoas, e umidade alta o ano todo. Isso acelera a sulfatação das placas e o desgaste da caixa.',
					'Na prática, a Moura tem tradição em carros nacionais e polos mais reforçados — aguenta bem partidas frias sequenciais (o clássico "gira, gira, pega" de manhã). A Heliar Free traz tecnologia de placas de cálcio-prata com melhor tolerância térmica, o que se traduz em menos perda de carga em dias muito quentes.',
					'Nas nossas trocas em Alvorada e Viamão — onde a variação térmica é maior por causa da região mais aberta —, Moura e Heliar apresentam vida útil praticamente idêntica: entre 2,5 e 3 anos em uso urbano normal.',
				),
			),
			array(
				'h2' => 'Preço em Porto Alegre (60 Ah, referência 2026)',
				'paragrafos' => array(
					'Comparativo dos modelos mais vendidos, com entrega e instalação inclusas em Porto Alegre, Canoas, Gravataí, Alvorada e Viamão:',
				),
				'lista' => array(
					'Moura M60GE 60Ah — R$ 515 à vista, 10x R$ 51,50 no cartão sem juros (3% OFF no Pix).',
					'Heliar 60Ah HE60DD — R$ 510 à vista, 10x R$ 51,00 no cartão sem juros (3% OFF no Pix).',
					'Diferença média: cerca de R$ 5 no mesmo Ah — na prática, empate técnico de preço.',
				),
			),
			array(
				'h2' => 'Para quem a Moura é a melhor escolha',
				'paragrafos' => array(
					'A Moura entrega o melhor custo-benefício quando o carro é de uso diário urbano em Porto Alegre e região — trabalho, escola, mercado. Também é a preferida de motoristas de aplicativo pelo preço e pela rede nacional (útil quando o carro pega estrada com frequência).',
				),
				'lista' => array(
					'Carros populares: Onix, HB20, Gol, Palio, Uno.',
					'Motoristas de Uber e 99 que rodam RMPA.',
					'Quem viaja para litoral, serra ou fora do RS e quer acionamento fácil de garantia.',
				),
			),
			array(
				'h2' => 'Para quem a Heliar vale o investimento',
				'paragrafos' => array(
					'A Heliar Free (linha premium, sem manutenção, com olho mágico de carga) faz sentido em carros com mais eletrônica embarcada, sistemas start-stop e uso mais exigente. Também é primeira escolha em carros importados e SUVs médios.',
				),
				'lista' => array(
					'SUVs e sedãs médios: Compass, Corolla, Civic, HR-V, Tracker.',
					'Carros com start-stop (versão EFB da Heliar).',
					'Quem prefere olho mágico de carga para conferir status sem multímetro.',
				),
			),
			array(
				'h2' => 'Tecnologia e CCA: chumbo-cálcio, EFB e AGM',
				'paragrafos' => array(
					'Além de preço e garantia, o que separa uma bateria da outra é a tecnologia interna e a CCA (Cold Cranking Amps — corrente de partida a frio). Quanto maior a CCA, mais folga o motor tem para pegar nas manhãs de 2 °C do inverno gaúcho.',
					'Moura e Heliar usam chumbo-cálcio selado nas linhas comuns, com CCA equivalente no mesmo Ah (uma 60Ah fica na faixa de 480 a 540 CCA nas duas marcas). A diferença aparece nas linhas para start-stop: a Heliar tem a linha EFB (Enhanced Flooded Battery), feita para o ciclo de liga-desliga constante, e a Moura atende esse uso com a linha Moura Start-Stop EFB. Para carros com start-stop de fábrica, AGM ou EFB não é opcional — colocar uma bateria comum reduz a vida útil pela metade.',
				),
				'lista' => array(
					'Chumbo-cálcio selada: uso urbano comum, sem start-stop. Moura e Heliar empatam.',
					'EFB: obrigatória em carros com start-stop simples (Onix Turbo, HB20 2020+, Renegade).',
					'AGM: SUVs e importados com start-stop + recuperação de energia. Custa mais, mas é a única especificação aceita.',
					'CCA: confira o valor no rótulo da bateria original. Nunca instale uma bateria com CCA abaixo da de fábrica.',
				),
			),
			array(
				'h2' => 'Veredito AWR: qual comprar',
				'paragrafos' => array(
					'Não existe marca "errada" entre Moura e Heliar — as duas são de linha premium e cumprem os 24 meses de garantia. A decisão prática é:',
					'Se o critério for preço e rede nacional, vá de Moura. Se o critério for tecnologia embarcada, olho mágico e uso mais exigente, vá de Heliar. Em qualquer caso, ligue no WhatsApp da AWR informando placa ou modelo do carro — confirmamos a especificação correta (Ah, polaridade, EFB ou comum) antes de sair para instalar em Porto Alegre e região.',
				),
			),
			array(
				'h2' => 'Preço lado a lado em 2026',
				'paragrafos' => array(
					'Comparando as amperagens mais vendidas, com instalação e base de troca inclusas na AWR, a diferença fica em poucos reais entre as duas marcas:',
				),
				'lista' => array(
					'60Ah comum: Moura R$ 515 x Heliar R$ 510.',
					'70Ah: Moura a partir de R$ 775 x Heliar a partir de R$ 729.',
					'EFB start-stop 60Ah: Moura a partir de R$ 745 x Heliar a partir de R$ 769.',
					'Ambas com 24 meses de garantia, nota fiscal e 10x sem juros — Pix à vista com 3% de desconto.',
				),
			),
			array(
				'h2' => 'Qual escolher pelo seu perfil de uso',
				'paragrafos' => array(
					'Motorista de aplicativo, que faz muitas partidas por dia: prefira a Moura pela relação custo-benefício e pela facilidade de acionar garantia em qualquer cidade.',
					'Carro com start-stop, muita eletrônica embarcada ou uso de fim de semana com o veículo parado: a Heliar, com o indicador visual de carga, ajuda no acompanhamento e tolera melhor o calor. Em ambos os casos, o determinante continua sendo instalar a especificação correta — bateria comum em carro que pede EFB dura metade do tempo, independentemente da marca.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Moura ou Heliar dura mais no clima de Porto Alegre?',
				'resposta' => 'Na prática, as duas duram entre 2,5 e 3 anos em uso urbano normal no RS. A Heliar Free tolera um pouco melhor o calor extremo do verão gaúcho; a Moura suporta melhor a sequência de partidas frias no inverno. A diferença é pequena e depende mais do uso do que da marca.',
			),
			array(
				'pergunta' => 'A garantia da Moura e da Heliar é a mesma?',
				'resposta' => 'Sim, ambas oferecem 24 meses de garantia de fábrica nas linhas atuais vendidas pela AWR. A Moura tem rede autorizada maior no Brasil; a Heliar oferece laudo digital via app, que costuma ser mais rápido em Porto Alegre.',
			),
			array(
				'pergunta' => 'Qual a diferença de preço entre Moura e Heliar?',
				'resposta' => 'Poucos reais nas amperagens mais vendidas. Na 60Ah, a Moura sai por R$ 515 e a Heliar por R$ 510, ambas com instalação, base de troca e 24 meses de garantia.',
			),
			array(
				'pergunta' => 'Vale pagar mais caro na Heliar?',
				'resposta' => 'Vale se o carro tem start-stop, muita eletrônica ou você quer o olho mágico de carga. Para uso urbano comum em carro popular, a Moura entrega o mesmo resultado por preço equivalente.',
			),
			array(
				'pergunta' => 'A AWR instala Moura e Heliar em casa em Porto Alegre?',
				'resposta' => 'Sim. Instalamos as duas marcas no local — casa, trabalho, garagem ou estacionamento — em até 35 minutos em Porto Alegre, Canoas, Gravataí, Alvorada, Viamão, São Leopoldo e Novo Hamburgo. Base de troca e nota fiscal inclusas.',
			),
			array(
				'pergunta' => 'Posso pagar parcelado na bateria Moura ou Heliar?',
				'resposta' => 'Sim, em até 10x sem juros no cartão. Pix à vista tem 3% de desconto. Aceitamos débito, crédito e Pix.',
			),
		),
		'relacionados' => array(
			'quanto-custa-uma-bateria-moura',
			'garantia-bateria-moura-quanto-tempo-dura',
			'bateria-do-hb20-qual-comprar',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'quanto-tempo-dura-uma-bateria-de-carro',
		'titulo' => 'Quanto Tempo Dura uma Bateria de Carro? 2 a 4 Anos',
		'h1' => 'Quanto tempo dura uma bateria de carro: duração real por tipo e uso',
		'descricao' => 'A duração média de uma bateria de carro é de 2 a 4 anos. Veja o que encurta a vida útil, como medir a idade da sua e quando trocar em Porto Alegre.',
		'categoria' => 'Manutenção',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'quanto tempo dura uma bateria de carro',
		'dataPublicacao' => '2026-08-04',
		'tempoLeitura' => 7,
		'imagemCapa' => 'assets/img/blog/bateria-fraca.webp',
		'imagemAlt' => 'Bateria automotiva com etiqueta de data de fabricação sendo conferida por técnico',
		'intro' => array(
			'A resposta curta: uma bateria de carro dura entre 2 e 4 anos. A resposta útil é que essa faixa depende de três coisas — tipo de bateria, como o carro é usado e o clima da região. Em Porto Alegre e na Grande POA, com verões de 38 °C e manhãs de inverno perto de 2 °C, a média real que medimos nas trocas da AWR fica entre 2,5 e 3 anos.',
			'Este guia mostra a duração esperada por tipo de bateria, o que encurta a vida útil, como descobrir a idade da bateria que está no seu carro agora e em que ponto vale trocar antes de ficar na mão.',
		),
		'secoes' => array(
			array(
				'h2' => 'Duração média por tipo de bateria',
				'paragrafos' => array(
					'Nem toda bateria é feita para o mesmo ciclo de trabalho. Estas são as faixas que observamos em uso urbano no Rio Grande do Sul:',
				),
				'lista' => array(
					'Chumbo-cálcio selada (comum, a maioria dos carros): 2 a 3 anos.',
					'EFB (carros com start-stop simples): 3 a 4 anos.',
					'AGM (SUVs e importados com start-stop e recuperação de energia): 4 a 5 anos.',
					'Bateria de moto selada: 2 a 3 anos.',
					'Bateria de caminhão (par de 100 Ah a 150 Ah): 1,5 a 2,5 anos pelo uso pesado.',
				),
			),
			array(
				'h2' => 'O que encurta a vida útil no dia a dia',
				'paragrafos' => array(
					'Bateria não morre de velha — morre de ciclo mal feito. Estes são os fatores que mais aparecem nos nossos atendimentos em Porto Alegre, Canoas, Gravataí, Alvorada e Viamão:',
				),
				'lista' => array(
					'Trajetos curtos: 5 a 10 minutos por vez não recarregam o que a partida consumiu.',
					'Carro parado por semanas: a bateria se autodescarrega e sulfata.',
					'Calor extremo: acelera a evaporação e a corrosão interna das placas.',
					'Frio: aumenta a corrente exigida na partida e reduz a capacidade disponível.',
					'Acessórios ligados com o motor desligado: som, câmeras, rastreador e alarme mal instalados.',
					'Alternador fora de faixa: carregar de menos (abaixo de 13,8 V) ou de mais (acima de 14,8 V) destrói a bateria em meses.',
				),
			),
			array(
				'h2' => 'Como descobrir a idade da bateria do seu carro',
				'paragrafos' => array(
					'Toda bateria traz a data de fabricação gravada na etiqueta ou em baixo-relevo na tampa, normalmente no formato mês/ano ou em código alfanumérico. Se a etiqueta indica mais de 3 anos, a bateria já está no fim do ciclo mesmo que ainda esteja dando partida.',
					'O segundo teste é elétrico: com o motor desligado há pelo menos 2 horas, uma bateria saudável marca entre 12,5 V e 12,8 V. Abaixo de 12,4 V ela está parcialmente descarregada; abaixo de 12,0 V já perdeu capacidade de forma permanente. Com o motor ligado, o valor deve ficar entre 13,8 V e 14,7 V — fora disso o problema é o alternador, não a bateria.',
				),
			),
			array(
				'h2' => 'Quando vale trocar antes de quebrar',
				'paragrafos' => array(
					'Trocar por antecipação custa muito menos do que um guincho, uma reunião perdida ou uma viagem cancelada. A regra prática da AWR é: bateria com mais de 3 anos e qualquer sintoma (partida lenta, farol fraco, rádio resetando) é bateria para trocar agora.',
					'Se você depende do carro para trabalhar — motorista de aplicativo, representante comercial, entregador —, antecipe para 24 meses. O custo por mês é baixo perto do risco de ficar parado.',
				),
			),
			array(
				'h2' => 'Como fazer a bateria durar mais',
				'paragrafos' => array(
					'Cuidados simples que estendem meses de vida útil:',
				),
				'lista' => array(
					'Rode pelo menos 20 minutos seguidos algumas vezes por semana.',
					'Se o carro fica parado, dê partida e deixe funcionando 15 minutos a cada 7 dias.',
					'Mantenha os polos limpos e sem aquele pó esbranquiçado (sulfato).',
					'Desligue tudo antes de sair do carro: farol, luz interna, ar e som.',
					'Instale acessórios com profissional — som e rastreador mal ligados drenam corrente 24h por dia.',
					'Peça um teste de carga a cada revisão a partir do segundo ano. Na AWR o teste é gratuito.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto tempo dura uma bateria de carro nova?',
				'resposta' => 'Entre 2 e 4 anos. Em uso urbano em Porto Alegre, a média fica entre 2,5 e 3 anos para bateria comum, 3 a 4 anos para EFB e 4 a 5 anos para AGM.',
			),
			array(
				'pergunta' => 'Bateria pode durar 5 anos?',
				'resposta' => 'Pode, mas é exceção — normalmente em carros com uso diário longo, alternador em ordem e bateria AGM. Passados 4 anos, o risco de parada repentina cresce muito, mesmo que a bateria pareça bem.',
			),
			array(
				'pergunta' => 'Carro parado estraga a bateria?',
				'resposta' => 'Sim. Uma bateria parada perde cerca de 1% de carga por dia, e mais rápido no calor. Depois de 30 a 45 dias sem uso, ela pode chegar em descarga profunda e perder capacidade de forma permanente.',
			),
			array(
				'pergunta' => 'Como saber se preciso trocar a bateria ou é o alternador?',
				'resposta' => 'Meça a tensão com o motor ligado: 13,8 V a 14,7 V indica alternador em ordem, e nesse caso o problema é a bateria. Abaixo de 13,5 V ou acima de 14,8 V, o alternador é o suspeito.',
			),
			array(
				'pergunta' => 'A AWR faz teste de bateria em casa?',
				'resposta' => 'Sim. Fazemos teste de carga e de alternador no local, sem custo, em Porto Alegre e Grande POA. Se precisar trocar, o técnico já leva a bateria nova e instala na hora.',
			),
		),
		'relacionados' => array(
			'como-saber-se-bateria-do-carro-esta-fraca-porto-alegre',
			'bateria-ou-alternador-como-saber-porto-alegre',
			'bateria-de-carro-no-inverno-gaucho-cuidados',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
			'aplicacaoSlug' => 'carro-popular',
		),
	),
	array(
		'slug' => 'quanto-custa-a-bateria-de-um-carro-eletrico',
		'titulo' => 'Bateria de Carro Elétrico: Quanto Custa em 2026',
		'h1' => 'Quanto custa a bateria de um carro elétrico (e a de 12V que quase ninguém lembra)',
		'descricao' => 'Preço da bateria de tração de carro elétrico e da bateria auxiliar de 12V. Entenda a diferença, quando cada uma falha e quanto custa trocar no RS.',
		'categoria' => 'Preços',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'quanto custa a bateria de um carro elétrico',
		'dataPublicacao' => '2026-08-04',
		'tempoLeitura' => 7,
		'imagemCapa' => 'assets/img/blog/bateria-carro-eletrico.webp',
		'imagemAlt' => 'Técnico verificando a bateria auxiliar de 12V no compartimento de um carro elétrico',
		'intro' => array(
			'Todo carro elétrico tem duas baterias, e elas custam coisas muito diferentes. A bateria de tração é o pacote de alta tensão que move o carro, trocado em concessionária e coberto por garantia longa. A bateria auxiliar de 12V é uma bateria comum — a mesma tecnologia de um carro a combustão — e é ela que trava o carro quando descarrega.',
			'Este guia separa as duas, mostra a faixa de preço de cada uma no Brasil em 2026 e explica qual delas a AWR entrega e instala em Porto Alegre e região.',
		),
		'secoes' => array(
			array(
				'h2' => 'Bateria de tração: a faixa de preço em 2026',
				'paragrafos' => array(
					'A bateria de tração é o item mais caro de um elétrico e o preço acompanha a capacidade em kWh. Como referência de mercado, o pacote costuma representar de 25% a 40% do valor do carro, e a substituição fora de garantia parte da casa das dezenas de milhares de reais em modelos compactos, chegando a valores bem maiores em SUVs e sedãs de bateria grande.',
					'Na prática, a troca completa é rara: praticamente todas as montadoras oferecem 8 anos ou 160.000 km de garantia sobre o pacote de tração, com critério de degradação (normalmente abaixo de 70% da capacidade original). Antes de orçar um pacote novo, sempre confirme se o seu carro ainda está dentro dessa cobertura e peça o laudo de saúde da bateria na concessionária.',
				),
				'lista' => array(
					'Preço acompanha kWh: quanto maior a autonomia, maior o custo do pacote.',
					'Garantia típica: 8 anos ou 160.000 km, com limite de degradação.',
					'Troca de módulo individual, quando o fabricante permite, custa uma fração do pacote inteiro.',
					'Serviço exclusivo de rede autorizada — alta tensão exige técnico certificado.',
				),
			),
			array(
				'h2' => 'A bateria de 12V do elétrico: essa sim você troca como qualquer carro',
				'paragrafos' => array(
					'O que quase ninguém conta: o carro elétrico tem uma bateria de 12V exatamente como um carro a gasolina. Ela alimenta central, travas, faróis, som e — o mais importante — é ela que "acorda" o sistema de alta tensão. Se a 12V descarrega, o carro não liga mesmo com o pacote de tração cheio.',
					'Essa bateria de 12V dura entre 2 e 4 anos e custa o mesmo que a de um carro comum: a partir de R$ 329 em uma 60Ah, com modelos AGM entre R$ 1.129 e R$ 2.575 conforme o veículo. É esse item que a AWR fornece, entrega e instala no local em Porto Alegre e Grande POA.',
				),
			),
			array(
				'h2' => 'Sinais de que a 12V do seu elétrico está no fim',
				'paragrafos' => array(
					'Os sintomas são parecidos com os de um carro a combustão, mas aparecem de forma mais eletrônica:',
				),
				'lista' => array(
					'Carro não liga o sistema (fica "morto") mesmo com bateria de tração carregada.',
					'Central multimídia reiniciando ou demorando a subir.',
					'Travas e vidros lentos, alerta de sistema elétrico no painel.',
					'Carro perdendo o "acordar remoto" pelo aplicativo.',
				),
			),
			array(
				'h2' => 'Híbridos: mesma lógica',
				'paragrafos' => array(
					'Híbridos como Corolla Cross Hybrid, Toyota Prius, Haval H6 e CR-V também têm bateria de 12V separada do pacote híbrido. Ela costuma ser AGM e a troca segue o mesmo caminho: peça a especificação correta pela placa, porque colocar bateria comum onde o carro pede AGM reduz a vida útil pela metade.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto custa trocar a bateria de tração de um carro elétrico?',
				'resposta' => 'É o item mais caro do veículo e o preço varia conforme o kWh do pacote e o modelo — na maioria dos casos a substituição fora de garantia entra na casa das dezenas de milhares de reais. Peça sempre o orçamento oficial da rede autorizada antes de decidir.',
			),
			array(
				'pergunta' => 'A garantia cobre a bateria do carro elétrico?',
				'resposta' => 'Em geral sim: o padrão do mercado é 8 anos ou 160.000 km para o pacote de tração, com limite de degradação em torno de 70% da capacidade original. Confirme as condições no manual do seu modelo.',
			),
			array(
				'pergunta' => 'A AWR troca bateria de carro elétrico?',
				'resposta' => 'Trocamos a bateria auxiliar de 12V, que é a que mais deixa o carro parado — entregamos e instalamos no local em Porto Alegre e Grande POA. O pacote de tração de alta tensão é serviço exclusivo da rede autorizada da montadora.',
			),
			array(
				'pergunta' => 'Quanto dura a bateria de 12V de um carro elétrico?',
				'resposta' => 'De 2 a 4 anos, igual à de um carro a combustão. Em modelos que ficam muito tempo parados, ela pode falhar antes disso.',
			),
		),
		'relacionados' => array(
			'quanto-tempo-dura-uma-bateria-de-carro',
			'quanto-custa-a-bateria-nova-do-dolphin-mini',
			'bateria-descarregada-o-que-fazer',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'quanto-custa-uma-bateria-moura',
		'titulo' => 'Quanto Custa uma Bateria Moura? Tabela por Ah',
		'h1' => 'Quanto custa uma bateria Moura: preços por amperagem em 2026',
		'descricao' => 'Preço da bateria Moura 50Ah, 60Ah, 70Ah, 100Ah e EFB com instalação inclusa em Porto Alegre e Grande POA. Garantia de 24 meses e 10x sem juros.',
		'categoria' => 'Preços',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'quanto custa uma bateria moura',
		'dataPublicacao' => '2026-08-04',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/mecanico-instalando.webp',
		'imagemAlt' => 'Bateria Moura nova pronta para instalação no capô de um carro',
		'intro' => array(
			'A Moura é a bateria mais vendida do Rio Grande do Sul e a pergunta que mais recebemos no WhatsApp é direta: quanto custa? O preço depende da amperagem (Ah) que o seu carro pede e da tecnologia — comum ou EFB, para carros com start-stop.',
			'Abaixo está a referência de preço praticada pela AWR em 2026 em Porto Alegre, Canoas, Gravataí, Alvorada, Viamão, São Leopoldo e Novo Hamburgo, sempre com entrega, instalação no local, base de troca e nota fiscal inclusas.',
		),
		'secoes' => array(
			array(
				'h2' => 'Preço da bateria Moura por amperagem',
				'paragrafos' => array(
					'Valores de referência 2026, com instalação inclusa e 24 meses de garantia:',
				),
				'lista' => array(
					'Moura 50Ah — a partir de R$ 485. Indicada para Uno, Gol, Palio, Ka e populares 1.0 antigos.',
					'Moura 60Ah (M60GE) — R$ 515. A mais vendida: Onix, HB20, Argo, Sandero, Fiesta, Corsa.',
					'Moura 70Ah — a partir de R$ 775. Sedãs médios, SUVs compactos e carros com muito acessório.',
					'Moura 100Ah — a partir de R$ 985. Caminhonetes, utilitários e veículos a diesel.',
					'Moura Start-Stop EFB 60Ah — a partir de R$ 745. Obrigatória em carros com start-stop de fábrica.',
				),
			),
			array(
				'h2' => 'O que já está incluso no preço',
				'paragrafos' => array(
					'O valor anunciado pela AWR não é preço de balcão "seco". Ele inclui a entrega, a instalação feita por técnico, o teste do alternador e a retirada do casco velho.',
				),
				'lista' => array(
					'Entrega e instalação no local (casa, trabalho, garagem ou rua).',
					'Base de troca: você entrega a bateria antiga, sem custo adicional.',
					'Teste de alternador e do sistema de carga antes de instalar.',
					'Nota fiscal e 24 meses de garantia de fábrica, com acionamento intermediado pela AWR.',
				),
			),
			array(
				'h2' => 'Formas de pagamento e desconto',
				'paragrafos' => array(
					'Pix à vista tem 3% de desconto. No cartão, parcelamos em até 10x sem juros — uma Moura 60Ah de R$ 515 fica em 10x de R$ 51,50. Também aceitamos débito e dinheiro.',
					'Se você precisa da bateria mais barata possível, temos a linha de entrada a partir de R$ 329 (60Ah Eletra). A Moura fica no meio da tabela, com a melhor relação entre garantia e rede autorizada.',
				),
			),
			array(
				'h2' => 'Por que o preço da Moura varia entre lojas',
				'paragrafos' => array(
					'Três coisas explicam a diferença de preço que você vê pesquisando: a amperagem (uma 70Ah custa naturalmente mais que uma 60Ah), a linha (comum, EFB ou AGM) e o que está incluso. Muita oferta baixa na internet é preço sem instalação, sem base de troca e sem garantia local — na hora do problema, o cliente precisa levar a bateria até um autorizado por conta própria.',
					'Antes de comparar, confirme sempre: o preço inclui instalação? Inclui a retirada da bateria velha? A garantia é acionada onde?',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto custa uma bateria Moura 60Ah?',
				'resposta' => 'R$ 515 na AWR, com entrega, instalação no local, base de troca, nota fiscal e 24 meses de garantia. No Pix à vista sai com 3% de desconto; no cartão, 10x de R$ 51,50 sem juros.',
			),
			array(
				'pergunta' => 'Qual a garantia da bateria Moura?',
				'resposta' => '24 meses de garantia de fábrica nas linhas atuais vendidas pela AWR. Nós intermediamos o acionamento — você não precisa procurar o fabricante sozinho.',
			),
			array(
				'pergunta' => 'A Moura é melhor que as marcas mais baratas?',
				'resposta' => 'A Moura entrega mais garantia e a maior rede autorizada do país. Linhas de entrada custam menos e atendem bem carros de uso leve, mas com garantia menor. Para uso diário e motorista de aplicativo, a Moura costuma compensar.',
			),
			array(
				'pergunta' => 'Vocês instalam a Moura no mesmo dia?',
				'resposta' => 'Sim. Em Porto Alegre a média é de 35 minutos entre o pedido e a instalação; nas demais cidades da Grande POA, no mesmo dia dentro do horário de atendimento.',
			),
		),
		'relacionados' => array(
			'moura-vs-heliar',
			'garantia-bateria-moura-quanto-tempo-dura',
			'quanto-custa-trocar-bateria-do-carro-gravatai',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'quanto-custa-a-bateria-nova-do-dolphin-mini',
		'titulo' => 'Bateria do Dolphin Mini: Preço e Troca no Local',
		'h1' => 'Quanto custa uma bateria nova do BYD Dolphin Mini',
		'descricao' => 'Veja quanto custa a bateria nova do BYD Dolphin Mini, qual modelo é compatível e peça a sua com instalação grátis no local. Atendimento pelo WhatsApp.',
		'categoria' => 'Modelos',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria dolphin mini preço',
		'dataPublicacao' => '2026-08-04',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/bateria-carro-eletrico.webp',
		'imagemAlt' => 'Compartimento do motor de um carro elétrico compacto com a bateria auxiliar de 12V à vista',
		'intro' => array(
			'O BYD Dolphin Mini virou um dos elétricos mais vendidos do Brasil e, com a frota crescendo em Porto Alegre, cresceu também a dúvida sobre o custo de trocar a bateria. Como todo elétrico, ele tem duas: o pacote de tração Blade (LFP, de alta tensão) e a bateria auxiliar de 12V.',
			'São dois cenários de preço completamente diferentes — e o que mais deixa Dolphin Mini parado no estacionamento é justamente a barata das duas.',
		),
		'secoes' => array(
			array(
				'h2' => 'Bateria de tração Blade: o pacote de alta tensão',
				'paragrafos' => array(
					'O Dolphin Mini usa a bateria Blade de lítio-ferro-fosfato (LFP), com cerca de 38 kWh na versão vendida no Brasil. É uma química reconhecida pela durabilidade em ciclos, e a BYD cobre o pacote com garantia longa — o padrão do mercado para pacote de tração é de 8 anos ou 160.000 km, com critério de degradação.',
					'A substituição integral fora de garantia é um serviço de concessionária, com preço na casa das dezenas de milhares de reais, e é rara na prática. Quando existe falha localizada, o caminho normal é a troca de módulo pela rede autorizada, com custo muito menor. Peça sempre o laudo de estado de saúde (SOH) antes de qualquer orçamento.',
				),
			),
			array(
				'h2' => 'Bateria auxiliar de 12V: essa é a que costuma dar problema',
				'paragrafos' => array(
					'O Dolphin Mini tem uma bateria de 12V comum, igual à de um carro a combustão, responsável por travas, painel, multimídia e por ligar o sistema de alta tensão. Se ela descarrega, o carro não liga mesmo com o pacote Blade cheio — é o chamado telefone sem linha do elétrico.',
					'Essa bateria dura de 2 a 4 anos e a troca custa a partir de R$ 329, com modelos reforçados e AGM em faixas superiores conforme a especificação do veículo. A AWR entrega e instala no local em Porto Alegre e Grande POA, com teste do sistema de carga incluso.',
				),
			),
			array(
				'h2' => 'Sintomas de 12V fraca no Dolphin Mini',
				'paragrafos' => array(
					'Se o seu Dolphin Mini apresenta qualquer um destes sinais, a bateria de 12V é a primeira suspeita:',
				),
				'lista' => array(
					'Carro não "acorda" ao destravar, mesmo com carga alta no aplicativo.',
					'Tela multimídia demorando ou reiniciando sozinha.',
					'Alerta de sistema elétrico ao ligar.',
					'Carro que ficou parado alguns dias e não responde ao controle.',
				),
			),
			array(
				'h2' => 'Como preservar as duas baterias',
				'paragrafos' => array(
					'Boas práticas simples que valem tanto para o pacote Blade quanto para a 12V:',
				),
				'lista' => array(
					'Evite deixar o carro parado por semanas com carga muito baixa.',
					'Para uso diário, mantenha a carga entre 20% e 80%; carga cheia apenas antes de viagens.',
					'Use carga rápida DC só quando necessário.',
					'Se o carro ficar parado, ligue o sistema por alguns minutos a cada semana para manter a 12V.',
					'Peça teste da 12V a cada revisão a partir do segundo ano.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto custa a bateria nova do Dolphin Mini?',
				'resposta' => 'Depende de qual: a bateria auxiliar de 12V parte de R$ 329 com instalação inclusa; já o pacote de tração Blade é um serviço de concessionária, com custo na casa das dezenas de milhares de reais e normalmente coberto pela garantia de fábrica.',
			),
			array(
				'pergunta' => 'Qual a garantia da bateria do Dolphin Mini?',
				'resposta' => 'O pacote de tração segue o padrão do segmento: garantia longa por tempo e quilometragem, com limite de degradação. Confirme os prazos exatos no manual do seu veículo e na rede BYD.',
			),
			array(
				'pergunta' => 'A AWR atende Dolphin Mini?',
				'resposta' => 'Sim, para a bateria de 12V — entregamos e instalamos no local em Porto Alegre, Canoas, Alvorada, Viamão, Gravataí, São Leopoldo e Novo Hamburgo, com teste do sistema de carga.',
			),
			array(
				'pergunta' => 'Dá para dar chupeta em um Dolphin Mini?',
				'resposta' => 'Dá, mas apenas nos terminais de 12V indicados pelo fabricante e com cabos adequados. Nunca conecte nada ao sistema de alta tensão. Em caso de dúvida, chame um técnico.',
			),
		),
		'relacionados' => array(
			'quanto-custa-a-bateria-de-um-carro-eletrico',
			'quanto-tempo-dura-uma-bateria-de-carro',
			'bateria-descarregada-o-que-fazer',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'heliar',
		),
	),
	array(
		'slug' => 'bateria-de-moto-quando-trocar',
		'titulo' => 'Bateria de Moto: Quando Trocar e Quanto Custa',
		'h1' => 'Bateria de moto: quando trocar, sinais e preço',
		'descricao' => 'Saiba quando trocar a bateria da sua moto, quanto custa hoje e como achar o modelo certo. Entrega rápida em Porto Alegre e região pelo WhatsApp.',
		'categoria' => 'Manutenção',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria de moto quando trocar',
		'dataPublicacao' => '2026-08-04',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/bateria-moto.webp',
		'imagemAlt' => 'Mecânico substituindo a bateria selada de uma motocicleta em oficina',
		'intro' => array(
			'Bateria de moto avisa menos que a de carro. Como muita moto ainda liga no pedal ou tem partida leve, o motociclista descobre o problema só quando aperta o botão e não acontece nada — normalmente com pressa, na frente do trabalho.',
			'A vida útil média de uma bateria de moto selada é de 2 a 3 anos. Este guia mostra os sinais de que a hora chegou, como testar sem levar em oficina e quanto custa trocar em Porto Alegre e Grande POA.',
		),
		'secoes' => array(
			array(
				'h2' => 'Sinais de que a bateria da moto precisa ser trocada',
				'paragrafos' => array(
					'Dois ou mais destes sintomas juntos significam bateria no fim:',
				),
				'lista' => array(
					'Partida elétrica falha, mas no pedal a moto pega normal.',
					'Buzina fraca ou abafada com o motor desligado.',
					'Farol e painel apagando ou piscando ao apertar o botão de partida.',
					'Setas piscando devagar.',
					'Moto que só liga depois de ficar carregando algumas horas.',
					'Bateria estufada, com vazamento ou terminais esbranquiçados.',
				),
			),
			array(
				'h2' => 'Quanto tempo dura e o que encurta a vida útil',
				'paragrafos' => array(
					'Uma bateria selada de moto (5 Ah a 12 Ah) dura de 2 a 3 anos em uso regular. O grande vilão é a moto parada: parada de 3 a 4 semanas, ela pode entrar em descarga profunda e não recuperar mais a capacidade original.',
					'O segundo vilão é o excesso de acessório — alarme, farol auxiliar de LED, carregador USB e rastreador consomem corrente mesmo com a moto desligada. Em moto de entregador, que faz muitas partidas curtas por dia, a média cai para perto de 18 a 24 meses.',
				),
			),
			array(
				'h2' => 'Como testar a bateria da moto em 2 minutos',
				'paragrafos' => array(
					'Com a moto desligada há pelo menos duas horas, meça a tensão nos terminais com um multímetro: acima de 12,6 V significa bateria carregada; entre 12,0 V e 12,4 V, parcialmente descarregada; abaixo de 11,8 V, bateria comprometida.',
					'Ligue a moto e meça de novo com o motor acelerado: o valor deve subir para a faixa de 13,5 V a 14,5 V. Se não subir, o problema está no regulador/retificador, e trocar a bateria sem resolver isso vai queimar a nova em poucas semanas.',
				),
			),
			array(
				'h2' => 'Quanto custa e como funciona a troca',
				'paragrafos' => array(
					'As baterias de moto mais comuns (5 Ah, 6 Ah, 7 Ah, 9 Ah e 12 Ah) atendem modelos como CG 160, Biz, Fan, Factor, Fazer, XRE, Bros, Titan e scooters urbanas. A AWR trabalha com linha selada de baixa manutenção, com garantia de fábrica e nota fiscal.',
					'Informe modelo e ano da moto pelo WhatsApp que confirmamos a amperagem e a posição dos polos antes de sair. Em Porto Alegre, entregamos e instalamos no local, inclusive na garagem do prédio ou na frente do trabalho.',
				),
			),
			array(
				'h2' => 'Como fazer a bateria da moto durar mais',
				'paragrafos' => array(
					'Cuidados simples, principalmente para quem usa a moto só no fim de semana:',
				),
				'lista' => array(
					'Rode pelo menos 20 minutos por semana, ou use um carregador inteligente (float).',
					'Nunca use carregador de bateria de carro em bateria de moto sem regulagem de corrente.',
					'Mantenha os terminais limpos e apertados.',
					'Desligue o alarme extra quando a moto ficar guardada por longos períodos.',
					'Confira o regulador de tensão se a bateria durou menos de 1 ano.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto tempo dura uma bateria de moto?',
				'resposta' => 'De 2 a 3 anos em uso regular. Em motos de entrega, com muitas partidas curtas por dia, a média cai para 18 a 24 meses. Motos paradas por semanas seguidas podem perder a bateria bem antes disso.',
			),
			array(
				'pergunta' => 'Dá para recarregar a bateria da moto em vez de trocar?',
				'resposta' => 'Dá, se a descarga foi pontual (alarme ligado, moto parada) e a bateria tem menos de 2 anos. Se ela descarrega de novo em poucos dias, já perdeu capacidade e precisa ser trocada.',
			),
			array(
				'pergunta' => 'Posso usar bateria de amperagem maior na minha moto?',
				'resposta' => 'Só se couber no compartimento e a polaridade for a mesma. Amperagem um pouco maior não danifica o sistema, mas amperagem menor que a original reduz a partida e a vida útil.',
			),
			array(
				'pergunta' => 'A AWR troca bateria de moto no local?',
				'resposta' => 'Sim, entregamos e instalamos bateria de moto em Porto Alegre e Grande POA. Envie modelo e ano no WhatsApp para confirmarmos a amperagem correta e o preço antes do deslocamento.',
			),
		),
		'relacionados' => array(
			'quanto-tempo-dura-uma-bateria-de-carro',
			'bateria-de-caminhao-quando-trocar',
			'bateria-descarregada-o-que-fazer',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'bateria-de-caminhao-quando-trocar',
		'titulo' => 'Bateria de Caminhão: Quando Trocar e Sinais',
		'h1' => 'Bateria de caminhão: quando trocar, sinais e cuidados',
		'descricao' => 'Bateria de caminhão dura de 1,5 a 2,5 anos. Sinais de troca, por que trocar o par junto, teste de carga e atendimento na frota em Porto Alegre.',
		'categoria' => 'Manutenção',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria de caminhão quando trocar',
		'dataPublicacao' => '2026-08-04',
		'tempoLeitura' => 7,
		'imagemCapa' => 'assets/img/blog/bateria-caminhao.webp',
		'imagemAlt' => 'Técnico medindo a tensão das baterias no compartimento lateral de um caminhão',
		'intro' => array(
			'Em caminhão, bateria fraca não é só transtorno: é frete parado, entrega atrasada e diária perdida. Como o sistema é de 24V formado por duas baterias de 12V em série, um problema em uma delas derruba o conjunto inteiro.',
			'A vida útil típica de uma bateria de caminhão em serviço pesado fica entre 1,5 e 2,5 anos. Veja quando trocar, por que o par precisa ser trocado junto e como funciona o atendimento da AWR em pátio e frota em Porto Alegre e Grande POA.',
		),
		'secoes' => array(
			array(
				'h2' => 'Sinais de que a bateria do caminhão precisa ser trocada',
				'paragrafos' => array(
					'No diesel, os sintomas aparecem primeiro na partida a frio:',
				),
				'lista' => array(
					'Motor girando devagar nas manhãs frias, principalmente no inverno gaúcho.',
					'Necessidade de duas ou três tentativas de partida.',
					'Luzes do painel oscilando ao acionar o motor de arranque.',
					'Ar condicionado, guincho ou plataforma perdendo força com o motor desligado.',
					'Terminais com sulfato branco/esverdeado ou caixa estufada.',
					'Necessidade recorrente de chupeta no pátio.',
				),
			),
			array(
				'h2' => 'Por que trocar as duas baterias juntas',
				'paragrafos' => array(
					'As duas baterias em série trabalham como um conjunto único: a mais fraca define o desempenho do par. Colocar uma bateria nova ao lado de uma velha faz a nova trabalhar sobrecarregada e perder vida útil em poucos meses — na prática, você paga duas vezes.',
					'A recomendação técnica é substituir sempre o par, com mesma marca, mesma amperagem e mesma data de fabricação. Vale o mesmo para frotas: padronizar o modelo simplifica o estoque e o controle de garantia.',
				),
			),
			array(
				'h2' => 'Amperagem correta e uso da frota',
				'paragrafos' => array(
					'Caminhões leves e médios costumam usar par de 100 Ah; pesados, extrapesados e veículos com muito acessório pedem 135 Ah, 150 Ah ou 180 Ah. Quem roda com sleeper, geladeira, inversor ou ar condicionado estacionário deve considerar amperagem maior ou bateria de ciclo profundo auxiliar.',
					'Nunca instale amperagem menor que a original: o motor de arranque de um diesel exige corrente de partida alta e a bateria subdimensionada se degrada rapidamente.',
				),
			),
			array(
				'h2' => 'Teste de carga: o jeito certo de decidir',
				'paragrafos' => array(
					'Medir só a tensão em repouso engana. Uma bateria de caminhão pode marcar 12,5 V parada e ainda assim não sustentar a partida, porque perdeu capacidade de entregar corrente sob carga.',
					'O teste correto é o de carga (ou por condutância), que mede a corrente real de partida contra o valor nominal. Fazemos esse teste no pátio, nas duas baterias e no alternador, antes de recomendar qualquer troca — se o problema for alternador ou cabo de massa, trocar bateria não resolve.',
				),
			),
			array(
				'h2' => 'Como aumentar a vida útil no serviço pesado',
				'paragrafos' => array(
					'Rotinas simples que evitam parada de veículo:',
				),
				'lista' => array(
					'Aperte e limpe os terminais mensalmente — folga gera resistência e calor.',
					'Confira o cabo de massa; massa ruim simula bateria ruim.',
					'Evite deixar sistemas ligados com o motor desligado por horas.',
					'Registre a data de instalação na própria bateria e programe a troca preventiva.',
					'Em frota, faça teste de carga a cada 6 meses.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto tempo dura a bateria de um caminhão?',
				'resposta' => 'Entre 1,5 e 2,5 anos em serviço pesado. Caminhões com uso leve e manutenção em dia podem passar de 3 anos, mas o desgaste é sempre maior que em carros de passeio.',
			),
			array(
				'pergunta' => 'Posso trocar só uma das duas baterias?',
				'resposta' => 'Não é recomendado. A bateria mais fraca puxa o conjunto para baixo e a nova se desgasta rápido. Troque sempre o par, com mesma marca e amperagem.',
			),
			array(
				'pergunta' => 'Qual amperagem devo usar?',
				'resposta' => 'Use a mesma indicada pelo fabricante ou maior. Leves e médios geralmente usam par de 100 Ah; pesados, de 135 Ah a 180 Ah, especialmente com sleeper e acessórios.',
			),
			array(
				'pergunta' => 'A AWR atende frota e pátio?',
				'resposta' => 'Sim. Atendemos frotas em Porto Alegre e Grande POA com entrega no pátio, teste de carga das baterias e do alternador, nota fiscal e condições para pessoa jurídica.',
			),
		),
		'relacionados' => array(
			'bateria-de-moto-quando-trocar',
			'bateria-de-nobreak-quando-trocar',
			'quanto-tempo-dura-uma-bateria-de-carro',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
			'aplicacaoSlug' => 'caminhonete',
		),
	),
	array(
		'slug' => 'bateria-de-nobreak-quando-trocar',
		'titulo' => 'Bateria de Nobreak: Quando Trocar e Como Testar',
		'h1' => 'Bateria de nobreak: quando trocar, sinais e vida útil',
		'descricao' => 'Bateria de nobreak dura de 2 a 4 anos. Veja os sinais de troca, como testar a autonomia, qual modelo usar e onde comprar em Porto Alegre.',
		'categoria' => 'Manutenção',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria nobreak quando trocar',
		'dataPublicacao' => '2026-08-04',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/bateria-nobreak.webp',
		'imagemAlt' => 'Técnico substituindo baterias seladas dentro de um nobreak em sala técnica',
		'intro' => array(
			'Nobreak com bateria velha é pior do que nobreak nenhum: ele passa a sensação de proteção e desliga tudo no primeiro piscar de luz. Em consultório, loja, servidor, portão eletrônico ou sistema de câmeras, isso significa dados perdidos e operação parada.',
			'A bateria selada de nobreak (VRLA/AGM) dura de 2 a 4 anos, dependendo da temperatura do ambiente e do número de quedas de energia. Veja como identificar a hora da troca e como escolher a bateria certa.',
		),
		'secoes' => array(
			array(
				'h2' => 'Sinais de que a bateria do nobreak precisa ser trocada',
				'paragrafos' => array(
					'A maioria dos nobreaks avisa — só que de um jeito discreto:',
				),
				'lista' => array(
					'Autonomia despencou: o equipamento que segurava 15 minutos agora não segura 2.',
					'Nobreak apitando de forma contínua ou LED de bateria em vermelho/âmbar.',
					'Equipamentos desligando na hora exata da queda de energia.',
					'Nobreak esquentando mais que o normal.',
					'Bateria estufada, com marcas de vazamento ou cheiro forte.',
					'Mais de 3 anos desde a última troca (mesmo sem sintoma).',
				),
			),
			array(
				'h2' => 'Quanto tempo dura e o que reduz a vida útil',
				'paragrafos' => array(
					'A vida útil projetada da bateria selada de nobreak é de 3 a 5 anos em ambiente climatizado, mas na prática brasileira ela fica entre 2 e 4 anos. O fator mais destrutivo é o calor: acima de 25 °C, cada 8 a 10 °C a mais reduz a expectativa de vida praticamente pela metade.',
					'O segundo fator é o número de ciclos: em regiões com muitas quedas de energia, a bateria descarrega e recarrega com frequência e se desgasta mais rápido. Nobreak instalado atrás de armário, sem ventilação, é o cenário clássico de bateria durando um ano e meio.',
				),
			),
			array(
				'h2' => 'Como testar a autonomia sem risco',
				'paragrafos' => array(
					'O teste mais simples é o de descarga controlada: com equipamentos não críticos ligados, tire o nobreak da tomada e cronometre até ele apitar em bateria baixa. Compare com a autonomia original do equipamento — se caiu abaixo de 50%, é hora de trocar.',
					'Nunca faça esse teste com servidor, gravador de câmeras ou equipamento médico em operação. E se o nobreak desliga instantaneamente ao tirar da tomada, não repita o teste: a bateria já está inutilizada.',
				),
			),
			array(
				'h2' => 'Qual bateria usar na troca',
				'paragrafos' => array(
					'Nobreaks compactos usam baterias seladas de 12V 7Ah ou 9Ah; modelos maiores e racks usam 12V 18Ah, 45Ah ou bancos com várias baterias em série. Sempre respeite a tensão e a capacidade original do fabricante e substitua todas as baterias do banco ao mesmo tempo, com mesmo modelo e lote.',
					'Misturar bateria nova com usada no mesmo banco desequilibra a carga e derruba a vida útil do conjunto — o mesmo princípio das baterias em série de caminhão.',
				),
				'lista' => array(
					'12V 7Ah / 9Ah: nobreaks de computador, roteador, câmeras e portão eletrônico.',
					'12V 18Ah: nobreaks de maior autonomia e pequenos racks.',
					'12V 45Ah ou mais: bancos externos, sistemas de segurança e servidores.',
					'Troque o banco inteiro de uma vez, nunca uma bateria isolada.',
				),
			),
			array(
				'h2' => 'Onde comprar em Porto Alegre',
				'paragrafos' => array(
					'A AWR trabalha com baterias seladas VRLA/AGM para nobreak, alarme, CFTV, portão eletrônico e sistemas de segurança, com nota fiscal e garantia de fábrica. Informe o modelo do nobreak ou a especificação impressa na bateria antiga (tensão e Ah) pelo WhatsApp que confirmamos a compatibilidade e o preço.',
					'Atendemos empresas e condomínios em Porto Alegre, Canoas, Gravataí, Alvorada, Viamão, São Leopoldo e Novo Hamburgo, com entrega no local e condições para pessoa jurídica.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto tempo dura a bateria de um nobreak?',
				'resposta' => 'De 2 a 4 anos na prática. Em ambiente climatizado e com poucas quedas de energia, pode chegar a 5 anos; em local quente e sem ventilação, pode não passar de 18 meses.',
			),
			array(
				'pergunta' => 'Posso trocar só uma bateria do banco?',
				'resposta' => 'Não é recomendado. As baterias em série se equilibram entre si: uma nova junto de usadas se desgasta rapidamente. Troque todas ao mesmo tempo, com mesmo modelo.',
			),
			array(
				'pergunta' => 'Bateria estufada de nobreak é perigosa?',
				'resposta' => 'Sim. Estufamento indica gaseificação interna por sobrecarga ou calor. Desligue o equipamento, não perfure a bateria e faça o descarte em ponto adequado — nós recebemos o material usado na troca.',
			),
			array(
				'pergunta' => 'Dá para usar bateria de carro no nobreak?',
				'resposta' => 'Não é indicado. Bateria automotiva é feita para picos curtos de corrente, e o nobreak exige descarga lenta e contínua. Use bateria selada VRLA/AGM estacionária, que é projetada para esse ciclo.',
			),
		),
		'relacionados' => array(
			'bateria-de-caminhao-quando-trocar',
			'bateria-de-moto-quando-trocar',
			'quanto-tempo-dura-uma-bateria-de-carro',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'sinais-de-que-a-bateria-da-moto-esta-morrendo',
		'titulo' => 'Bateria da Moto Morrendo? 7 Sinais de Alerta',
		'h1' => 'Sinais de que a bateria da sua moto está morrendo',
		'descricao' => 'Partida lenta, farol fraco, seta devagar: veja 7 sinais de bateria de moto no fim, como testar com multímetro e quando é o regulador de tensão.',
		'categoria' => 'Moto',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'sinais bateria de moto fraca',
		'dataPublicacao' => '2026-08-10',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/bateria-moto.webp',
		'imagemAlt' => 'Painel de motocicleta com luzes fracas indicando bateria descarregada',
		'intro' => array(
			'A bateria de moto raramente morre de uma vez: ela avisa por alguns dias antes de deixar o motociclista parado. O problema é que os sinais são sutis, e quem roda todo dia acaba se acostumando com a partida um pouco mais lenta.',
			'Reunimos os sete sinais mais confiáveis, o teste de multímetro que separa bateria ruim de sistema de carga ruim e o que fazer em cada caso.',
		),
		'secoes' => array(
			array(
				'h2' => 'Os 7 sinais de bateria de moto no fim',
				'paragrafos' => array(
					'Dois ou mais destes sintomas juntos já indicam troca próxima:',
				),
				'lista' => array(
					'Partida elétrica lenta ou que só funciona com o motor quente.',
					'A moto só pega no pedal ou empurrando.',
					'Farol e painel apagam ou piscam ao apertar o botão de partida.',
					'Seta piscando devagar e buzina abafada com o motor desligado.',
					'Alarme disparando sozinho ou trancando a moto sem motivo.',
					'Depois de 3 ou 4 dias parada, a moto não liga mais na chave.',
					'Caixa da bateria estufada, com vazamento ou terminais esbranquiçados.',
				),
			),
			array(
				'h2' => 'O teste que separa bateria ruim de carga ruim',
				'paragrafos' => array(
					'Com a moto desligada há pelo menos duas horas, meça a tensão nos terminais: acima de 12,6 V a bateria está carregada; entre 12,0 V e 12,4 V, parcialmente descarregada; abaixo de 11,8 V, comprometida.',
					'Depois ligue a moto e acelere: a tensão precisa subir para a faixa de 13,5 V a 14,5 V. Se não sobe, o culpado é o regulador/retificador ou o estator, não a bateria — e trocar só a bateria resolve por poucas semanas.',
				),
			),
			array(
				'h2' => 'Por que a bateria morre antes do tempo',
				'paragrafos' => array(
					'Moto parada é o principal motivo. Entre três e quatro semanas sem rodar, a bateria pode entrar em descarga profunda e nunca mais recuperar a capacidade original. Acessórios como alarme, rastreador, farol de LED auxiliar e carregador USB consomem corrente mesmo com a chave fora.',
					'O segundo motivo é o uso só em trechos curtos: o sistema de carga não tem tempo de repor o que a partida consumiu, e a bateria vive em déficit permanente.',
				),
			),
			array(
				'h2' => 'O que fazer quando o diagnóstico confirma a troca',
				'paragrafos' => array(
					'Confirme a amperagem original (5Ah nas 125 a 160cc, 6Ah a 9Ah nas 250 e 300cc, 12Ah em big trail e custom) e a posição dos terminais antes de comprar. Bateria com polaridade invertida não encaixa no chicote sem adaptação.',
					'Em Porto Alegre e região a AWR leva a bateria até a moto, instala, testa o sistema de carga e recolhe a bateria velha como base de troca — com nota fiscal e garantia de fábrica.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Bateria de moto avisa antes de morrer?',
				'resposta' => 'Quase sempre. Partida lenta, farol fraco e seta devagar aparecem dias antes da falha total. Quando a moto só liga no pedal, a bateria já está no fim.',
			),
			array(
				'pergunta' => 'Dá para recarregar em vez de trocar?',
				'resposta' => 'Se a descarga foi pontual e a bateria tem menos de 2 anos, sim. Se ela volta a descarregar em poucos dias, já perdeu capacidade e precisa ser substituída.',
			),
			array(
				'pergunta' => 'Como saber se o problema é o regulador de tensão?',
				'resposta' => 'Meça a tensão com o motor acelerado. Se ficar abaixo de 13,5 V ou passar de 15 V, o regulador está fora de faixa e vai comprometer também a bateria nova.',
			),
		),
		'relacionados' => array(
			'bateria-de-moto-quando-trocar',
			'guia-de-instalacao-segura-bateria-de-moto',
			'bateria-descarregada-o-que-fazer',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'heliar',
		),
	),
	array(
		'slug' => 'cuidados-com-a-bateria-de-moto-no-inverno',
		'titulo' => 'Bateria de Moto no Inverno: Cuidados Essenciais',
		'h1' => 'Cuidados com a bateria de moto no inverno e na moto parada',
		'descricao' => 'Frio e moto parada matam bateria de moto. Veja como guardar, quando usar carregador float e o que fazer antes de voltar a rodar na primavera.',
		'categoria' => 'Moto',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria de moto no inverno',
		'dataPublicacao' => '2026-08-10',
		'tempoLeitura' => 5,
		'imagemCapa' => 'assets/img/blog/bateria-moto.webp',
		'imagemAlt' => 'Motocicleta guardada em garagem durante o inverno',
		'intro' => array(
			'No inverno gaúcho a bateria de moto sofre duas vezes: o frio aumenta a resistência interna e reduz a corrente disponível para a partida, e a moto costuma ficar mais dias parada na garagem.',
			'Essa combinação explica por que tanta bateria morre entre junho e setembro. Com alguns cuidados simples, ela chega inteira na primavera.',
		),
		'secoes' => array(
			array(
				'h2' => 'Por que o frio derruba a bateria',
				'paragrafos' => array(
					'Em temperaturas baixas, a reação química interna fica mais lenta e a bateria entrega menos corrente justamente quando o motor exige mais, porque o óleo está mais viscoso. Uma bateria já com 60% de capacidade, que passava despercebida no verão, simplesmente não gira o motor a 5 °C.',
				),
			),
			array(
				'h2' => 'Moto parada: o que fazer',
				'paragrafos' => array(
					'Se a moto vai ficar semanas sem rodar:',
				),
				'lista' => array(
					'Rode pelo menos 20 minutos por semana — dar partida e desligar piora a situação.',
					'Use um carregador inteligente com modo float, próprio para bateria de moto.',
					'Se não houver carregador, desconecte o cabo negativo para cortar o consumo do alarme e do rastreador.',
					'Guarde a moto em local coberto e seco, longe de piso muito frio.',
					'Verifique a tensão a cada 15 dias: abaixo de 12,4 V, recarregue antes que vire descarga profunda.',
				),
			),
			array(
				'h2' => 'Nunca use carregador de bateria de carro',
				'paragrafos' => array(
					'Carregadores automotivos comuns entregam corrente alta demais para uma bateria de 5Ah a 12Ah. O resultado é sobreaquecimento, perda de eletrólito e caixa estufada. Use carregador com corrente regulada (em torno de 10% da capacidade em Ah) ou um float específico para moto.',
				),
			),
			array(
				'h2' => 'Antes de voltar a rodar',
				'paragrafos' => array(
					'Meça a tensão em repouso, limpe os terminais e confira o aperto. Se a moto ficou parada o inverno inteiro e a bateria já tem mais de dois anos, o mais provável é que ela não recupere. Nesse caso vale trocar antes da primeira viagem, não no meio da estrada.',
					'A AWR entrega e instala bateria de moto no local em Porto Alegre e região metropolitana, com teste do sistema de carga incluído.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Quanto tempo a moto pode ficar parada sem descarregar a bateria?',
				'resposta' => 'Sem acessórios ligados, cerca de 3 a 4 semanas. Com alarme ou rastreador, o prazo cai para 10 a 15 dias.',
			),
			array(
				'pergunta' => 'Preciso tirar a bateria da moto no inverno?',
				'resposta' => 'Não é obrigatório. Basta desconectar o negativo ou manter um carregador float. Se for retirar, guarde em local seco e recarregue a cada 30 dias.',
			),
			array(
				'pergunta' => 'Bateria AGM ou gel aguenta melhor o frio?',
				'resposta' => 'Sim. AGM e gel mantêm a corrente de partida mais estável em baixa temperatura e toleram melhor longos períodos parados do que a selada comum.',
			),
		),
		'relacionados' => array(
			'sinais-de-que-a-bateria-da-moto-esta-morrendo',
			'bateria-de-moto-quando-trocar',
			'bateria-de-carro-no-inverno-gaucho-cuidados',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'guia-de-instalacao-segura-bateria-de-moto',
		'titulo' => 'Instalar Bateria de Moto: Passo a Passo Seguro',
		'h1' => 'Guia de instalação segura da bateria de moto',
		'descricao' => 'Passo a passo para trocar a bateria da moto sem danificar a parte elétrica, com a ordem certa dos polos. Precisa de bateria nova? Peça pelo WhatsApp.',
		'categoria' => 'Moto',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'como instalar bateria de moto',
		'dataPublicacao' => '2026-08-10',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/bateria-moto.webp',
		'imagemAlt' => 'Mecânico conectando os terminais da bateria de uma motocicleta',
		'intro' => array(
			'Trocar a bateria da moto é simples, mas a ordem dos cabos e a polaridade não perdoam erro: inverter os terminais pode queimar o regulador, a central de injeção ou o chicote.',
			'Este guia mostra o passo a passo seguro, os erros mais comuns e o que conferir depois que a bateria nova entrar.',
		),
		'secoes' => array(
			array(
				'h2' => 'Antes de começar',
				'paragrafos' => array(
					'Separe o que vai precisar e prepare a moto:',
				),
				'lista' => array(
					'Chave de fenda ou Philips e chave de boca (geralmente 8 ou 10 mm).',
					'Moto desligada, chave fora e sobre o cavalete, em local plano.',
					'Bateria nova conferida: mesma amperagem, mesma medida de caixa e mesma posição dos terminais.',
					'Evite anéis e pulseiras de metal: encostar num terminal com ferramenta ou joia causa curto.',
				),
			),
			array(
				'h2' => 'Passo a passo da remoção',
				'paragrafos' => array(
					'A ordem dos cabos é a parte que mais gera dano quando é ignorada:',
				),
				'lista' => array(
					'Remova a tampa lateral ou o banco para acessar o compartimento.',
					'Desconecte primeiro o cabo NEGATIVO (preto, sinal −).',
					'Depois desconecte o cabo POSITIVO (vermelho, sinal +).',
					'Solte a cinta ou o suporte e retire a bateria na vertical, sem virar.',
				),
			),
			array(
				'h2' => 'Passo a passo da instalação',
				'paragrafos' => array(
					'Na montagem, a ordem se inverte:',
				),
				'lista' => array(
					'Limpe a base do compartimento e os terminais do chicote.',
					'Encaixe a bateria nova com os terminais no mesmo lado da anterior.',
					'Conecte primeiro o cabo POSITIVO e aperte firme, sem forçar a rosca.',
					'Conecte por último o cabo NEGATIVO.',
					'Prenda a cinta de fixação: bateria solta vibra e reduz a vida útil.',
					'Ligue a moto e confira painel, farol, seta e buzina.',
				),
			),
			array(
				'h2' => 'Erros comuns e o que fazer depois',
				'paragrafos' => array(
					'Os erros mais frequentes são inverter a polaridade, apertar demais o terminal (que trinca o polo), deixar a bateria solta e reaproveitar um terminal já corroído. Se soltar faísca forte ao conectar, pare e revise: há algo em curto ou ligado.',
					'Depois da instalação, meça a tensão com o motor acelerado. Se não ficar entre 13,5 V e 14,5 V, o sistema de carga precisa de reparo — senão a bateria nova dura poucas semanas. A bateria velha deve ir para descarte adequado: ela é resíduo perigoso e a AWR recebe a usada como base de troca.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Qual cabo tirar primeiro na bateria de moto?',
				'resposta' => 'O negativo. Na instalação, a ordem se inverte: conecte primeiro o positivo e por último o negativo, para evitar curto com a ferramenta.',
			),
			array(
				'pergunta' => 'Posso instalar sozinho ou preciso de oficina?',
				'resposta' => 'A maioria das motos permite a troca com ferramenta simples. Nas cidades com cobertura, a AWR faz a instalação no local sem custo, já com teste do sistema de carga.',
			),
			array(
				'pergunta' => 'O que acontece se inverter a polaridade?',
				'resposta' => 'Pode queimar fusível, regulador de tensão, central de injeção ou o chicote. Sempre confira o sinal + e − antes de encostar o cabo.',
			),
		),
		'relacionados' => array(
			'sinais-de-que-a-bateria-da-moto-esta-morrendo',
			'cuidados-com-a-bateria-de-moto-no-inverno',
			'bateria-de-moto-quando-trocar',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'zetta',
		),
	),
	array(
		'slug' => 'moura-vs-zetta-vs-heliar',
		'titulo' => 'Moura, Zetta ou Heliar? Qual Bateria Comprar',
		'h1' => 'Moura, Zetta ou Heliar: qual bateria comprar em Porto Alegre',
		'descricao' => 'Comparativo das três marcas mais vendidas: preço inicial, garantia, para quem cada uma vale a pena e qual escolher para Uber, Start-Stop ou uso diário.',
		'categoria' => 'Comparativos',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'moura zetta ou heliar',
		'dataPublicacao' => '2026-09-18',
		'tempoLeitura' => 7,
		'imagemCapa' => 'assets/img/blog/mecanico-instalando.webp',
		'imagemAlt' => 'Baterias Moura, Zetta e Heliar lado a lado antes da instalação',
		'intro' => array(
			'Quem chega na AWR sabendo que precisa trocar a bateria quase sempre faz a mesma pergunta: Moura, Zetta ou Heliar? As três são vendidas lado a lado, têm garantia de fábrica e aguentam o inverno gaúcho — a diferença está no perfil de uso e no quanto você quer investir.',
			'Abaixo está a comparação que fazemos no balcão todos os dias, com as faixas de preço praticadas pela AWR em Porto Alegre e região.',
		),
		'secoes' => array(
			array(
				'h2' => 'Resumo rápido: qual marca combina com você',
				'paragrafos' => array(
					'Se você quer o caminho curto, é assim que a escolha costuma cair em quase todos os atendimentos.',
				),
				'lista' => array(
					'Moura: líder nacional, fornecedora de montadoras, até 24 meses de garantia. A partir de R$ 425.',
					'Heliar: tecnologia Clarios, indicada para carro moderno, muita eletrônica e Start-Stop. A partir de R$ 409.',
					'Zetta: fabricada pelo Grupo Moura, melhor custo-benefício para quem roda muito. A partir de R$ 379.',
				),
			),
			array(
				'h2' => 'Moura: para quem não quer risco na partida',
				'paragrafos' => array(
					'A Moura é a bateria automotiva mais vendida do Brasil e equipamento original em VW, Fiat, GM e Ford. É a escolha padrão de quem usa o carro para trabalhar, viaja com frequência ou simplesmente não quer voltar ao assunto nos próximos dois anos.',
					'A rede autorizada é a maior do país, o que facilita muito acionar a garantia fora de Porto Alegre. A linha cobre do carro popular ao Start-Stop, com versões Preventiva, EFB e AGM.',
				),
			),
			array(
				'h2' => 'Heliar: para carro moderno e Start-Stop',
				'paragrafos' => array(
					'A Heliar é a marca premium da Clarios, mesma engenharia usada em baterias de fábrica de marcas europeias. Se o seu carro tem Start-Stop, multimídia grande, alarme e rastreador, a linha AGM Free é a indicação mais segura.',
					'O olho mágico de carga integrado ajuda no diagnóstico rápido — dá para ver o estado da bateria sem aparelho.',
				),
			),
			array(
				'h2' => 'Zetta: o melhor custo por quilômetro rodado',
				'paragrafos' => array(
					'A Zetta sai da mesma fábrica da Moura, com posicionamento mais acessível. É a mais vendida da AWR entre motoristas de aplicativo, justamente porque o carro roda muito e a bateria trabalha bem em ciclo diário.',
					'Para Gol, Uno, Celta, Ka, Onix e HB20 no uso comum, a Zetta entrega o essencial pagando menos.',
				),
			),
			array(
				'h2' => 'E o preço? O que muda de uma para a outra',
				'paragrafos' => array(
					'Na prática, a diferença entre a Zetta e a Moura de mesma amperagem costuma ser de algumas dezenas de reais — e é por isso que vale olhar o uso antes do preço.',
					'Em todas elas o valor já inclui a entrega, a instalação no local e o abatimento do casco velho. A confirmação do preço do seu modelo é feita pelo WhatsApp, com a amperagem certa para o seu carro.',
				),
			),
			array(
				'h2' => 'Qual escolher no seu caso',
				'paragrafos' => array(
					'Reduzindo a três situações comuns:',
				),
				'lista' => array(
					'Uber, 99 ou entregador: Zetta, pelo custo por quilômetro rodado.',
					'Carro de família, viagem e pouco uso: Moura, pela garantia e pela rede nacional.',
					'Carro com Start-Stop ou muita eletrônica: Heliar AGM, pela tolerância a ciclos.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Zetta é Moura?',
				'resposta' => 'A Zetta é fabricada pelo Grupo Moura, na mesma plataforma técnica, com posicionamento mais acessível e 12 meses de garantia.',
			),
			array(
				'pergunta' => 'Qual dura mais: Moura, Zetta ou Heliar?',
				'resposta' => 'A durabilidade depende mais do uso e do estado do alternador do que da marca. Em uso comum, as três entregam a vida útil esperada; a Moura e a Heliar têm garantia maior.',
			),
			array(
				'pergunta' => 'Posso colocar bateria comum em carro Start-Stop?',
				'resposta' => 'Não é indicado. O Start-Stop exige AGM ou EFB; usar bateria comum reduz muito a vida útil e pode gerar falhas no sistema.',
			),
			array(
				'pergunta' => 'A instalação é cobrada à parte?',
				'resposta' => 'Não. Na área de cobertura da AWR a entrega e a instalação são gratuitas, com teste do alternador e recolhimento da bateria antiga.',
			),
		),
		'relacionados' => array(
			'moura-vs-heliar',
			'quanto-custa-uma-bateria-moura',
			'quanto-tempo-dura-uma-bateria-de-carro',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'zetta',
		),
	),
	array(
		'slug' => 'como-escolher-a-amperagem-da-bateria',
		'titulo' => 'Qual Amperagem de Bateria o Seu Carro Precisa',
		'h1' => 'Como escolher a amperagem certa da bateria do seu carro',
		'descricao' => 'Entenda o que significa 60Ah, 70Ah ou 100Ah, o que acontece se errar para mais ou para menos e como descobrir a amperagem certa do seu carro.',
		'categoria' => 'Guia de compra',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'como escolher amperagem da bateria',
		'dataPublicacao' => '2026-09-19',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/mecanico-instalando.webp',
		'imagemAlt' => 'Técnico conferindo a etiqueta de amperagem de uma bateria automotiva',
		'intro' => array(
			'Amperagem é o número que aparece em destaque na etiqueta da bateria: 50Ah, 60Ah, 70Ah, 100Ah. Ele indica quanta carga a bateria consegue armazenar — e é a primeira informação que pedimos quando alguém chama no WhatsApp pedindo preço.',
			'A escolha não é chute nem preferência: cada carro tem uma faixa definida pela montadora. Abaixo está o jeito mais simples de descobrir a sua e o que muda quando se erra para mais ou para menos.',
		),
		'secoes' => array(
			array(
				'h2' => 'O que significa Ah na prática',
				'paragrafos' => array(
					'Ah (ampère-hora) é a capacidade de armazenamento. Quanto maior o número, mais energia a bateria guarda e mais tempo ela sustenta o carro com o motor desligado — som, alarme, rastreador, luzes.',
					'Não confunda com CCA, que é a corrente de partida a frio: mede a força para girar o motor no frio, não a autonomia.',
				),
			),
			array(
				'h2' => 'Como descobrir a amperagem do seu carro',
				'paragrafos' => array(
					'Há três caminhos, do mais rápido ao mais seguro:',
				),
				'lista' => array(
					'Olhar a etiqueta da bateria que já está no carro — o número costuma vir ao lado da marca.',
					'Consultar o manual do proprietário, na seção de especificações elétricas.',
					'Informar marca, modelo e ano no buscador do site ou no WhatsApp: devolvemos as opções compatíveis.',
				),
			),
			array(
				'h2' => 'Faixas típicas por tipo de carro',
				'paragrafos' => array(
					'As faixas abaixo são as que mais saem no balcão e servem como referência inicial — a confirmação é sempre pelo modelo e ano.',
				),
				'lista' => array(
					'Populares 1.0 e 1.4 (Onix, HB20, Gol, Uno, Ka, Mobi): 50 a 60Ah.',
					'Sedãs e SUVs médios (Corolla, Civic, Compass, Renegade, Tracker): 60 a 70Ah.',
					'SUVs grandes e picapes (Hilux, S10, Ranger, Pajero): 75 a 100Ah.',
					'Carros com Start-Stop: exigem EFB ou AGM, além da amperagem correta.',
				),
			),
			array(
				'h2' => 'Posso colocar uma bateria maior?',
				'paragrafos' => array(
					'Subir um degrau de amperagem, quando a bateria cabe no berço e os polos ficam na mesma posição, costuma ser aceitável e dá alguma folga para quem tem muitos acessórios.',
					'O que não vale é exagerar: bateria grande demais pode não encaixar na fixação, forçar os cabos e ficar sempre parcialmente carregada, porque o alternador foi dimensionado para outra capacidade.',
				),
			),
			array(
				'h2' => 'E se eu colocar uma bateria menor?',
				'paragrafos' => array(
					'Aí o risco é maior. Uma bateria abaixo do especificado trabalha no limite todos os dias, descarrega mais fundo e envelhece rápido — em geral é a origem daquela troca que "durou menos de um ano".',
					'No frio de Porto Alegre e região o efeito aparece mais cedo, porque a partida exige mais corrente.',
				),
			),
			array(
				'h2' => 'Polaridade e medidas: o detalhe que trava a instalação',
				'paragrafos' => array(
					'Além da amperagem, a bateria precisa ter a polaridade certa (lado do polo positivo) e caber na caixa. É por isso que a instalação da AWR é feita por técnico: ele confere encaixe, fixação, aperto dos terminais e testa o alternador antes de sair.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Amperagem maior faz o carro ficar mais forte?',
				'resposta' => 'Não. A amperagem define quanta carga a bateria armazena, não a potência do motor. O que ajuda na partida a frio é o CCA.',
			),
			array(
				'pergunta' => 'Como sei a amperagem sem abrir o capô?',
				'resposta' => 'Informe marca, modelo e ano na busca do site ou no WhatsApp da AWR. Devolvemos as baterias compatíveis com preço e prazo.',
			),
			array(
				'pergunta' => 'Carro com Start-Stop aceita bateria comum da mesma amperagem?',
				'resposta' => 'Não é indicado. O sistema exige tecnologia EFB ou AGM, feita para muitos ciclos de carga e descarga.',
			),
		),
		'relacionados' => array(
			'moura-vs-zetta-vs-heliar',
			'quanto-tempo-dura-uma-bateria-de-carro',
			'como-saber-se-bateria-do-carro-esta-fraca-porto-alegre',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'agm-ou-efb-qual-bateria-start-stop',
		'titulo' => 'AGM ou EFB: Qual Bateria para Carro Start-Stop',
		'h1' => 'AGM ou EFB: qual bateria usar em carro com Start-Stop',
		'descricao' => 'Diferença entre AGM e EFB, qual delas o seu carro com Start-Stop aceita e por que bateria comum estraga rápido nesse sistema.',
		'categoria' => 'Guia de compra',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'agm ou efb start-stop',
		'dataPublicacao' => '2026-09-19',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/mecanico-instalando.webp',
		'imagemAlt' => 'Bateria AGM instalada em carro com sistema Start-Stop',
		'intro' => array(
			'Carros com Start-Stop desligam o motor no semáforo e religam quando você tira o pé do freio. Nesse vai e vem, a bateria sustenta sozinha o ar-condicionado, a multimídia e a injeção — e faz isso dezenas de vezes por dia.',
			'Bateria comum não foi feita para esse trabalho. Existem duas tecnologias próprias para ele: EFB e AGM. Veja qual é a do seu carro.',
		),
		'secoes' => array(
			array(
				'h2' => 'O que é EFB',
				'paragrafos' => array(
					'EFB é a evolução da bateria chumbo-ácido comum, com placas reforçadas e aditivos que suportam muito mais ciclos de carga e descarga. É a tecnologia usada na maioria dos Start-Stop de entrada, como T-Cross, Polo e Virtus em versões mais simples.',
				),
			),
			array(
				'h2' => 'O que é AGM',
				'paragrafos' => array(
					'Na AGM o eletrólito fica absorvido em mantas de fibra de vidro, sem líquido livre. Ela aceita recarga mais rápida, resiste melhor à vibração e sustenta cargas altas por mais tempo — é a indicada para Start-Stop com frenagem regenerativa e para carros com muita eletrônica embarcada.',
				),
			),
			array(
				'h2' => 'Como saber qual o seu carro pede',
				'paragrafos' => array(
					'A ordem de conferência é sempre a mesma:',
				),
				'lista' => array(
					'Olhar a etiqueta da bateria original — costuma vir escrito EFB ou AGM.',
					'Consultar o manual do proprietário.',
					'Informar marca, modelo, ano e versão no WhatsApp da AWR para confirmarmos a aplicação.',
				),
			),
			array(
				'h2' => 'Pode trocar EFB por AGM?',
				'paragrafos' => array(
					'Subir de EFB para AGM é possível na maior parte dos casos, desde que a medida e a polaridade sejam compatíveis. O caminho inverso não: colocar EFB onde a montadora especificou AGM tende a reduzir muito a vida útil.',
					'Trocar qualquer uma das duas por bateria comum é o pior cenário — o sistema passa a trabalhar fora do projeto e a bateria se desgasta em poucos meses.',
				),
			),
			array(
				'h2' => 'Precisa de codificação depois da troca?',
				'paragrafos' => array(
					'Vários modelos exigem que a central seja informada da bateria nova, para ajustar o regime de recarga. Quando o seu carro precisa desse procedimento, avisamos antes da troca e orientamos o caminho correto.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Bateria AGM é mais cara?',
				'resposta' => 'Sim, custa mais que a comum e que a EFB, porque a construção é diferente. Em carro com Start-Stop ela compensa pela durabilidade no uso correto.',
			),
			array(
				'pergunta' => 'Posso desligar o Start-Stop e usar bateria comum?',
				'resposta' => 'Não recomendamos. O botão desativa a função na viagem, mas o sistema elétrico continua projetado para bateria de ciclo profundo.',
			),
			array(
				'pergunta' => 'A AWR instala AGM e EFB no local?',
				'resposta' => 'Sim, dentro da área de cobertura de entrega e instalação, com teste do alternador e recolhimento da bateria antiga.',
			),
		),
		'relacionados' => array(
			'como-escolher-a-amperagem-da-bateria',
			'moura-vs-zetta-vs-heliar',
			'moura-vs-heliar',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'heliar',
		),
	),
	array(
		'slug' => 'bateria-para-uber-e-99',
		'titulo' => 'Bateria para Uber e 99: Qual Dura Mais Rodando',
		'h1' => 'Bateria para motorista de aplicativo: qual escolher para rodar o dia inteiro',
		'descricao' => 'Quem roda de Uber ou 99 descarrega a bateria de um jeito diferente. Veja qual tecnologia aguenta mais e como evitar parar no meio da corrida.',
		'categoria' => 'Guia de compra',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria para uber',
		'dataPublicacao' => '2026-09-19',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/carro-parado-noite.webp',
		'imagemAlt' => 'Motorista de aplicativo com o carro parado à noite na rua',
		'intro' => array(
			'Para quem vive do carro, bateria descarregada não é transtorno: é dia de trabalho perdido. E o uso em aplicativo castiga a bateria de um jeito específico — muitas partidas, celular e ar-condicionado ligados o tempo todo e longas esperas com o motor desligado.',
			'Este guia é o que explicamos todos os dias para motoristas de Uber e 99 em Porto Alegre, Canoas e Gravataí.',
		),
		'secoes' => array(
			array(
				'h2' => 'Por que a bateria de quem roda em app dura menos',
				'paragrafos' => array(
					'Não é o quilômetro rodado que desgasta, é o ciclo. Cada partida tira uma parte da carga e o alternador precisa repor. Em corridas curtas, com paradas frequentes, a reposição nem sempre acontece por completo.',
					'Some a isso carregador de celular, suporte, rastreador e ar-condicionado no verão: a bateria trabalha praticamente sem folga.',
				),
			),
			array(
				'h2' => 'Que tipo de bateria escolher',
				'paragrafos' => array(
					'A recomendação muda conforme o carro e a rotina:',
				),
				'lista' => array(
					'Popular sem Start-Stop, muita rodagem: Zetta, pelo custo por quilômetro rodado.',
					'Carro de uso misto, com viagem e família: Moura, pela garantia maior e pela rede nacional.',
					'Carro com Start-Stop ou muita eletrônica: Heliar AGM ou linha EFB, feitas para ciclos.',
				),
			),
			array(
				'h2' => 'Hábitos que estendem a vida da bateria rodando',
				'paragrafos' => array(
					'Pequenos ajustes na rotina rendem meses a mais:',
				),
				'lista' => array(
					'Evitar ficar com ar-condicionado e som ligados por longos períodos com o motor desligado, entre corridas.',
					'Desligar carregadores e acessórios ao encerrar o dia.',
					'Manter os terminais limpos e bem apertados — folga gera queda de corrente.',
					'Fazer teste de carga e de alternador a cada seis meses.',
				),
			),
			array(
				'h2' => 'O sinal de alerta que o motorista de app não pode ignorar',
				'paragrafos' => array(
					'Partida lenta no começo do dia é o aviso mais comum. Em uso comum dá para empurrar por algumas semanas; rodando em aplicativo, o normal é parar em poucos dias — geralmente longe de casa e com passageiro no carro.',
					'Se apareceu, vale testar na hora. O teste é gratuito e feito no local.',
				),
			),
			array(
				'h2' => 'Troca sem sair da rua',
				'paragrafos' => array(
					'A AWR entrega e instala no lugar onde o carro estiver, dentro da área de cobertura, com recolhimento da bateria antiga. Para quem roda, é a diferença entre perder meia hora e perder o turno inteiro.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Qual bateria é a mais indicada para Uber?',
				'resposta' => 'Em carro popular sem Start-Stop, a Zetta costuma ser a melhor relação entre preço e durabilidade para quem roda muito. Em carro com Start-Stop, a indicação é AGM ou EFB.',
			),
			array(
				'pergunta' => 'Quantos anos dura a bateria rodando em aplicativo?',
				'resposta' => 'Depende do ciclo e do estado do alternador. É comum durar menos que em uso particular, por isso recomendamos teste semestral.',
			),
			array(
				'pergunta' => 'Dá para trocar a bateria durante o expediente?',
				'resposta' => 'Sim. A troca é feita no local, sem levar o carro à loja, dentro da área de cobertura da AWR.',
			),
		),
		'relacionados' => array(
			'moura-vs-zetta-vs-heliar',
			'como-saber-se-bateria-do-carro-esta-fraca-porto-alegre',
			'como-escolher-a-amperagem-da-bateria',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'zetta',
		),
	),
	array(
		'slug' => 'carro-parado-muito-tempo-bateria',
		'titulo' => 'Carro Parado Descarrega a Bateria? O Que Fazer',
		'h1' => 'Carro parado por muito tempo: como evitar que a bateria descarregue',
		'descricao' => 'Quanto tempo o carro pode ficar parado sem descarregar, o que consome energia com o motor desligado e o que fazer antes de viajar.',
		'categoria' => 'Manutenção',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'carro parado bateria descarrega',
		'dataPublicacao' => '2026-09-19',
		'tempoLeitura' => 5,
		'imagemCapa' => 'assets/img/blog/carro-parado-noite.webp',
		'imagemAlt' => 'Carro estacionado e parado por vários dias em garagem',
		'intro' => array(
			'Carro parado não fica em repouso total. Alarme, central, rastreador e memória da multimídia continuam consumindo energia — é o chamado consumo de repouso.',
			'Por isso é tão comum o carro que passou férias na garagem não pegar no dia da volta. Veja como evitar.',
		),
		'secoes' => array(
			array(
				'h2' => 'Quanto tempo o carro aguenta parado',
				'paragrafos' => array(
					'Com bateria nova e sistema elétrico em ordem, algumas semanas paradas costumam não ser problema. Com bateria já no segundo ou terceiro ano, poucos dias podem bastar para a partida ficar fraca.',
					'Quanto mais antiga a bateria, menor a margem — ela perde a capacidade de segurar carga em repouso antes de dar qualquer outro sinal.',
				),
			),
			array(
				'h2' => 'O que fazer se o carro vai ficar parado',
				'paragrafos' => array(
					'As medidas abaixo resolvem a maioria dos casos:',
				),
				'lista' => array(
					'Ligar o carro e deixá-lo rodando de verdade, por pelo menos 20 minutos, uma vez por semana — marcha lenta na garagem repõe pouco.',
					'Desligar acessórios ligados na tomada 12V antes de guardar o carro.',
					'Se a parada for longa, desconectar o polo negativo (atenção: isso apaga memórias e pode exigir recodificação em alguns modelos).',
					'Deixar o carro em local coberto — calor e frio extremos aceleram a autodescarga.',
				),
			),
			array(
				'h2' => 'Rodar curto é quase tão ruim quanto ficar parado',
				'paragrafos' => array(
					'Trajeto de cinco minutos até a padaria consome mais carga na partida do que o alternador consegue repor no caminho. Repetido todos os dias, o efeito é o mesmo de um carro parado: a bateria vive em déficit.',
					'Uma vez por semana, um trajeto mais longo ajuda a recompor a carga.',
				),
			),
			array(
				'h2' => 'O carro não pegou depois de parado: e agora?',
				'paragrafos' => array(
					'A chupeta resolve na hora, mas não diz se a bateria ainda presta. O teste de carga mostra se ela recupera ou se apenas está sendo sustentada pelo alternador.',
					'Se a bateria já tem mais de dois anos e descarregou sozinha depois de poucos dias parada, o mais provável é que a troca já esteja na hora.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Ligar o carro parado por 10 minutos por dia resolve?',
				'resposta' => 'Ajuda pouco. Marcha lenta gera pouca recarga; é melhor rodar 20 minutos ou mais, uma vez por semana.',
			),
			array(
				'pergunta' => 'Desconectar a bateria estraga alguma coisa?',
				'resposta' => 'Não danifica a bateria, mas apaga memórias do carro e, em alguns modelos, exige recodificação de vidros e central.',
			),
			array(
				'pergunta' => 'A AWR testa a bateria no local?',
				'resposta' => 'Sim, o teste de bateria e de alternador é gratuito e feito onde o carro estiver, dentro da área de cobertura.',
			),
		),
		'relacionados' => array(
			'bateria-descarregada-o-que-fazer',
			'bateria-ou-alternador-como-saber-porto-alegre',
			'bateria-de-carro-no-inverno-gaucho-cuidados',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'como-fazer-chupeta-com-seguranca',
		'titulo' => 'Como Fazer Chupeta no Carro Sem Estragar Nada',
		'h1' => 'Como fazer chupeta com segurança: passo a passo na ordem certa',
		'descricao' => 'A ordem correta dos cabos, o que nunca fazer e por que a chupeta não substitui a troca. Passo a passo simples para não danificar a eletrônica.',
		'categoria' => 'Emergência',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'como fazer chupeta no carro',
		'dataPublicacao' => '2026-09-19',
		'tempoLeitura' => 5,
		'imagemCapa' => 'assets/img/blog/bateria-fraca.webp',
		'imagemAlt' => 'Cabos de chupeta conectados aos polos de uma bateria de carro',
		'intro' => array(
			'A chupeta tira o carro do lugar, mas feita na ordem errada pode queimar fusível, módulo ou até a central de injeção. A sequência importa mais do que a força do carro que vai ajudar.',
			'Abaixo está o passo a passo que orientamos por telefone antes de o técnico chegar.',
		),
		'secoes' => array(
			array(
				'h2' => 'Antes de começar',
				'paragrafos' => array(
					'Confira três coisas: os dois carros desligados, o freio de mão puxado e as baterias com a mesma tensão (12V com 12V).',
					'Se a bateria estiver estufada, vazando ou com cheiro forte de enxofre, não faça chupeta. Nesse estado o risco é real — chame socorro.',
				),
			),
			array(
				'h2' => 'A ordem correta dos cabos',
				'paragrafos' => array(
					'Siga exatamente esta sequência:',
				),
				'lista' => array(
					'1. Cabo vermelho no polo positivo da bateria descarregada.',
					'2. Outra ponta do vermelho no polo positivo da bateria boa.',
					'3. Cabo preto no polo negativo da bateria boa.',
					'4. Outra ponta do preto em uma parte metálica sem pintura do carro descarregado — não no polo negativo da bateria fraca.',
					'5. Ligar o carro que está ajudando, esperar cerca de dois minutos e então dar partida no carro parado.',
				),
			),
			array(
				'h2' => 'Como retirar os cabos',
				'paragrafos' => array(
					'A remoção é na ordem inversa: preto do carro que pegou, preto da bateria boa, vermelho da bateria boa, vermelho da bateria que estava descarregada.',
					'Evite encostar as garras uma na outra enquanto houver algum cabo conectado.',
				),
			),
			array(
				'h2' => 'O que nunca fazer',
				'paragrafos' => array(
					'Três erros aparecem em quase todo atendimento:',
				),
				'lista' => array(
					'Inverter os polos — é o caminho mais rápido para queimar componentes eletrônicos.',
					'Empurrar carro automático ou com injeção eletrônica para pegar no tranco.',
					'Sair com o carro logo depois e desligá-lo em seguida: sem tempo de recarga, ele não pega de novo.',
				),
			),
			array(
				'h2' => 'Depois da chupeta, teste',
				'paragrafos' => array(
					'A chupeta não diz se o problema é a bateria ou o alternador. Se o carro precisou de chupeta mais de uma vez na mesma semana, a bateria está no fim.',
					'O teste de bateria e de alternador da AWR é gratuito e feito no local, sem levar o carro à loja.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Posso fazer chupeta em carro com Start-Stop?',
				'resposta' => 'Sim, respeitando a mesma ordem de cabos e os pontos de conexão indicados pela montadora, que em muitos modelos ficam fora da bateria.',
			),
			array(
				'pergunta' => 'Quanto tempo preciso rodar depois da chupeta?',
				'resposta' => 'Se a bateria ainda estiver boa, ao menos 20 a 30 minutos rodando ajudam a recompor parte da carga.',
			),
			array(
				'pergunta' => 'A AWR atende quando o carro não liga?',
				'resposta' => 'Sim. O atendimento vai até o local, testa e, se for o caso, troca a bateria na hora, dentro da área de cobertura.',
			),
		),
		'relacionados' => array(
			'bateria-descarregada-o-que-fazer',
			'carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser',
			'bateria-ou-alternador-como-saber-porto-alegre',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'moura',
		),
	),
	array(
		'slug' => 'bateria-descarrega-durante-a-noite',
		'titulo' => 'Bateria Descarrega à Noite? Descubra o Motivo',
		'h1' => 'Bateria descarrega durante a noite: as causas mais comuns',
		'descricao' => 'Carro dorme bom e amanhece sem carga? Veja o que consome energia com o motor desligado, como identificar a fuga e quando é a bateria.',
		'categoria' => 'Diagnóstico',
		'cidadeAlvo' => 'Porto Alegre',
		'cidadeSlug' => 'porto-alegre',
		'palavraChave' => 'bateria descarrega durante a noite',
		'dataPublicacao' => '2026-09-19',
		'tempoLeitura' => 6,
		'imagemCapa' => 'assets/img/blog/carro-parado-noite.webp',
		'imagemAlt' => 'Carro parado na rua à noite com a bateria descarregada',
		'intro' => array(
			'O carro funcionou o dia inteiro, dormiu normal e de manhã não gira. Quando isso se repete, quase sempre há uma de duas explicações: a bateria perdeu a capacidade de segurar carga, ou algo no carro está consumindo energia durante a noite.',
			'Veja como separar uma coisa da outra antes de trocar peça à toa.',
		),
		'secoes' => array(
			array(
				'h2' => '1. A bateria chegou ao fim da vida útil',
				'paragrafos' => array(
					'É a causa mais frequente. Bateria velha ainda dá partida no fim da tarde, quando está aquecida e recém-carregada, mas não sustenta a noite inteira. O sintoma clássico é o carro que só falha de manhã.',
					'Se ela tem mais de dois anos, comece por aqui: um teste de carga responde em minutos.',
				),
			),
			array(
				'h2' => '2. Consumo parasita (fuga de corrente)',
				'paragrafos' => array(
					'Algum circuito continua ligado depois que o carro é trancado. Os suspeitos habituais são alarme mal instalado, rastreador, som com módulo extra, luz de porta-malas ou porta-luvas que não apaga e central multimídia que não entra em repouso.',
					'Esse diagnóstico se faz com multímetro medindo a corrente de repouso e removendo fusíveis um a um até encontrar o circuito responsável.',
				),
			),
			array(
				'h2' => '3. Alternador ou regulador de tensão',
				'paragrafos' => array(
					'Se o alternador não carrega o suficiente durante o dia, a bateria começa a noite já em déficit. Aqui o sinal costuma vir acompanhado de luz no painel ou faróis que oscilam com o motor ligado.',
				),
			),
			array(
				'h2' => '4. Terminais frouxos, sujos ou oxidados',
				'paragrafos' => array(
					'Aquele pó esbranquiçado nos polos cria resistência e atrapalha tanto a partida quanto a recarga. É a causa mais barata de resolver — limpeza e reaperto — e uma das mais ignoradas.',
				),
			),
			array(
				'h2' => 'Como descobrir qual é o seu caso',
				'paragrafos' => array(
					'Um teste no local separa rapidamente os cenários:',
				),
				'lista' => array(
					'Bateria não segura carga no teste: é troca.',
					'Bateria aprovada e alternador carregando pouco: problema de carga.',
					'Bateria e alternador ok, mas descarrega parada: consumo parasita, é preciso caçar o circuito.',
				),
			),
			array(
				'h2' => 'Enquanto o problema não é resolvido',
				'paragrafos' => array(
					'Evite deixar acessórios ligados na tomada 12V, confira se todas as portas e o porta-malas ficaram bem fechados e não conte com chupeta como rotina — cada descarga profunda encurta o que resta da bateria.',
				),
			),
		),
		'faq' => array(
			array(
				'pergunta' => 'Alarme e rastreador descarregam a bateria?',
				'resposta' => 'Quando bem instalados, o consumo é pequeno e previsto. Instalações improvisadas são uma das causas mais comuns de fuga de corrente.',
			),
			array(
				'pergunta' => 'É bateria ou alternador?',
				'resposta' => 'O teste de carga com o motor ligado e desligado mostra a diferença. A AWR faz os dois testes gratuitamente no local.',
			),
			array(
				'pergunta' => 'Vale a pena recarregar a bateria em vez de trocar?',
				'resposta' => 'Só faz sentido se a descarga teve causa pontual, como farol esquecido aceso. Bateria que descarrega sozinha toda noite já perdeu capacidade.',
			),
		),
		'relacionados' => array(
			'bateria-ou-alternador-como-saber-porto-alegre',
			'carro-parado-muito-tempo-bateria',
			'como-saber-se-bateria-do-carro-esta-fraca-porto-alegre',
		),
		'linksLongTail' => array(
			'marcaSlug' => 'heliar',
		),
	),
);
