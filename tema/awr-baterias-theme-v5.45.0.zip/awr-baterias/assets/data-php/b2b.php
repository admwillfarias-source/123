<?php
/** Gerado de assets/data/b2b.json — não editar. */
return array(
	array(
		'slug' => 'energia-solar',
		'nome' => 'Energia solar off-grid',
		'dor' => 'Sistemas fotovoltaicos isolados perdem autonomia quando o banco de baterias é subdimensionado ou usa tecnologia automotiva comum.',
		'solucao' => 'Fornecemos baterias estacionárias e de ciclo profundo para sistemas off-grid e híbridos, dimensionando o banco pelo consumo diário em kWh e pelos dias de autonomia desejados.',
		'publico' => 'Integradores solares, sítios, chácaras e propriedades sem rede estável',
	),
	array(
		'slug' => 'provedores-de-internet',
		'nome' => 'Provedores de internet (ISP)',
		'dor' => 'Queda de energia derruba POPs, torres e caixas ópticas — e o cliente final percebe na hora.',
		'solucao' => 'Baterias VRLA estacionárias para nobreaks de POP, torres e armários de rua, com reposição programada e troca preventiva antes da falha.',
		'publico' => 'Provedores regionais, integradores de rede e operadoras',
	),
	array(
		'slug' => 'agronegocio',
		'nome' => 'Agronegócio',
		'dor' => 'Máquina parada na safra custa caro, e o ambiente rural castiga a bateria com poeira, vibração e longos períodos de inatividade.',
		'solucao' => 'Baterias de alta amperagem para tratores, colheitadeiras, pulverizadores e implementos, além de bancos para cercas elétricas e bombeamento solar.',
		'publico' => 'Produtores rurais, cooperativas e revendas de máquinas agrícolas',
	),
	array(
		'slug' => 'equipamentos-medicos',
		'nome' => 'Equipamentos médicos',
		'dor' => 'Equipamento hospitalar não pode desligar: a bateria de reserva precisa responder no instante da queda.',
		'solucao' => 'Baterias VRLA seladas para camas hospitalares, macas motorizadas, autoclaves, nobreaks de UTI e equipamentos de diagnóstico, com laudo e reposição programada.',
		'publico' => 'Clínicas, hospitais, home care e assistências técnicas',
	),
	array(
		'slug' => 'litio-lifepo4',
		'nome' => 'Upgrade para lítio LiFePO4',
		'dor' => 'Quem depende de peso baixo, ciclagem intensa e recarga rápida chega ao limite do chumbo-ácido.',
		'solucao' => 'Projeto de migração para LiFePO4 com BMS, avaliação do carregador atual e cálculo do retorno pelo custo por ciclo — não apenas pelo preço da peça.',
		'publico' => 'Náutico, mobilidade elétrica, solar off-grid e operações industriais',
	),
	array(
		'slug' => 'contratos-manutencao',
		'nome' => 'Data centers e condomínios',
		'dor' => 'Bancos de baterias envelhecem em silêncio e só mostram o problema durante a falta de energia.',
		'solucao' => 'Contrato de manutenção com inventário do parque instalado, testes periódicos de capacidade, laudo e substituição preventiva agendada.',
		'publico' => 'Data centers, condomínios, indústrias e facilities',
	),
);
