# AWR Baterias 5.28.0
- Menu de emergência "Bateria arriou? Onde você está?" na home e nas páginas de cidade: nível (AWR Express, mesmo dia, agendada, RS por transportadora) e prazo vindos do cadastro oficial de cidades; botões Pedir agora (WhatsApp com cidade e carro), Ligar, Encontrar minha bateria.
- Botão "Mande uma foto da bateria" (WhatsApp).
- Bloco "O que você recebe em {cidade}" nas páginas de cidade.
- Calculadora de banco de baterias na linha estacionária (Freedom DF500–DF4100), com orçamento pelo WhatsApp.
