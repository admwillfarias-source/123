<?php
/**
 * Faixa de busca no padrão da home — usada logo abaixo do hero das páginas internas.
 *
 * Uso: awr_part( 'searchband' ) ou awr_part( 'searchband', array( 'tag' => '...', 'nota' => '...' ) ).
 * Nas páginas de baterias estacionárias a faixa não é exibida (regra em awr_show_searchband()).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$args = wp_parse_args( $args ?? array(), array(
	'tag'   => 'Busque sua bateria aqui',
	'nota'  => 'Sem cadastro. Preço final com instalação inclusa.',
	'force' => false,
) );

if ( ! $args['force'] && ! awr_show_searchband() ) { return; }
if ( ! function_exists( 'awr_search_rendered' ) || awr_search_rendered() ) { return; }
?>
<section class="awr-searchband">
	<div class="awr-container">
		<div class="awr-hero__search">
			<?php if ( $args['tag'] ) : ?>
				<span class="awr-hero__search-tag"><?php echo esc_html( $args['tag'] ); ?></span>
			<?php endif; ?>
			<?php awr_part( 'search', array( 'autofocus' => false, 'titulo' => '' ) ); ?>
			<?php if ( $args['nota'] ) : ?>
				<p class="awr-hero__search-note"><?php echo esc_html( $args['nota'] ); ?></p>
			<?php endif; ?>
		</div>
	</div>
</section>
