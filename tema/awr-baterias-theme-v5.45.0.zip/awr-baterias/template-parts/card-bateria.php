<?php
/**
 * Card de produto (bateria) — paridade 1:1 com o card do app React.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$p       = $args['produto'] ?? array();
$veiculo = $args['veiculo'] ?? '';
if ( ! $p ) { return; }

$sob     = ! empty( $p['sob_consulta'] ) || empty( $p['price'] );
$price   = (float) ( $p['price'] ?? 0 );
$pix     = $price ? round( $price * 0.97, 2 ) : 0; // 3% OFF no Pix (igual ao app)
$parcela = $price ? $price / 10 : 0;
$brand   = (string) ( $p['brand'] ?? '' );
$garantia = awr_garantia_label( (string) ( $p['sku'] ?? '' ), (string) ( $p['name'] ?? '' ) );
$casco    = awr_valor_casco( (string) ( $p['sku'] ?? '' ), (string) ( $p['name'] ?? '' ) );
$nome    = $p['name'] ?: trim( $brand . ' ' . $p['sku'] );
$amp     = $p['amperagem'] ?? '';
$pid     = (int) ( $p['id'] ?? 0 );
$msg     = awr_wa_pedido_msg( $p, $veiculo, awr_current_url() );
$msg_duv = 'Olá! Tenho uma dúvida sobre a bateria ' . $nome . ' (SKU ' . $p['sku'] . ')'
	. ( $veiculo ? " para {$veiculo}" : '' ) . '.';

?>
<article class="awr-card awr-card--clickable" role="button" tabindex="0"
	data-awr-checkout
	data-sku="<?php echo esc_attr( $p['sku'] ); ?>"
	data-nome="<?php echo esc_attr( $nome ); ?>"
	data-preco="<?php echo esc_attr( $price ); ?>"
	data-pid="<?php echo esc_attr( $pid ); ?>"
	data-casco="<?php echo esc_attr( $casco ); ?>"
	data-imagem="<?php echo esc_url( $p['image'] ?? '' ); ?>"
	data-garantia="<?php echo esc_attr( $garantia ); ?>"
	data-veiculo="<?php echo esc_attr( $veiculo ); ?>"
	aria-label="Ver detalhes e comprar <?php echo esc_attr( $nome ); ?>">

	<button type="button" class="awr-card__media" data-awr-checkout
		data-sku="<?php echo esc_attr( $p['sku'] ); ?>"
		data-nome="<?php echo esc_attr( $nome ); ?>"
		data-preco="<?php echo esc_attr( $price ); ?>"
		data-pid="<?php echo esc_attr( $pid ); ?>"
		data-casco="<?php echo esc_attr( $casco ); ?>"
		data-imagem="<?php echo esc_url( $p['image'] ?? '' ); ?>"
		data-garantia="<?php echo esc_attr( $garantia ); ?>"
		data-veiculo="<?php echo esc_attr( $veiculo ); ?>"
		aria-label="Ver detalhes e comprar">
		<?php if ( ! empty( $p['image'] ) ) : ?>
			<?php
			$awr_eager = ! empty( $args['eager'] );
			$awr_img   = ! empty( $p['image_id'] ) ? wp_get_attachment_image( (int) $p['image_id'], 'woocommerce_thumbnail', false, array(
				'alt'           => $nome,
				'loading'       => $awr_eager ? 'eager' : 'lazy',
				'decoding'      => 'async',
				'fetchpriority' => $awr_eager ? 'high' : 'auto',
				'sizes'         => '(max-width: 600px) 45vw, (max-width: 1024px) 30vw, 260px',
			) ) : '';
			if ( $awr_img ) : echo $awr_img; // phpcs:ignore WordPress.Security.EscapeOutput
			else : ?>
			<img src="<?php echo esc_url( $p['image'] ); ?>" alt="<?php echo esc_attr( $nome ); ?>" loading="<?php echo $awr_eager ? 'eager' : 'lazy'; ?>" decoding="async" width="600" height="600">
			<?php endif; ?>
		<?php else : ?>
			<span class="awr-card__noimg" aria-hidden="true">🔋</span>
		<?php endif; ?>
		<?php if ( $brand ) : ?><span class="awr-card__badge awr-card__badge--brand"><?php echo esc_html( $brand ); ?></span><?php endif; ?>
		<span class="awr-card__badge awr-card__badge--online">✓ <?php echo esc_html( $garantia ?: 'Compra segura' ); ?></span>
	</button>

	<div class="awr-card__body">
		<p class="awr-card__title" title="<?php echo esc_attr( $nome ); ?>"><?php echo esc_html( $nome ); ?></p>
		<ul class="awr-card__tags" aria-label="Serviços incluídos">
			<?php if ( $amp ) : ?><li class="awr-tag awr-tag--gold">⚡ <?php echo esc_html( $amp ); ?> Ah</li><?php endif; ?>
			<?php $cca = (int) ( $p['cca'] ?? 0 ); ?>
			<?php if ( $cca ) : ?><li class="awr-tag awr-tag--gold">❄ <?php echo esc_html( $cca ); ?> CCA</li><?php endif; ?>
			<li class="awr-tag awr-tag--green">Instalação</li>
			<li class="awr-tag awr-tag--green">Teste de alternador grátis</li>
			<?php if ( $garantia ) : ?><li class="awr-tag awr-tag--navy"><?php echo esc_html( $garantia ); ?></li><?php endif; ?>
		</ul>

		<div class="awr-price">
			<span class="awr-price__bar" aria-hidden="true"></span>
			<div class="awr-price__inner">
				<p class="awr-price__label"><?php echo $sob ? 'Preço sob consulta' : 'Preço à vista'; ?></p>
				<p class="awr-price__value"><?php echo $sob ? '—' : esc_html( awr_brl( $price ) ); ?></p>
				<p class="awr-price__note"><?php echo $sob ? 'Confirme no WhatsApp' : '✓ Já com instalação'; ?></p>
				<?php if ( ! $sob ) : ?>
					<p class="awr-price__installment">10× <?php echo esc_html( awr_brl( $parcela ) ); ?> S/ Juros</p>
					<p class="awr-price__pix"><span>⚡ 3% OFF no Pix</span><strong><?php echo esc_html( awr_brl( $pix ) ); ?></strong></p>
				<?php endif; ?>
			</div>
		</div>

		<div class="awr-card__actions">
			<a class="awr-btn awr-btn--green awr-btn--pedido" target="_top" rel="noopener"
				data-awr-conv="pedido_1clique"
				data-sku="<?php echo esc_attr( $p['sku'] ); ?>"
				data-preco="<?php echo esc_attr( $price ); ?>"
				href="<?php echo esc_url( awr_wa( $msg ) ); ?>"><?php echo awr_wa_icon( 19 ); // phpcs:ignore WordPress.Security.EscapeOutput ?> Pedir no WhatsApp agora</a>
			<button type="button" class="awr-btn awr-btn--ghost awr-btn--sec" data-awr-checkout
				data-sku="<?php echo esc_attr( $p['sku'] ); ?>"
				data-nome="<?php echo esc_attr( $nome ); ?>"
				data-preco="<?php echo esc_attr( $price ); ?>"
				data-pid="<?php echo esc_attr( $pid ); ?>"
				data-casco="<?php echo esc_attr( $casco ); ?>"
				data-imagem="<?php echo esc_url( $p['image'] ?? '' ); ?>"
				data-garantia="<?php echo esc_attr( $garantia ); ?>"
				data-veiculo="<?php echo esc_attr( $veiculo ); ?>">Comprar online (pagar na entrega)</button>
			<a class="awr-card__duvida" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $msg_duv ) ); ?>">Tenho uma dúvida</a>
		</div>


		<p class="awr-price__fine">Preço válido com devolução do casco. Pague na entrega: Pix, Crédito ou Débito.</p>



		<div class="awr-card__foot">
			<span>★ <strong><?php echo esc_html( awr_company()['rating'] ); ?></strong> · +<?php echo esc_html( awr_company()['reviews'] ); ?> avaliações</span>
			<span>Compra 100% segura</span>
		</div>
	</div>

</article>
