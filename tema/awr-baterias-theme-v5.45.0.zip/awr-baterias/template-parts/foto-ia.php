<?php
/** Identificação da bateria pela foto (motor de IA do app). @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Identificação por IA oculta no tema; o envio de foto pelo WhatsApp permanece.
return;
$awr_ep = str_replace( '/diagnostico', '/foto-bateria', function_exists( 'awr_diag_endpoint' ) ? awr_diag_endpoint() : 'https://quick-battery-hero.lovable.app/api/public/diagnostico' );
?>
<div class="awr-foto-ia" data-ep="<?php echo esc_url( $awr_ep ); ?>" data-base="<?php echo esc_url( home_url( '/bateria/' ) ); ?>" style="margin-top:14px;border:1px dashed #1d4ed8;border-radius:12px;padding:14px;background:#eff6ff">
 <strong>Identificar minha bateria pela foto</strong>
 <p style="font-size:12px;margin:4px 0 10px">Fotografe a etiqueta da bateria atual. A leitura indica modelos da tabela AWR; o técnico confirma antes da troca.</p>
 <label class="awr-btn awr-btn--primary" style="cursor:pointer">📷 Tirar ou escolher foto<input type="file" accept="image/*" capture="environment" style="position:absolute;width:1px;height:1px;opacity:0"></label>
 <div class="awr-foto-out" aria-live="polite" style="margin-top:10px;font-size:14px"></div>
</div>
<?php if ( empty( $GLOBALS['awr_foto_js'] ) ) : $GLOBALS['awr_foto_js'] = 1; ?>
<script>
document.addEventListener('change',function(e){var b=e.target.closest&&e.target.closest('.awr-foto-ia');if(!b||!e.target.files||!e.target.files[0])return;var o=b.querySelector('.awr-foto-out');o.textContent='Lendo a etiqueta…';
createImageBitmap(e.target.files[0]).then(function(bm){var k=Math.min(1,1024/Math.max(bm.width,bm.height)),c=document.createElement('canvas');c.width=Math.round(bm.width*k);c.height=Math.round(bm.height*k);c.getContext('2d').drawImage(bm,0,0,c.width,c.height);
return fetch(b.dataset.ep,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({imagem:c.toDataURL('image/jpeg',0.85)})})}).then(function(r){return r.json()}).then(function(j){if(j.error){o.textContent=j.error;return}
var brl=function(n){return n.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})},l=[j.exato].concat(j.sugestoes||[]).filter(Boolean),esc=function(s){var d=document.createElement('div');d.textContent=String(s);return d.innerHTML.split('"').join('&quot;')};
var h=j.legivel?'<p>Lido: '+esc([j.marca,j.codigo,j.amperagem&&j.amperagem+' Ah',j.cca&&j.cca+' CCA',j.tecnologia].filter(Boolean).join(' · ')||'etiqueta parcial')+'</p>':'<p>Não deu para ler a etiqueta. Envie a foto pelo WhatsApp que a equipe identifica.</p>';
h+=l.map(function(s,i){return '<div style="display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px;background:#fff;border-radius:8px;padding:10px;margin-top:6px"><span><b>'+(i===0&&j.exato?'Mesmo modelo: ':'Compatível: ')+esc(s.sku)+'</b> · '+Number(s.ah)+' Ah · '+Number(s.cca)+' CCA · '+brl(s.precoVista)+'</span><a class="awr-btn awr-btn--primary" href="'+b.dataset.base+encodeURIComponent(s.sku)+'/">Ver e comprar</a></div>'}).join('');o.innerHTML=h}).catch(function(){o.textContent='Não conseguimos ler a foto agora. Envie pelo WhatsApp.'})});
</script>
<?php endif; ?>
