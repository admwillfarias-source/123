<?php
/**
 * Blocos do vertical de motos: seletor Marca > Modelo > Ano, marcas atendidas,
 * modelos em destaque e texto semântico. Paridade com MotoBlocks.tsx do app.
 *
 * @var array  $args ['cidade' => slug|'', 'cidade_nome' => string|'']
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$cidade      = isset( $args['cidade'] ) ? (string) $args['cidade'] : '';
$cidade_nome = isset( $args['cidade_nome'] ) ? (string) $args['cidade_nome'] : '';
$sufixo      = $cidade_nome ? ' em ' . $cidade_nome : '';
$onde        = $cidade_nome ? 'em ' . $cidade_nome : 'em Porto Alegre e região';
$brands      = awr_moto_brands();
$destaques   = awr_moto_destaques( 12 );

// Índice enxuto para o seletor (marca => modelos com faixa de anos).
$idx = array();
foreach ( awr_moto_models() as $m ) {
	$idx[ $m['marca_slug'] ]['nome']       = $m['marca'];
	$idx[ $m['marca_slug'] ]['modelos'][]  = array(
		's' => $m['slug'],
		'n' => $m['modelo'],
		'd' => $m['de'],
		'a' => $m['ate'],
	);
}
?>
<section class="awr-block awr-moto-busca">
	<h2 class="awr-section-title">Encontre a bateria da sua moto<?php echo esc_html( $sufixo ); ?></h2>
	<p class="awr-lead">Selecione marca, modelo e ano para ver a bateria compatível, com amperagem e polaridade corretas.</p>
	<form class="awr-moto-form" id="awr-moto-form" data-cidade="<?php echo esc_attr( $cidade ); ?>">
		<label class="awr-moto-form__field">
			<span>Marca</span>
			<select id="awr-moto-marca" required>
				<option value="">Selecione a marca</option>
				<?php foreach ( $brands as $b ) : ?>
					<option value="<?php echo esc_attr( $b['slug'] ); ?>"><?php echo esc_html( $b['nome'] ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<label class="awr-moto-form__field">
			<span>Modelo</span>
			<select id="awr-moto-modelo" required disabled>
				<option value="">Selecione a marca primeiro</option>
			</select>
		</label>
		<label class="awr-moto-form__field">
			<span>Ano</span>
			<select id="awr-moto-ano" disabled>
				<option value="">Todos os anos</option>
			</select>
		</label>
		<button type="submit" class="awr-btn awr-btn--gold">Ver bateria compatível</button>
	</form>
	<script type="application/json" id="awr-moto-index"><?php echo wp_json_encode( $idx ); ?></script>
	<script>
	(function () {
		var form = document.getElementById('awr-moto-form');
		if (!form) { return; }
		var idx = JSON.parse(document.getElementById('awr-moto-index').textContent || '{}');
		var sMarca = document.getElementById('awr-moto-marca');
		var sModelo = document.getElementById('awr-moto-modelo');
		var sAno = document.getElementById('awr-moto-ano');
		var cidade = form.getAttribute('data-cidade') || '';

		function reset(sel, label) {
			sel.innerHTML = '<option value="">' + label + '</option>';
		}
		sMarca.addEventListener('change', function () {
			var m = idx[sMarca.value];
			reset(sModelo, m ? 'Selecione o modelo' : 'Selecione a marca primeiro');
			reset(sAno, 'Todos os anos');
			sAno.disabled = true;
			sModelo.disabled = !m;
			if (!m) { return; }
			m.modelos.forEach(function (x) {
				var o = document.createElement('option');
				o.value = x.s; o.textContent = x.n; o.dataset.de = x.d; o.dataset.ate = x.a;
				sModelo.appendChild(o);
			});
		});
		sModelo.addEventListener('change', function () {
			var o = sModelo.options[sModelo.selectedIndex];
			reset(sAno, 'Todos os anos');
			sAno.disabled = !o || !o.value;
			if (!o || !o.value) { return; }
			for (var y = parseInt(o.dataset.ate, 10); y >= parseInt(o.dataset.de, 10); y--) {
				var op = document.createElement('option');
				op.value = String(y); op.textContent = String(y);
				sAno.appendChild(op);
			}
		});
		form.addEventListener('submit', function (ev) {
			ev.preventDefault();
			if (!sModelo.value) { sModelo.focus(); return; }
			var url = '/baterias-para/' + sModelo.value + '/' + (cidade ? cidade + '/' : '');
			if (sAno.value) { url += '?ano=' + sAno.value; }
			window.location.href = url;
		});
	})();
	</script>
</section>

<section class="awr-block">
	<h2 class="awr-section-title">Marcas de moto atendidas</h2>
	<p><a class="awr-btn awr-btn--gold" href="<?php echo esc_url( home_url( '/loja/c/moto/' ) ); ?>">Ver baterias para moto na loja →</a></p>
	<ul class="awr-chips">
		<?php foreach ( $brands as $b ) : ?>
			<li>
				<a class="awr-chip" href="<?php echo esc_url( awr_moto_brand_url( $b['slug'] ) ); ?>">
					Bateria de moto <?php echo esc_html( $b['nome'] ); ?> <small>(<?php echo (int) $b['total']; ?>)</small>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</section>

<section class="awr-block">
	<h2 class="awr-section-title">Motos mais atendidas<?php echo esc_html( $sufixo ); ?></h2>
	<ul class="awr-links-rel__grid">
		<?php foreach ( $destaques as $m ) : ?>
			<?php $url = awr_vc_url( $m['slug'], $cidade ); ?>
			<li>
				<a class="awr-links-rel__item" href="<?php echo esc_url( $url ); ?>">
					<span>
						Bateria para <?php echo esc_html( $m['label'] ); ?>
						<small><?php echo esc_html( awr_moto_ah_range( $m['ahs'] ) . ' · ' . ( $m['de'] === $m['ate'] ? $m['de'] : $m['de'] . '–' . $m['ate'] ) ); ?></small>
					</span>
					<b aria-hidden="true">→</b>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</section>

<section class="awr-block awr-prose">
	<h2 class="awr-section-title">Como escolher a bateria certa para a sua moto</h2>
	<p>Praticamente toda moto de rua usa bateria de 12 volts — o que muda é a capacidade em ampère-hora (Ah) e o formato da caixa. Motos de 125cc a 160cc como CG, Fan, Titan, Biz, Pop e Factor trabalham com 5Ah. Modelos de 250cc a 300cc como Twister, CB 300, Fazer 250 e XRE 300 pedem de 6Ah a 9Ah. Big trail, custom e motos com acessórios elétricos normalmente usam 12Ah. Além da amperagem, a polaridade (positivo à direita ou à esquerda) precisa bater com o chicote da moto.</p>
	<h3>Bateria selada e bateria convencional</h3>
	<p>A bateria convencional tem eletrólito líquido e exige completar água destilada de tempos em tempos. A selada (VRLA) já sai ativada de fábrica, não pede manutenção e não corre risco de vazar ácido no chicote — por isso é o padrão nas motos atuais. Trocar uma convencional por uma selada equivalente é possível na maioria dos casos, desde que a medida da caixa e a posição dos terminais sejam as mesmas.</p>
	<h3>AGM e gel: quando compensam</h3>
	<p>Nas baterias AGM o eletrólito fica absorvido em mantas de fibra de vidro; nas de gel, ele é imobilizado em forma de gel. As duas tecnologias resistem melhor à vibração e à moto parada por períodos longos, seguram melhor a corrente de partida no frio e toleram mais ciclos de descarga. Para uso urbano diário, a selada comum atende bem e custa menos; para moto de trilha, viagem, custom ou que fica dias na garagem, AGM ou gel duram mais.</p>
	<h3>Sinais de que a bateria está no fim</h3>
	<p>Partida elétrica lenta ou só no pedal, farol e painel fracos com o motor desligado, seta piscando devagar, alarme disparando sozinho e a moto que só liga depois de dias parada indicam bateria no fim ou sistema de carga irregular. Na troca <?php echo esc_html( $onde ); ?> testamos o regulador de tensão e o alternador junto: bateria nova em moto com carga irregular volta a falhar em poucas semanas.</p>
</section>
