<?php
/**
 * Bloco "Como funciona" — carrossel de 4 passos (paridade com ComoFuncionaSlider.tsx do app).
 * Passos 1–3 abrem o buscador em modal; passo 4 aciona Ligar/WhatsApp.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_c = awr_company();
$steps = array(
	array( 'ico' => '🚗', 't' => 'Selecione o Carro', 'd' => 'Informe marca, modelo e ano do seu veículo.' ),
	array( 'ico' => '🔋', 't' => 'Finalize o Pedido', 'd' => 'Compare as baterias, sem cadastro. Pague na entrega.' ),
	array( 'ico' => '🛠️', 't' => 'Instalação Profissional', 'd' => 'Entrega, teste e instalação grátis em até 35 minutos.' ),
	array( 'ico' => '💬', 't' => 'Ficou na Dúvida?', 'd' => 'Ligue ou envie mensagem — respondemos em 2 minutos.' ),
);
?>
<section class="awr-cf" aria-labelledby="awr-cf-title" data-awr-slider>
	<div class="awr-container">
		<p class="awr-cf__eyebrow" id="awr-cf-title"><span></span>COMO FUNCIONA<span></span></p>

		<div class="awr-cf__stage">
			<?php foreach ( $steps as $i => $s ) : ?>
				<?php $is_contact = 3 === $i; ?>
				<div class="awr-cf__slide<?php echo 0 === $i ? ' is-active' : ''; ?>" data-awr-slide="<?php echo (int) $i; ?>"<?php echo 0 === $i ? '' : ' aria-hidden="true"'; ?>>
					<?php if ( $is_contact ) : ?>
						<div class="awr-cf__card">
							<span class="awr-cf__ico" aria-hidden="true"><?php echo esc_html( $s['ico'] ); ?></span>
							<span class="awr-cf__txt">
								<b><span class="awr-cf__n"><?php echo (int) ( $i + 1 ); ?></span><?php echo esc_html( $s['t'] ); ?></b>
								<em><?php echo esc_html( $s['d'] ); ?></em>
							</span>
							<span class="awr-cf__acts">
								<a class="awr-btn awr-btn--navy" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">Ligar</a>
								<a class="awr-btn awr-btn--green" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Estou com dúvida sobre qual bateria escolher.' ) ); ?>">WhatsApp</a>
							</span>
						</div>
					<?php else : ?>
						<button type="button" class="awr-cf__card awr-cf__card--btn" data-awr-open-search>
							<span class="awr-cf__ico" aria-hidden="true"><?php echo esc_html( $s['ico'] ); ?></span>
							<span class="awr-cf__txt">
								<b><span class="awr-cf__n"><?php echo (int) ( $i + 1 ); ?></span><?php echo esc_html( $s['t'] ); ?></b>
								<em><?php echo esc_html( $s['d'] ); ?></em>
							</span>
							<span class="awr-cf__go" aria-hidden="true">→</span>
						</button>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="awr-cf__dots" role="tablist" aria-label="Etapas">
			<?php foreach ( $steps as $i => $s ) : ?>
				<button type="button" class="awr-cf__dot<?php echo 0 === $i ? ' is-active' : ''; ?>" data-awr-dot="<?php echo (int) $i; ?>" role="tab" aria-selected="<?php echo 0 === $i ? 'true' : 'false'; ?>" aria-label="Passo <?php echo (int) ( $i + 1 ); ?>: <?php echo esc_attr( $s['t'] ); ?>"><span></span></button>
			<?php endforeach; ?>
		</div>
	</div>
</section>
