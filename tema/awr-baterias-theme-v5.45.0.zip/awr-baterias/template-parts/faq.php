<?php
/**
 * Bloco de perguntas frequentes (espelha o JSON-LD FAQPage de awr_schema_cidade).
 *
 * Uso: awr_part( 'faq', array( 'titulo' => '...', 'itens' => array( array( 'q' => '', 'r' => '' ) ) ) );
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$args  = wp_parse_args( $args ?? array(), array( 'titulo' => 'Perguntas frequentes', 'itens' => array() ) );
$itens = (array) $args['itens'];
if ( ! $itens ) { return; }
?>
<section class="awr-block awr-faq">
	<h2 class="awr-section-title"><?php echo esc_html( $args['titulo'] ); ?></h2>
	<dl class="awr-faq__list">
		<?php foreach ( $itens as $item ) : ?>
			<div class="awr-faq__item">
				<dt class="awr-faq__q"><?php echo esc_html( $item['q'] ?? $item['pergunta'] ?? '' ); ?></dt>
				<dd class="awr-faq__a"><?php echo esc_html( $item['r'] ?? $item['resposta'] ?? '' ); ?></dd>

			</div>
		<?php endforeach; ?>
	</dl>
</section>
