<?php
/**
 * Como Funciona — grade de 4 cards (paridade com a seção da home do app).
 * Passos 1–3 abrem o buscador em modal; passo 4 aciona contato.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_c  = awr_company();
$awr_st = array(
	array( '🚗', 'Selecione o Carro', 'Informe marca, modelo e ano do seu veículo.' ),
	array( '🔋', 'Finalize o Pedido', 'Compare as baterias, sem cadastro. Pague na entrega.' ),
	array( '🛠️', 'Instalação Profissional', 'Entrega, teste e instalação grátis em até 35 minutos.' ),
	array( '💬', 'Ficou na Dúvida?', 'Ligue ou envie mensagem — respondemos em 2 minutos.' ),
);
?>
<section class="awr-sec awr-cfgrid awr-sec--soft" aria-labelledby="awr-cfgrid-title">
	<div class="awr-container">
		<div class="awr-sec__head">
			<h2 class="awr-section-title" id="awr-cfgrid-title">Como funciona</h2>
			<p>Da busca à instalação em até 35 minutos, sem cadastro e sem burocracia.</p>
		</div>

		<div class="awr-cfgrid__grid">
			<?php foreach ( $awr_st as $i => $s ) : ?>
				<?php if ( 3 === $i ) : ?>
					<div class="awr-cfgrid__card">
						<span class="awr-cfgrid__n"><?php echo (int) ( $i + 1 ); ?></span>
						<span class="awr-cfgrid__ico" aria-hidden="true"><?php echo esc_html( $s[0] ); ?></span>
						<h3><?php echo esc_html( $s[1] ); ?></h3>
						<p><?php echo esc_html( $s[2] ); ?></p>
						<span class="awr-cf__acts">
							<a class="awr-btn awr-btn--navy" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">Ligar</a>
							<a class="awr-btn awr-btn--green" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Estou com dúvida sobre qual bateria escolher.' ) ); ?>">WhatsApp</a>
						</span>
					</div>
				<?php else : ?>
					<button type="button" class="awr-cfgrid__card" data-awr-open-search>
						<span class="awr-cfgrid__n"><?php echo (int) ( $i + 1 ); ?></span>
						<span class="awr-cfgrid__ico" aria-hidden="true"><?php echo esc_html( $s[0] ); ?></span>
						<h3><?php echo esc_html( $s[1] ); ?></h3>
						<p><?php echo esc_html( $s[2] ); ?></p>
					</button>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
	</div>
</section>
