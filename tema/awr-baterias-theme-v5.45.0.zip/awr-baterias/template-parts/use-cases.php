<?php
/**
 * "Qual é o seu caso agora?" — paridade com UseCasesGrid.tsx.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_cases = array(
	array( '🆘', 'AGORA', 'Carro não liga', 'Socorro no local em até 35 minutos, com teste de bateria e alternador.', 'Olá! Meu carro não liga agora. Preciso de socorro.', true ),
	array( '🔋', 'PREVENTIVO', 'Bateria fraca', 'Testamos grátis e trocamos só se precisar. Sem empurra-empurra.', 'Olá! Minha bateria está fraca, quero um diagnóstico.', false ),
	array( '🚗', 'FROTA E APPS', 'Uber, 99 e frota', 'Modelos reforçados para quem roda o dia inteiro, com preço de frota.', 'Olá! Rodo de aplicativo e quero uma bateria reforçada.', false ),
	array( '⚡', 'START-STOP', 'AGM e EFB', 'Instalação com codificação correta para veículos start-stop.', 'Olá! Meu carro é start-stop, preciso de bateria AGM/EFB.', false ),
);
?>
<section class="awr-usecases" aria-labelledby="awr-usecases-title">
	<div class="awr-container">
		<div class="awr-sec__head">
			<h2 class="awr-section-title" id="awr-usecases-title">Qual é o seu caso agora?</h2>
			<p>Escolha a situação e fale direto com quem resolve.</p>
		</div>
		<div class="awr-usecases__grid">
			<?php foreach ( $awr_cases as $c ) : ?>
				<article class="<?php echo $c[5] ? 'is-urgent' : ''; ?>">
					<span aria-hidden="true"><?php echo esc_html( $c[0] ); ?></span>
					<p class="awr-usecases__eyebrow"><?php echo esc_html( $c[1] ); ?></p>
					<h3><?php echo esc_html( $c[2] ); ?></h3>
					<p><?php echo esc_html( $c[3] ); ?></p>
					<a class="awr-btn <?php echo $c[5] ? 'awr-btn--green' : 'awr-btn--outline'; ?>" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $c[4] ) ); ?>" aria-label="Falar no WhatsApp sobre <?php echo esc_attr( $c[1] ); ?>">Falar no WhatsApp</a>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>
