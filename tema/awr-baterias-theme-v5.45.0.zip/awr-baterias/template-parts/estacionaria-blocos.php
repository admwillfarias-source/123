<?php
/**
 * Blocos exclusivos da LP de baterias estacionárias (paridade com
 * EstacionariaBlocks.tsx do app): tribos, tabela de modelos, calculadora
 * de autonomia, programa de parceiros e FAQ ampliado.
 *
 * Uso: awr_part( 'estacionaria-blocos', array( 'cidade' => 'canoas' ) );
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$args    = wp_parse_args( $args ?? array(), array( 'cidade' => '' ) );
$awr_est = awr_estacionaria();
if ( ! $awr_est ) { return; }

$awr_cid_slug = (string) $args['cidade'];
$awr_cid_nome = '';
if ( $awr_cid_slug && function_exists( 'awr_segmento_cidade_by_slug' ) ) {
	$awr_c        = awr_segmento_cidade_by_slug( $awr_cid_slug );
	$awr_cid_nome = $awr_c ? (string) $awr_c['nome'] : '';
}

/** Mensagem de WhatsApp com a cidade resolvida. */
$awr_msg = function ( $tpl ) use ( $awr_cid_nome ) {
	return str_replace( '%CIDADE%', $awr_cid_nome, (string) $tpl );
};
?>

<?php
// Perfil regional: evita que todas as cidades repitam o mesmo texto.
$awr_perfil = ( $awr_cid_slug && function_exists( 'awr_est_perfil_cidade' ) )
	? awr_est_perfil_cidade( $awr_cid_slug, $awr_cid_nome )
	: null;
?>
<?php if ( $awr_perfil ) : ?>
<section class="awr-app-section awr-est">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Quem compra bateria estacionária em <?php echo esc_html( $awr_cid_nome ); ?></h2>
		<p class="awr-est__lead"><?php echo esc_html( $awr_perfil['perfil'] ); ?></p>
		<ul class="awr-app-benefits">
			<?php foreach ( (array) $awr_perfil['quem'] as $awr_q ) : ?>
				<li><?php echo esc_html( $awr_q ); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
<?php endif; ?>


<section class="awr-app-section awr-est">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Qual é a sua aplicação?</h2>
		<p class="awr-est__lead">Cada uso pede uma bateria diferente. Escolha o cenário mais parecido com o seu e fale direto com quem entende dele.</p>
		<div class="awr-est-tribos">
			<?php foreach ( (array) $awr_est['tribos'] as $t ) : ?>
				<article class="awr-est-tribo" id="<?php echo esc_attr( $t['slug'] ); ?>">
					<p class="awr-est-tribo__eyebrow"><?php echo esc_html( $t['eyebrow'] ); ?></p>
					<h3 class="awr-est-tribo__titulo"><?php echo esc_html( $t['titulo'] ); ?></h3>
					<p class="awr-est-tribo__dor"><?php echo esc_html( $t['dor'] ); ?></p>
					<p class="awr-est-tribo__arg"><?php echo esc_html( $t['argumento'] ); ?></p>
					<ul class="awr-est-tribo__bullets">
						<?php foreach ( (array) $t['bullets'] as $b ) : ?>
							<li><?php echo esc_html( $b ); ?></li>
						<?php endforeach; ?>
					</ul>
					<p class="awr-est-tribo__modelos"><strong>Modelos mais pedidos:</strong> <?php echo esc_html( $t['modelosSugeridos'] ); ?></p>
					<a
						class="awr-est-wa"
						target="_top"
						rel="noopener"
						data-awr-est-lead="<?php echo esc_attr( $t['key'] ); ?>"
						data-awr-est-cidade="<?php echo esc_attr( $awr_cid_nome ); ?>"
						href="<?php echo esc_url( awr_wa( $awr_msg( $awr_cid_nome ? $t['waCidade'] : $t['wa'] ) ) ); ?>"
					><?php echo esc_html( $t['ctaLabel'] ); ?></a>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="awr-sec awr-services awr-est">
	<div class="awr-container">
		<div class="awr-sec__head">
			<h2 class="awr-section-title">Tudo o que fazemos na linha estacionária</h2>
			<p>Do dimensionamento à destinação ambiental do banco antigo.</p>
		</div>
		<div class="awr-services__grid">
			<?php
			$awr_serv_est = array(
				array( '🔋', 'Troca do banco de baterias', 'ESTACIONÁRIA', 'Baterias novas, com data de fabricação recente e terminais conferidos.' ),
				array( '🔌', 'Nobreak, UPS e iluminação de emergência', 'DIMENSIONAMENTO', 'Bancos calculados em Ah para nobreak, UPS e luminárias de emergência.' ),
				array( '🧮', 'Cálculo de autonomia', 'GRÁTIS', 'Carga em watts, horas de autonomia e tensão do banco — sem compromisso.' ),
				array( '🚚', 'Entrega e envio', 'POA, RS E DEMAIS ESTADOS', 'Entrega própria na Grande Porto Alegre e transportadora para o resto do país.' ),
				array( '♻️', 'Logística reversa', 'RECOLHIMENTO', 'Recolhemos o banco antigo e encaminhamos para recicladora licenciada.' ),
				array( '🧾', 'Nota fiscal e garantia', 'CNPJ OU CPF', 'Nota no mesmo dia, com garantia de fábrica registrada em seu nome.' ),
			);
			foreach ( $awr_serv_est as $awr_s ) :
				?>
				<article>
					<span class="awr-services__ico" aria-hidden="true"><?php echo esc_html( $awr_s[0] ); ?></span>
					<div>
						<p class="awr-services__eyebrow"><?php echo esc_html( $awr_s[2] ); ?></p>
						<h3><?php echo esc_html( $awr_s[1] ); ?></h3>
						<p><?php echo esc_html( $awr_s[3] ); ?></p>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>


<section class="awr-app-section awr-est" id="estacionarias-loja">
	<div class="awr-hub-body">
		<?php awr_part( 'produtos-woo', array( 'produtos' => awr_shop_products_by_cat( 'estacionaria' ), 'titulo' => 'Baterias estacionárias disponíveis na loja', 'lead' => 'Preço e estoque reais. Compre pelo site ou confirme a aplicação no WhatsApp.' ) ); ?>
	</div>
</section>

<section class="awr-app-section awr-app-section--muted awr-est">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Modelos, códigos e amperagens</h2>
		<p class="awr-est__lead">Já sabe o código da bateria? Confirme a especificação e peça o preço direto pelo modelo.</p>
		<p><a class="awr-btn awr-btn--gold" href="<?php echo esc_url( home_url( '/loja/c/estacionaria/' ) ); ?>">Ver baterias estacionárias na loja →</a></p>
		<div class="awr-est-filtros" data-awr-est-filtros role="group" aria-label="Filtrar modelos por aplicação">
			<button type="button" class="awr-est-filtro is-active" data-filtro="todos">Todos</button>
			<?php foreach ( (array) $awr_est['tribos'] as $awr_t ) : ?>
				<button type="button" class="awr-est-filtro" data-filtro="<?php echo esc_attr( $awr_t['key'] ); ?>"><?php echo esc_html( $awr_t['titulo'] ); ?></button>
			<?php endforeach; ?>
		</div>
		<div class="awr-est-tabela-wrap">
			<table class="awr-est-tabela">
				<thead>
					<tr>
						<th>Modelo</th>
						<th>Tensão</th>
						<th>Capacidade</th>
						<th>Indicado para</th>
						<th>Preço</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( (array) $awr_est['modelos'] as $m ) : ?>
						<?php if ( empty( $m['codigo'] ) ) { continue; } ?>
						<tr data-tribo="<?php echo esc_attr( $m['tribo'] ?? '' ); ?>">
							<td class="awr-est-tabela__modelo"><?php echo esc_html( $m['codigo'] ); ?></td>
							<td><?php echo esc_html( $m['tensao'] ); ?></td>
							<td><?php echo esc_html( $m['ah'] ); ?></td>
							<td><?php echo esc_html( $m['aplicacao'] ); ?></td>
							<td>
								<a
									class="awr-est-link"
									target="_top"
									rel="noopener"
									data-awr-est-lead="modelo"
									data-awr-est-modelo="<?php echo esc_attr( $m['codigo'] ); ?>"
									data-awr-est-cidade="<?php echo esc_attr( $awr_cid_nome ); ?>"
									href="<?php echo esc_url( awr_wa( sprintf( 'Olá! Quero o preço da bateria %1$s (%2$s %3$s)%4$s. Tem disponível?', $m['codigo'], $m['tensao'], $m['ah'], $awr_cid_nome ? ' em ' . $awr_cid_nome : '' ) ) ); ?>"
								>Consultar preço</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<p class="awr-est__nota">Disponibilidade e preço variam por lote e por marca. Confirme no WhatsApp antes de fechar o pedido.</p>
	</div>
</section>

<section class="awr-app-section awr-est">
	<div class="awr-hub-body">
		<div class="awr-est-calc" data-awr-calc data-cidade="<?php echo esc_attr( $awr_cid_nome ); ?>">
			<h2 class="awr-app-section__title">Calculadora de autonomia</h2>
			<p class="awr-est__lead">Informe a carga em watts e quanto tempo ela precisa continuar ligada. O cálculo já considera o rendimento do inversor e uma descarga máxima de 50%, que é o que preserva a vida útil do banco.</p>
			<div class="awr-est-calc__grid">
				<label>Carga (W)
					<input type="number" inputmode="numeric" min="1" value="300" data-calc-watts>
				</label>
				<label>Autonomia (horas)
					<input type="number" inputmode="decimal" min="0.5" step="0.5" value="2" data-calc-horas>
				</label>
				<label>Tensão do banco
					<select data-calc-tensao>
						<option value="12">12V</option>
						<option value="24">24V</option>
						<option value="48">48V</option>
					</select>
				</label>
			</div>
			<button type="button" class="awr-est-calc__btn" data-calc-run>Calcular Ah necessário</button>
			<div class="awr-est-calc__out" data-calc-out hidden></div>
		</div>
	</div>
</section>

<section class="awr-app-section awr-est">
	<div class="awr-hub-body">
		<div class="awr-est-dimensionar">
			<div>
				<h2 class="awr-est-dimensionar__titulo">Precisa de ajuda para dimensionar?</h2>
				<p class="awr-est-dimensionar__lead">Nossa equipe calcula o banco com você: carga em watts, autonomia desejada, tensão do inversor e espaço disponível. Você recebe a indicação de modelo, a quantidade de baterias e o preço fechado — sem custo e sem compromisso.</p>
			</div>
			<a
				class="awr-est-wa"
				target="_top"
				rel="noopener"
				data-awr-est-lead="dimensionamento"
				data-awr-est-cidade="<?php echo esc_attr( $awr_cid_nome ); ?>"
				href="<?php echo esc_url( awr_wa( 'Olá! Preciso de ajuda para dimensionar um banco de baterias estacionárias' . ( $awr_cid_nome ? ' em ' . $awr_cid_nome : '' ) . '. Minha carga é de ___ W e preciso de ___ horas de autonomia.' ) ); ?>"
			>Falar com um consultor técnico</a>
		</div>
	</div>
</section>

<section class="awr-app-section awr-app-section--muted awr-est">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Logística reversa e destinação ambiental</h2>
		<p class="awr-est__lead">Bateria chumbo-ácido é resíduo perigoso e não pode ir para o lixo comum. Em toda troca, a AWR recolhe o banco antigo e encaminha para reciclagem por recicladora licenciada, conforme a Política Nacional de Resíduos Sólidos.</p>
		<ul class="awr-app-benefits">
			<li>Recolhimento do banco antigo no mesmo atendimento da entrega</li>
			<li>Encaminhamento para reciclagem em operador licenciado</li>
			<li>Comprovante de recolhimento para empresas e condomínios que precisam prestar contas</li>
			<li>Abatimento do casco velho no valor da bateria nova</li>
		</ul>
		<p class="awr-est__nota">Precisa de documentação específica para auditoria ou ESG? Peça no WhatsApp junto com o orçamento e informamos o que conseguimos emitir para o seu caso.</p>
	</div>
</section>

<section class="awr-app-section awr-est">
	<div class="awr-hub-body">
		<div class="awr-est-b2b">
			<h2 class="awr-est-b2b__titulo">Programa de parceiros e atacado</h2>
			<p class="awr-est-b2b__lead">Se você instala sistemas solares, monta som automotivo, administra condomínios ou cuida de TI e segurança eletrônica, trabalhamos com preço de parceiro, reposição programada e nota fiscal em CNPJ.</p>
			<div class="awr-est-b2b__grid">
				<?php foreach ( (array) $awr_est['b2b'] as $p ) : ?>
					<div class="awr-est-b2b__card">
						<h3><?php echo esc_html( $p['titulo'] ); ?></h3>
						<p><?php echo esc_html( $p['descricao'] ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
			<a
				class="awr-est-wa"
				target="_top"
				rel="noopener"
				data-awr-est-lead="b2b"
				data-awr-est-cidade="<?php echo esc_attr( $awr_cid_nome ); ?>"
				href="<?php echo esc_url( awr_wa( $awr_est['b2bWa'] . ( $awr_cid_nome ? ' Estou em ' . $awr_cid_nome . '.' : '' ) ) ); ?>"
			>Quero preço de parceiro</a>
		</div>
	</div>
</section>

<section class="awr-app-section"><div class="awr-hub-body awr-hub-body--narrow">
 <h2 class="awr-app-section__title">Garantia por linha</h2>
 <table class="awr-app-table"><thead><tr><th>Linha</th><th>Garantia</th></tr></thead><tbody>
 <?php foreach ( awr_data( 'comercial' )['garantiasEstacionarias'] ?? array() as $garantia ) : ?><tr><td><?php echo esc_html( $garantia['linha'] ); ?></td><td><?php echo esc_html( $garantia['prazo'] ); ?></td></tr><?php endforeach; ?>
 </tbody></table>
</div></section>
<?php
// FAQ: perguntas gerais + perguntas próprias da cidade (conteúdo não repetido).
$awr_faq_est = (array) $awr_est['faq'];
if ( $awr_perfil && ! empty( $awr_perfil['faq'] ) ) {
	$awr_faq_est = array_merge( (array) $awr_perfil['faq'], $awr_faq_est );
}
?>
<section class="awr-app-section awr-app-section--muted awr-est">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Perguntas frequentes sobre baterias estacionárias<?php echo $awr_cid_nome ? esc_html( ' em ' . $awr_cid_nome ) : ''; ?></h2>
		<div class="awr-app-faq">
			<?php foreach ( $awr_faq_est as $f ) : ?>
				<details>
					<summary><?php echo esc_html( $f['pergunta'] ); ?></summary>
					<p><?php echo esc_html( $f['resposta'] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php
if ( function_exists( 'awr_jsonld' ) ) {
	$awr_est_ld = array();
	foreach ( $awr_faq_est as $f ) {

		$awr_est_ld[] = array(
			'@type'          => 'Question',
			'name'           => $f['pergunta'],
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f['resposta'] ),
		);
	}
	if ( $awr_est_ld ) {
		awr_jsonld( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $awr_est_ld ) );
	}
}
?>
