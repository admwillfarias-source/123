<?php
/** Ficha técnica da tabela oficial. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_e = function_exists( 'awr_espec_bateria' ) ? awr_espec_bateria( (string) ( $args['sku'] ?? '' ) ) : null;
if ( ! $awr_e ) { return; }
$awr_l = array( 'Modelo' => $awr_e['modelo'], 'Amperagem' => $awr_e['ah'] . ' Ah', 'Corrente de partida (CCA)' => $awr_e['cca'] . ' A', 'Peso' => $awr_e['peso'] . ' kg', 'Garantia de fábrica' => $awr_e['garantia'] . ' meses' );
?>
<section class="awr-app-section"><div class="awr-hub-body">
 <h2>Ficha técnica</h2>
 <dl style="display:grid;gap:6px;grid-template-columns:repeat(auto-fit,minmax(min(260px,100%),1fr))">
  <?php foreach ( $awr_l as $k => $v ) : ?><div style="display:flex;justify-content:space-between;border-bottom:1px solid #e2e8f0;padding:4px 0"><dt><?php echo esc_html( $k ); ?></dt><dd style="margin:0;font-weight:700"><?php echo esc_html( $v ); ?></dd></div><?php endforeach; ?>
 </dl>
</div></section>
