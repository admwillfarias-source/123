<?php
/** Menu de emergência: nível e prazo vêm do cadastro oficial de cidades. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_sel = (string) ( $args['cidade'] ?? 'porto-alegre' );
$awr_c   = awr_company();
$awr_lista = array();
foreach ( (array) awr_cidades() as $c ) {
	$modo = awr_city_delivery_mode( $c );
	$awr_lista[ $c['slug'] ] = array(
		'nome'  => $c['nome'],
		'nivel' => 'rapida' === $modo ? 'AWR Express' : ( 'ate-17h' === $modo ? 'AWR no mesmo dia' : 'AWR agendada' ),
		'selo'  => awr_city_delivery_badge( $c ),
		'promessa' => awr_city_delivery_promise( $c ),
	);
}
$awr_lista['outra'] = array( 'nome' => '', 'nivel' => 'AWR RS', 'selo' => 'Envio por transportadora · 2 a 3 dias úteis', 'promessa' => 'por transportadora em 2 a 3 dias úteis (confirmado pelo CEP no pedido)' );
if ( ! isset( $awr_lista[ $awr_sel ] ) ) { $awr_sel = 'porto-alegre'; }
$awr_ini = $awr_lista[ $awr_sel ] ?? reset( $awr_lista );
?>
<?php if ( is_front_page() ) : ?>
<section class="awr-app-section awr-pillars"><div class="awr-hub-body awr-pillars__grid">
 <a class="awr-pillar awr-pillar--auto" href="#awr-emerg-t"><small>AWR AUTOMOTIVA</small><strong>Carro parado? A AWR vai até você.</strong><span>Entrega, instalação e teste no local.</span></a>
 <a class="awr-pillar awr-pillar--energy" href="<?php echo esc_url( home_url( '/baterias-estacionarias/' ) ); ?>"><small>AWR ENERGIA</small><strong>Sistema de energia? A bateria certa para ele.</strong><span>Nobreak, solar, CFTV, alarme e telecom.</span></a>
</div></section>
<?php endif; ?>
<section class="awr-app-section awr-emergencia" aria-labelledby="awr-emerg-t" data-rest="<?php echo esc_url( rest_url( 'awr/v1/frete' ) ); ?>" data-wa="<?php echo esc_attr( $awr_c['whatsapp_number'] ); ?>">
 <div class="awr-hub-body awr-emergencia__panel">
  <p class="awr-emergencia__eyebrow">⚡ Bateria agora?</p>
  <h2 id="awr-emerg-t">Bateria arriou? Onde você está?</h2>
  <div class="awr-emergencia__fields">
   <label>Cidade<select class="awr-emerg-cidade">
    <?php foreach ( $awr_lista as $slug => $i ) : ?>
     <option value="<?php echo esc_attr( $slug ); ?>" data-nome="<?php echo esc_attr( $i['nome'] ); ?>" data-nivel="<?php echo esc_attr( $i['nivel'] ); ?>" data-selo="<?php echo esc_attr( $i['selo'] ); ?>" data-promessa="<?php echo esc_attr( $i['promessa'] ); ?>" <?php selected( $slug, $awr_sel ); ?>><?php echo esc_html( $i['nome'] ?: 'Outra cidade do RS' ); ?></option>
    <?php endforeach; ?>
   </select></label>
   <label>Seu carro (opcional)<input class="awr-emerg-veiculo" maxlength="60" placeholder="Ex.: Onix 2019"></label>
  </div>
  <label class="awr-emergencia__cep">Ou informe seu CEP<input class="awr-emerg-cep" inputmode="numeric" maxlength="9" placeholder="00000-000"></label>
  <p class="awr-emerg-cepres" aria-live="polite"></p>
  <div class="awr-emergencia__delivery" aria-live="polite">
   <strong class="awr-emerg-nivel"><?php echo esc_html( $awr_ini['nivel'] ); ?></strong>
   <div class="awr-emerg-selo"><?php echo esc_html( $awr_ini['selo'] ); ?></div>
   <small>Instalação, teste de bateria e alternador e garantia. Prazo confirmado no atendimento.</small>
  </div>
  <div class="awr-emergencia__actions">
   <a class="awr-btn awr-btn--wa awr-emerg-pedir" target="_blank" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Minha bateria arriou. Preciso de bateria ' . $awr_ini['promessa'] . '.' ) ); ?>">Pedir agora</a>
   <a class="awr-btn awr-emerg-call" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">Ligar</a>
   <a class="awr-btn awr-emerg-search" href="<?php echo esc_url( home_url( '/buscar/' ) ); ?>">Encontrar minha bateria</a>
   <a class="awr-btn awr-emerg-foto" target="_blank" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Vou mandar a foto da etiqueta da minha bateria para vocês indicarem o modelo certo e o preço.', false ) ); ?>">📷 Mande uma foto da bateria</a>
  </div>
 </div>
</section>
<?php if ( empty( $GLOBALS['awr_emerg_js'] ) ) : $GLOBALS['awr_emerg_js'] = 1; ?>
<script>
document.addEventListener('change',function(e){var s=e.target.closest&&e.target.closest('.awr-emergencia');if(s)awrEm(s)});
document.addEventListener('input',function(e){var s=e.target.closest&&e.target.closest('.awr-emergencia');if(s)awrEm(s)});
document.addEventListener('input',function(e){if(!e.target.classList||!e.target.classList.contains('awr-emerg-cep'))return;var s=e.target.closest('.awr-emergencia'),d=e.target.value.replace(/\D/g,''),o=s.querySelector('.awr-emerg-cepres');s.dataset.cep='';s.dataset.prazo='';if(d.length!==8){o.textContent='';awrEm(s);return}
fetch(s.dataset.rest+'?cep='+d).then(function(r){return r.json()}).then(function(j){o.textContent=j.prazo+(j.valor===0?' · instalação inclusa':(j.valor?' · frete R$ '+Number(j.valor).toFixed(2).replace('.',','):''));s.dataset.cep=d;s.dataset.prazo=j.prazo;awrEm(s)}).catch(function(){o.textContent='Consulte a entrega no WhatsApp'})});
function awrEm(s){var o=s.querySelector('.awr-emerg-cidade').selectedOptions[0],v=s.querySelector('.awr-emerg-veiculo').value,n=o.dataset.nome;
s.querySelector('.awr-emerg-nivel').textContent=o.dataset.nivel;s.querySelector('.awr-emerg-selo').textContent=o.dataset.selo;
var m='Olá! Minha bateria arriou'+(n?' em '+n:'')+(s.dataset.cep?' (CEP '+s.dataset.cep+')':'')+(v?'. Carro: '+v:'')+'. Preciso de bateria '+(s.dataset.prazo?s.dataset.prazo.toLowerCase():o.dataset.promessa)+'.';
s.querySelector('.awr-emerg-pedir').href='https://wa.me/'+s.dataset.wa+'?text='+encodeURIComponent(m);
s.querySelector('.awr-emerg-foto').href='https://wa.me/'+s.dataset.wa+'?text='+encodeURIComponent('Olá! Vou mandar a foto da etiqueta da minha bateria'+(n?' (estou em '+n+')':'')+' para vocês indicarem o modelo certo e o preço.');}
</script>
<?php endif; ?>
