<?php
/**
 * Tríade de conversão — paridade com TrustStrip.tsx (preset "conversao").
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_items = array(
	array( '💳', 'Pague só na instalação' ),
	array( '🔎', 'Teste de alternador grátis' ),
	array( '♻️', 'Desconto no casco velho' ),
);
?>
<section class="awr-trustbar" aria-label="Vantagens AWR Baterias">
	<div class="awr-container">
		<ul>
			<?php foreach ( $awr_items as $it ) : ?>
				<li><span aria-hidden="true"><?php echo esc_html( $it[0] ); ?></span><span><?php echo esc_html( $it[1] ); ?></span></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
