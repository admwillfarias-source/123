<?php
/** Lista do que acompanha o atendimento na cidade. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_nome = (string) ( $args['cidade_nome'] ?? '' );
$awr_itens = array( 'Bateria nova instalada onde o carro está', 'Teste de bateria e do alternador', 'Retirada da bateria usada (casco)', 'Nota fiscal e garantia de fábrica', 'Pagamento na entrega: Pix, cartão ou dinheiro', 'Opções AGM e EFB para Start-Stop' );
?>
<section class="awr-app-section"><div class="awr-hub-body">
 <h2>O que você recebe<?php echo $awr_nome ? ' em ' . esc_html( $awr_nome ) : ''; ?></h2>
 <ul style="display:grid;gap:6px;grid-template-columns:repeat(auto-fit,minmax(min(260px,100%),1fr));list-style:none;padding:0">
  <?php foreach ( $awr_itens as $i ) : ?><li>✓ <?php echo esc_html( $i ); ?></li><?php endforeach; ?>
 </ul>
</div></section>
