<?php
/**
 * Grade de produtos reais do WooCommerce (nome, foto, preço e estoque).
 * Args: produtos (de awr_shop_hydrate), titulo, lead, vazio, attr (atributos extras por item).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$a = wp_parse_args( $args ?? array(), array( 'produtos' => array(), 'titulo' => '', 'lead' => '', 'vazio' => '', 'filtro' => false, 'ativo' => 0 ) );
$awr_lista = (array) $a['produtos'];
?>
<?php if ( $a['titulo'] ) : ?><h2 class="awr-app-section__title"><?php echo esc_html( $a['titulo'] ); ?></h2><?php endif; ?>
<?php if ( $a['lead'] ) : ?><p><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
<ul class="awr-woo-grid" data-awr-woo-grid>
	<?php foreach ( $awr_lista as $awr_w ) :
		$awr_w_ah   = (int) ( $awr_w['amperagem'] ?? 0 );
		$awr_hidden = $a['filtro'] && $awr_w_ah !== (int) $a['ativo'];
		$awr_w_wa   = awr_wa( 'Olá! Quero a bateria ' . $awr_w['name'] . ( $awr_w['sku'] ? ' (' . $awr_w['sku'] . ')' : '' ) . '. Pode confirmar disponibilidade e entrega?' );
		?>
		<li class="awr-woo-card" data-awr-woo-item data-ah="<?php echo $awr_w_ah; ?>"<?php echo $awr_hidden ? ' hidden' : ''; ?>>
			<a class="awr-woo-card__media" href="<?php echo esc_url( $awr_w['permalink'] ); ?>">
				<?php if ( $awr_w['image'] ) : ?><img src="<?php echo esc_url( $awr_w['image'] ); ?>" alt="<?php echo esc_attr( $awr_w['name'] ); ?>" width="240" height="240" loading="lazy" decoding="async"><?php else : ?><span aria-hidden="true">🔋</span><?php endif; ?>
			</a>
			<p class="awr-woo-card__meta"><?php echo esc_html( trim( ( $awr_w_ah ? $awr_w_ah . 'Ah' : '' ) . ( $awr_w['brand'] ? ' · ' . $awr_w['brand'] : '' ), ' ·' ) ); ?> · <?php echo $awr_w['in_stock'] ? 'Em estoque' : 'Sob encomenda'; ?></p>
			<h3 class="awr-woo-card__nome"><a href="<?php echo esc_url( $awr_w['permalink'] ); ?>"><?php echo esc_html( $awr_w['name'] ); ?></a></h3>
			<?php $awr_garantia = awr_garantia_label( $awr_w['sku'], $awr_w['name'] ); if ( $awr_garantia ) : ?><p class="awr-woo-card__meta"><?php echo esc_html( $awr_garantia ); ?></p><?php endif; ?>
			<p class="awr-woo-card__preco"><?php echo $awr_w['sob_consulta'] ? 'Preço sob consulta' : esc_html( awr_brl( (float) $awr_w['price'] ) ) . ' <small>à vista, com troca</small>'; ?></p>
			<div class="awr-woo-card__acoes">
				<a class="awr-btn awr-btn--gold" href="<?php echo esc_url( $awr_w['permalink'] ); ?>">Comprar</a>
				<a class="awr-btn awr-btn--wa-outline" target="_top" rel="noopener" href="<?php echo esc_url( $awr_w_wa ); ?>">WhatsApp</a>
			</div>
		</li>
	<?php endforeach; ?>
</ul>
<p class="awr-woo-vazio" data-awr-woo-vazio<?php echo ( $a['filtro'] ? (bool) array_filter( $awr_lista, function ( $x ) use ( $a ) { return (int) ( $x['amperagem'] ?? 0 ) === (int) $a['ativo']; } ) : (bool) $awr_lista ) ? ' hidden' : ''; ?>><?php echo esc_html( $a['vazio'] ? $a['vazio'] : 'Sem estoque no momento — confirme no WhatsApp.' ); ?></p>
