<?php
/** Pós-venda: avaliação e contato. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_c = awr_company();
?>
<section class="awr-app-section"><div class="awr-hub-body" style="text-align:center">
 <h2>Depois da instalação, conte como foi</h2>
 <p>Sua avaliação ajuda outros motoristas a escolher com segurança.</p>
 <p><a class="awr-btn awr-btn--primary" target="_blank" rel="noopener" href="<?php echo esc_url( $awr_c['reviews_url'] ); ?>">Avaliar no Google</a> <a class="awr-btn awr-btn--wa" target="_blank" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Recebi minha bateria e quero falar com o pós-venda.', false ) ); ?>">Falar com o pós-venda</a></p>
</div></section>
