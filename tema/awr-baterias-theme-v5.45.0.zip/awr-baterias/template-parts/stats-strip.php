<?php
/**
 * Faixa de números (navy) — paridade com StatsStrip.tsx.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_tempo = isset( $args['tempo'] ) ? (string) $args['tempo'] : '35 min';
$awr_stats = array(
	array( '+10.000', 'Baterias instaladas', 'Porto Alegre e Grande POA' ),
	array( '4,9 ★', 'Avaliação no Google', '1.935+ avaliações reais' ),
	array( $awr_tempo, preg_match( '/min$/', $awr_tempo ) ? 'Tempo médio de entrega' : 'Prazo de entrega', 'Da confirmação à instalação' ),
	array( 'Até 24 meses', 'Garantia de fábrica', 'Registrada em nota fiscal' ),
);
?>
<section class="awr-stats-band" aria-labelledby="awr-stats-title">
	<div class="awr-container">
		<div class="awr-sec__head">
			<span class="awr-stats-band__pill">NÚMEROS QUE COMPROVAM</span>
			<h2 class="awr-section-title" id="awr-stats-title">A maior operação de <span>bateria a domicílio</span> do RS</h2>
			<p>Estrutura própria, equipe certificada e estoque das principais marcas.</p>
		</div>
		<ul>
			<?php foreach ( $awr_stats as $s ) : ?>
				<li>
					<b><?php echo esc_html( $s[0] ); ?></b>
					<strong><?php echo esc_html( $s[1] ); ?></strong>
					<small><?php echo esc_html( $s[2] ); ?></small>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
