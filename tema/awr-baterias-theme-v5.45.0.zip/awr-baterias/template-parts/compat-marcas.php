<?php
/**
 * Compatibilidades agrupadas por marca, em blocos recolhíveis.
 * Todo o texto permanece no HTML (indexável); só a apresentação é colapsada.
 *
 * Uso: awr_part( 'compat-marcas', array( 'grupos' => awr_product_compat_grouped( $sku ) ) );
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$args   = wp_parse_args( $args ?? array(), array( 'grupos' => array(), 'aberto' => 2 ) );
$grupos = (array) $args['grupos'];
if ( ! $grupos ) { return; }
$i = 0;
?>
<div class="awr-compat__marcas">
	<?php foreach ( $grupos as $marca => $modelos ) : $i++; ?>
		<details class="awr-compat__marca"<?php echo $i <= (int) $args['aberto'] ? ' open' : ''; ?>>
			<summary><span class="awr-compat__nome"><?php echo esc_html( $marca ); ?></span>
				<span class="awr-compat__qtd"><?php echo (int) count( $modelos ); ?> modelo<?php echo count( $modelos ) > 1 ? 's' : ''; ?></span>
			</summary>
			<ul class="awr-compat__lista">
				<?php foreach ( $modelos as $m ) : $anos = awr_compat_anos( $m['de'], $m['ate'] ); ?>
					<li>
						<?php if ( ! empty( $m['url'] ) ) : ?>
							<a href="<?php echo esc_url( $m['url'] ); ?>"><?php echo esc_html( $m['modelo'] ); ?></a>
						<?php else : ?>
							<?php echo esc_html( $m['modelo'] ); ?>
						<?php endif; ?>
						<?php if ( $anos ) : ?><span class="awr-compat__anos"><?php echo esc_html( $anos ); ?></span><?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</details>
	<?php endforeach; ?>
</div>
