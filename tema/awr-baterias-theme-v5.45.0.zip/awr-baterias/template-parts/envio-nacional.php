<?php
/** Estacionárias: envio RS/SC/PR/SP. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<section class="awr-app-section"><div class="awr-hub-body">
 <h2>Enviamos estacionárias para RS, SC, PR e SP</h2>
 <p>Na região metropolitana de Porto Alegre, entrega e instalação no local. Nas demais cidades dos quatro estados, envio com frete calculado pelo CEP no pedido.</p>
 <p><a class="awr-btn awr-btn--wa" target="_blank" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Quero orçamento de bateria estacionária com envio para minha cidade.' ) ); ?>">Pedir orçamento com frete</a></p>
</div></section>
