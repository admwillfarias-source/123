<?php
/** AWR Frotas no B2B. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_c = awr_company();
?>
<section class="awr-app-section awr-frotas" data-wa="<?php echo esc_attr( $awr_c['whatsapp_number'] ); ?>"><div class="awr-hub-body" style="border:2px solid #1d4ed8;border-radius:16px;padding:20px;background:#fff">
 <h2>AWR Frotas</h2>
 <p>Para quem não pode ficar parado: aplicativo, frotas, transportadoras e locadoras. Troca no local, teste do sistema elétrico e atendimento prioritário.</p>
 <form style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(min(200px,100%),1fr))">
  <label>Perfil<select name="t" style="width:100%;padding:10px"><option>Motorista de aplicativo (Uber/99)</option><option>Frota de empresa</option><option>Transportadora</option><option>Locadora</option><option>Táxi</option></select></label>
  <label>Nº de veículos<input name="q" type="number" min="1" value="1" style="width:100%;padding:10px"></label>
  <label>Empresa (opcional)<input name="e" maxlength="80" style="width:100%;padding:10px"></label>
  <button class="awr-btn awr-btn--wa" type="submit">Pedir orçamento de frota</button>
 </form>
</div></section>
<script>
document.querySelector('.awr-frotas form').addEventListener('submit',function(ev){ev.preventDefault();var f=new FormData(this),e=f.get('e'),w=this.closest('.awr-frotas').dataset.wa;window.open('https://wa.me/'+w+'?text='+encodeURIComponent('Olá! Quero orçamento AWR Frotas. Perfil: '+f.get('t')+'. Veículos: '+f.get('q')+'.'+(e?' Empresa: '+e+'.':'')),'_blank','noopener')});
</script>
