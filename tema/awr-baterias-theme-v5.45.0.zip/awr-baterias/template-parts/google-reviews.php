<?php
/**
 * Selo de avaliações do Google — paridade com GoogleReviewsBadge.tsx.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_g       = awr_google();
$awr_rating  = isset( $awr_g['rating'] ) ? $awr_g['rating'] : array();
$awr_reviews = isset( $awr_g['reviews'] ) ? array_slice( (array) $awr_g['reviews'], 0, 3 ) : array();
$awr_avg     = number_format_i18n( (float) ( $awr_rating['averageRating'] ?? 4.9 ), 1 );
$awr_total   = number_format_i18n( (int) ( $awr_rating['totalReviews'] ?? 1935 ) );
$awr_url     = 'https://www.google.com/maps/search/?api=1&query=AWR+Baterias+Porto+Alegre';
?>
<section class="awr-gbadge" aria-labelledby="awr-gbadge-title">
	<div class="awr-container">
		<h2 class="awr-section-title" id="awr-gbadge-title" style="text-align:center">O que os clientes dizem</h2>
		<div class="awr-gbadge__box">
			<span class="awr-gbadge__score"><?php echo esc_html( $awr_avg ); ?></span>
			<span>
				<span class="awr-gbadge__stars" aria-hidden="true">★★★★★</span>
				<span class="awr-gbadge__meta"><br><?php echo esc_html( $awr_total ); ?>+ avaliações no Google</span>
			</span>
			<a class="awr-btn awr-btn--outline" target="_blank" rel="noopener nofollow" href="<?php echo esc_url( $awr_url ); ?>">Ver avaliações</a>
		</div>

		<?php if ( $awr_reviews ) : ?>
			<ul class="awr-gbadge__list">
				<?php foreach ( $awr_reviews as $r ) : ?>
					<li>
						<span class="awr-gbadge__stars" aria-hidden="true">★★★★★</span>
						<p>“<?php echo esc_html( $r['text'] ); ?>”</p>
						<b><?php echo esc_html( $r['author'] ); ?></b>
						<span class="awr-gbadge__meta"> · <?php echo esc_html( $r['date'] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</section>
