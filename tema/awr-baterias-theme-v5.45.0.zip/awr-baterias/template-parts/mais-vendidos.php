<?php
/** Prateleira de produtos oficiais. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$segmento = (string) ( $args['segmento'] ?? '' );
?>
<section class="awr-app-section" data-mais-vendidos="<?php echo esc_attr( $segmento ); ?>"><div class="awr-hub-body">
 <?php awr_part( 'produtos-woo', array( 'produtos' => awr_mais_vendidos( $segmento ), 'titulo' => 'Mais vendidos', 'vazio' => 'Produtos indisponíveis para consulta no momento — confirme no WhatsApp.' ) ); ?>
</div></section>