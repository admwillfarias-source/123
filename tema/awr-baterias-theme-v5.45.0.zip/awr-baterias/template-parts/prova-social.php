<?php
/**
 * Provas sociais + selos de confiança.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_c  = awr_company();
$google = awr_google();
$awr_tempo = isset( $args['tempo'] ) ? (string) $args['tempo'] : '35 min';
$awr_tv = preg_match( '/^(\d+) min$/', $awr_tempo, $mm ) ? array( 'v' => $mm[1], 'l' => 'min para entrega' ) : array( 'v' => $awr_tempo, 'l' => 'entrega' );
$stats  = array(
	$awr_tv,
	array( 'v' => '17', 'l' => 'anos de mercado' ),
	array( 'v' => 'Até 24', 'l' => 'meses de garantia' ),
	array( 'v' => $awr_c['reviews'] . '+', 'l' => 'avaliações no Google' ),
);
?>
<section class="awr-trust">
	<div class="awr-container">
		<ul class="awr-stats">
			<?php foreach ( $stats as $s ) : ?>
				<li class="awr-stat"><strong><?php echo esc_html( $s['v'] ); ?></strong><span><?php echo esc_html( $s['l'] ); ?></span></li>
			<?php endforeach; ?>
		</ul>

		<div class="awr-reviews">
			<p class="awr-reviews__head">
				<strong><?php echo esc_html( $awr_c['rating'] ); ?>★</strong> no Google ·
				<a href="<?php echo esc_url( $awr_c['reviews_url'] ); ?>" target="_blank" rel="noopener nofollow">ver avaliações</a>
			</p>
			<ul class="awr-reviews__list">
				<?php foreach ( array_slice( (array) ( $google['reviews'] ?? array() ), 0, 3 ) as $r ) : ?>
					<li class="awr-review">
						<p class="awr-review__text">“<?php echo esc_html( $r['text'] ?? ( $r['texto'] ?? '' ) ); ?>”</p>
						<p class="awr-review__author"><?php echo esc_html( $r['author'] ?? ( $r['autor'] ?? 'Cliente AWR' ) ); ?></p>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
</section>
