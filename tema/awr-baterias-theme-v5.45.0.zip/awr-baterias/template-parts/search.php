<?php
/**
 * Widget de busca — bloco reutilizado em todas as páginas.
 * O JS (assets/js/awr-search.js, sob demanda) faz autocomplete, ano e resultados via REST.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$args      = wp_parse_args( $args ?? array(), array( 'autofocus' => false, 'inline' => true, 'titulo' => '', 'compact' => false ) );
$awr_c     = awr_company();
if ( function_exists( 'awr_search_rendered' ) ) {
	// Uma única busca por página (a faixa abaixo do hero). As demais chamadas
	// viram um atalho para ela, evitando IDs duplicados no documento.
	if ( awr_search_rendered() ) {
		echo '<p class="awr-search__anchor"><a class="awr-btn awr-btn--gold awr-btn--xl" href="#awr-search">Buscar a bateria do meu veículo</a></p>';
		return;
	}
	awr_search_rendered( true );
}
?>
<div class="awr-searchtabs" data-awr-tabs>
	<?php if ( ! $args['compact'] ) : ?>
	<div class="awr-searchtabs__bar" role="tablist" aria-label="Como encontrar sua bateria">
		<button type="button" class="awr-searchtabs__btn is-on" role="tab" aria-selected="true" data-awr-tab="busca">
			<b>Buscar por veículo</b><span>Sei o modelo e o ano</span>
		</button>
		<button type="button" class="awr-searchtabs__btn" role="tab" aria-selected="false" data-awr-tab="diagnostico">
			<b>⚡ Diagnóstico por IA</b><span>Dúvida sobre o sintoma? Descubra o modelo certo</span>
		</button>
	</div>
	<?php endif; ?>
	<div data-awr-panel="busca">
<section class="awr-search" id="awr-search" data-awr-search data-inline="<?php echo $args['inline'] ? '1' : '0'; ?>">

	<?php if ( $args['titulo'] ) : ?>
		<h2 class="awr-search__title"><?php echo esc_html( $args['titulo'] ); ?></h2>
	<?php endif; ?>

	<form class="awr-search__form" role="search" autocomplete="off" data-awr-form>
		<label class="awr-search__label" for="awr-q">Modelo do veículo</label>
		<div class="awr-search__row">
			<span class="awr-search__icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg></span>
			<input
				id="awr-q"
				class="awr-search__input"
				type="text"
				name="q"
				inputmode="search"
				autocapitalize="off"
				autocorrect="off"
				spellcheck="false"
				placeholder="<?php echo ( isset( $_SERVER['REQUEST_URI'] ) && false !== strpos( (string) $_SERVER['REQUEST_URI'], 'moto' ) ) ? 'Ex.: CG 150 2020' : 'Ex.: Onix 2018'; ?>"
				aria-describedby="awr-q-help"
				<?php echo $args['autofocus'] ? 'autofocus' : ''; ?>
				data-awr-input>
			<button class="awr-btn awr-btn--gold awr-search__submit" type="submit">Buscar bateria</button>
		</div>
		<p class="awr-search__help" id="awr-q-help"<?php echo $args['compact'] ? ' hidden' : ''; ?>>Digite o modelo e o ano — a busca é automática quando o ano é reconhecido.</p>
		<ul class="awr-suggestions" role="listbox" hidden data-awr-suggestions></ul>
		<div class="awr-years" hidden data-awr-years>
			<span class="awr-years__label">Selecione o ano:</span>
			<div class="awr-years__grid" data-awr-years-grid></div>
		</div>
	</form>

	<div class="awr-search__populares" data-awr-populares>
		<?php
		$awr_uri_pop = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore
		$awr_e_moto  = false !== strpos( $awr_uri_pop, 'moto' );
		?>
		<span class="awr-search__populares-label"><?php echo $awr_e_moto ? 'Motos mais buscadas:' : 'Carros mais buscados:'; ?></span>
		<?php foreach ( ( $awr_e_moto ? array( 'CG 150', 'Z900', 'Tiger 800' ) : array( 'Onix', 'Creta', 'Sandero', 'HB20' ) ) as $awr_pop ) : ?>
			<button type="button" class="awr-chip awr-chip--pop" data-awr-pop="<?php echo esc_attr( $awr_pop ); ?>"><?php echo esc_html( $awr_pop ); ?></button>
		<?php endforeach; ?>
	</div>

	<div class="awr-results" data-awr-results aria-live="polite"></div>
</section>
	</div>
	<?php if ( ! $args['compact'] ) : ?>
	<div class="awr-search awr-search--diag" data-awr-panel="diagnostico" hidden>
		<p class="awr-search__label">Diagnóstico grátis em 3 passos — sem sair do site</p>
		<div data-awr-diag></div>
	</div>
	<?php endif; ?>
</div>

