<?php
/**
 * Card "Como funciona" exibido ao lado do hero (substitui a imagem).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$steps = array(
	array( 'Selecione o Carro', 'Modelo e ano' ),
	array( 'Finalize o Pedido', 'Site ou WhatsApp' ),
	array( 'Instalação no local', 'Em até 35 min' ),
	array( 'Suporte da central', 'Ligue quando quiser' ),
);
?>
<div class="awr-hcard" aria-label="Como funciona">
	<p class="awr-hcard__title">Como funciona</p>
	<ol class="awr-hcard__list">
		<?php foreach ( $steps as $i => $s ) : ?>
			<li class="awr-hcard__item">
				<span class="awr-hcard__n"><?php echo esc_html( $i + 1 ); ?></span>
				<span>
					<strong><?php echo esc_html( $s[0] ); ?></strong>
					<em><?php echo esc_html( $s[1] ); ?></em>
				</span>
				<span class="awr-hcard__bar" style="--awr-p: <?php echo esc_attr( ( $i + 1 ) * 25 ); ?>%"></span>
			</li>
		<?php endforeach; ?>
	</ol>
</div>
