<?php
/** AWR Engenharia no hub estacionário. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_itens = array(
	array( 'Dimensionamento', 'Cálculo de Ah, tensão e autonomia para nobreak, solar, CFTV, alarme e telecom.' ),
	array( 'Banco de baterias', 'Montagem em série e paralelo com modelos da mesma linha e data.' ),
	array( 'Atendimento a empresas', 'Orçamento para condomínios, provedores, indústria e integradores.' ),
);
?>
<section class="awr-app-section"><div class="awr-hub-body">
 <p style="font-size:12px;font-weight:700;text-transform:uppercase;color:#1d4ed8;margin:0">AWR Energia</p>
 <h2>AWR Engenharia: a bateria certa para seu sistema</h2>
 <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(min(220px,100%),1fr))">
  <?php foreach ( $awr_itens as $i ) : ?><div style="background:#f1f5f9;border-radius:10px;padding:14px"><h3><?php echo esc_html( $i[0] ); ?></h3><p><?php echo esc_html( $i[1] ); ?></p></div><?php endforeach; ?>
 </div>
 <p><a class="awr-btn awr-btn--primary" href="#calculadora">Usar a calculadora</a> <a class="awr-btn" href="<?php echo esc_url( home_url( '/solucoes-b2b/' ) ); ?>">Soluções para empresas</a></p>
</div></section>
