<?php
/** Menu para cidades atendidas por transportadora. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_nome = (string) ( $args['cidade_nome'] ?? '' );
?>
<section class="awr-app-section"><div class="awr-hub-body" style="border:2px solid #1d4ed8;border-radius:16px;padding:20px;background:#fff">
 <p style="font-size:12px;font-weight:700;text-transform:uppercase;color:#1d4ed8;margin:0">AWR RS · envio para <?php echo esc_html( $awr_nome ); ?></p>
 <h2>Escolha sua bateria ou peça ajuda</h2>
 <p>Envio por transportadora; prazo e frete calculados pelo CEP no pedido.</p>
 <div style="display:grid;gap:8px;grid-template-columns:repeat(auto-fit,minmax(min(180px,100%),1fr))">
  <a class="awr-btn awr-btn--primary" href="<?php echo esc_url( home_url( '/buscar/' ) ); ?>">Escolha sua bateria</a>
  <a class="awr-btn awr-btn--wa" target="_blank" rel="noopener" href="<?php echo esc_url( awr_wa( "Olá! Estou em {$awr_nome} e preciso de ajuda para escolher a bateria." ) ); ?>">Precisa de ajuda?</a>
  <a class="awr-btn" target="_blank" rel="noopener" href="<?php echo esc_url( awr_wa( "Olá! Vou mandar a foto da etiqueta da minha bateria (estou em {$awr_nome}) para vocês indicarem o modelo certo e o preço.", false ) ); ?>">📷 Mande uma foto da bateria</a>
 </div>
</div></section>
