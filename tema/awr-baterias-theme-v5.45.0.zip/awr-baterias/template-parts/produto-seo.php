<?php
/**
 * Blocos de SEO das páginas de produto/SKU: ficha técnica e cobertura regional.
 * Espelha as seções do app em src/routes/bateria.$sku.tsx.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$a     = isset( $args ) && is_array( $args ) ? $args : array();
$sku   = strtoupper( (string) ( $a['sku'] ?? '' ) );
$marca = (string) ( $a['marca'] ?? '' );
$ah    = (int) ( $a['ah'] ?? 0 );
if ( ! $sku ) { return; }

$info_gtin = function_exists( 'awr_gtin_info' ) ? awr_gtin_info( $sku ) : null;
if ( ! $ah && $info_gtin ) { $ah = (int) $info_gtin['ah']; }

// v4.2.0 — a marca é sempre a do fabricante. A AWR é a revendedora e nunca
// pode aparecer aqui: marca de revendedor reprova o item no Merchant Center.
if ( '' === trim( $marca ) || 0 === stripos( trim( $marca ), 'AWR' ) ) {
	$marca = function_exists( 'awr_resolve_brand' ) ? (string) awr_resolve_brand( $sku ) : '';
}

$linhas = array();
if ( $marca && 0 !== stripos( $marca, 'AWR' ) ) { $linhas['Marca'] = $marca; }
$linhas['Modelo / SKU'] = $sku;
$linhas['Tensão']       = '12V';
if ( $ah ) { $linhas['Capacidade'] = $ah . 'Ah'; }
if ( function_exists( 'awr_bateria_tecnologia' ) ) {
	$tec = awr_bateria_tecnologia( $sku );
	if ( $tec ) { $linhas['Tecnologia'] = $tec; }
	$pol = awr_bateria_polaridade( $sku );
	if ( $pol ) { $linhas['Polaridade'] = $pol; }
}
$awr_esp = function_exists( 'awr_espec_bateria' ) ? awr_espec_bateria( $sku ) : null;
if ( $awr_esp && ! empty( $awr_esp['cca'] ) ) { $linhas['CCA (partida a frio)'] = (int) $awr_esp['cca'] . ' A'; }
if ( $awr_esp && ! empty( $awr_esp['peso'] ) ) { $linhas['Peso'] = str_replace( '.', ',', (string) (float) $awr_esp['peso'] ) . ' kg'; }
if ( $info_gtin ) { $linhas['Código de barras (GTIN)'] = $info_gtin['gtin']; }
$garantia = function_exists( 'awr_garantia_label' ) ? awr_garantia_label( $sku ) : '';
$linhas['Garantia'] = $garantia ? $garantia . ' de fábrica, com nota fiscal' : 'Garantia de fábrica, com nota fiscal';

$cidades = function_exists( 'awr_cidades_produto' ) ? awr_cidades_produto() : array();
?>
<section class="awr-block awr-produto-specs">
	<h2 class="awr-section-title">Especificações técnicas</h2>
	<table class="awr-spec-table">
		<tbody>
		<?php foreach ( $linhas as $k => $v ) : ?>
			<tr><th scope="row"><?php echo esc_html( $k ); ?></th><td><?php echo esc_html( $v ); ?></td></tr>
		<?php endforeach; ?>
		</tbody>
	</table>
</section>

<?php if ( $cidades ) : ?>
<section class="awr-block awr-produto-cobertura">
	<h2 class="awr-section-title">Onde entregamos e instalamos</h2>
	<p class="awr-lead">Entrega e instalação no local com frota própria. Prazo por cidade:</p>
	<ul class="awr-chips">
		<?php foreach ( $cidades as $c ) : $awr_cd = function_exists( 'awr_cidade_by_slug' ) ? awr_cidade_by_slug( $c['slug'] ) : null; ?>
			<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-em/' . $c['slug'] . '/' ) ); ?>"><?php echo esc_html( $c['nome'] ); ?><?php if ( $awr_cd && function_exists( 'awr_city_delivery_badge' ) ) : ?> · <?php echo esc_html( awr_city_delivery_badge( $awr_cd ) ); ?><?php endif; ?></a></li>
		<?php endforeach; ?>
	</ul>
	<p class="awr-lead"><a href="<?php echo esc_url( home_url( '/baterias-em/caxias-do-sul/' ) ); ?>">Caxias do Sul</a> e demais cidades do RS: envio por transportadora em 1 a 5 dias úteis. Em toda instalação o teste de alternador é grátis.</p>
</section>
<?php endif; ?>
<section class="awr-block awr-produto-como">
	<h2 class="awr-section-title">Como funciona a entrega e a instalação</h2>
	<ol class="awr-lead">
		<li>Confirmamos a bateria certa pelo seu veículo, com a amperagem e a tecnologia indicadas pela montadora.</li>
		<li>O técnico leva a bateria, testa o alternador e instala no local.</li>
		<li>Você escolhe pagar com a bateria usada na troca ou sem ela, com nota fiscal e garantia de fábrica.</li>
	</ol>
</section>
