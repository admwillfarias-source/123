<?php
/**
 * Corpo compartilhado das páginas de categoria (aplicações, modelos,
 * benefícios, FAQ e outras categorias).
 *
 * Uso: awr_part( 'segmento-corpo', array( 'seg' => $seg, 'cidade' => 'canoas' ) );
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$args      = wp_parse_args( $args ?? array(), array( 'seg' => null, 'cidade' => '' ) );
$awr_seg   = (array) $args['seg'];
if ( ! $awr_seg ) { return; }
$awr_hub   = (array) $awr_seg['hub'];
$awr_cid   = (string) $args['cidade'];
$awr_outros = array_values( array_filter( awr_segmentos(), function ( $x ) use ( $awr_seg ) { return $x['key'] !== $awr_seg['key']; } ) );
?>
<?php if ( 'estacionaria' === $awr_seg['key'] ) { awr_part( 'awr-engenharia' ); awr_part( 'calculadora-banco' ); awr_part( 'envio-nacional' ); awr_part( 'estacionaria-blocos', array( 'cidade' => $awr_cid ) ); } ?>
<?php
if ( 'caminhao' === $awr_seg['key'] ) {
	$awr_ahs_pesadas = array( 100, 150, 180, 200, 210, 220, 225, 230 );
	$awr_pesadas     = array();
	foreach ( $awr_ahs_pesadas as $awr_ah_x ) {
		foreach ( awr_shop_products_by_amperage( $awr_ah_x, 12 ) as $awr_px ) { $awr_pesadas[ $awr_px['id'] ] = $awr_px; }
	}
	$awr_pesadas = array_values( $awr_pesadas );
	$awr_ah_ativo = isset( $_GET['ah'] ) ? (int) $_GET['ah'] : 150; // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! in_array( $awr_ah_ativo, $awr_ahs_pesadas, true ) ) { $awr_ah_ativo = 150; }
	?>
<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Encontre a bateria do veículo pesado</h2>
		<p>Escolha a amperagem e veja as baterias da nossa loja, com preço e estoque reais. No sistema 24V são duas baterias: confirme o par no WhatsApp.</p>
		<form class="awr-moto-form" data-awr-pesado-form method="get" autocomplete="off">
			<label class="awr-moto-form__field"><span>Veículo</span><select data-awr-pesado-tipo autocomplete="off"><option>Caminhão</option><option>Carreta</option><option>Ônibus</option><option>Micro-ônibus</option><option>Máquina agrícola</option></select></label>
			<label class="awr-moto-form__field"><span>Sistema</span><select data-awr-pesado-sistema autocomplete="off"><option>24V (par)</option><option>12V (uma bateria)</option></select></label>
			<label class="awr-moto-form__field"><span>Amperagem</span><select name="ah" data-awr-pesado-ah autocomplete="off" onchange="if(!window.awrPesado)this.form.submit()"><?php foreach ( $awr_ahs_pesadas as $awr_ah ) : ?><option value="<?php echo (int) $awr_ah; ?>" <?php selected( $awr_ah_ativo, $awr_ah ); ?>><?php echo (int) $awr_ah; ?>Ah</option><?php endforeach; ?></select></label>
		</form>
		<?php awr_part( 'produtos-woo', array( 'produtos' => $awr_pesadas, 'filtro' => true, 'ativo' => $awr_ah_ativo, 'vazio' => 'Sem estoque nesta amperagem — confirme no WhatsApp.' ) ); ?>
		<a class="awr-btn awr-btn--gold" data-awr-pesado-wa target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Preciso de bateria para caminhão. Sistema 24V (par), ' . $awr_ah_ativo . 'Ah. Pode confirmar aplicação, disponibilidade e preço do par?' ) ); ?>" data-wa-base="<?php echo esc_attr( awr_wa( '' ) ); ?>">Confirmar conjunto e disponibilidade</a>
		<p style="margin-top:.75rem;font-size:.8rem;opacity:.75;">A aplicação final depende do fabricante e do modelo. Em 24V, confirme o valor do par antes do pedido.</p>
		<script>
		(function(){window.awrPesado=1;var f=document.querySelector('[data-awr-pesado-form]');if(!f)return;var ah=f.querySelector('[data-awr-pesado-ah]'),tipo=f.querySelector('[data-awr-pesado-tipo]'),sistema=f.querySelector('[data-awr-pesado-sistema]'),itens=document.querySelectorAll('[data-awr-woo-item]'),vazio=document.querySelector('[data-awr-woo-vazio]'),wa=document.querySelector('[data-awr-pesado-wa]');function atualizar(){var n=0;itens.forEach(function(item){var on=item.getAttribute('data-ah')===ah.value;item.hidden=!on;if(on)n++;});if(vazio)vazio.hidden=n>0;var destino=sistema.value.indexOf('24V')===0?'par':'modelo';var msg='Olá! Preciso de bateria para '+tipo.value.toLowerCase()+'. Sistema '+sistema.value+', '+ah.value+'Ah. Pode confirmar aplicação, disponibilidade e preço do '+destino+'?';var base=(wa.getAttribute('data-wa-base')||'').split('?')[0];if(base)wa.href=base+'?text='+encodeURIComponent(msg);}ah.addEventListener('change',atualizar);tipo.addEventListener('change',atualizar);sistema.addEventListener('change',atualizar);atualizar();})();
		</script>
	</div>
</section>
<?php } ?>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Onde se aplica</h2>
		<ul class="awr-app-benefits">
			<?php foreach ( (array) $awr_hub['aplicacoes'] as $item ) : ?>
				<li><?php echo esc_html( $item ); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<?php
$awr_marcas_seg = array();
foreach ( (array) ( $awr_hub['marcas'] ?? array() ) as $awr_mslug ) {
	$awr_mo = awr_marca_by_slug( $awr_mslug );
	if ( $awr_mo ) { $awr_marcas_seg[] = $awr_mo; }
}
if ( $awr_marcas_seg ) :
	?>
<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Marcas que trabalhamos</h2>
		<ul class="awr-app-reco">
			<?php foreach ( $awr_marcas_seg as $awr_mo ) : ?>
				<li>
					<h3 class="awr-app-reco__modelo">
						<a href="<?php echo esc_url( home_url( '/marca/' . $awr_mo['slug'] . '/' ) ); ?>"><?php echo esc_html( $awr_mo['nomeCompleto'] ?? $awr_mo['nome'] ); ?></a>
					</h3>
					<p class="awr-app-reco__ideal"><?php echo esc_html( $awr_mo['tagline'] ?? '' ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
<?php endif; ?>

<?php if ( 'estacionaria' !== $awr_seg['key'] ) : ?>
<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Modelos e amperagens</h2>
		<ul class="awr-app-reco">
			<?php foreach ( (array) $awr_hub['modelos'] as $m ) : ?>
				<li>
					<p class="awr-app-reco__brand"><?php echo esc_html( $m['especificacao'] ); ?></p>
					<h3 class="awr-app-reco__modelo"><?php echo esc_html( $m['modelo'] ); ?></h3>
					<p class="awr-app-reco__ideal"><?php echo esc_html( $m['uso'] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
		<p style="margin-top:.75rem;font-size:.8rem;opacity:.75;">Disponibilidade e preço variam por modelo e marca. Confirme no WhatsApp antes de fechar o pedido.</p>
	</div>
</section>
<?php endif; ?>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Por que comprar na AWR</h2>
		<ul class="awr-app-reco">
			<?php foreach ( (array) $awr_hub['beneficios'] as $b ) : ?>
				<li>
					<h3 class="awr-app-reco__modelo"><?php echo esc_html( $b['titulo'] ); ?></h3>
					<p class="awr-app-reco__ideal"><?php echo esc_html( $b['descricao'] ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<?php awr_part( 'google-reviews' ); ?>

<section class="awr-app-section">
	<div class="awr-hub-body awr-hub-body--narrow">
		<h2 class="awr-app-section__title">Perguntas frequentes</h2>
		<div class="awr-app-faq">
			<?php foreach ( (array) $awr_hub['faq'] as $f ) : ?>
				<details>
					<summary><?php echo esc_html( $f['pergunta'] ); ?></summary>
					<p><?php echo esc_html( $f['resposta'] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php
if ( function_exists( 'awr_jsonld' ) ) {
	$awr_faq_ld = array();
	foreach ( (array) $awr_hub['faq'] as $f ) {
		$awr_faq_ld[] = array(
			'@type'          => 'Question',
			'name'           => $f['pergunta'],
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f['resposta'] ),
		);
	}
	if ( $awr_faq_ld ) {
		awr_jsonld( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $awr_faq_ld ) );
	}
}
?>

<section class="awr-app-section awr-app-section--muted">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Outros tipos de bateria</h2>
		<ul class="awr-app-outras">
			<?php foreach ( $awr_outros as $o ) : ?>
				<li>
					<a href="<?php echo esc_url( awr_segmento_url( $o, $awr_cid ) ); ?>">
						<div>
							<h3><?php echo esc_html( $o['nome'] ); ?></h3>
							<p><?php echo esc_html( $o['eyebrow'] ); ?></p>
						</div>
						<span class="awr-app-outras__arrow" aria-hidden="true">→</span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
		<p style="margin-top:1rem;">Precisa de bateria automotiva? <a href="<?php echo esc_url( home_url( '/buscar/' ) ); ?>">Busque pelo modelo do seu carro</a>. Para fornecimento com nota em CNPJ, veja as <a href="<?php echo esc_url( home_url( '/solucoes-b2b/' ) ); ?>">soluções B2B da AWR</a>.</p>
	</div>
</section>
