<?php
/**
 * Hero das páginas de categoria (paridade visual com o app):
 * breadcrumb, eyebrow dourado, H1, lead, CTAs duplos e selos de confiança.
 *
 * Uso: awr_part( 'segmento-hero', array( 'seg' => $seg, 'h1' => '...', 'trilha' => array(), 'atual' => '...', 'wa' => $wa ) );
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$args = wp_parse_args( $args ?? array(), array(
	'seg'    => null,
	'h1'     => '',
	'lead'   => '',
	'trilha' => array(),
	'atual'  => '',
	'wa'     => '',
	'local'  => '',
) );

$awr_seg = (array) $args['seg'];
if ( ! $awr_seg ) { return; }
$awr_c   = awr_contact();
$awr_wa  = $args['wa'] ? $args['wa'] : awr_wa( $awr_seg['wa'] );
$awr_h1  = $args['h1'] ? $args['h1'] : $awr_seg['hub']['h1'];
$awr_led = $args['lead'] ? $args['lead'] : $awr_seg['hub']['tagline'];
$awr_est  = 'estacionaria' === $awr_seg['key'];
$awr_modo = isset( $args['modo'] ) ? (string) $args['modo'] : '';
// Selos por modo de atendimento: urgência local (35 min) ou envio (transportadora).
if ( $awr_est && 'entrega' === $awr_modo ) {
	$awr_bdg = array(
		'Entrega e instalação em até 35 minutos',
		'Pix com desconto ou 10x sem juros',
		'Nota fiscal e garantia de fábrica',
		'Recolhemos a bateria usada',
	);
} elseif ( $awr_est && 'atendimento' === $awr_modo ) {
	$awr_bdg = array(
		'Atendimento e troca no local',
		'Dimensionamento antes da compra',
		'Nota fiscal em CNPJ ou CPF',
		'Garantia de fábrica',
	);
} elseif ( $awr_est && 'envio' === $awr_modo ) {
	$awr_bdg = array(
		'Envio com rastreio',
		'Pagamento via Pix',
		'Nota fiscal em CNPJ ou CPF',
		'Garantia de fábrica',
	);
}
$awr_bdg = $awr_est && $awr_modo ? $awr_bdg : ( $awr_est
	? array(
		'Entrega expressa para nobreak parado em Porto Alegre',
		'Nota fiscal em CNPJ e cotação formal',
		'Recolhemos a bateria usada',
		'Envio por transportadora para RS, SC, SP e PR',
	)
	: array(
		'Entrega e instalação no local',
		'Nota fiscal e garantia de fábrica',
		'Recolhemos a bateria usada',
		'Atendimento por WhatsApp na hora',
	)
);
?>
<section class="awr-hub-hero awr-hub-hero--seg">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'trilha' => (array) $args['trilha'], 'atual' => $args['atual'] ) ); ?>
		<p class="awr-hub-hero__eyebrow"><?php echo esc_html( $awr_seg['eyebrow'] ); ?></p>
		<h1 class="awr-hub-hero__title"><?php echo esc_html( $awr_h1 ); ?></h1>
		<p class="awr-hub-hero__lead"><?php echo esc_html( $awr_led ); ?></p>

		<div class="awr-hub-hero__ctas">
			<a
				class="awr-hub-cta__wa"
				target="_top"
				rel="noopener"
				data-awr-est-lead="hero"
				data-awr-est-cidade="<?php echo esc_attr( $args['local'] ); ?>"
				href="<?php echo esc_url( $awr_wa ); ?>"
			>Pedir orçamento no WhatsApp</a>
			<a class="awr-hub-cta__tel" href="<?php echo esc_url( $awr_c['phone_href'] ); ?>">Ligar <?php echo esc_html( $awr_c['phone'] ); ?></a>
		</div>

		<ul class="awr-hub-hero__badges">
			<?php foreach ( $awr_bdg as $awr_b ) : ?>
				<li><?php echo esc_html( $awr_b ); ?></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
<?php awr_part( 'searchband' ); ?>
