<?php
/**
 * Breadcrumb único + JSON-LD BreadcrumbList.
 *
 * Uso: awr_part( 'breadcrumb', array(
 *   'trilha' => array( array( 'nome' => 'Cidades', 'url' => home_url( '/baterias-em/' ) ) ),
 *   'atual'  => 'Porto Alegre',
 * ) );
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$args   = wp_parse_args( $args ?? array(), array( 'trilha' => array(), 'atual' => '' ) );
$trilha = array_merge(
	array( array( 'nome' => 'Início', 'url' => home_url( '/' ) ) ),
	(array) $args['trilha']
);
?>
<nav class="awr-breadcrumb" aria-label="Você está aqui">
	<?php foreach ( $trilha as $item ) : ?>
		<a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['nome'] ); ?></a> ›
	<?php endforeach; ?>
	<?php if ( $args['atual'] ) : ?><span><?php echo esc_html( $args['atual'] ); ?></span><?php endif; ?>
</nav>
<?php
$awr_bc_list = array();
$awr_bc_pos  = 0;
foreach ( $trilha as $item ) {
	$awr_bc_pos++;
	$awr_bc_list[] = array(
		'@type'    => 'ListItem',
		'position' => $awr_bc_pos,
		'name'     => $item['nome'],
		'item'     => $item['url'],
	);
}
if ( $args['atual'] ) {
	$awr_bc_pos++;
	$awr_bc_list[] = array(
		'@type'    => 'ListItem',
		'position' => $awr_bc_pos,
		'name'     => $args['atual'],
	);
}
// v3.81.0 — em páginas de produto/SKU a trilha estruturada é a da loja (inc/schema-shop.php).
$awr_bc_skip = ( function_exists( 'is_product' ) && is_product() )
	|| ( function_exists( 'awr_current_route' ) && 'sku' === awr_current_route() );
if ( ! $awr_bc_skip ) {
	awr_jsonld( array(
		'@context'        => 'https://schema.org',
		'@type'           => 'BreadcrumbList',
		'itemListElement' => $awr_bc_list,
	) );
}
