<?php
/**
 * Hero navy padrão (mesmo visual da home) para as páginas internas.
 *
 * Uso:
 * awr_part( 'hero', array(
 *   'eyebrow' => 'Baterias por veículo',
 *   'h1'      => 'Bateria para Onix 2018',
 *   'gold'    => 'em Porto Alegre',   // trecho dourado no fim do H1 (opcional)
 *   'lead'    => 'Texto de apoio.',
 *   'badges'  => array( 'Instalação grátis' ),
 *   'wa'      => 'Mensagem do WhatsApp' | array( 'url' => '...', 'label' => '...' ),
 *   'trilha'  => array( array( 'nome' => '...', 'url' => '...' ) ),
 *   'atual'   => 'Título do breadcrumb',
 *   'crumb'   => true,
 * ) );
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$args = wp_parse_args( $args ?? array(), array(
	'eyebrow' => '',
	'h1'      => '',
	'gold'    => '',
	'lead'    => '',
	'badges'  => null,
	'wa'      => '',
	'wa_label'=> 'Pedir no WhatsApp',
	'tel'     => true,
	'trilha'  => array(),
	'atual'   => '',
	'crumb'   => true,
	'h1_tag'  => 'h1',
	'search'  => true,
) );

// H1 sugerido pela planilha SEO (Metas por URL) tem prioridade sobre o padrão da rota.
if ( function_exists( 'awr_seo_lote_h1' ) ) {
	$awr_h1_lote = awr_seo_lote_h1();
	if ( $awr_h1_lote ) { $args['h1'] = $awr_h1_lote; }
}

if ( ! $args['h1'] ) { return; }

$awr_hc = awr_contact();
$awr_wa = '';
if ( is_array( $args['wa'] ) ) {
	$awr_wa = $args['wa']['url'] ?? '';
	if ( ! empty( $args['wa']['label'] ) ) { $args['wa_label'] = $args['wa']['label']; }
} elseif ( $args['wa'] ) {
	$awr_wa = awr_wa( $args['wa'] );
}

$awr_badges = null === $args['badges']
	? array( 'Entrega e instalação no local', 'Nota fiscal e garantia de fábrica', 'Pague na entrega em 10x', 'Atendimento imediato no WhatsApp' )
	: (array) $args['badges'];

$awr_tag = in_array( $args['h1_tag'], array( 'h1', 'h2' ), true ) ? $args['h1_tag'] : 'h1';
?>
<section class="awr-hero-band">
	<span class="awr-hero-band__strip" aria-hidden="true"></span>
	<span class="awr-hero-band__glow" aria-hidden="true"></span>
	<div class="awr-hero-band__inner">
		<?php
		if ( $args['crumb'] ) {
			awr_part( 'breadcrumb', array( 'trilha' => (array) $args['trilha'], 'atual' => $args['atual'] ? $args['atual'] : $args['h1'] ) );
		}
		?>

		<?php if ( $args['eyebrow'] ) : ?>
			<p class="awr-hero-band__eyebrow"><span class="awr-hero-band__dot" aria-hidden="true"></span><?php echo esc_html( $args['eyebrow'] ); ?></p>
		<?php endif; ?>

		<<?php echo esc_html( $awr_tag ); ?> class="awr-hero-band__title">
			<?php echo esc_html( $args['h1'] ); ?>
			<?php if ( $args['gold'] ) : ?><span class="awr-hero-band__gold"><?php echo esc_html( $args['gold'] ); ?></span><?php endif; ?>
		</<?php echo esc_html( $awr_tag ); ?>>

		<?php if ( $args['lead'] ) : ?>
			<p class="awr-hero-band__lead"><?php echo esc_html( $args['lead'] ); ?></p>
		<?php endif; ?>

		<?php if ( $awr_badges ) : ?>
			<ul class="awr-hero-band__badges">
				<?php foreach ( $awr_badges as $awr_b ) : ?>
					<li><?php echo esc_html( $awr_b ); ?></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<div class="awr-hero-band__ctas">
			<?php if ( $awr_wa ) : ?>
				<a class="awr-hero-band__wa" target="_top" rel="noopener" href="<?php echo esc_url( $awr_wa ); ?>">
					<?php echo awr_wa_icon(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<?php echo esc_html( $args['wa_label'] ); ?>
				</a>
			<?php endif; ?>
			<?php if ( $args['tel'] ) : ?>
				<a class="awr-hero-band__tel" href="<?php echo esc_attr( $awr_hc['phone_href'] ); ?>">Ligar <?php echo esc_html( $awr_hc['phone'] ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</section>
<?php
if ( false !== ( $args['search'] ?? true ) ) { awr_part( 'searchband' ); }
