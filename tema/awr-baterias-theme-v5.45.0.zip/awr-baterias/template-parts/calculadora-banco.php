<?php
/** Calculadora de banco de baterias (mesma fórmula do app). @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_c = awr_company();
$awr_woo = array();
if ( function_exists( 'wc_get_product_id_by_sku' ) ) {
	foreach ( array( 'DF500', 'DF700', 'DF1000', 'DF1500', 'DF2000', 'DF2500', 'DF3000', 'DF4100' ) as $s ) {
		$id = (int) wc_get_product_id_by_sku( $s );
		$pr = $id ? wc_get_product( $id ) : null;
		if ( $pr && 'publish' === $pr->get_status() ) { $awr_woo[ $s ] = array( 'preco' => (float) $pr->get_price(), 'url' => get_permalink( $id ) ); }
	}
}
?>
<section id="calculadora" class="awr-app-section awr-calc" data-wa="<?php echo esc_attr( $awr_c['whatsapp_number'] ); ?>"><div class="awr-hub-body">
 <p style="font-size:12px;font-weight:700;text-transform:uppercase;color:#1d4ed8;margin:0">AWR Energia</p>
 <h2>Calculadora de banco de baterias</h2>
 <p>A bateria certa para seu sistema. Informe o consumo e o tempo que precisa de energia.</p>
 <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(min(160px,100%),1fr))">
  <label>Aplicação<select name="ap" style="width:100%;padding:10px"><option>Nobreak</option><option>Solar / off-grid</option><option>CFTV</option><option>Alarme / portão</option><option>Telecom</option><option>Outro</option></select></label>
  <label>Consumo (W)<input name="w" type="number" min="1" value="300" style="width:100%;padding:10px"></label>
  <label>Autonomia (horas)<input name="h" type="number" min="0.5" step="0.5" value="4" style="width:100%;padding:10px"></label>
  <label>Tensão<select name="v" style="width:100%;padding:10px"><option value="12">12 V</option><option value="24">24 V</option><option value="48">48 V</option></select></label>
 </div>
 <div class="awr-calc-out" aria-live="polite" style="margin-top:12px;background:#f1f5f9;border-radius:10px;padding:14px"></div>
</div></section>
<script>
(function(){var s=document.querySelector('.awr-calc');if(!s)return;
var W=<?php echo wp_json_encode( (object) $awr_woo ); ?>;var M=[['DF500',40],['DF700',50],['DF1000',70],['DF1500',93],['DF2000',115],['DF2500',165],['DF3000',185],['DF4100',240]];
function r(){var g=function(n){return s.querySelector('[name='+n+']').value},w=+g('w'),h=+g('h'),v=+g('v'),o=s.querySelector('.awr-calc-out');
if(!(w>0&&h>0)){o.textContent='';return}
var ah=Math.ceil(w*h/(v*0.85*0.5)),se=Math.max(1,Math.round(v/12)),op=M.map(function(m){var t=Math.ceil(ah/m[1])*se;return [m[0],m[1],t]}).filter(function(x){return x[2]<=16}).slice(0,3);
var txt='Aplicação: '+g('ap')+'. Carga: '+w+' W por '+h+' h em '+v+' V. Estimativa: '+ah+' Ah. Opções: '+op.map(function(x){return x[2]+'x '+x[0]}).join(', ')+'.';
o.innerHTML='<strong style="font-size:20px;color:#1d4ed8">≈ '+ah+' Ah em '+v+' V</strong><p style="font-size:12px">'+se+' bateria(s) de 12 V em série por conjunto. Considera eficiência de 85% e uso de até 50% da carga.</p><ul>'+op.map(function(x){var w=W[x[0]];return '<li><strong>'+x[2]+'× Freedom '+x[0]+'</strong> ('+x[1]+' Ah)'+(w&&w.preco?' · '+w.preco.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})+' cada <a class="awr-btn awr-btn--primary" href="'+w.url+'">Comprar</a>':'')+'</li>'}).join('')+'</ul><a class="awr-btn awr-btn--wa" target="_blank" rel="noopener" href="https://wa.me/'+s.dataset.wa+'?text='+encodeURIComponent('Olá! Quero orçamento de banco de baterias. '+txt)+'">Receber orçamento no WhatsApp</a><p style="font-size:12px">Estimativa inicial; o técnico confirma antes do orçamento.</p>';}
s.addEventListener('input',r);s.addEventListener('change',r);r();})();
</script>
