# 5.21.0

- Páginas de produto: H1 com região, preço sem a bateria usada na troca, CCA e peso na ficha, prazo real por cidade (Caxias só por transportadora) e seção "Como funciona a entrega e a instalação".
- Selos: aplicação correta conforme a montadora e preço com/sem troca.
- Feed do Google: título Marca + Ah + Código + Aplicação e tipo de produto por segmento (inc/merchant-titulo.php).
