# AWR Baterias 5.27.0

- Mais vendidos nas páginas de carro, moto, caminhão e estacionária, na ordem dos SKUs oficiais.
- Nome, imagem, preço e disponibilidade do produto real do WooCommerce; não substitui SKUs ausentes.
- CNPJ e razão social no rodapé, com fonte compartilhada com o app.
- Garantias Freedom/Moura Nobreak 2 anos, Moura VRLA 1 ano, Global/Duran 90 dias; prioridade sobre filtros antigos que ocultavam garantias.
- Política de troca e devolução depende do texto oficial do cliente.
- Não inclui instalação no WordPress nem alterações no Cloudflare/GTM.