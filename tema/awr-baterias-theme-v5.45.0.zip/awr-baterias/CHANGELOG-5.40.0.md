# 5.40.0 — Calendário editorial do blog

- Novo painel **Posts → Calendário editorial** com as 119 pautas aprovadas (nov/2026–ago/2027), filtro por mês e categoria, edição de título/data/hora/responsável, contadores de previstas/publicadas/atrasadas e ficha SEO de cada pauta.
- Fluxo: Pauta → Em produção → Revisão SEO → Revisão técnica → Aprovado → Agendado → Publicado. "Aprovar" só para Editor/Administrador e só a partir de "Revisão técnica"; "Agendar" só depois de aprovado (status nativo `future`).
- "Criar rascunho" gera um post nativo em rascunho com slug, resumo (meta description), title SEO e links internos sugeridos.
- Posts publicados pelo calendário aparecem em /blog/, /blog/{slug}/, sitemap e links internos, com o mesmo layout dos guias; o endereço nativo redireciona (301) para /blog/{slug}/.
- Aviso de WP-Cron desativado ou de agendamentos perdidos.
- Article Schema passa a informar `dateModified`.
