# 5.37.0 — Execução 2 do plano SEO
- /bateria-24h-porto-alegre/ agora redireciona (301) para /socorro-bateria/, sai do sitemap e o texto deixa de prometer 24h.
- Artigos do blog e páginas marca+cidade: "socorro 24h" trocado por "socorro de bateria"; FAQs informam plantão 06:30–22h.
- Home: meta description com Moura, Heliar, Zetta e Excell; H2 de marcas e de cidades com "Porto Alegre". H1 e title preservados.
