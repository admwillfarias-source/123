# 5.35.0 — Core Web Vitals no celular
- HTML público com s-maxage de 4 h (antes 1 h) e stale-while-revalidate, para o Cloudflare servir do cache.
- Visitas anônimas sem carrinho deixam de receber cookie de sessão do WooCommerce (cookie impedia o cache).
- INP: eventos de GA4/Ads/GTM dos cliques (WhatsApp, telefone, pedido) são enviados depois da tela responder ao toque.
