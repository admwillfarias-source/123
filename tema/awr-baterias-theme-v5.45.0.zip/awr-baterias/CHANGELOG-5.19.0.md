# AWR Baterias 5.19.0

- Fonte única para promessa de entrega por cidade.
- Até 35 min: Porto Alegre, Canoas, Gravataí, Cachoeirinha, São Leopoldo, Novo Hamburgo e Campo Bom.
- Até 40 min: Esteio e Sapucaia do Sul.
- Entrega durante o dia para pedidos até 17h: Alvorada, Viamão, Nova Santa Rita, Estância Velha e Sapiranga.
- Entrega no dia seguinte: Eldorado do Sul e Guaíba.
- SEO automotivo ampliado para 45 cidades do RS atendidas por transportadora em 1 a 2 dias úteis.
- H1, H2, H3, títulos, descrições, FAQ, CTAs e dados estruturados alinhados às novas regras.
- Páginas estacionárias mantêm atendimento local ampliado em RS, SC, PR e SP, com prazo confirmado no WhatsApp fora da frota rápida.
- Hub de cidades ganhou links internos para o lote do interior do RS.
