<?php
/**
 * Fallback genérico (arquivos, posts nativos do WP).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

if ( ! have_posts() ) :
	// Busca/arquivo sem resultados: hero com busca de bateria.
	awr_part( 'hero', array(
		'eyebrow' => 'Busca sem resultados',
		'h1'      => 'Nada encontrado',
		'gold'    => '— tente pelo veículo',
		'lead'    => 'Não achamos conteúdo para este endereço. Busque a bateria certa pelo modelo do seu carro ou moto.',
		'crumb'   => false,
		'search'  => true,
	) );
	get_footer();
	return;
endif;
?>
<div class="awr-container awr-prose">
	<?php if ( is_home() || is_archive() || is_search() ) : ?>
		<?php
		// v3.82.0 — H1 próprio: nunca reaproveitar o <title> (que é escrito para a SERP).
		if ( is_search() ) {
			$awr_h1 = 'Resultados para “' . get_search_query() . '”';
		} elseif ( is_archive() ) {
			$awr_h1 = wp_strip_all_tags( get_the_archive_title() );
		} else {
			$awr_h1 = 'Blog da AWR Baterias';
		}
		?>
		<h1 class="awr-page-title"><?php echo esc_html( $awr_h1 ); ?></h1>
		<ul class="awr-postlist">
			<?php while ( have_posts() ) : the_post(); ?>
				<li>
					<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
					<p><?php echo esc_html( wp_trim_words( get_the_excerpt(), 28 ) ); ?></p>
				</li>
			<?php endwhile; ?>
		</ul>
		<?php the_posts_pagination(); ?>
	<?php else : ?>
		<?php while ( have_posts() ) : the_post(); ?>
			<article <?php post_class(); ?>>
				<h1 class="awr-page-title"><?php the_title(); ?></h1>
				<?php the_content(); ?>
			</article>
		<?php endwhile; ?>
	<?php endif; ?>
</div>
<?php get_footer(); ?>
