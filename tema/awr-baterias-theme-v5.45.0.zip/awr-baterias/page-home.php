<?php
/**
 * Fallback: página estática com slug "home" usa o mesmo layout da front-page.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
require AWR_DIR . '/front-page.php';
