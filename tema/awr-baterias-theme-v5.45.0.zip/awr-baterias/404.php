<?php
/**
 * Página 404 — hero com busca e saídas para os hubs principais.
 * O status 404 e o noindex são definidos em inc/rewrites.php e inc/seo.php.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

awr_part( 'hero', array(
	'eyebrow' => 'Erro 404',
	'h1'      => 'Página não encontrada',
	'gold'    => '— encontre sua bateria',
	'lead'    => 'O endereço mudou ou não existe mais. Busque a bateria certa pelo modelo do seu veículo ou navegue pelos atalhos abaixo.',
	'crumb'   => false,
	'badges'  => array( 'Entrega e instalação em 35 min', 'Pague na entrega', 'Garantia de fábrica' ),
) );
?>
<div class="awr-container awr-prose">
	<h2 class="awr-section-title">Atalhos rápidos</h2>
	<ul class="awr-chips">
		<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/' ) ); ?>">Página inicial</a></li>
		<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias/' ) ); ?>">Baterias por cidade</a></li>
		<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-para/' ) ); ?>">Baterias por veículo</a></li>
		<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/marcas/' ) ); ?>">Marcas de bateria</a></li>
		<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/bateria-estacionaria/' ) ); ?>">Baterias estacionárias</a></li>
		<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/lojas/' ) ); ?>">Nossas lojas</a></li>
	</ul>
</div>
<?php get_footer(); ?>
