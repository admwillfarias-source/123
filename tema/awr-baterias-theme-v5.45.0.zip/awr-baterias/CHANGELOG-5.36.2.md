# 5.36.2
- Busca com reserva offline: se o servidor não responder em 6 s, sugestões e baterias compatíveis saem de `assets/js/awr-vindex.json` (arquivo estático, cacheado pelo Cloudflare). Sem preço, o cartão oferece pedir pelo WhatsApp.
- Índice gerado por `tools/gen-vindex.py` a partir de `assets/data/batteries.json` no build.
