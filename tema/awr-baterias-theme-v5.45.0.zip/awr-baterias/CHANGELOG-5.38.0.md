# 5.38.0 — Execução 3 do plano SEO
- Páginas nacionais para 10 veículos prioritários (Strada, Argo, Creta, Ka, Kicks, Ranger, Onix, Renegade, T-Cross, Hilux) em /baterias-para/{veiculo}/, agrupando todas as versões do catálogo com tabela versão × ano × amperagem × modelos compatíveis.
- Novos endereços: /baterias-para/fiat-argo/, /hyundai-creta/, /chevrolet-onix/, /jeep-renegade/, /volkswagen-t-cross/. Os já existentes passam a mostrar todas as versões.
- Páginas de marca (Moura, Heliar, Zetta, Excell): título nacional "Preço, Modelos e Amperagens", bloco "para os carros mais buscados" e links por amperagem.
- Sitemap inclui os 10 veículos prioritários.
