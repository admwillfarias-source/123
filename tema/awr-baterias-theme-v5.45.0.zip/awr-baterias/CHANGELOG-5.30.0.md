# AWR Baterias 5.30.0
- Menu com AWR Energia, Comparar e Central Técnica.
- Home: duas entradas (AWR Automotiva / AWR Energia) acima do menu de emergência.
- Novas páginas: /comparar/ (filtros Ah, CCA, garantia + comparador de 3 modelos da tabela oficial), /garantia/, /rastrear-pedido/ (WhatsApp) e /central-tecnica/.
- Links de garantia, rastreio, comparador e central no rodapé.
- Após instalar: Configurações > Links permanentes > Salvar (novas URLs).
