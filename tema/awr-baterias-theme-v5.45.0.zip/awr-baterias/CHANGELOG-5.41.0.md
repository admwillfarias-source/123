# 5.41.0
- Calendário editorial: os 12 artigos de novembro/2026 já vêm redigidos ao clicar em "Criar rascunho" (campo `corpo`), com marcadores [CONFIRMAR] para revisão. O fluxo de aprovação não mudou.
- Novas páginas /baterias-porto-alegre/{centro,zona-norte,zona-leste,zona-sul,avenida-protasio-alves}/ reunindo os bairros que já têm página (dados em zonas-poa.json, gerados por scripts/gen-zonas-poa.mjs). Entram no sitemap de bairros. Após instalar, salve Configurações → Links permanentes uma vez.
- Aviso "Loja mais próxima" saiu de dentro do cabeçalho; no celular flutua acima da barra inferior e não cobre mais o título (paridade com o app).
