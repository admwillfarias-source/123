# AWR Baterias 5.31.0
- Menu de emergência: consulta por CEP (prazo e frete das faixas oficiais) via /wp-json/awr/v1/frete; mensagem do WhatsApp leva o CEP.
- Calculadora de banco: mostra preço e botão Comprar dos modelos Freedom publicados no WooCommerce.
- /socorro-bateria/: menu de emergência no topo (página para anúncios).
- Pós-venda (Avaliar no Google + WhatsApp) na confirmação do pedido e no "pedido recebido" do WooCommerce.
- Ficha técnica (tabela oficial) nas páginas de produto e SKU.
- AWR Frotas na página B2B.
- Bloco "Enviamos estacionárias para RS, SC, PR e SP".
