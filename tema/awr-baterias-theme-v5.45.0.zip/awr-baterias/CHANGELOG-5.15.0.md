# AWR Baterias, tema v5.15.0 (sobre a v5.14.0)

Não testado em WordPress ao vivo. Valide em homologação antes de publicar.

## O que mudou

1. **Laço redirect x canonical (corrigido)**
   - `inc/seo-lote.php`: o canonical cruzado agora aponta para `/baterias-em/{cidade}/` em TODAS as cidades. Antes, São Leopoldo, Novo Hamburgo e Guaíba apontavam para a URL antiga.
   - `inc/redirects.php`: o 301 de `/novo-hamburgo/`, `/sao-leopoldo/` e `/bateria-guaiba/` (e variações) fica DESLIGADO por padrão (Etapa B). Liga em Ajustes > AWR Indexação.
   - Caxias do Sul: o canonical de `/baterias-automotivas-moura-em-caxias-do-sul/` passou a apontar para o mesmo destino do 301 (`/bateria/moura/caxias-do-sul/`).
2. **Nota copiada nos bairros (corrigido)**: `routes/bairro.php` não imprime mais `4.9 / 1935` em todas as páginas. O `aggregateRating` só aparece quando o perfil da loja que atende tem avaliações próprias (mesma regra de `routes/loja.php`).
3. **Indexação por dados (T28, novo)**: `inc/seo-indexacao.php` + `assets/data/indexaveis.json`.
   - Padrão: `off` (nada muda).
   - `envio`: cidades sem loja só ficam indexáveis para URLs com impressões no Search Console (28 no export) ou mercados de foco x modelos populares. Sitemap veículo x cidade: 186.560 -> ~30 mil URLs.
   - `estrito`: como `envio` e, nas cidades com loja, só os 400 modelos mais populares. ~8 mil URLs.
   - Páginas fora da regra recebem `noindex,follow`. Nada é apagado.
   - Corrige também `awr_vc_populares()`, que só casava slug exato e perdia Onix, HB20, Corolla, Renegade, Creta, T-Cross, Argo e Toro (casamento por prefixo: 72 modelos).
4. `inc/rewrites.php`: a chave de cache do sitemap passa a incluir o modo de indexação (a troca de modo vale na hora).
5. Versão 5.15.0 em `style.css` e `functions.php`.

## Como ativar (ordem)

1. Publicar em homologação. Testar os 6 itens do checklist abaixo.
2. Publicar em produção. Salvar "AWR Indexação" uma vez (modo `off`) e reenviar o sitemap no Search Console.
3. Após 7 dias estáveis: modo `envio`. Esperar 14 dias, comparar cliques e posição.
4. Etapa B (301): uma cidade por vez, 3 semanas depois do canonical. O checkbox atual liga as 3 cidades juntas; para ligar uma de cada vez use o filtro `awr_redirect_etapa_b_slugs`.
5. Modo `estrito` só depois de avaliar o `envio` com o export completo do Search Console (API).

## Checklist de testes

- `curl -I https://awrbaterias.com.br/novo-hamburgo/` : sem 301 enquanto a Etapa B estiver desligada. Com 301, o destino deve ser `/baterias-em/novo-hamburgo/`.
- view-source de `/baterias-em/novo-hamburgo/`: 1 `<title>`, 1 meta description, 1 canonical autorreferenciado.
- view-source de `/novo-hamburgo/` (se for 200): canonical para `/baterias-em/novo-hamburgo/`.
- view-source de uma página de bairro: sem `aggregateRating` (ou com a nota da loja, se existir).
- Com modo `envio`: uma URL `/baterias-para/{modelo}/{cidade-de-envio-fora-do-foco}/` tem `noindex,follow` e NÃO está no sitemap; uma URL da lista de permissão continua indexável.
- `/awr-sitemap.xml` abre sem erro e lista as seções `veiculoscidade-*` com o total reduzido.

## Reverter

- Ajustes > AWR Indexação > modo `off` e Etapa B desmarcada.
- Ou reinstalar a v5.14.0.

## Limites conhecidos

- O export do Search Console traz no máximo 1.000 páginas. A lista de permissão só protege o que aparece nele. Gere a lista completa pela API antes do modo `estrito`.
- A regra só atua em veículo x cidade. Veículo/ano e veículo/modelo não mudam (geram ~31% dos cliques recentes).

---

# v5.16.1 (sobre a 5.16.0)

Só código. Nenhum texto do site foi alterado.

1. `inc/rewrites.php`: a chave de cache do sitemap usava "off" como padrão do modo de indexação, mas o padrão efetivo passou a ser "envio" na 5.16.0. Ao desligar o modo ("off"), o sitemap filtrado podia ficar até 12 h em cache. Padrão corrigido para "envio".
2. `inc/seo-indexacao.php`: pausar a Etapa B passa a pausar também o relógio. Antes, desmarcar por semanas e religar liberava as 3 cidades de uma vez (teste: sem a correção, religar no dia 65 liberava 3; com ela, continua em 1).

## Observações sobre a 5.16.0 (não alteradas aqui)

- Calendário da Etapa B testado: dia 0 = Guaíba; dia 21 = + Novo Hamburgo; dia 42 = + São Leopoldo.
- O relógio começa na primeira visita a qualquer página que consulte a regra (ou ao abrir Ajustes > AWR Indexação), não na data do upload do tema.
- Ao instalar, salve uma vez Ajustes > AWR Indexação: isso limpa o cache de redirects (`awr_legacy_redirects`, 24 h) e evita 301 antigos da v5.14.
- `assets/data-php/indexaveis.php` não é lido por nenhum código (o tema lê o `.json`). Inofensivo.
- Texto da cidade de caminhão: o título diz "150Ah a 225Ah" e o corpo diz "100Ah a 225Ah".
