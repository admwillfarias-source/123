# AWR Baterias 5.29.0
- Páginas de cidades por transportadora: bloco "Escolha sua bateria / Precisa de ajuda? / Mande uma foto".
- Bloco AWR Engenharia (dimensionamento, banco de baterias, empresas) no hub estacionário.
- Assinaturas "A bateria que chega até você" e "A bateria certa para seu sistema" no rodapé.
