<?php
/**
 * Loja WooCommerce (catálogo virtual /loja/) — mesma identidade do app.
 *
 * Consultas enxutas: IDs em cache por 10 min e hidratação em lote com
 * wc_get_product(), sem depender dos templates padrão do WooCommerce.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const AWR_SHOP_PER_PAGE = 400; // 5.18.0: catálogo inteiro numa página

/** Ordenações disponíveis na loja. */
function awr_shop_orders() {
	return array(
		'relevancia' => 'Mais relevantes',
		'menor'      => 'Menor preço',
		'maior'      => 'Maior preço',
		'novidades'  => 'Novidades',
	);
}

/** Ordenação atual (querystring ?ordem=). */
function awr_shop_order() {
	$o = isset( $_GET['ordem'] ) ? sanitize_key( wp_unslash( $_GET['ordem'] ) ) : 'relevancia'; // phpcs:ignore WordPress.Security.NonceVerification
	return array_key_exists( $o, awr_shop_orders() ) ? $o : 'relevancia';
}

/** Categorias de produto com pelo menos 1 item publicado (cache 1 h). */
function awr_shop_categorias() {
	$key   = 'awr_shop_cats_' . awr_cache_ver();
	$cache = get_transient( $key );
	if ( is_array( $cache ) ) { return $cache; }

	$out   = array();
	$terms = taxonomy_exists( 'product_cat' )
		? get_terms( array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => true,
			'orderby'    => 'count',
			'order'      => 'DESC',
			'number'     => 40,
		) )
		: array();

	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			if ( 'uncategorized' === $t->slug || 'sem-categoria' === $t->slug ) { continue; }
			$out[] = array(
				'slug'  => $t->slug,
				'nome'  => $t->name,
				'total' => (int) $t->count,
				'url'   => home_url( '/loja/c/' . $t->slug . '/' ),
			);
		}
	}
	set_transient( $key, $out, HOUR_IN_SECONDS );
	return $out;
}

/** Categoria pelo slug (ou null). */
function awr_shop_categoria_by_slug( $slug ) {
	$slug = sanitize_title( $slug );
	foreach ( awr_shop_categorias() as $c ) {
		if ( $c['slug'] === $slug ) { return $c; }
	}
	return null;
}

/** URL da loja com categoria/página/ordem. */
function awr_shop_url( $cat = '', $page = 1, $ordem = '' ) {
	$path = $cat ? '/loja/c/' . sanitize_title( $cat ) . '/' : '/loja/';
	if ( $page > 1 ) { $path .= 'page/' . (int) $page . '/'; }
	$url = home_url( $path );
	if ( $ordem && 'relevancia' !== $ordem ) { $url = add_query_arg( 'ordem', $ordem, $url ); }
	return $url;
}

/**
 * Consulta paginada do catálogo.
 *
 * @param string $cat   Slug da categoria (vazio = tudo).
 * @param int    $page  Página (1+).
 * @param string $ordem Chave de awr_shop_orders().
 * @return array{produtos:array,total:int,paginas:int,pagina:int}
 */
function awr_shop_query( $cat = '', $page = 1, $ordem = 'relevancia' ) {
	$vazio = array( 'produtos' => array(), 'total' => 0, 'paginas' => 1, 'pagina' => 1 );
	if ( ! function_exists( 'wc_get_product' ) ) { return $vazio; }

	$cat   = sanitize_title( $cat );
	$page  = max( 1, (int) $page );
	$ordem = array_key_exists( $ordem, awr_shop_orders() ) ? $ordem : 'relevancia';
	$key   = 'awr_shop_' . md5( $cat . '|' . $page . '|' . $ordem . '|' . awr_cache_ver() );

	// IDs e total guardados juntos: nunca mostram contagem 0 com cards na tela.
	$cache = get_transient( $key );
	$ids   = ( is_array( $cache ) && isset( $cache['ids'] ) ) ? $cache['ids'] : null;
	$total = ( is_array( $cache ) && isset( $cache['total'] ) ) ? (int) $cache['total'] : 0;

	if ( ! is_array( $ids ) ) {
		$args = array(
			'post_type'              => 'product',
			'post_status'            => 'publish',
			'posts_per_page'         => AWR_SHOP_PER_PAGE,
			'paged'                  => $page,
			'fields'                 => 'ids',
			'ignore_sticky_posts'    => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
			'no_found_rows'          => false,
		);

		if ( 'menor' === $ordem || 'maior' === $ordem ) {
			$args['meta_key'] = '_price'; // phpcs:ignore WordPress.DB.SlowDBQuery
			$args['orderby']  = 'meta_value_num';
			$args['order']    = 'menor' === $ordem ? 'ASC' : 'DESC';
		} elseif ( 'novidades' === $ordem ) {
			$args['orderby'] = 'date';
			$args['order']   = 'DESC';
		} else {
			$args['orderby'] = array( 'menu_order' => 'ASC', 'date' => 'DESC', 'title' => 'ASC' );
		}

		$tax = array();

		// Visibilidade de catálogo resolvida na própria consulta: o total bate com o exibido.
		if ( taxonomy_exists( 'product_visibility' ) ) {
			$tax[] = array(
				'taxonomy' => 'product_visibility',
				'field'    => 'name',
				'terms'    => array( 'exclude-from-catalog' ),
				'operator' => 'NOT IN',
			);
		}

		if ( $cat ) {
			$tax[] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => $cat,
			);
		}

		if ( $tax ) {
			$tax['relation']   = 'AND';
			$args['tax_query'] = $tax; // phpcs:ignore WordPress.DB.SlowDBQuery
		}

		$q     = new WP_Query( $args );
		$ids   = array_map( 'intval', $q->posts );
		$total = (int) $q->found_posts;
		wp_reset_postdata();

		set_transient( $key, array( 'ids' => $ids, 'total' => $total ), 10 * MINUTE_IN_SECONDS );
	}

	if ( ! $ids ) { return $vazio; }

	$produtos = awr_shop_hydrate( $ids );

	return array(
		'produtos' => $produtos,
		'total'    => $total,
		'paginas'  => max( 1, (int) ceil( $total / AWR_SHOP_PER_PAGE ) ),
		'pagina'   => $page,
	);
}

/**
 * Converte IDs de produto no formato usado pelos cards (1 lote de queries).
 *
 * @param array $ids IDs de produto.
 * @return array
 */
function awr_shop_hydrate( $ids ) {
	$ids = array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
	if ( ! $ids || ! function_exists( 'wc_get_product' ) ) { return array(); }

	_prime_post_caches( $ids, false, true );

	$produtos = array();
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( ! $p ) { continue; }

		$sku   = (string) $p->get_sku();
		$price = (float) $p->get_price();
		$img   = $p->get_image_id() ? wp_get_attachment_image_src( $p->get_image_id(), 'large' ) : null;
		$produtos[] = array(
			'id'           => $id,
			'sku'          => $sku,
			'brand'        => $sku ? awr_brand_by_sku( $sku ) : '',
			'name'         => $p->get_name(),
			'price'        => $price,
			'permalink'    => get_permalink( $id ),
			'image'        => $img ? $img[0] : '',
			'image_id'     => (int) $p->get_image_id(),
			'amperagem'    => awr_extract_amperage( $sku, $p->get_name() ),
			'in_stock'     => $p->is_in_stock(),
			'sob_consulta' => $price <= 0,
		);
	}
	return $produtos;
}

/**
 * Índice amperagem => IDs do catálogo WooCommerce (1 consulta, cache 1 h).
 *
 * @return array<int,int[]>
 */
function awr_shop_amperage_index() {
	static $memo = null;
	if ( null !== $memo ) { return $memo; }

	$key   = 'awr_shop_ahidx_' . awr_cache_ver();
	$cache = get_transient( $key );
	if ( is_array( $cache ) ) {
		$memo = $cache;
		return $memo;
	}

	$idx = array();
	if ( function_exists( 'wc_get_product' ) ) {
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			"SELECT p.ID, p.post_title, pm.meta_value AS sku
			 FROM {$wpdb->posts} p
			 LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_sku'
			 WHERE p.post_type = 'product' AND p.post_status = 'publish'
			 LIMIT 3000"
		);
		foreach ( (array) $rows as $r ) {
			$ah = awr_extract_amperage( (string) $r->sku, (string) $r->post_title );
			if ( $ah < 20 || $ah > 260 ) { continue; }
			if ( ! isset( $idx[ $ah ] ) ) { $idx[ $ah ] = array(); }
			$idx[ $ah ][] = (int) $r->ID;
		}
		ksort( $idx );
	}

	set_transient( $key, $idx, HOUR_IN_SECONDS );
	$memo = $idx;
	return $memo;
}

/**
 * Produtos do WooCommerce com determinada amperagem.
 *
 * @param int $ah    Amperagem.
 * @param int $limit Máximo de itens.
 * @return array
 */
function awr_shop_products_by_amperage( $ah, $limit = 48 ) {
	$ah  = (int) $ah;
	$idx = awr_shop_amperage_index();
	if ( $ah <= 0 || empty( $idx[ $ah ] ) ) { return array(); }
	return awr_shop_hydrate( array_slice( $idx[ $ah ], 0, max( 1, (int) $limit ) ) );
}


/** Produtos publicados de uma categoria do WooCommerce (cache 1 h). */
function awr_shop_products_by_cat( $slug, $limit = 48 ) {
	if ( ! function_exists( 'wc_get_product' ) || ! taxonomy_exists( 'product_cat' ) ) { return array(); }
	$slug = sanitize_title( $slug );
	$key  = 'awr_shop_cat_' . md5( $slug . '|' . (int) $limit . '|' . awr_cache_ver() );
	$ids  = get_transient( $key );
	if ( ! is_array( $ids ) ) {
		$ids = get_posts( array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => max( 1, (int) $limit ),
			'fields'         => 'ids',
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
			'tax_query'      => array( array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => $slug, 'include_children' => true ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
		) );
		set_transient( $key, $ids, HOUR_IN_SECONDS );
	}
	return awr_shop_hydrate( $ids );
}

/** [awr_estacionarias] — lista das estacionárias da loja para colar em páginas do painel. */
add_shortcode( 'awr_estacionarias', function ( $atts ) {
	$atts = shortcode_atts( array( 'categoria' => 'estacionaria', 'titulo' => 'Baterias estacionárias disponíveis na loja' ), $atts );
	ob_start();
	echo '<section class="awr-app-section awr-est" id="awr-app"><div class="awr-hub-body">';
	awr_part( 'produtos-woo', array( 'produtos' => awr_shop_products_by_cat( $atts['categoria'] ), 'titulo' => $atts['titulo'], 'lead' => 'Preço e estoque reais. Compre pelo site ou confirme a aplicação no WhatsApp.' ) );
	echo '</div></section>';
	return ob_get_clean();
} );

/** Limpa o cache da loja quando o catálogo muda. */
function awr_flush_shop_cache() {
	global $wpdb;
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_awr_shop_%' OR option_name LIKE '_transient_timeout_awr_shop_%'" ); // phpcs:ignore WordPress.DB
}
add_action( 'woocommerce_update_product', 'awr_flush_shop_cache' );
add_action( 'woocommerce_new_product', 'awr_flush_shop_cache' );
