<?php
/**
 * Regras de entrega AWR Baterias — paridade com src/lib/delivery.ts do app.
 *
 * PORTO ALEGRE (todos os dias, incluindo fim de semana e feriado):
 *   06:30–08:30  plantão   — taxa R$ 60,00
 *   08:31–18:00  comercial — entrega GRÁTIS
 *   18:01–22:00  plantão   — taxa R$ 60,00
 * DEMAIS CIDADES: lojas das 09:00 às 18:00 em dias úteis.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'AWR_ATEND_INICIO', 6 * 60 + 30 );   // 06:30
define( 'AWR_ATEND_FIM', 22 * 60 );          // 22:00
define( 'AWR_PLANTAO_MANHA_INICIO', 6 * 60 + 30 );
define( 'AWR_PLANTAO_MANHA_FIM', 8 * 60 + 30 );
define( 'AWR_GRATIS_INICIO', 8 * 60 + 31 );
define( 'AWR_GRATIS_FIM', 18 * 60 );
define( 'AWR_PLANTAO_NOITE_INICIO', 18 * 60 + 1 );
define( 'AWR_PLANTAO_NOITE_FIM', 22 * 60 );
define( 'AWR_OUTRAS_INICIO', 9 * 60 );
define( 'AWR_OUTRAS_FIM', 18 * 60 );
define( 'AWR_TAXA_PLANTAO', 60 );

/** Aviso padrão sobre a previsão de 35 minutos. */
function awr_aviso_35min() {
	return 'A entrega em ~35 min é uma estimativa e pode variar conforme a demanda e o trânsito. Assim que recebermos o pedido, confirmamos a previsão de entrega no WhatsApp.';
}

/** Feriados fixos (nacionais + Porto Alegre) — espelha src/lib/holidays.ts. */
function awr_feriados() {
	return array(
		// 2026
		'2026-01-01', '2026-02-02', '2026-02-16', '2026-02-17', '2026-04-03', '2026-04-21',
		'2026-05-01', '2026-06-04', '2026-09-07', '2026-09-20', '2026-10-12', '2026-11-02',
		'2026-11-15', '2026-11-20', '2026-12-25',
		// 2027
		'2027-01-01', '2027-02-02', '2027-02-08', '2027-02-09', '2027-03-26', '2027-04-21',
		'2027-05-01', '2027-05-27', '2027-09-07', '2027-09-20', '2027-10-12', '2027-11-02',
		'2027-11-15', '2027-11-20', '2027-12-25',
		// 2028
		'2028-01-01', '2028-02-02', '2028-02-28', '2028-02-29', '2028-04-14', '2028-04-21',
		'2028-05-01', '2028-06-15', '2028-09-07', '2028-09-20', '2028-10-12', '2028-11-02',
		'2028-11-15', '2028-11-20', '2028-12-25',
	);
}

function awr_is_feriado( $ts = null ) {
	$ts = $ts ? $ts : current_time( 'timestamp' );
	return in_array( gmdate( 'Y-m-d', $ts ), awr_feriados(), true );
}

function awr_is_fds_ou_feriado( $ts = null ) {
	$ts  = $ts ? $ts : current_time( 'timestamp' );
	$dow = (int) gmdate( 'w', $ts );
	return ( 0 === $dow || 6 === $dow || awr_is_feriado( $ts ) );
}

function awr_eh_porto_alegre( $cidade = '' ) {
	if ( ! $cidade ) { return true; }
	$n = strtolower( remove_accents( trim( $cidade ) ) );
	return in_array( $n, array( 'porto alegre', 'porto-alegre', 'poa' ), true );
}

define( 'AWR_RAIO_SEM_TAXA_KM', 12 );
define( 'AWR_TAXA_DISTANCIA', 20 );

/** Cidades com entrega e instalação em até 35 minutos (centroide aproximado). */
function awr_cidades_35min() {
	return array(
		'Porto Alegre'    => array( -30.0346, -51.2177 ),
		'Canoas'          => array( -29.9177, -51.1836 ),
		'Gravataí'        => array( -29.9444, -50.9919 ),
		'Cachoeirinha'    => array( -29.9511, -51.0939 ),
		'São Leopoldo'    => array( -29.7603, -51.1472 ),
		'Sapucaia do Sul' => array( -29.8277, -51.1450 ),
		'Esteio'          => array( -29.8608, -51.1789 ),
		'Novo Hamburgo'   => array( -29.6883, -51.1306 ),
		'Campo Bom'       => array( -29.6747, -51.0606 ),
	);
}

/** Coordenadas das lojas AWR. */
function awr_lojas_geo() {
	return array(
		array( -30.0532, -51.2230 ), array( -30.0359, -51.1786 ),
		array( -29.9237, -51.1810 ), array( -29.9498, -51.0207 ),
		array( -29.7755, -51.1393 ), array( -29.6768, -51.1278 ),
	);
}

function awr_norm_cidade( $cidade ) {
	$n = strtolower( remove_accents( (string) $cidade ) );
	$n = str_replace( '-', ' ', $n );
	return trim( preg_replace( '/\s+/', ' ', $n ) );
}

/** Retorna as coordenadas da cidade de 35 min, ou null. */
function awr_cidade_35min( $cidade ) {
	$n = awr_norm_cidade( $cidade );
	if ( '' === $n ) { return null; }
	foreach ( awr_cidades_35min() as $nome => $geo ) {
		$k = awr_norm_cidade( $nome );
		if ( $k === $n || 0 === strpos( $k, $n ) || 0 === strpos( $n, $k ) ) { return $geo; }
	}
	return null;
}

function awr_haversine_km( $a, $b ) {
	$r    = 6371;
	$dlat = deg2rad( $b[0] - $a[0] );
	$dlng = deg2rad( $b[1] - $a[1] );
	$x    = sin( $dlat / 2 ) ** 2 + cos( deg2rad( $a[0] ) ) * cos( deg2rad( $b[0] ) ) * sin( $dlng / 2 ) ** 2;
	return 2 * $r * asin( sqrt( $x ) );
}

/** Distância aproximada (km) da cidade até a loja mais próxima. */
function awr_distancia_loja_km( $cidade ) {
	$geo = awr_cidade_35min( $cidade );
	if ( ! $geo ) { return null; }
	$best = null;
	foreach ( awr_lojas_geo() as $loja ) {
		$d = awr_haversine_km( $geo, $loja );
		if ( null === $best || $d < $best ) { $best = $d; }
	}
	return $best;
}

/** 'rapida' | 'consultar' | 'fora-rs' */
function awr_regiao_atendimento( $cidade = '', $uf = '' ) {
	$estado = strtoupper( trim( (string) $uf ) );
	if ( $estado && 'RS' !== $estado ) { return 'fora-rs'; }
	if ( ! $cidade ) { return 'rapida'; }
	return awr_cidade_35min( $cidade ) ? 'rapida' : 'consultar';
}

function awr_aviso_consultar_regiao() {
	return 'Ainda não temos entrega em 35 minutos na sua região. Vamos verificar a disponibilidade de atendimento e confirmar tudo com você pelo WhatsApp.';
}

function awr_aviso_fora_rs() {
	return 'No momento não estamos atendendo a sua região — nossa operação de entrega e instalação cobre apenas o Rio Grande do Sul.';
}

/** Taxa de entrega (R$) para o horário/cidade informados.
 *  POA: grátis no comercial (qualquer distância), R$ 60 no plantão.
 *  Demais cidades: R$ 20 acima de 12 km da loja, sem plantão. */
function awr_taxa_entrega( $min, $cidade = '', $ts = null ) {
	if ( ! awr_eh_porto_alegre( $cidade ) ) {
		$km = awr_distancia_loja_km( $cidade );
		return ( null !== $km && $km > AWR_RAIO_SEM_TAXA_KM ) ? AWR_TAXA_DISTANCIA : 0;
	}
	if ( $min >= AWR_PLANTAO_MANHA_INICIO && $min <= AWR_PLANTAO_MANHA_FIM ) { return AWR_TAXA_PLANTAO; }
	if ( $min >= AWR_PLANTAO_NOITE_INICIO && $min <= AWR_PLANTAO_NOITE_FIM ) { return AWR_TAXA_PLANTAO; }
	return 0;
}

/** Texto único de horários, usado em FAQs e blocos de conteúdo. */
function awr_texto_horarios() {
	return 'Em Porto Alegre há plantão das 06:30 às 22h todos os dias, inclusive fins de semana e feriados — taxa de R$ 60,00 nos horários de plantão (06:30–08:30 e 18:01–22:00) e entrega grátis das 08:31 às 18h. Porto Alegre, Canoas, Gravataí, Cachoeirinha, São Leopoldo, Novo Hamburgo e Campo Bom têm entrega em até 35 minutos; Esteio e Sapucaia do Sul, em até 40 minutos; Alvorada, Viamão, Nova Santa Rita, Estância Velha e Sapiranga recebem durante o dia para pedidos confirmados até as 17h; Guaíba e Eldorado do Sul recebem no dia seguinte.';
}
