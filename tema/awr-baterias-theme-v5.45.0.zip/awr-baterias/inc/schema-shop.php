<?php
/**
 * Dados estruturados (schema.org) da loja e das páginas de produto.
 *
 * - BreadcrumbList em /loja/, /loja/c/{cat}/, produto Woo e /bateria/{sku}/.
 * - ItemList com resumo Product (nome, imagem, sku, marca e oferta) nas
 *   listagens da loja, para habilitar rich results de catálogo.
 * O schema Product completo continua em awr_product_schema() (inc/woo.php).
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Monta um BreadcrumbList a partir de pares nome/url.
 *
 * @param array  $trilha Lista de array( 'nome' => ..., 'url' => ... ). O último item pode vir sem url.
 * @param string $id     Âncora @id do bloco.
 * @return array|null
 */
function awr_breadcrumb_schema( $trilha, $id = '' ) {
	$items = array();
	foreach ( array_values( (array) $trilha ) as $i => $item ) {
		$nome = trim( (string) ( $item['nome'] ?? '' ) );
		if ( '' === $nome ) { continue; }
		$entry = array(
			'@type'    => 'ListItem',
			'position' => count( $items ) + 1,
			'name'     => $nome,
		);
		if ( ! empty( $item['url'] ) ) { $entry['item'] = (string) $item['url']; }
		$items[] = $entry;
	}
	if ( count( $items ) < 2 ) { return null; }

	$schema = array(
		'@context'        => 'https://schema.org',
		'@type'           => 'BreadcrumbList',
		'itemListElement' => $items,
	);
	if ( $id ) { $schema['@id'] = $id; }
	return $schema;
}

/** Resumo Product usado dentro do ItemList das listagens. */
function awr_shop_product_summary( $p, $position ) {
	$url = ! empty( $p['permalink'] ) ? (string) $p['permalink'] : '';
	if ( ! $url && ! empty( $p['sku'] ) ) { $url = home_url( '/bateria/' . strtolower( (string) $p['sku'] ) . '/' ); }
	if ( ! $url ) { return null; }

	$sku   = strtoupper( trim( (string) ( $p['sku'] ?? '' ) ) );
	$name  = trim( (string) ( $p['name'] ?? ( $sku ? 'Bateria ' . $sku : '' ) ) );
	$price = (float) ( $p['price'] ?? 0 );
	if ( '' === $name ) { return null; }

	$product = array(
		'@type' => 'Product',
		'name'  => $name,
		'url'   => $url,
	);
	if ( function_exists( 'awr_schema_valid_sku' ) && awr_schema_valid_sku( $sku ) ) {
		$product['sku'] = $sku;
		$product['mpn'] = $sku;
	}
	if ( ! empty( $p['brand'] ) ) {
		$product['brand'] = array( '@type' => 'Brand', 'name' => (string) $p['brand'] );
	}
	if ( ! empty( $p['image'] ) ) { $product['image'] = array( (string) $p['image'] ); }
	if ( $price > 0 && empty( $p['sob_consulta'] ) ) {
		$product['offers'] = array(
			'@type'         => 'Offer',
			'url'           => $url,
			'price'         => number_format( $price, 2, '.', '' ),
			'priceCurrency' => 'BRL',
			'itemCondition' => 'https://schema.org/NewCondition',
			'availability'  => ( ! isset( $p['in_stock'] ) || $p['in_stock'] )
				? 'https://schema.org/InStock'
				: 'https://schema.org/OutOfStock',
			'seller'        => array( '@type' => 'Organization', 'name' => 'AWR Baterias' ),
		);
	}

	return array(
		'@type'    => 'ListItem',
		'position' => (int) $position,
		'item'     => $product,
	);
}

/**
 * ItemList com resumo Product para uma listagem da loja.
 *
 * @param array  $produtos Produtos hidratados (awr_shop_query).
 * @param string $nome     Nome da lista.
 * @param string $url      URL da listagem (@id).
 * @param int    $offset   Deslocamento de posição por paginação.
 * @return array|null
 */
function awr_shop_itemlist_schema( $produtos, $nome, $url, $offset = 0 ) {
	$items = array();
	foreach ( array_values( (array) $produtos ) as $i => $p ) {
		$entry = awr_shop_product_summary( $p, $offset + $i + 1 );
		if ( $entry ) { $items[] = $entry; }
	}
	if ( ! $items ) { return null; }

	return array(
		'@context'        => 'https://schema.org',
		'@type'           => 'ItemList',
		'@id'             => $url . '#produtos',
		'name'            => $nome,
		'url'             => $url,
		'numberOfItems'   => count( $items ),
		'itemListOrder'   => 'https://schema.org/ItemListOrderAscending',
		'itemListElement' => $items,
	);
}

/** Emite os dados estruturados da loja e do produto. */
add_action( 'wp_footer', function () {
	$route = function_exists( 'awr_current_route' ) ? awr_current_route() : '';
	$loja  = home_url( '/loja/' );

	// --- Listagens da loja: BreadcrumbList + ItemList (Product) ---
	if ( in_array( $route, array( 'shop', 'shop_page', 'shop_cat', 'shop_cat_page' ), true ) && function_exists( 'awr_shop_query' ) ) {
		$cat   = in_array( $route, array( 'shop_cat', 'shop_cat_page' ), true ) ? awr_param_a() : '';
		$page  = 1;
		if ( 'shop_page' === $route ) { $page = max( 1, (int) awr_param_a() ); }
		if ( 'shop_cat_page' === $route ) { $page = max( 1, (int) awr_param_b() ); }
		$ordem = function_exists( 'awr_shop_order' ) ? awr_shop_order() : 'relevancia';
		$term  = $cat && function_exists( 'awr_shop_categoria_by_slug' ) ? awr_shop_categoria_by_slug( $cat ) : null;
		$res   = awr_shop_query( $cat, $page, $ordem );
		$url   = awr_shop_url( $cat, $page, '' );
		$nome  = $term ? $term['nome'] : 'Loja de baterias AWR';

		$trilha = array( array( 'nome' => 'Início', 'url' => home_url( '/' ) ), array( 'nome' => 'Loja', 'url' => $loja ) );
		if ( $term ) { $trilha[] = array( 'nome' => $term['nome'], 'url' => awr_shop_url( $cat, 1, '' ) ); }
		if ( $page > 1 ) { $trilha[] = array( 'nome' => 'Página ' . $page, 'url' => $url ); }

		$bc = awr_breadcrumb_schema( $trilha, $url . '#breadcrumb' );
		if ( $bc ) { awr_jsonld( $bc ); }

		$per  = defined( 'AWR_SHOP_PER_PAGE' ) ? (int) AWR_SHOP_PER_PAGE : 24;
		$list = awr_shop_itemlist_schema( $res['produtos'] ?? array(), $nome, $url, ( $page - 1 ) * $per );
		if ( $list ) { awr_jsonld( $list ); }
		return;
	}

	// --- Produto WooCommerce: BreadcrumbList (Product já sai em routes/produto.php) ---
	if ( function_exists( 'is_product' ) && is_product() ) {
		$pid    = get_queried_object_id();
		$trilha = array(
			array( 'nome' => 'Início', 'url' => home_url( '/' ) ),
			array( 'nome' => 'Loja', 'url' => $loja ),
		);
		$terms = get_the_terms( $pid, 'product_cat' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$t        = $terms[0];
			$trilha[] = array( 'nome' => $t->name, 'url' => awr_shop_url( $t->slug, 1, '' ) );
		}
		$trilha[] = array( 'nome' => get_the_title( $pid ), 'url' => get_permalink( $pid ) );

		$bc = awr_breadcrumb_schema( $trilha, get_permalink( $pid ) . '#breadcrumb' );
		if ( $bc ) { awr_jsonld( $bc ); }
		return;
	}

	// --- Página de SKU do tema: /bateria/{sku}/ ---
	// v3.82.0 — a trilha estruturada espelha exatamente a trilha visível de routes/sku.php.
	if ( 'sku' === $route ) {
		$sku = strtoupper( (string) awr_param_a() );
		$url = home_url( '/bateria/' . strtolower( $sku ) . '/' );
		$bc  = awr_breadcrumb_schema(
			array(
				array( 'nome' => 'Início', 'url' => home_url( '/' ) ),
				array( 'nome' => 'Modelos de bateria', 'url' => home_url( '/baterias/' ) ),
				array( 'nome' => 'Bateria ' . $sku, 'url' => $url ),
			),
			$url . '#breadcrumb'
		);
		if ( $bc ) { awr_jsonld( $bc ); }
	}
}, 7 );
