<?php
/**
 * Calendário editorial do blog (painel em Posts → Calendário editorial).
 *
 * Fluxo: Pauta → Em produção → Revisão SEO → Revisão técnica → Aprovado → Agendado → Publicado.
 * - Usa posts nativos do WordPress (draft → future → publish) e o agendamento nativo.
 * - Nada é agendado sem aprovação explícita de um Editor (edit_others_posts).
 * - Posts publicados pelo calendário entram em /blog/{slug}/ pelo mesmo template dos guias.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const AWR_ED_OPT    = 'awr_editorial_estado';
const AWR_ED_META   = '_awr_editorial_id';
const AWR_ED_STATUS = array( 'pauta' => 'Pauta', 'producao' => 'Em produção', 'rev_seo' => 'Revisão SEO', 'rev_tec' => 'Revisão técnica', 'aprovado' => 'Aprovado', 'agendado' => 'Agendado', 'publicado' => 'Publicado' );

/** Pautas aprovadas (assets/data/calendario-editorial.json). */
function awr_ed_itens() {
	$d = awr_data( 'calendario-editorial' );
	return is_array( $d ) && ! empty( $d['itens'] ) ? $d['itens'] : array();
}

function awr_ed_estado() { $e = get_option( AWR_ED_OPT, array() ); return is_array( $e ) ? $e : array(); }

/** Item do calendário + alterações salvas no painel + estado real do post. */
function awr_ed_item( $base ) {
	$e   = awr_ed_estado();
	$it  = array_merge( $base, (array) ( $e[ $base['id'] ] ?? array() ) );
	$it['status'] = $it['status'] ?? 'pauta';
	if ( ! empty( $it['post_id'] ) ) {
		$ps = get_post_status( (int) $it['post_id'] );
		if ( 'publish' === $ps ) { $it['status'] = 'publicado'; }
		elseif ( 'future' === $ps ) { $it['status'] = 'agendado'; }
		elseif ( false === $ps ) { $it['post_id'] = 0; }
	}
	return $it;
}

function awr_ed_salvar( $id, $campos ) {
	$e        = awr_ed_estado();
	$e[ $id ] = array_merge( (array) ( $e[ $id ] ?? array() ), $campos );
	update_option( AWR_ED_OPT, $e, false );
}

/** Data/hora local (America/Sao_Paulo) no formato do WordPress. */
function awr_ed_datetime( $it ) {
	$tz = new DateTimeZone( 'America/Sao_Paulo' );
	$dt = DateTime::createFromFormat( 'Y-m-d H:i', $it['data'] . ' ' . $it['hora'], $tz );
	return $dt ? $dt : new DateTime( 'now', $tz );
}

add_action( 'admin_menu', function () {
	add_posts_page( 'Calendário editorial', 'Calendário editorial', 'edit_posts', 'awr-calendario', 'awr_ed_pagina' );
} );

/** Ações do painel (todas com nonce e checagem de permissão). */
add_action( 'admin_post_awr_ed', function () {
	if ( ! current_user_can( 'edit_posts' ) ) { wp_die( 'Sem permissão.' ); }
	check_admin_referer( 'awr_ed' );
	$id   = sanitize_text_field( wp_unslash( $_POST['id'] ?? '' ) );
	$acao = sanitize_key( $_POST['acao'] ?? '' );
	$base = null;
	foreach ( awr_ed_itens() as $b ) { if ( $b['id'] === $id ) { $base = $b; break; } }
	if ( ! $base ) { wp_die( 'Pauta não encontrada.' ); }
	$it  = awr_ed_item( $base );
	$msg = 'ok';

	if ( 'salvar' === $acao ) {
		$novo = array(
			'titulo'      => sanitize_text_field( wp_unslash( $_POST['titulo'] ?? $it['titulo'] ) ),
			'data'        => preg_match( '/^\d{4}-\d{2}-\d{2}$/', $_POST['data'] ?? '' ) ? $_POST['data'] : $it['data'],
			'hora'        => preg_match( '/^\d{2}:\d{2}$/', $_POST['hora'] ?? '' ) ? $_POST['hora'] : $it['hora'],
			'responsavel' => sanitize_text_field( wp_unslash( $_POST['responsavel'] ?? '' ) ),
		);
		$st = sanitize_key( $_POST['status'] ?? $it['status'] );
		// Aprovado/Agendado/Publicado só pelos botões próprios.
		if ( isset( AWR_ED_STATUS[ $st ] ) && ! in_array( $st, array( 'aprovado', 'agendado', 'publicado' ), true ) ) { $novo['status'] = $st; }
		awr_ed_salvar( $id, $novo );
		// Data mudou depois de agendado: reagenda o post nativo.
		if ( 'agendado' === $it['status'] && ! empty( $it['post_id'] ) ) {
			$dt = awr_ed_datetime( array_merge( $it, $novo ) );
			wp_update_post( array( 'ID' => (int) $it['post_id'], 'post_date' => $dt->format( 'Y-m-d H:i:s' ), 'post_date_gmt' => get_gmt_from_date( $dt->format( 'Y-m-d H:i:s' ) ), 'edit_date' => true ) );
		}
	} elseif ( 'rascunho' === $acao && empty( $it['post_id'] ) ) {
		$links = '';
		foreach ( (array) ( $it['links'] ?? array() ) as $l ) { $links .= '<li><a href="' . esc_url( home_url( $l ) ) . '">' . esc_html( $l ) . '</a></li>'; }
		$corpo = '<!-- wp:paragraph --><p><em>Rascunho criado pelo calendário. Escreva o artigo completo (introdução, H2/H3, FAQ). Não invente preços, garantias, estoques ou especificações; não prometa 24h; 35 min só onde for real.</em></p><!-- /wp:paragraph -->'
			. '<!-- wp:heading --><h2>Links internos sugeridos</h2><!-- /wp:heading --><!-- wp:list --><ul>' . $links . '</ul><!-- /wp:list -->';
		// Rascunho redigido (calendario-editorial.json → corpo) substitui o esqueleto; continua em revisão.
		if ( ! empty( $it['corpo'] ) ) { $corpo = wp_kses_post( $it['corpo'] ); }
		$pid = wp_insert_post( array(
			'post_type' => 'post', 'post_status' => 'draft', 'post_title' => $it['titulo'], 'post_name' => $it['slug'],
			'post_excerpt' => $it['meta'], 'post_content' => $corpo,
			'meta_input' => array( AWR_ED_META => $id, '_awr_title_seo' => $it['titleSeo'], '_awr_categoria' => $it['categoria'] ),
		), true );
		if ( is_wp_error( $pid ) ) { $msg = 'erro'; } else { awr_ed_salvar( $id, array( 'post_id' => $pid, 'status' => 'producao' ) ); }
	} elseif ( 'aprovar' === $acao ) {
		if ( ! current_user_can( 'edit_others_posts' ) ) { wp_die( 'Somente Editor ou Administrador aprova.' ); }
		if ( empty( $it['post_id'] ) || 'rev_tec' !== $it['status'] ) { $msg = 'fluxo'; }
		else { awr_ed_salvar( $id, array( 'status' => 'aprovado', 'aprovado_por' => get_current_user_id(), 'aprovado_em' => current_time( 'mysql' ) ) ); }
	} elseif ( 'agendar' === $acao ) {
		if ( ! current_user_can( 'publish_posts' ) ) { wp_die( 'Sem permissão para agendar.' ); }
		if ( 'aprovado' !== $it['status'] || empty( $it['post_id'] ) ) { $msg = 'fluxo'; }
		else {
			$dt  = awr_ed_datetime( $it );
			$loc = $dt->format( 'Y-m-d H:i:s' );
			wp_update_post( array( 'ID' => (int) $it['post_id'], 'post_title' => $it['titulo'], 'post_status' => $dt->getTimestamp() > time() ? 'future' : 'publish', 'post_date' => $loc, 'post_date_gmt' => get_gmt_from_date( $loc ), 'edit_date' => true ) );
			awr_ed_salvar( $id, array( 'status' => 'agendado' ) );
			delete_transient( 'awr_wp_posts_blog' );
		}
	}
	wp_safe_redirect( add_query_arg( array( 'page' => 'awr-calendario', 'mes' => sanitize_text_field( $_POST['mes'] ?? '' ), 'awr_msg' => $msg ), admin_url( 'edit.php' ) ) );
	exit;
} );

/** Diagnóstico do agendamento nativo (WP-Cron). */
function awr_ed_cron_aviso() {
	$avisos = array();
	if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) { $avisos[] = 'DISABLE_WP_CRON está ativo: confirme que existe um cron real chamando wp-cron.php a cada 5–15 minutos.'; }
	$perdidos = get_posts( array( 'post_status' => 'future', 'date_query' => array( array( 'before' => gmdate( 'Y-m-d H:i:s', time() - 900 ), 'column' => 'post_date_gmt' ) ), 'fields' => 'ids', 'numberposts' => 20 ) );
	if ( $perdidos ) { $avisos[] = count( $perdidos ) . ' post(s) agendado(s) passaram do horário sem publicar (agendamento perdido). Verifique o WP-Cron.'; }
	return $avisos;
}

function awr_ed_pagina() {
	$itens = array_map( 'awr_ed_item', awr_ed_itens() );
	$meses = array_values( array_unique( array_map( function ( $i ) { return substr( $i['data'], 0, 7 ); }, $itens ) ) );
	sort( $meses );
	$mes   = sanitize_text_field( $_GET['mes'] ?? '' );
	if ( ! in_array( $mes, $meses, true ) ) { $mes = $meses[0] ?? ''; }
	$cat   = sanitize_text_field( wp_unslash( $_GET['cat'] ?? '' ) );
	$hoje  = wp_date( 'Y-m-d' );
	$lista = array_filter( $itens, function ( $i ) use ( $mes, $cat ) { return 0 === strpos( $i['data'], $mes ) && ( '' === $cat || $i['categoria'] === $cat ); } );
	usort( $lista, function ( $a, $b ) { return strcmp( $a['data'] . $a['hora'], $b['data'] . $b['hora'] ); } );
	$cats  = array_values( array_unique( array_column( $itens, 'categoria' ) ) );
	$tot   = array( 'previstas' => 0, 'publicadas' => 0, 'atrasadas' => 0 );
	foreach ( $lista as $i ) { $tot['previstas']++; if ( 'publicado' === $i['status'] ) { $tot['publicadas']++; } elseif ( $i['data'] < $hoje ) { $tot['atrasadas']++; } }
	$msgs  = array( 'fluxo' => 'Ação fora do fluxo: aprovar exige status "Revisão técnica" com rascunho; agendar exige "Aprovado".', 'erro' => 'Não foi possível criar o rascunho.', 'ok' => 'Salvo.' );
	?>
	<div class="wrap">
		<h1>Calendário editorial do blog</h1>
		<p>12 publicações por mês · fuso America/Sao_Paulo · <strong>nada é agendado sem aprovação de um Editor</strong>.</p>
		<?php if ( isset( $_GET['awr_msg'], $msgs[ $_GET['awr_msg'] ] ) ) : ?><div class="notice notice-<?php echo 'ok' === $_GET['awr_msg'] ? 'success' : 'warning'; ?>"><p><?php echo esc_html( $msgs[ $_GET['awr_msg'] ] ); ?></p></div><?php endif; ?>
		<?php foreach ( awr_ed_cron_aviso() as $a ) : ?><div class="notice notice-error"><p><?php echo esc_html( $a ); ?></p></div><?php endforeach; ?>
		<form method="get" style="margin:12px 0">
			<input type="hidden" name="page" value="awr-calendario">
			<select name="mes"><?php foreach ( $meses as $m ) : ?><option value="<?php echo esc_attr( $m ); ?>" <?php selected( $m, $mes ); ?>><?php echo esc_html( wp_date( 'F Y', strtotime( $m . '-15' ) ) ); ?></option><?php endforeach; ?></select>
			<select name="cat"><option value="">Todas as categorias</option><?php foreach ( $cats as $c ) : ?><option <?php selected( $c, $cat ); ?>><?php echo esc_html( $c ); ?></option><?php endforeach; ?></select>
			<button class="button">Filtrar</button>
			<span style="margin-left:16px">Previstas: <strong><?php echo (int) $tot['previstas']; ?></strong> · Publicadas: <strong><?php echo (int) $tot['publicadas']; ?></strong> · Atrasadas: <strong style="color:#b32d2e"><?php echo (int) $tot['atrasadas']; ?></strong></span>
		</form>
		<table class="widefat striped">
			<thead><tr><th>Data / hora</th><th>Título e ficha SEO</th><th>Categoria</th><th>Status e responsável</th><th>Ações</th></tr></thead>
			<tbody>
			<?php foreach ( $lista as $i ) :
				$atraso = 'publicado' !== $i['status'] && $i['data'] < $hoje; ?>
				<tr<?php echo $atraso ? ' style="background:#fcf0f1"' : ''; ?>>
					<td>					<form id="awr-ed-<?php echo esc_attr( md5( $i['id'] ) ); ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
<?php wp_nonce_field( 'awr_ed' ); ?>
					<input type="hidden" name="action" value="awr_ed"><input type="hidden" name="id" value="<?php echo esc_attr( $i['id'] ); ?>"><input type="hidden" name="mes" value="<?php echo esc_attr( $mes ); ?>"></form><input form="awr-ed-<?php echo esc_attr( md5( $i['id'] ) ); ?>" type="date" name="data" value="<?php echo esc_attr( $i['data'] ); ?>"><br><input form="awr-ed-<?php echo esc_attr( md5( $i['id'] ) ); ?>" type="time" name="hora" value="<?php echo esc_attr( $i['hora'] ); ?>"><?php echo $atraso ? '<br><strong style="color:#b32d2e">Atrasado</strong>' : ''; ?></td>
					<td style="max-width:420px"><input form="awr-ed-<?php echo esc_attr( md5( $i['id'] ) ); ?>" type="text" name="titulo" value="<?php echo esc_attr( $i['titulo'] ); ?>" style="width:100%">
						<details><summary>Ficha SEO (<?php echo esc_html( $i['id'] ); ?>)</summary>
							<p><strong>Title:</strong> <?php echo esc_html( $i['titleSeo'] ); ?><br><strong>Meta:</strong> <?php echo esc_html( $i['meta'] ); ?><br><strong>URL:</strong> /blog/<?php echo esc_html( $i['slug'] ); ?>/<br><strong>Links:</strong> <?php echo esc_html( implode( ' · ', (array) $i['links'] ) ); ?><br><strong>Impressões GSC (aprox.):</strong> <?php echo (int) $i['impressoes']; ?></p>
						</details></td>
					<td><?php echo esc_html( $i['categoria'] ); ?></td>
					<td><select form="awr-ed-<?php echo esc_attr( md5( $i['id'] ) ); ?>" name="status"><?php foreach ( AWR_ED_STATUS as $k => $l ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( $k, $i['status'] ); ?> <?php disabled( in_array( $k, array( 'aprovado', 'agendado', 'publicado' ), true ) && $k !== $i['status'] ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?></select>
						<br><input form="awr-ed-<?php echo esc_attr( md5( $i['id'] ) ); ?>" type="text" name="responsavel" placeholder="Responsável" value="<?php echo esc_attr( $i['responsavel'] ?? '' ); ?>"></td>
					<td>
						<button form="awr-ed-<?php echo esc_attr( md5( $i['id'] ) ); ?>" class="button" name="acao" value="salvar">Salvar</button>
						<?php if ( empty( $i['post_id'] ) ) : ?><button form="awr-ed-<?php echo esc_attr( md5( $i['id'] ) ); ?>" class="button" name="acao" value="rascunho">Criar rascunho</button><?php else : ?>
							<a class="button" href="<?php echo esc_url( get_edit_post_link( (int) $i['post_id'] ) ); ?>">Editar texto</a>
						<?php endif; ?>
						<?php if ( 'rev_tec' === $i['status'] && current_user_can( 'edit_others_posts' ) ) : ?><button form="awr-ed-<?php echo esc_attr( md5( $i['id'] ) ); ?>" class="button button-primary" name="acao" value="aprovar">Aprovar</button><?php endif; ?>
						<?php if ( 'aprovado' === $i['status'] ) : ?><button form="awr-ed-<?php echo esc_attr( md5( $i['id'] ) ); ?>" class="button button-primary" name="acao" value="agendar">Agendar no WordPress</button><?php endif; ?>
						<?php if ( 'publicado' === $i['status'] ) : ?><a class="button" href="<?php echo esc_url( home_url( '/blog/' . get_post_field( 'post_name', (int) $i['post_id'] ) . '/' ) ); ?>" target="_blank">Ver artigo</a><?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php
}

/**
 * Posts publicados pelo calendário no formato do dataset do blog
 * (entram em /blog/, /blog/{slug}/, sitemap e links internos).
 */
function awr_ed_posts_publicados() {
	$c = get_transient( 'awr_wp_posts_blog' );
	if ( is_array( $c ) ) { return $c; }
	$out = array();
	$q   = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 200, 'meta_key' => AWR_ED_META, 'orderby' => 'date', 'order' => 'DESC', 'suppress_filters' => false ) );
	foreach ( $q as $wp ) {
		$out[] = array(
			'slug'            => $wp->post_name,
			'titulo'          => get_post_meta( $wp->ID, '_awr_title_seo', true ) ?: $wp->post_title,
			'h1'              => $wp->post_title,
			'descricao'       => $wp->post_excerpt,
			'categoria'       => get_post_meta( $wp->ID, '_awr_categoria', true ) ?: 'Guia',
			'cidadeAlvo'      => 'Porto Alegre',
			'tempoLeitura'    => max( 2, (int) ceil( str_word_count( wp_strip_all_tags( $wp->post_content ) ) / 200 ) ),
			'dataPublicacao'  => get_post_time( 'c', false, $wp ),
			'dataAtualizacao' => get_post_modified_time( 'c', false, $wp ),
			'wp_id'           => $wp->ID,
			'relacionados'    => array(),
		);
	}
	set_transient( 'awr_wp_posts_blog', $out, HOUR_IN_SECONDS );
	return $out;
}
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( 'post' === $post->post_type ) { delete_transient( 'awr_wp_posts_blog' ); }
}, 10, 3 );
add_action( 'save_post_post', function () { delete_transient( 'awr_wp_posts_blog' ); } );

/** O permalink nativo de um post do calendário passa a ser /blog/{slug}/. */
add_filter( 'post_link', function ( $url, $post ) {
	return get_post_meta( $post->ID, AWR_ED_META, true ) ? home_url( '/blog/' . $post->post_name . '/' ) : $url;
}, 10, 2 );
add_action( 'template_redirect', function () {
	if ( is_singular( 'post' ) && get_post_meta( get_queried_object_id(), AWR_ED_META, true ) ) {
		wp_safe_redirect( home_url( '/blog/' . get_post_field( 'post_name', get_queried_object_id() ) . '/' ), 301 );
		exit;
	}
}, 1 );
