<?php
/**
 * Vertical de motos — paridade com src/lib/moto.ts do app.
 *
 * Identifica os itens de moto do catálogo (HTZ/HTX/HT12A/MTX/MTZ/MBTX/MBTZ) e monta
 * o índice Marca > Modelo > Ano usado pelo seletor e pelas páginas de marca.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Item do catálogo é de linha moto? */
function awr_is_moto_item( $it ) {
	foreach ( array( 'h', 'm', 'z', 'e' ) as $k ) {
		$s = isset( $it[ $k ] ) ? trim( (string) $it[ $k ] ) : '';
		if ( '' !== $s && preg_match( '/^(HTZ|HTX|HT12A|MTX|MTZ|MBTX|MBTZ)/i', $s ) ) { return true; }
	}
	return false;
}

/** Title case igual ao do app. */
function awr_moto_tc( $s ) {
	$parts = explode( ' ', mb_strtolower( trim( (string) $s ), 'UTF-8' ) );
	foreach ( $parts as $i => $w ) {
		if ( '' === $w ) { continue; }
		$parts[ $i ] = ( mb_strlen( $w, 'UTF-8' ) <= 2 && ! preg_match( '/^\d/', $w ) )
			? mb_strtoupper( $w, 'UTF-8' )
			: mb_strtoupper( mb_substr( $w, 0, 1, 'UTF-8' ), 'UTF-8' ) . mb_substr( $w, 1, null, 'UTF-8' );
	}
	return trim( preg_replace( '/\s+/', ' ', implode( ' ', $parts ) ) );
}

/** Índice de modelos de moto: slug (marca-modelo) => dados. */
function awr_moto_models() {
	static $out = null;
	if ( null !== $out ) { return $out; }

	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		if ( ! awr_is_moto_item( $it ) ) { continue; }
		$slug = awr_slugify( $it['ma'] . ' ' . $it['mo'] );
		$skus = array();
		foreach ( array( 'h', 'm', 'z', 'e' ) as $k ) {
			$s = isset( $it[ $k ] ) ? trim( (string) $it[ $k ] ) : '';
			if ( '' !== $s ) { $skus[] = $s; }
		}
		if ( ! isset( $out[ $slug ] ) ) {
			$out[ $slug ] = array(
				'slug'       => $slug,
				'marca'      => awr_moto_tc( $it['ma'] ),
				'marca_slug' => awr_slugify( $it['ma'] ),
				'modelo'     => awr_moto_tc( $it['mo'] ),
				'label'      => awr_moto_tc( $it['ma'] ) . ' ' . awr_moto_tc( $it['mo'] ),
				'de'         => (int) $it['d'],
				'ate'        => (int) $it['a'],
				'skus'       => $skus,
			);
		} else {
			$out[ $slug ]['de']   = min( $out[ $slug ]['de'], (int) $it['d'] );
			$out[ $slug ]['ate']  = max( $out[ $slug ]['ate'], (int) $it['a'] );
			$out[ $slug ]['skus'] = array_values( array_unique( array_merge( $out[ $slug ]['skus'], $skus ) ) );
		}
	}

	foreach ( $out as $slug => $m ) {
		$ahs = array();
		foreach ( $m['skus'] as $s ) {
			$ah = awr_extract_amperage( $s );
			if ( $ah ) { $ahs[ (int) $ah ] = (int) $ah; }
		}
		sort( $ahs );
		$out[ $slug ]['ahs'] = array_values( $ahs );
	}

	uasort( $out, function ( $a, $b ) { return strcoll( $a['label'], $b['label'] ); } );
	return $out;
}

/** Marcas de moto com total de modelos, ordenadas por cobertura. */
function awr_moto_brands() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$out = array();
	foreach ( awr_moto_models() as $m ) {
		if ( isset( $out[ $m['marca_slug'] ] ) ) {
			$out[ $m['marca_slug'] ]['total']++;
		} else {
			$out[ $m['marca_slug'] ] = array( 'slug' => $m['marca_slug'], 'nome' => $m['marca'], 'total' => 1 );
		}
	}
	uasort( $out, function ( $a, $b ) {
		return $b['total'] === $a['total'] ? strcoll( $a['nome'], $b['nome'] ) : $b['total'] - $a['total'];
	} );
	return $out;
}

function awr_moto_brand( $slug ) {
	$b = awr_moto_brands();
	return isset( $b[ $slug ] ) ? $b[ $slug ] : null;
}

function awr_moto_models_by_brand( $marca_slug ) {
	$out = array();
	foreach ( awr_moto_models() as $m ) {
		if ( $m['marca_slug'] === $marca_slug ) { $out[] = $m; }
	}
	return $out;
}

/** Faixa de amperagem apresentável ("5Ah" ou "5Ah a 12Ah"). */
function awr_moto_ah_range( $ahs ) {
	$ahs = array_values( (array) $ahs );
	if ( ! $ahs ) { return '5Ah a 12Ah'; }
	if ( 1 === count( $ahs ) ) { return $ahs[0] . 'Ah'; }
	return $ahs[0] . 'Ah a ' . end( $ahs ) . 'Ah';
}

/** Modelos em destaque (mais buscados na região), como no app. */
function awr_moto_destaques( $limit = 12 ) {
	$prefer = array( 'cg', 'fan', 'titan', 'biz', 'pop', 'factor', 'fazer', 'xre', 'bros', 'nxr', 'twister', 'cb' );
	$top    = array();
	$resto  = array();
	foreach ( awr_moto_models() as $m ) {
		$mo  = mb_strtolower( $m['modelo'], 'UTF-8' );
		$hit = false;
		foreach ( $prefer as $p ) {
			if ( false !== mb_strpos( $mo, $p, 0, 'UTF-8' ) ) { $hit = true; break; }
		}
		if ( $hit ) { $top[] = $m; } else { $resto[] = $m; }
	}
	return array_slice( array_merge( $top, $resto ), 0, $limit );
}

/** FAQ do vertical de motos (paridade com FAQ_MOTO do app). */
function awr_moto_faq() {
	return array(
		array(
			'q' => 'Quanto tempo dura uma bateria de moto?',
			'r' => 'Em uso urbano regular, de 2 a 3 anos. Moto que fica muito tempo parada ou que roda só trechos curtos costuma reduzir esse prazo, porque a bateria não completa a recarga.',
		),
		array(
			'q' => 'Qual a diferença entre bateria AGM e convencional de moto?',
			'r' => 'A convencional tem eletrólito líquido e pede reposição de água destilada. A AGM é selada, não exige manutenção, resiste melhor à vibração e à moto parada por períodos longos, e mantém a partida mais estável no frio.',
		),
		array(
			'q' => 'Como saber a voltagem e a amperagem da bateria da minha moto?',
			'r' => 'A voltagem é 12V em praticamente todas as motos de rua. A amperagem varia: 5Ah nas 125 a 160cc, 6Ah a 9Ah nas 250 e 300cc e 12Ah em big trail e custom. Selecione marca, modelo e ano na busca acima que mostramos a bateria correta.',
		),
		array(
			'q' => 'Como instalar a bateria de moto com segurança?',
			'r' => 'Com a moto desligada, remova primeiro o cabo negativo e depois o positivo, encaixe a bateria nova respeitando a polaridade, reconecte o positivo antes do negativo e confira se os terminais estão firmes. Nas cidades com cobertura, a instalação é feita por técnico da AWR sem custo.',
		),
		array(
			'q' => 'Minha moto tem partida no pedal, preciso de bateria?',
			'r' => 'Sim. Mesmo com pedal, a injeção eletrônica, o painel e as luzes dependem da bateria. Sem ela, a moto pode nem funcionar corretamente.',
		),
	);
}

/** URL da página de marca de moto. */
function awr_moto_brand_url( $slug ) {
	return home_url( '/baterias-para-moto/marca/' . $slug . '/' );
}
