<?php
/**
 * Conteúdo regional das páginas de bateria estacionária por cidade.
 *
 * Cada cidade tem perfil de cliente, lista "quem compra" e perguntas próprias,
 * para que as páginas /baterias-estacionarias/{cidade}/ não sejam o mesmo
 * template com o nome trocado.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Perfil regional da cidade na linha estacionária.
 *
 * @param string $slug Slug da cidade.
 * @param string $nome Nome exibido da cidade (fallback do mapa).
 * @return array{perfil:string,quem:array,faq:array}
 */
function awr_est_perfil_cidade( $slug, $nome = '' ) {
	$mapa = array(
		'porto-alegre' => array(
			'perfil' => 'A maior parte dos pedidos da capital vem de salas de TI, clínicas e prédios comerciais do Centro, Moinhos de Vento e Praia de Belas, onde o nobreak sustenta servidor, PABX e controle de acesso.',
			'quem'   => array( 'Salas de servidor e PABX em prédios comerciais', 'Clínicas e consultórios com equipamento sensível', 'Condomínios com portão, interfone e CFTV', 'Lojas com PDV e catraca eletrônica' ),
			'faq'    => array(
				array( 'pergunta' => 'Vocês instalam banco de baterias em prédio comercial em Porto Alegre?', 'resposta' => 'Sim. Trocamos o banco no local, com agendamento fora do horário de pico quando o prédio exige, nota fiscal em CNPJ e recolhimento das baterias antigas no mesmo atendimento.' ),
				array( 'pergunta' => 'Dá para emitir nota em CNPJ para condomínio?', 'resposta' => 'Sim, emitimos nota fiscal em CNPJ do condomínio ou da administradora e enviamos cotação formal antes da compra, para aprovação em assembleia ou pelo síndico.' ),
			),
		),
		'canoas' => array(
			'perfil' => 'Em Canoas o volume vem de indústria, logística e oficinas ao longo da BR-116, além de condomínios que precisam manter portão e CFTV ativos na queda de energia.',
			'quem'   => array( 'Galpões e centros de distribuição', 'Oficinas e lojas de som automotivo', 'Condomínios residenciais e comerciais', 'Empresas com CFTV e cerca elétrica' ),
			'faq'    => array(
				array( 'pergunta' => 'Atendem empresas em Canoas com nota em CNPJ?', 'resposta' => 'Sim. Emitimos nota fiscal em CNPJ, enviamos cotação formal e podemos programar reposição periódica do banco de baterias para a sua operação.' ),
				array( 'pergunta' => 'Quanto tempo leva a entrega em Canoas?', 'resposta' => 'Canoas está na área de entrega própria da AWR: os modelos em estoque saem no mesmo dia, com troca do banco no local.' ),
			),
		),
		'esteio' => array(
			'perfil' => 'Esteio concentra comércio de rua e pequenas empresas que sentem primeiro a queda de energia: PDV, balança e alarme param junto.',
			'quem'   => array( 'Comércio de rua com PDV e balança', 'Pequenas indústrias e prestadores', 'Sistemas de alarme e CFTV', 'Escritórios com nobreak de rack' ),
			'faq'    => array(
				array( 'pergunta' => 'Qual bateria segura o PDV da loja em Esteio?', 'resposta' => 'Para caixa, computador e leitor, normalmente um banco de 7Ah a 18Ah resolve. Mande a potência do nobreak pelo WhatsApp que calculamos a autonomia sem custo.' ),
				array( 'pergunta' => 'Vocês recolhem a bateria velha em Esteio?', 'resposta' => 'Sim, recolhemos o banco antigo na entrega e abatemos o casco no valor da bateria nova.' ),
			),
		),
		'gravatai' => array(
			'perfil' => 'Em Gravataí a procura mistura polo industrial e bairros residenciais grandes, com bastante pedido de energia solar e sistemas de segurança em chácaras e casas afastadas.',
			'quem'   => array( 'Integradores de energia solar off-grid', 'Indústria e prestadores do polo', 'Casas e chácaras com portão e alarme', 'Comércio de bairro com nobreak' ),
			'faq'    => array(
				array( 'pergunta' => 'Tem bateria para sistema solar off-grid em Gravataí?', 'resposta' => 'Sim, trabalhamos com estacionárias VRLA e de ciclo profundo para off-grid. Informe a carga em watts e a autonomia desejada que dimensionamos o banco.' ),
				array( 'pergunta' => 'Atendem chácaras e zonas mais afastadas?', 'resposta' => 'Atendemos Gravataí inteira; para endereços mais distantes confirmamos o prazo pelo WhatsApp antes de fechar o pedido.' ),
			),
		),
		'cachoeirinha' => array(
			'perfil' => 'Cachoeirinha pede muito banco pequeno de nobreak: escritório, consultório e loja que não podem perder o sistema no meio do atendimento.',
			'quem'   => array( 'Escritórios e consultórios', 'Lojas com PDV e câmeras', 'Condomínios com portão automático', 'Pequenas indústrias e depósitos' ),
			'faq'    => array(
				array( 'pergunta' => 'Trocam a bateria do nobreak no local em Cachoeirinha?', 'resposta' => 'Sim. Levamos a bateria, trocamos no local, testamos o nobreak com carga e recolhemos a usada.' ),
				array( 'pergunta' => 'Precisa desligar o sistema para trocar?', 'resposta' => 'Na maioria dos nobreaks a troca é rápida e feita com o equipamento desligado por poucos minutos, combinada com você no melhor horário.' ),
			),
		),
		'alvorada' => array(
			'perfil' => 'Em Alvorada o pedido mais comum é de segurança eletrônica e portão automático em residências e condomínios, além de comércio de bairro.',
			'quem'   => array( 'Portão automático e interfone', 'Alarme, cerca elétrica e CFTV', 'Comércio de bairro', 'Iluminação de emergência' ),
			'faq'    => array(
				array( 'pergunta' => 'Qual bateria usa o portão automático?', 'resposta' => 'Quase sempre 12V de 7Ah, mas alguns centrais usam 5Ah ou 9Ah. Mande a foto da bateria atual pelo WhatsApp que confirmamos o modelo.' ),
				array( 'pergunta' => 'Entregam no mesmo dia em Alvorada?', 'resposta' => 'Sim, para os modelos em estoque a entrega é no mesmo dia dentro do horário de atendimento.' ),
			),
		),
		'viamao' => array(
			'perfil' => 'Viamão tem muita casa, sítio e condomínio horizontal — aqui o banco de baterias costuma sustentar portão, poço e sistema de segurança quando falta luz.',
			'quem'   => array( 'Casas e sítios com portão e bomba', 'Condomínios horizontais', 'Sistemas solares off-grid', 'Alarme e CFTV residencial' ),
			'faq'    => array(
				array( 'pergunta' => 'Bateria estacionária serve para bomba d\'água?', 'resposta' => 'Serve quando ligada a um inversor dimensionado para a bomba. Informe a potência em watts e o tempo de uso que calculamos o banco necessário.' ),
				array( 'pergunta' => 'Atendem o interior de Viamão?', 'resposta' => 'Sim. Confirmamos o prazo pelo WhatsApp conforme o endereço, e em muitos casos entregamos no mesmo dia.' ),
			),
		),
		'sao-leopoldo' => array(
			'perfil' => 'São Leopoldo soma universidade, clínicas e indústria: aqui aparecem bastante bancos maiores, de rack, e reposição programada.',
			'quem'   => array( 'Salas de TI e nobreak de rack', 'Clínicas e laboratórios', 'Indústria e metalúrgicas', 'Comércio e escritórios' ),
			'faq'    => array(
				array( 'pergunta' => 'Fazem reposição programada do banco em São Leopoldo?', 'resposta' => 'Sim. Registramos a data de instalação e avisamos quando o banco se aproxima do fim da vida útil, com cotação antecipada.' ),
				array( 'pergunta' => 'Trabalham com nobreak de rack maior?', 'resposta' => 'Sim, dimensionamos bancos de 12V, 24V e 48V conforme o equipamento e a autonomia desejada.' ),
			),
		),
		'sapucaia-do-sul' => array(
			'perfil' => 'Em Sapucaia do Sul o perfil é industrial e de prestador de serviço, com pedidos de reposição de banco de nobreak e de iluminação de emergência predial.',
			'quem'   => array( 'Indústria e oficinas', 'Iluminação de emergência predial', 'Empresas com CFTV e controle de acesso', 'Comércio local' ),
			'faq'    => array(
				array( 'pergunta' => 'Emitem cotação formal para empresa?', 'resposta' => 'Sim, enviamos cotação com modelo, quantidade, prazo e condição de pagamento para aprovação interna.' ),
				array( 'pergunta' => 'Recolhem o banco antigo da empresa?', 'resposta' => 'Recolhemos e encaminhamos para recicladora licenciada, com comprovante quando a empresa precisa prestar contas.' ),
			),
		),
		'novo-hamburgo' => array(
			'perfil' => 'Novo Hamburgo tem forte presença de indústria calçadista, comércio e clínicas — o uso mais comum é nobreak de escritório e sistemas de segurança.',
			'quem'   => array( 'Indústria e escritórios', 'Clínicas e consultórios', 'Lojas e PDV', 'CFTV e controle de acesso' ),
			'faq'    => array(
				array( 'pergunta' => 'Entregam e instalam em Novo Hamburgo no mesmo dia?', 'resposta' => 'Sim, Novo Hamburgo está na área de entrega própria da AWR, com troca do banco no local.' ),
				array( 'pergunta' => 'Dá para parcelar a compra da empresa?', 'resposta' => 'Sim, parcelamos em até 10x sem juros no cartão, além de Pix com desconto à vista.' ),
			),
		),
		'campo-bom' => array(
			'perfil' => 'Campo Bom pede bastante banco pequeno e médio: comércio, oficinas e casas com sistema de segurança e portão automático.',
			'quem'   => array( 'Comércio e oficinas', 'Portão automático e interfone', 'Nobreak de escritório', 'Alarme e CFTV' ),
			'faq'    => array(
				array( 'pergunta' => 'Qual o prazo de entrega em Campo Bom?', 'resposta' => 'Para modelos em estoque, entrega no mesmo dia dentro do horário de atendimento.' ),
				array( 'pergunta' => 'Vocês testam o nobreak depois da troca?', 'resposta' => 'Sim, testamos com carga para confirmar que o equipamento está sustentando a autonomia esperada.' ),
			),
		),
		'sapiranga' => array(
			'perfil' => 'Em Sapiranga a procura vem de comércio, pequenas indústrias e casas em áreas de morro, onde a queda de energia é mais sentida.',
			'quem'   => array( 'Comércio e pequenas indústrias', 'Casas com portão e alarme', 'Nobreak de escritório', 'Iluminação de emergência' ),
			'faq'    => array(
				array( 'pergunta' => 'Atendem Sapiranga com entrega própria?', 'resposta' => 'Sim, Sapiranga faz parte da área de cobertura própria, com entrega e troca no local.' ),
				array( 'pergunta' => 'Como escolher entre 7Ah e 18Ah?', 'resposta' => 'Depende da carga e da autonomia: quanto maior o Ah, mais tempo o sistema fica ligado. Mande os dados do nobreak que calculamos.' ),
			),
		),
		'estancia-velha' => array(
			'perfil' => 'Estância Velha combina indústria de pequeno porte e residências — os pedidos mais frequentes são de nobreak, alarme e portão.',
			'quem'   => array( 'Pequenas indústrias', 'Escritórios com nobreak', 'Portão, alarme e CFTV', 'Comércio de bairro' ),
			'faq'    => array(
				array( 'pergunta' => 'Tem estoque para entrega imediata em Estância Velha?', 'resposta' => 'Os modelos mais usados ficam em estoque; confirmamos disponibilidade no WhatsApp antes de sair para a entrega.' ),
				array( 'pergunta' => 'Fazem a instalação junto?', 'resposta' => 'Sim, a troca do banco é feita pelo nosso técnico no endereço, sem custo adicional na área de cobertura.' ),
			),
		),
		'ivoti' => array(
			'perfil' => 'Ivoti tem muitos pedidos ligados a casas, pousadas e pequenos negócios, com atenção especial a energia solar e segurança.',
			'quem'   => array( 'Pousadas e pequenos negócios', 'Sistemas solares off-grid', 'Casas com portão e alarme', 'Nobreak de escritório' ),
			'faq'    => array(
				array( 'pergunta' => 'Vocês dimensionam banco solar em Ivoti?', 'resposta' => 'Sim, sem custo. Informe consumo em watts, horas de autonomia e tensão do inversor pelo WhatsApp.' ),
				array( 'pergunta' => 'Entregam em Ivoti no mesmo dia?', 'resposta' => 'Na maioria dos casos sim, dentro do horário de atendimento e com o modelo em estoque.' ),
			),
		),
	);

	// Cidades de envio por transportadora: perfis por porte/vocação regional.
	$envio = array(
		'caxias-do-sul'         => array( 'indústria metalmecânica e transportadoras', array( 'Indústria metalmecânica', 'Transportadoras e frotas', 'Salas de TI', 'Integradores solares' ) ),
		'pelotas'               => array( 'comércio, universidades e agroindústria', array( 'Comércio e universidades', 'Agroindústria', 'Clínicas', 'CFTV e alarme' ) ),
		'santa-maria'           => array( 'serviços, saúde e ensino', array( 'Clínicas e laboratórios', 'Escolas e faculdades', 'Comércio', 'Nobreak de rack' ) ),
		'joinville'             => array( 'indústria e automação', array( 'Indústria e automação', 'Salas de servidor', 'Integradores solares', 'Segurança eletrônica' ) ),
		'florianopolis'         => array( 'tecnologia, turismo e serviços', array( 'Empresas de tecnologia', 'Hotéis e pousadas', 'Clínicas', 'Condomínios' ) ),
		'blumenau'              => array( 'indústria têxtil e comércio', array( 'Indústria têxtil', 'Comércio e escritórios', 'Sistemas solares', 'CFTV' ) ),
		'sao-jose'              => array( 'logística e comércio', array( 'Centros de distribuição', 'Comércio e PDV', 'Escritórios', 'Segurança eletrônica' ) ),
		'itajai'                => array( 'operação portuária e logística', array( 'Operadores logísticos', 'Escritórios portuários', 'Comércio', 'CFTV e alarme' ) ),
		'chapeco'               => array( 'agroindústria e cooperativas', array( 'Agroindústria', 'Cooperativas', 'Propriedades rurais', 'Nobreak e CFTV' ) ),
		'sao-paulo'             => array( 'salas de TI, data center de borda e prédios corporativos', array( 'Salas de TI e rack', 'Prédios corporativos', 'Clínicas', 'Integradores' ) ),
		'guarulhos'             => array( 'logística, indústria e aeroportuária', array( 'Operadores logísticos', 'Indústria', 'Escritórios', 'Segurança eletrônica' ) ),
		'campinas'              => array( 'tecnologia, pesquisa e indústria', array( 'Empresas de tecnologia', 'Laboratórios', 'Indústria', 'Nobreak de rack' ) ),
		'sao-bernardo-do-campo' => array( 'indústria automotiva e metalurgia', array( 'Indústria automotiva', 'Metalúrgicas', 'Oficinas e som automotivo', 'Escritórios' ) ),
		'santo-andre'           => array( 'indústria e comércio do ABC', array( 'Indústria do ABC', 'Comércio e PDV', 'Condomínios', 'CFTV' ) ),
		'osasco'                => array( 'serviços financeiros e comércio', array( 'Escritórios e call centers', 'Comércio', 'Salas de TI', 'Segurança eletrônica' ) ),
		'curitiba'              => array( 'serviços, TI e indústria', array( 'Salas de TI', 'Indústria', 'Clínicas', 'Condomínios' ) ),
		'londrina'              => array( 'agronegócio, saúde e ensino', array( 'Agronegócio', 'Clínicas e hospitais', 'Faculdades', 'Comércio' ) ),
		'maringa'               => array( 'comércio, agro e serviços', array( 'Comércio e escritórios', 'Agronegócio', 'Integradores solares', 'CFTV' ) ),
		'ponta-grossa'          => array( 'indústria e logística', array( 'Indústria', 'Transportadoras', 'Escritórios', 'Segurança eletrônica' ) ),
		'cascavel'              => array( 'agroindústria e comércio', array( 'Agroindústria', 'Cooperativas', 'Comércio', 'Nobreak e CFTV' ) ),
	);

	if ( isset( $mapa[ $slug ] ) ) { return $mapa[ $slug ]; }

	$nome = $nome ? $nome : ucwords( str_replace( '-', ' ', $slug ) );
	if ( isset( $envio[ $slug ] ) ) {
		list( $voc, $quem ) = $envio[ $slug ];
		return array(
			'perfil' => "Em {$nome} o atendimento é por envio: a maior parte dos pedidos vem de {$voc}, que compram o banco dimensionado e recebem por transportadora com nota fiscal e rastreio.",
			'quem'   => $quem,
			'faq'    => array(
				array( 'pergunta' => "Como funciona o envio para {$nome}?", 'resposta' => "Fechamos o pedido pelo WhatsApp com o dimensionamento pronto, cotamos o frete na hora e enviamos por transportadora com nota fiscal e código de rastreio." ),
				array( 'pergunta' => "Quem faz a instalação em {$nome}?", 'resposta' => "A instalação fica com a equipe técnica do cliente ou com o integrador local. Enviamos a orientação de ligação do banco junto com o orçamento." ),
			),
		);
	}

	return array(
		'perfil' => "Em {$nome} atendemos nobreak, energia solar, CFTV, telecom e som automotivo, com dimensionamento do banco feito antes da compra.",
		'quem'   => array( 'Nobreak, UPS e sala de TI', 'Energia solar off-grid', 'CFTV, alarme e portão', 'Som automotivo e ciclo pesado' ),
		'faq'    => array(
			array( 'pergunta' => "Vocês dimensionam o banco para {$nome}?", 'resposta' => 'Sim, sem custo: informe a carga em watts, a autonomia desejada e a tensão do inversor pelo WhatsApp.' ),
			array( 'pergunta' => 'A bateria antiga é recolhida?', 'resposta' => 'Sim, recolhemos o banco antigo e encaminhamos para recicladora licenciada, abatendo o casco no valor da nova.' ),
		),
	);
}
