<?php
/**
 * Título e tipo de produto do feed do Google (Google for WooCommerce).
 * Fórmula: Bateria [Marca] [Modelo] [Ah] – [Aplicação] ([Código]).
 * Usa só dados reais do produto (marca, nome, SKU, categorias).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Segmento do produto pelas categorias do Woo. */
function awr_feed_segmento( $wc_product ) {
	if ( ! $wc_product || ! method_exists( $wc_product, 'get_id' ) ) { return 'carro'; }
	$terms = get_the_terms( $wc_product->get_id(), 'product_cat' );
	$txt   = '';
	if ( $terms && ! is_wp_error( $terms ) ) { $txt = strtolower( remove_accents( implode( ' ', wp_list_pluck( $terms, 'slug' ) ) ) ); }
	$txt .= ' ' . strtolower( remove_accents( (string) $wc_product->get_name() ) );
	if ( false !== strpos( $txt, 'estacion' ) ) { return 'estacionaria'; }
	if ( false !== strpos( $txt, 'cadeira' ) ) { return 'cadeira'; }
	if ( false !== strpos( $txt, 'moto' ) ) { return 'moto'; }
	if ( false !== strpos( $txt, 'caminh' ) || false !== strpos( $txt, 'pesad' ) ) { return 'caminhao'; }
	return 'carro';
}

function awr_feed_titulo( $wc_product ) {
	$nome = trim( (string) $wc_product->get_name() );
	$sku  = strtoupper( trim( (string) $wc_product->get_sku() ) );
	if ( '' === $sku ) { return ''; }
	$marca = function_exists( 'awr_resolve_brand' ) ? (string) awr_resolve_brand( $sku, $nome, $wc_product ) : '';
	if ( 0 === stripos( $marca, 'AWR' ) ) { $marca = ''; }
	$ah  = function_exists( 'awr_extract_amperage' ) ? (int) awr_extract_amperage( $nome ? $nome : $sku ) : 0;
	if ( ! $ah && function_exists( 'awr_extract_amperage' ) ) { $ah = (int) awr_extract_amperage( $sku ); }
	$seg = awr_feed_segmento( $wc_product );
	$aplic = array(
		'carro'        => 'Para Carros e SUVs',
		'moto'         => 'Para Moto',
		'caminhao'     => 'Linha Pesada Caminhão e Ônibus',
		'estacionaria' => 'Nobreak e Energia Solar',
		'cadeira'      => 'Cadeira de Rodas Motorizada',
	);
	$pre = 'estacionaria' === $seg ? 'Bateria Estacionária' : 'Bateria';
	$t   = trim( $pre . ( $marca ? ' ' . $marca : '' ) . ( $ah ? ' ' . $ah . 'Ah' : '' ) . ' ' . $sku );
	$t  .= ' – ' . $aplic[ $seg ];
	return function_exists( 'mb_substr' ) ? mb_substr( $t, 0, 150 ) : substr( $t, 0, 150 );
}

function awr_feed_product_type( $wc_product ) {
	$map = array(
		'carro'        => 'Baterias > Automotiva',
		'moto'         => 'Baterias > Moto',
		'caminhao'     => 'Baterias > Caminhão',
		'estacionaria' => 'Baterias > Estacionária',
		'cadeira'      => 'Baterias > Cadeira de Rodas',
	);
	$base = $map[ awr_feed_segmento( $wc_product ) ];
	if ( 'Baterias > Automotiva' === $base && function_exists( 'awr_bateria_tecnologia' ) ) {
		$tec = (string) awr_bateria_tecnologia( (string) $wc_product->get_sku(), (string) $wc_product->get_name() );
		if ( $tec ) { $base .= ' > ' . $tec; }
	}
	return $base;
}

add_filter( 'woocommerce_gla_product_attribute_values', function ( $attributes, $wc_product = null ) {
	if ( ! is_array( $attributes ) || ! $wc_product || ! method_exists( $wc_product, 'get_sku' ) ) { return $attributes; }
	try {
		$titulo = awr_feed_titulo( $wc_product );
		if ( $titulo ) { $attributes['title'] = $titulo; }
		$attributes['productTypes'] = array( awr_feed_product_type( $wc_product ) );
	} catch ( \Throwable $e ) {
		return $attributes;
	}
	return $attributes;
}, 20, 2 );
