<?php
/**
 * Blocos por termo de busca em cada cidade — espelho de src/data/cidadesServicos.ts.
 * GERADO automaticamente; edite o arquivo TS e regenere.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

function awr_cidade_servicos( $slug ) {
	static $d = null;
	if ( null === $d ) {
		$d = array(
			'porto-alegre' => array(
				'domicilio' => 'A bateria automotiva a domicílio em Porto Alegre sai das unidades Medianeira e Petrópolis conforme a zona da cidade, com média de 35 minutos entre a confirmação e a instalação. O técnico vai até casa, trabalho, garagem de prédio, box de estacionamento ou via pública, com a bateria já separada para o seu modelo e preço confirmado antes da saída.',
				'troca' => 'A troca de bateria é feita no local, com teste do alternador antes e depois. Você recebe nota fiscal, garantia de fábrica e a retirada da bateria velha já incluída — não precisa levar o carro até a loja nem ficar sem o veículo.',
				'socorro' => 'Para carro parado a capital tem o maior horário de cobertura da região: das 6h30 às 22h, todos os dias. Se o motor só dá um clique ou as luzes estão fracas, o mesmo atendimento que leva a bateria também testa o alternador, o que evita trocar a peça errada.',
				'pertoDeMim' => 'Quem procura loja de bateria perto de si em Porto Alegre tem duas opções próprias: Medianeira, na Av. Carlos Barbosa, 1452, e Petrópolis, na Av. Protásio Alves, 4189. Dá para retirar na loja ou pedir a instalação no endereço.',
			),
			'canoas' => array(
				'domicilio' => 'Em Canoas a bateria a domicílio sai da loja da Av. Guilherme Schell, 3266, no bairro Fátima, com prazo médio de 35 minutos. Fátima, Igara e Niterói ficam abaixo desse tempo; Guajuviras e Mathias Velho variam conforme a BR-116.',
				'troca' => 'A troca acontece onde o carro está: garagem de casa, pátio de empresa ou estacionamento. Antes de instalar, testamos bateria e alternador — importante para a frota comercial da cidade, que costuma rodar com rastreador ligado e o motor desligado.',
				'socorro' => 'Carro que não pega de manhã é a chamada mais comum em Canoas. O socorro é feito pela unidade Fátima no horário da loja, e o técnico já leva as amperagens de maior giro (60Ah e 70Ah) para resolver na primeira ida.',
				'pertoDeMim' => 'A loja fica na Av. Guilherme Schell, 3266, perto da ULBRA e do Canoas Shopping — referência para quem busca bateria perto de si em Canoas ou em Esteio, cidade atendida pela mesma unidade.',
			),
			'gravatai' => array(
				'domicilio' => 'Gravataí é atendida pela loja da Av. Dorival Cândido Luz de Oliveira, 6625, no Bom Princípio, com média de 40 minutos até a instalação. O mesmo veículo cobre Cachoeirinha, Alvorada e Viamão, por isso confirmamos o horário antes de sair.',
				'troca' => 'A troca é feita no local com teste de bateria e de alternador, nota fiscal e garantia de fábrica. A bateria antiga é retirada no mesmo atendimento e o valor de troca já entra no preço final.',
				'socorro' => 'Para carro parado em Gravataí, o socorro sai da unidade Bom Princípio no horário de funcionamento da loja. Informe o ponto exato — a RS-118 e a Av. Dorival Cândido concentram a maior parte dos chamados.',
				'pertoDeMim' => 'A unidade AWR mais próxima de quem está em Gravataí é a do Bom Princípio, na Av. Dorival Cândido Luz de Oliveira, 6625, com atendimento na loja e a domicílio.',
			),
			'sao-leopoldo' => array(
				'domicilio' => 'Em São Leopoldo o atendimento a domicílio sai da loja da Av. Feitoria, 917, bairro São José, com média de 40 minutos. A mesma unidade atende Sapucaia do Sul, o que mantém a rota curta pela BR-116.',
				'troca' => 'A troca é feita no endereço do cliente, com teste do alternador para confirmar se a falha é da bateria. Nota fiscal, garantia de fábrica e retirada do casco velho estão incluídas.',
				'socorro' => 'O socorro em São Leopoldo cobre a região da Unisinos, o Centro e os bairros ao longo da Av. Feitoria, no horário de funcionamento da loja. O técnico leva testador e as amperagens de maior saída.',
				'pertoDeMim' => 'Quem busca bateria perto de si em São Leopoldo tem a unidade da Av. Feitoria, 917, no São José — atendimento na loja ou entrega com instalação no local.',
			),
			'novo-hamburgo' => array(
				'domicilio' => 'Novo Hamburgo é atendida pela loja da Av. Vítor Hugo Kunz, 961, em Hamburgo Velho, com média de 40 minutos. Essa unidade também cobre Campo Bom, Estância Velha, Ivoti e Sapiranga pela RS-239.',
				'troca' => 'A troca é feita no local, sem levar o carro à oficina. Testamos bateria e alternador, instalamos a nova, emitimos nota fiscal e retiramos a bateria antiga no mesmo atendimento.',
				'socorro' => 'Para carro parado em Novo Hamburgo, o socorro sai de Hamburgo Velho no horário da loja. Se o carro liga com chupeta e morre de novo no dia seguinte, avise: o problema pode ser o alternador, e testamos isso antes de vender a bateria.',
				'pertoDeMim' => 'A loja de referência para quem procura bateria perto de si em Novo Hamburgo é a de Hamburgo Velho, na Av. Vítor Hugo Kunz, 961.',
			),
			'esteio' => array(
				'domicilio' => 'Esteio é atendida pela loja de Canoas (Av. Guilherme Schell, 3266), com média de 40 minutos até a instalação — a rota depende do fluxo da BR-116 no momento do pedido.',
				'troca' => 'A troca acontece no seu endereço, com teste de bateria e alternador, nota fiscal e garantia de fábrica. Não é preciso deslocar o carro até a loja em Canoas.',
				'socorro' => 'Para carro parado em Esteio, o atendimento sai da unidade de Canoas no horário de funcionamento dela. Informe rua e referência para o técnico ir direto ao ponto.',
				'pertoDeMim' => 'A unidade AWR mais próxima de Esteio fica em Canoas, no bairro Fátima, na Av. Guilherme Schell, 3266 — é a loja responsável pelo atendimento na cidade.',
			),
			'cachoeirinha' => array(
				'domicilio' => 'Cachoeirinha é atendida pela loja de Gravataí (Av. Dorival Cândido Luz de Oliveira, 6625), com média de 50 minutos. A rota passa pela Av. Flores da Cunha, principal eixo da cidade.',
				'troca' => 'A troca é feita no local, com teste do alternador incluído, nota fiscal, garantia de fábrica e retirada da bateria velha.',
				'socorro' => 'Carro parado em Cachoeirinha é atendido pela equipe de Gravataí no horário da loja. Estacionamento de supermercado, pátio de empresa e via pública estão cobertos, desde que o local seja seguro para o técnico.',
				'pertoDeMim' => 'A unidade mais próxima de Cachoeirinha é a de Gravataí, no Bom Princípio — mesma equipe que faz a entrega e a instalação na cidade.',
			),
			'alvorada' => array(
				'domicilio' => 'Alvorada é atendida pela unidade de Gravataí, com média de 55 minutos até a instalação. O prazo varia conforme o bairro e o trânsito da Av. Presidente Getúlio Vargas.',
				'troca' => 'A troca é feita no endereço do cliente, com teste de bateria e alternador antes da instalação, nota fiscal e garantia de fábrica.',
				'socorro' => 'Para carro parado em Alvorada, o socorro sai de Gravataí no horário de funcionamento da loja. Confirme o endereço completo no WhatsApp para o técnico sair direto.',
				'pertoDeMim' => 'A loja AWR de referência para Alvorada é a de Gravataí, na Av. Dorival Cândido Luz de Oliveira, 6625 — atendimento na loja ou entrega com instalação.',
			),
			'viamao' => array(
				'domicilio' => 'Viamão é atendida pela unidade de Gravataí, com média de 55 minutos. Por ser uma cidade extensa, o prazo muda bastante entre o Centro e os bairros mais afastados — confirmamos antes de sair.',
				'troca' => 'A troca é feita no local, com teste de bateria e de alternador, nota fiscal, garantia de fábrica e retirada do casco antigo.',
				'socorro' => 'Para carro parado em Viamão, o atendimento sai de Gravataí no horário da loja. Informe um ponto de referência claro, o que reduz bastante o tempo de chegada nos bairros mais distantes.',
				'pertoDeMim' => 'A unidade AWR mais próxima de Viamão fica em Gravataí, no Bom Princípio, e é a responsável pelo atendimento na cidade.',
			),
			'sapucaia-do-sul' => array(
				'domicilio' => 'Sapucaia do Sul é atendida pela loja de São Leopoldo (Av. Feitoria, 917), com média de 50 minutos. A rota usa a BR-116, principal ligação entre as duas cidades.',
				'troca' => 'A troca é feita onde o carro está, com teste do alternador incluído, nota fiscal, garantia de fábrica e retirada da bateria velha no mesmo atendimento.',
				'socorro' => 'Carro parado em Sapucaia do Sul é atendido pela equipe de São Leopoldo, no horário de funcionamento da loja, com testador e as amperagens de maior saída no veículo.',
				'pertoDeMim' => 'A unidade mais próxima de Sapucaia do Sul é a de São Leopoldo, na Av. Feitoria, 917, bairro São José.',
			),
		);
	}
	return $d[ $slug ] ?? null;
}
