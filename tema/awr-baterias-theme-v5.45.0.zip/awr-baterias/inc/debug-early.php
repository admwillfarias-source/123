<?php
/**
 * Diagnóstico de chamadas antecipadas (WordPress 6.8+).
 *
 * Captura avisos do tipo "wp_is_block_theme foi chamada incorretamente" e
 * "_load_textdomain_just_in_time", grava o rastreamento de pilha completo e
 * identifica o plugin (ou tema) responsável.
 *
 * Ativação: adicione ao wp-config.php
 *     define( 'AWR_DEBUG_EARLY', true );
 *
 * Log: /wp-content/awr-early.log
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** O diagnóstico está ligado? */
function awr_debug_early_on() {
	return defined( 'AWR_DEBUG_EARLY' ) && AWR_DEBUG_EARLY;
}

/** Caminho do log. */
function awr_debug_early_file() {
	return WP_CONTENT_DIR . '/awr-early.log';
}

/** Extrai o primeiro arquivo de plugin/tema presente na pilha. */
function awr_debug_early_blame( $trace ) {
	foreach ( $trace as $frame ) {
		if ( empty( $frame['file'] ) ) { continue; }
		$file = wp_normalize_path( $frame['file'] );
		if ( false !== strpos( $file, '/wp-includes/' ) || false !== strpos( $file, '/wp-admin/' ) ) { continue; }
		if ( preg_match( '#/(plugins|mu-plugins|themes)/([^/]+)/#', $file, $m ) ) {
			return array(
				'tipo'    => $m[1],
				'nome'    => $m[2],
				'arquivo' => $file . ':' . ( isset( $frame['line'] ) ? (int) $frame['line'] : 0 ),
			);
		}
	}
	return array( 'tipo' => 'desconhecido', 'nome' => '—', 'arquivo' => '—' );
}

/** Ocorrências acumuladas nesta requisição/opção. */
function awr_debug_early_entries() {
	$saved = get_option( 'awr_early_calls', array() );
	return is_array( $saved ) ? $saved : array();
}

add_action( 'doing_it_wrong_run', function ( $function_name, $message, $version ) {
	if ( ! awr_debug_early_on() ) { return; }

	$watched = array( 'wp_is_block_theme', '_load_textdomain_just_in_time', 'wp_get_global_settings', 'wp_get_global_styles', '_wp_get_block_theme' );
	$hit     = false;
	foreach ( $watched as $w ) {
		if ( false !== strpos( (string) $function_name, $w ) ) { $hit = true; break; }
	}
	if ( ! $hit ) { return; }

	$trace = debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 25 ); // phpcs:ignore
	$blame = awr_debug_early_blame( $trace );

	$lines   = array();
	$lines[] = '=== ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC ===';
	$lines[] = 'Função: ' . $function_name;
	$lines[] = 'Mensagem: ' . wp_strip_all_tags( (string) $message );
	$lines[] = 'Versão: ' . (string) $version;
	$lines[] = 'URL: ' . ( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '-' ); // phpcs:ignore
	$lines[] = 'Culpado: ' . $blame['tipo'] . ' → ' . $blame['nome'];
	$lines[] = 'Arquivo: ' . $blame['arquivo'];
	$lines[] = 'Pilha:';
	foreach ( $trace as $i => $frame ) {
		$lines[] = sprintf(
			'  #%d %s%s%s() em %s:%d',
			$i,
			isset( $frame['class'] ) ? $frame['class'] : '',
			isset( $frame['type'] ) ? $frame['type'] : '',
			isset( $frame['function'] ) ? $frame['function'] : '?',
			isset( $frame['file'] ) ? wp_normalize_path( $frame['file'] ) : '-',
			isset( $frame['line'] ) ? (int) $frame['line'] : 0
		);
	}
	$lines[] = '';

	// phpcs:ignore WordPress.WP.AlternativeFunctions
	@file_put_contents( awr_debug_early_file(), implode( "\n", $lines ) . "\n", FILE_APPEND );

	// Resumo consultável no painel (últimas 20 ocorrências únicas).
	$saved = awr_debug_early_entries();
	$key   = md5( $function_name . '|' . $blame['arquivo'] );
	if ( ! isset( $saved[ $key ] ) ) {
		$saved[ $key ] = array(
			'funcao'  => (string) $function_name,
			'tipo'    => $blame['tipo'],
			'nome'    => $blame['nome'],
			'arquivo' => $blame['arquivo'],
			'quando'  => gmdate( 'Y-m-d H:i:s' ),
			'vezes'   => 0,
		);
	}
	$saved[ $key ]['vezes'] = (int) $saved[ $key ]['vezes'] + 1;
	$saved                  = array_slice( $saved, -20, 20, true );
	update_option( 'awr_early_calls', $saved, false );
}, 10, 3 );

/** Limpeza manual: /wp-admin/?awr_early_clear=1 */
add_action( 'admin_init', function () {
	if ( empty( $_GET['awr_early_clear'] ) || ! current_user_can( 'manage_options' ) ) { return; } // phpcs:ignore
	check_admin_referer( 'awr_early_clear' );
	delete_option( 'awr_early_calls' );
	// phpcs:ignore WordPress.WP.AlternativeFunctions
	@unlink( awr_debug_early_file() );
	wp_safe_redirect( admin_url() );
	exit;
} );
