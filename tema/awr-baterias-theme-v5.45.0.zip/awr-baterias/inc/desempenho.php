<?php
/** Painel de conversões e SEO da AWR, com GA4 e Search Console. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const AWR_GOOGLE_SCOPES = 'https://www.googleapis.com/auth/analytics.readonly https://www.googleapis.com/auth/webmasters.readonly';

function awr_perf_encrypt( $value ) {
	if ( '' === (string) $value ) { return ''; }
	$key = hash( 'sha256', wp_salt( 'auth' ), true );
	$iv  = random_bytes( 12 );
	$tag = '';
	$out = openssl_encrypt( (string) $value, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
	return base64_encode( $iv . $tag . $out );
}

function awr_perf_decrypt( $value ) {
	$raw = base64_decode( (string) $value, true );
	if ( false === $raw || strlen( $raw ) < 29 ) { return ''; }
	$key = hash( 'sha256', wp_salt( 'auth' ), true );
	$out = openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ) );
	return false === $out ? '' : $out;
}

function awr_perf_settings() {
	return array(
		'client_id'     => (string) get_option( 'awr_perf_client_id', '' ),
		'client_secret' => awr_perf_decrypt( get_option( 'awr_perf_client_secret', '' ) ),
		'ga4_property'  => preg_replace( '/\D/', '', (string) get_option( 'awr_perf_ga4_property', '' ) ),
		'gsc_property'  => (string) get_option( 'awr_perf_gsc_property', '' ),
		'token'         => json_decode( awr_perf_decrypt( get_option( 'awr_perf_google_token', '' ) ), true ),
	);
}

function awr_perf_redirect_uri() { return admin_url( 'options-general.php?page=awr-desempenho' ); }

function awr_perf_google_request( $method, $url, $body = null ) {
	$s = awr_perf_settings();
	$t = is_array( $s['token'] ) ? $s['token'] : array();
	if ( empty( $t['access_token'] ) || (int) ( $t['expires_at'] ?? 0 ) < time() + 60 ) {
		if ( empty( $t['refresh_token'] ) ) { return new WP_Error( 'awr_auth', 'Autorize a conta Google para carregar os relatórios.' ); }
		$refresh = wp_remote_post( 'https://oauth2.googleapis.com/token', array( 'timeout' => 15, 'body' => array(
			'client_id' => $s['client_id'], 'client_secret' => $s['client_secret'], 'refresh_token' => $t['refresh_token'], 'grant_type' => 'refresh_token',
		) ) );
		if ( is_wp_error( $refresh ) ) { return $refresh; }
		$data = json_decode( wp_remote_retrieve_body( $refresh ), true );
		if ( wp_remote_retrieve_response_code( $refresh ) >= 300 || empty( $data['access_token'] ) ) { return new WP_Error( 'awr_refresh', $data['error_description'] ?? 'A autorização Google precisa ser renovada.' ); }
		$t = array_merge( $t, $data, array( 'expires_at' => time() + (int) ( $data['expires_in'] ?? 3600 ) ) );
		update_option( 'awr_perf_google_token', awr_perf_encrypt( wp_json_encode( $t ) ), false );
	}
	$args = array( 'method' => $method, 'timeout' => 20, 'headers' => array( 'Authorization' => 'Bearer ' . $t['access_token'], 'Content-Type' => 'application/json' ) );
	if ( null !== $body ) { $args['body'] = wp_json_encode( $body ); }
	$res = wp_remote_request( $url, $args );
	if ( is_wp_error( $res ) ) { return $res; }
	$data = json_decode( wp_remote_retrieve_body( $res ), true );
	if ( wp_remote_retrieve_response_code( $res ) >= 300 ) { return new WP_Error( 'awr_google', $data['error']['message'] ?? 'O Google recusou a consulta.' ); }
	return is_array( $data ) ? $data : array();
}

function awr_perf_gsc_sites() {
	$data = awr_perf_google_request( 'GET', 'https://www.googleapis.com/webmasters/v3/sites' );
	if ( is_wp_error( $data ) ) { return $data; }
	return array_values( array_filter( (array) ( $data['siteEntry'] ?? array() ), function ( $site ) {
		return 'siteUnverifiedUser' !== ( $site['permissionLevel'] ?? '' );
	} ) );
}

function awr_perf_gsc_report( $days = 28, $refresh = false ) {
	$s = awr_perf_settings();
	if ( ! $s['gsc_property'] ) { return new WP_Error( 'awr_property', 'Selecione uma propriedade verificada do Search Console.' ); }
	$key = 'awr_perf_gsc_' . md5( $s['gsc_property'] . '|' . $days );
	if ( ! $refresh && false !== ( $cached = get_transient( $key ) ) ) { return $cached; }
	$sites = awr_perf_gsc_sites();
	if ( is_wp_error( $sites ) ) { return $sites; }
	$valid = wp_list_pluck( $sites, 'siteUrl' );
	if ( ! in_array( $s['gsc_property'], $valid, true ) ) { return new WP_Error( 'awr_property', 'A propriedade selecionada não está mais verificada nesta conta.' ); }
	$end = gmdate( 'Y-m-d', strtotime( '-2 days' ) );
	$start = gmdate( 'Y-m-d', strtotime( '-' . ( $days + 1 ) . ' days' ) );
	$url = 'https://www.googleapis.com/webmasters/v3/sites/' . rawurlencode( $s['gsc_property'] ) . '/searchAnalytics/query';
	$data = awr_perf_google_request( 'POST', $url, array( 'startDate' => $start, 'endDate' => $end, 'dimensions' => array( 'page' ), 'rowLimit' => 1000 ) );
	if ( ! is_wp_error( $data ) ) { set_transient( $key, $data, DAY_IN_SECONDS ); update_option( 'awr_perf_last_gsc', time(), false ); }
	return $data;
}

function awr_perf_ga4_report( $days = 28, $refresh = false ) {
	$s = awr_perf_settings();
	if ( ! $s['ga4_property'] ) { return new WP_Error( 'awr_ga4', 'Informe o número da propriedade GA4 para carregar conversões.' ); }
	$key = 'awr_perf_ga4_' . md5( $s['ga4_property'] . '|' . $days );
	if ( ! $refresh && false !== ( $cached = get_transient( $key ) ) ) { return $cached; }
	$body = array(
		'dateRanges' => array( array( 'startDate' => $days . 'daysAgo', 'endDate' => 'yesterday' ) ),
		'dimensions' => array( array( 'name' => 'date' ), array( 'name' => 'eventName' ), array( 'name' => 'customEvent:city' ), array( 'name' => 'customEvent:vehicle' ), array( 'name' => 'customEvent:sku' ), array( 'name' => 'customEvent:product_name' ), array( 'name' => 'customEvent:page_type' ) ),
		'metrics' => array( array( 'name' => 'eventCount' ) ),
		'dimensionFilter' => array( 'filter' => array( 'fieldName' => 'eventName', 'inListFilter' => array( 'values' => array( 'whatsapp_click', 'phone_click', 'buscar_bateria', 'solicitar_bateria', 'checkout_complete' ) ) ) ),
		'limit' => '10000',
	);
	$data = awr_perf_google_request( 'POST', 'https://analyticsdata.googleapis.com/v1beta/properties/' . $s['ga4_property'] . ':runReport', $body );
	if ( ! is_wp_error( $data ) ) { set_transient( $key, $data, 15 * MINUTE_IN_SECONDS ); update_option( 'awr_perf_last_ga4', time(), false ); }
	return $data;
}

add_action( 'admin_menu', function () {
	add_options_page( 'AWR Desempenho', 'AWR Desempenho', 'manage_options', 'awr-desempenho', 'awr_perf_admin_page' );
} );

function awr_perf_handle_actions() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	if ( isset( $_POST['awr_perf_save'] ) && check_admin_referer( 'awr_perf_save' ) ) {
		update_option( 'awr_perf_client_id', sanitize_text_field( wp_unslash( $_POST['client_id'] ?? '' ) ), false );
		$secret = trim( (string) wp_unslash( $_POST['client_secret'] ?? '' ) );
		if ( $secret ) { update_option( 'awr_perf_client_secret', awr_perf_encrypt( $secret ), false ); }
		update_option( 'awr_perf_ga4_property', preg_replace( '/\D/', '', (string) ( $_POST['ga4_property'] ?? '' ) ), false );
		update_option( 'awr_perf_gsc_property', sanitize_text_field( wp_unslash( $_POST['gsc_property'] ?? '' ) ), false );
		wp_safe_redirect( awr_perf_redirect_uri() ); exit;
	}
	if ( isset( $_GET['code'], $_GET['state'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['state'] ) ), 'awr_google_oauth' ) ) {
		$s = awr_perf_settings();
		$res = wp_remote_post( 'https://oauth2.googleapis.com/token', array( 'timeout' => 15, 'body' => array(
			'code' => sanitize_text_field( wp_unslash( $_GET['code'] ) ), 'client_id' => $s['client_id'], 'client_secret' => $s['client_secret'], 'redirect_uri' => awr_perf_redirect_uri(), 'grant_type' => 'authorization_code',
		) ) );
		$data = is_wp_error( $res ) ? array() : json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! empty( $data['access_token'] ) ) {
			$data['expires_at'] = time() + (int) ( $data['expires_in'] ?? 3600 );
			update_option( 'awr_perf_google_token', awr_perf_encrypt( wp_json_encode( $data ) ), false );
			wp_safe_redirect( awr_perf_redirect_uri() ); exit;
		}
	}
}
add_action( 'admin_init', 'awr_perf_handle_actions' );

function awr_perf_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$s = awr_perf_settings();
	$days = in_array( (int) ( $_GET['days'] ?? 28 ), array( 7, 28, 90 ), true ) ? (int) $_GET['days'] : 28;
	$refresh = isset( $_GET['refresh'] ) && check_admin_referer( 'awr_perf_refresh' );
	$sites = ! empty( $s['token']['refresh_token'] ) ? awr_perf_gsc_sites() : array();
	$gsc = $s['gsc_property'] ? awr_perf_gsc_report( $days, $refresh ) : null;
	$ga4 = $s['ga4_property'] ? awr_perf_ga4_report( $days, $refresh ) : null;
	$oauth = add_query_arg( array( 'client_id' => $s['client_id'], 'redirect_uri' => awr_perf_redirect_uri(), 'response_type' => 'code', 'scope' => AWR_GOOGLE_SCOPES, 'access_type' => 'offline', 'prompt' => 'consent', 'state' => wp_create_nonce( 'awr_google_oauth' ) ), 'https://accounts.google.com/o/oauth2/v2/auth' );
	$totals = array( 'whatsapp_click' => 0, 'phone_click' => 0, 'buscar_bateria' => 0, 'solicitar_bateria' => 0, 'checkout_complete' => 0 );
	if ( is_array( $ga4 ) ) { foreach ( (array) ( $ga4['rows'] ?? array() ) as $row ) { $event = $row['dimensionValues'][1]['value'] ?? ''; if ( isset( $totals[ $event ] ) ) { $totals[ $event ] += (int) ( $row['metricValues'][0]['value'] ?? 0 ); } } }
	$conversion_rows = array();
	if ( is_array( $ga4 ) ) { foreach ( (array) ( $ga4['rows'] ?? array() ) as $row ) {
		$values = (array) ( $row['dimensionValues'] ?? array() );
		$event = (string) ( $values[1]['value'] ?? '' );
		$count = (int) ( $row['metricValues'][0]['value'] ?? 0 );
		$key = implode( '|', array( $event, $values[2]['value'] ?? '', $values[3]['value'] ?? '', $values[4]['value'] ?? '', $values[5]['value'] ?? '', $values[6]['value'] ?? '' ) );
		if ( ! isset( $conversion_rows[ $key ] ) ) { $conversion_rows[ $key ] = array( 'event' => $event, 'city' => $values[2]['value'] ?? '', 'vehicle' => $values[3]['value'] ?? '', 'sku' => $values[4]['value'] ?? '', 'product' => $values[5]['value'] ?? '', 'page_type' => $values[6]['value'] ?? '', 'count' => 0 ); }
		$conversion_rows[ $key ]['count'] += $count;
	} }
	usort( $conversion_rows, function ( $a, $b ) { return $b['count'] <=> $a['count']; } );
	$rows = is_array( $gsc ) ? (array) ( $gsc['rows'] ?? array() ) : array();
	usort( $rows, function ( $a, $b ) { return ( $b['impressions'] ?? 0 ) <=> ( $a['impressions'] ?? 0 ); } );
	?>
	<div class="wrap"><h1>AWR Desempenho</h1><p>Conversões e desempenho orgânico por página nos últimos <?php echo (int) $days; ?> dias.</p>
	<nav class="nav-tab-wrapper"><a class="nav-tab nav-tab-active" href="#resumo">Resumo</a><a class="nav-tab" href="#seo">SEO orgânico</a><a class="nav-tab" href="#config">Configuração</a></nav>
	<p><a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'page' => 'awr-desempenho', 'days' => $days, 'refresh' => 1 ), admin_url( 'options-general.php' ) ), 'awr_perf_refresh' ) ); ?>">Atualizar agora</a> <?php foreach ( array( 7, 28, 90 ) as $d ) : ?><a class="button <?php echo $days === $d ? 'button-primary' : ''; ?>" href="<?php echo esc_url( add_query_arg( array( 'page' => 'awr-desempenho', 'days' => $d ), admin_url( 'options-general.php' ) ) ); ?>"><?php echo (int) $d; ?> dias</a> <?php endforeach; ?></p>
	<?php if ( is_wp_error( $ga4 ) ) : ?><div class="notice notice-warning"><p><?php echo esc_html( $ga4->get_error_message() ); ?></p></div><?php endif; ?>
	<div id="resumo" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(170px,100%),1fr));gap:12px;max-width:1000px;margin:18px 0">
	<?php foreach ( array( 'whatsapp_click' => 'WhatsApp', 'phone_click' => 'Ligações', 'buscar_bateria' => 'Buscas', 'solicitar_bateria' => 'Pedidos iniciados', 'checkout_complete' => 'Pedidos concluídos' ) as $key => $label ) : ?><div class="card"><h2><?php echo esc_html( number_format_i18n( $totals[ $key ] ) ); ?></h2><p><?php echo esc_html( $label ); ?></p></div><?php endforeach; ?></div>
	<h2>Conversões por cidade, veículo e produto</h2>
	<?php if ( $conversion_rows ) : ?><table class="widefat striped"><thead><tr><th>Evento</th><th>Cidade</th><th>Veículo</th><th>SKU</th><th>Produto</th><th>Tipo de página</th><th>Total</th></tr></thead><tbody><?php foreach ( array_slice( $conversion_rows, 0, 200 ) as $row ) : ?><tr><td><?php echo esc_html( $row['event'] ); ?></td><td><?php echo esc_html( $row['city'] ?: '—' ); ?></td><td><?php echo esc_html( $row['vehicle'] ?: '—' ); ?></td><td><?php echo esc_html( $row['sku'] ?: '—' ); ?></td><td><?php echo esc_html( $row['product'] ?: '—' ); ?></td><td><?php echo esc_html( $row['page_type'] ?: '—' ); ?></td><td><?php echo esc_html( number_format_i18n( $row['count'] ) ); ?></td></tr><?php endforeach; ?></tbody></table><?php else : ?><p>Os detalhamentos aparecerão após o cadastro das dimensões abaixo e o recebimento de novos eventos.</p><?php endif; ?>
	<h2 id="seo">SEO orgânico e oportunidades de CTR</h2>
	<?php if ( is_wp_error( $gsc ) ) : ?><div class="notice notice-warning"><p><?php echo esc_html( $gsc->get_error_message() ); ?></p></div><?php elseif ( $rows ) : ?>
	<table class="widefat striped"><thead><tr><th>Página</th><th>Cliques</th><th>Impressões</th><th>CTR</th><th>Posição</th><th>Prioridade</th></tr></thead><tbody>
	<?php foreach ( array_slice( $rows, 0, 100 ) as $row ) : $ctr = 100 * (float) ( $row['ctr'] ?? 0 ); $pos = (float) ( $row['position'] ?? 0 ); $impact = ( $row['impressions'] ?? 0 ) >= 100 && ( $ctr < 2 || ( $pos >= 11 && $pos <= 20 ) ); ?>
	<tr><td><a href="<?php echo esc_url( $row['keys'][0] ?? '' ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $row['keys'][0] ?? '' ); ?></a></td><td><?php echo (int) ( $row['clicks'] ?? 0 ); ?></td><td><?php echo (int) ( $row['impressions'] ?? 0 ); ?></td><td><?php echo esc_html( number_format_i18n( $ctr, 2 ) ); ?>%</td><td><?php echo esc_html( number_format_i18n( $pos, 1 ) ); ?></td><td><?php echo $impact ? '<strong style="color:#b32d2e">Otimizar título e conteúdo</strong>' : 'Monitorar'; ?></td></tr>
	<?php endforeach; ?></tbody></table><?php else : ?><p>Conecte e selecione uma propriedade para exibir os dados.</p><?php endif; ?>
	<h2 id="config">Configuração Google</h2><p>Crie credenciais OAuth do tipo Aplicativo da Web e use este endereço de retorno: <code><?php echo esc_html( awr_perf_redirect_uri() ); ?></code>.</p>
	<form method="post"><?php wp_nonce_field( 'awr_perf_save' ); ?><table class="form-table"><tr><th>Client ID</th><td><input class="regular-text" name="client_id" value="<?php echo esc_attr( $s['client_id'] ); ?>"></td></tr><tr><th>Client secret</th><td><input class="regular-text" type="password" name="client_secret" placeholder="<?php echo $s['client_secret'] ? 'Salvo com proteção' : ''; ?>"></td></tr><tr><th>Propriedade GA4</th><td><input name="ga4_property" value="<?php echo esc_attr( $s['ga4_property'] ); ?>" placeholder="Somente números"></td></tr><tr><th>Search Console</th><td><select name="gsc_property"><option value="">Selecione após autorizar</option><?php if ( is_array( $sites ) ) : foreach ( $sites as $site ) : ?><option value="<?php echo esc_attr( $site['siteUrl'] ); ?>" <?php selected( $s['gsc_property'], $site['siteUrl'] ); ?>><?php echo esc_html( $site['siteUrl'] ); ?></option><?php endforeach; endif; ?></select></td></tr></table><p><button class="button button-primary" name="awr_perf_save" value="1">Salvar</button> <?php if ( $s['client_id'] && $s['client_secret'] ) : ?><a class="button" href="<?php echo esc_url( $oauth ); ?>">Autorizar conta Google</a><?php endif; ?></p></form>
	<h3>Dimensões personalizadas do GA4</h3><p>Cadastre como dimensões de evento: <code>page_type</code>, <code>city</code>, <code>vehicle</code>, <code>vehicle_year</code>, <code>brand</code>, <code>sku</code>, <code>product_name</code>, <code>source</code>, <code>utm_source</code>, <code>utm_medium</code> e <code>utm_campaign</code>. Elas começam a acumular dados após o cadastro.</p>
	</div><?php
}