<?php
/**
 * Ajustes → AWR Produtos (Merchant) — lista os itens reprovados/em risco no
 * Google Merchant Center com o motivo exato e permite corrigir na hora
 * preço, estoque, imagem, SKU, marca, GTIN e categoria.
 *
 * Fontes do motivo:
 *  1. tabela de problemas da extensão Google for WooCommerce (motivo oficial
 *     devolvido pelo Merchant Center);
 *  2. checagens locais do tema, que apontam o que o Merchant recusaria antes
 *     mesmo do feed subir.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ---------------------------------------------------------------------
   1) Motivos oficiais do Merchant Center (extensão Google for WooCommerce)
   --------------------------------------------------------------------- */

/** Tabela de problemas da extensão, quando instalada. */
function awr_gla_issues_table() {
	global $wpdb;
	static $tabela = null;
	if ( null !== $tabela ) { return $tabela; }
	$nome   = $wpdb->prefix . 'gla_merchant_issues';
	$existe = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $nome ) ); // phpcs:ignore WordPress.DB
	$tabela = $existe ? $nome : '';
	return $tabela;
}

/**
 * Motivos do Merchant Center por ID de produto.
 *
 * @return array<int,array<int,array{code:string,texto:string,grave:bool}>>
 */
function awr_gla_issues_por_produto() {
	$tabela = awr_gla_issues_table();
	if ( ! $tabela ) { return array(); }

	global $wpdb;
	$rows = $wpdb->get_results( "SELECT product_id, code, issue, severity FROM {$tabela} WHERE product_id > 0 LIMIT 3000" ); // phpcs:ignore WordPress.DB
	$out  = array();
	foreach ( (array) $rows as $r ) {
		$id = (int) $r->product_id;
		if ( ! isset( $out[ $id ] ) ) { $out[ $id ] = array(); }
		$out[ $id ][] = array(
			'code'  => (string) $r->code,
			'texto' => (string) $r->issue,
			'grave' => in_array( strtolower( (string) $r->severity ), array( 'error', 'disapproved', 'critical' ), true ),
		);
	}
	return $out;
}

/* ---------------------------------------------------------------------
   2) Checagens locais — o que o Merchant recusa ou penaliza
   --------------------------------------------------------------------- */

/**
 * Marca gravada no produto (taxonomia de marca ou meta do tema).
 * v4.2.0 — "AWR Baterias" é a loja, não um fabricante: conta como marca ausente.
 */
function awr_produto_marca_salva( $wc_product ) {
	if ( ! $wc_product || ! method_exists( $wc_product, 'get_id' ) ) { return ''; }
	foreach ( array( 'product_brand', 'pwb-brand', 'pa_marca', 'yith_product_brand' ) as $tax ) {
		if ( ! taxonomy_exists( $tax ) ) { continue; }
		$terms = get_the_terms( $wc_product->get_id(), $tax );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$nome = trim( (string) $terms[0]->name );
			if ( $nome && 0 !== stripos( $nome, 'AWR' ) ) { return $nome; }
		}
	}
	$meta = trim( (string) $wc_product->get_meta( '_awr_marca', true ) );
	return ( $meta && 0 !== stripos( $meta, 'AWR' ) ) ? $meta : '';
}

/**
 * Lista de produtos com pendência, já com os motivos.
 *
 * @param string $filtro '' | preco | foto | sku | marca | gtin | categoria | estoque | merchant
 * @return array
 */
function awr_merchant_produtos_pendentes( $filtro = '' ) {
	if ( ! function_exists( 'wc_get_product' ) ) { return array(); }

	global $wpdb;
	$ids    = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type='product' AND post_status='publish' LIMIT 2000" ); // phpcs:ignore WordPress.DB
	$oficia = awr_gla_issues_por_produto();
	$lista  = array();

	foreach ( $ids as $id ) {
		$id   = (int) $id;
		$prod = wc_get_product( $id );
		if ( ! $prod ) { continue; }

		$motivos = array();
		$chaves  = array();

		foreach ( $oficia[ $id ] ?? array() as $iss ) {
			$motivos[] = array(
				'tipo'  => 'merchant',
				'grave' => $iss['grave'],
				'texto' => $iss['texto'] . ( $iss['code'] ? ' (' . $iss['code'] . ')' : '' ),
			);
			$chaves[] = 'merchant';
		}

		$sku   = trim( (string) $prod->get_sku() );
		$preco = (float) $prod->get_price();

		if ( $preco <= 0 ) {
			$motivos[] = array( 'tipo' => 'preco', 'grave' => true, 'texto' => 'Sem preço — o Merchant Center recusa o item.' );
			$chaves[]  = 'preco';
		}
		if ( ! $prod->get_image_id() ) {
			$motivos[] = array( 'tipo' => 'foto', 'grave' => true, 'texto' => 'Sem foto principal — imagem é obrigatória no feed.' );
			$chaves[]  = 'foto';
		}
		if ( '' === $sku ) {
			$motivos[] = array( 'tipo' => 'sku', 'grave' => true, 'texto' => 'Sem SKU — o item fica sem identificador próprio.' );
			$chaves[]  = 'sku';
		}
		if ( ! awr_produto_categoria_nome( $prod ) ) {
			$motivos[] = array( 'tipo' => 'categoria', 'grave' => true, 'texto' => 'Sem categoria de produto.' );
			$chaves[]  = 'categoria';
		}
		if ( ! $prod->is_in_stock() ) {
			$motivos[] = array( 'tipo' => 'estoque', 'grave' => false, 'texto' => 'Fora de estoque — o item sai dos anúncios enquanto ficar assim.' );
			$chaves[]  = 'estoque';
		}
		if ( '' === awr_produto_marca_salva( $prod ) ) {
			$sugerida  = awr_resolve_brand( $sku, $prod->get_name(), $prod );
			$motivos[] = array(
				'tipo'  => 'marca',
				'grave' => false,
				'texto' => 'Sem marca cadastrada' . ( $sugerida ? ' — sugestão: ' . $sugerida . '.' : '.' ),
			);
			$chaves[] = 'marca';
		}
		if ( ! awr_produto_gtin( $prod ) ) {
			$da_tabela = awr_gtin_por_modelo( $sku );
			$motivos[] = array(
				'tipo'  => 'gtin',
				'grave' => false,
				'texto' => $da_tabela
					? 'Sem código de barras cadastrado — a tabela do tema tem ' . $da_tabela . ' para este modelo. Use o botão "Aplicar códigos de barras da tabela".'
					: 'Sem código de barras (GTIN/EAN) — vai ao Google com marca + código do modelo. Alcance um pouco menor, mas aprovado.',
			);
			$chaves[]  = 'gtin';
		}

		// Imagem principal pequena demais: o Google recusa abaixo de 250px e
		// prefere 800px ou mais para produtos.
		if ( $prod->get_image_id() ) {
			$meta = wp_get_attachment_metadata( (int) $prod->get_image_id() );
			$larg = (int) ( $meta['width'] ?? 0 );
			if ( $larg > 0 && $larg < 800 ) {
				$motivos[] = array(
					'tipo'  => 'imagem',
					'grave' => $larg < 250,
					'texto' => 'Foto principal com apenas ' . $larg . 'px de largura — o Google pede no mínimo 250px e recomenda 800px.',
				);
				$chaves[] = 'imagem';
			}
		}

		if ( ! $motivos ) { continue; }
		if ( $filtro && ! in_array( $filtro, $chaves, true ) ) { continue; }

		$lista[] = array(
			'id'        => $id,
			'nome'      => $prod->get_name(),
			'sku'       => $sku,
			'preco'     => $preco,
			'estoque'   => $prod->get_stock_status(),
			'marca'     => awr_produto_marca_salva( $prod ),
			'gtin'      => awr_produto_gtin( $prod ),
			'categoria' => awr_produto_categoria_nome( $prod ),
			'imagem'    => $prod->get_image_id() ? wp_get_attachment_image_url( $prod->get_image_id(), 'thumbnail' ) : '',
			'editar'    => get_edit_post_link( $id, '' ),
			'motivos'   => $motivos,
			'grave'     => (bool) array_filter( wp_list_pluck( $motivos, 'grave' ) ),
		);
	}

	usort( $lista, function ( $a, $b ) {
		if ( $a['grave'] === $b['grave'] ) { return strcmp( $a['nome'], $b['nome'] ); }
		return $a['grave'] ? -1 : 1;
	} );

	return $lista;
}

/* ---------------------------------------------------------------------
   3) Gravação das correções
   --------------------------------------------------------------------- */

/** Aplica no produto os campos enviados pelo formulário. */
function awr_merchant_salvar_produto( $id, $dados ) {
	$prod = function_exists( 'wc_get_product' ) ? wc_get_product( (int) $id ) : null;
	if ( ! $prod ) { return 'Produto não encontrado.'; }
	$feitos = array();

	// Preço.
	if ( isset( $dados['preco'] ) && '' !== trim( (string) $dados['preco'] ) ) {
		$preco = (float) str_replace( array( '.', ',' ), array( '', '.' ), (string) $dados['preco'] );
		if ( $preco > 0 ) {
			$prod->set_regular_price( (string) $preco );
			if ( ! $prod->get_sale_price() ) { $prod->set_price( (string) $preco ); }
			$feitos[] = 'preço';
		}
	}

	// Estoque.
	if ( ! empty( $dados['estoque'] ) && in_array( $dados['estoque'], array( 'instock', 'outofstock', 'onbackorder' ), true ) ) {
		$prod->set_stock_status( sanitize_key( $dados['estoque'] ) );
		$feitos[] = 'estoque';
	}

	// SKU (sempre em maiúsculas, sem espaços).
	if ( isset( $dados['sku'] ) && '' !== trim( (string) $dados['sku'] ) ) {
		$sku = strtoupper( trim( sanitize_text_field( $dados['sku'] ) ) );
		if ( $sku !== $prod->get_sku() ) {
			try {
				$prod->set_sku( $sku );
				$feitos[] = 'SKU';
			} catch ( Exception $e ) {
				return 'SKU recusado: ' . $e->getMessage();
			}
		}
	}

	// GTIN (somente dígitos, 8/12/13/14).
	if ( isset( $dados['gtin'] ) && '' !== trim( (string) $dados['gtin'] ) ) {
		$gtin = preg_replace( '/\D+/', '', (string) $dados['gtin'] );
		if ( in_array( strlen( (string) $gtin ), array( 8, 12, 13, 14 ), true ) ) {
			$prod->update_meta_data( '_global_unique_id', $gtin );
			$feitos[] = 'GTIN';
		} else {
			return 'GTIN inválido: use 8, 12, 13 ou 14 dígitos.';
		}
	}

	// Marca: taxonomia de marca quando existir, senão meta do tema.
	if ( isset( $dados['marca'] ) && '' !== trim( (string) $dados['marca'] ) ) {
		$marca = sanitize_text_field( $dados['marca'] );
		$tax   = '';
		foreach ( array( 'product_brand', 'pwb-brand', 'pa_marca', 'yith_product_brand' ) as $t ) {
			if ( taxonomy_exists( $t ) ) { $tax = $t; break; }
		}
		if ( $tax ) {
			wp_set_object_terms( (int) $id, $marca, $tax, false );
		} else {
			$prod->update_meta_data( '_awr_marca', $marca );
		}
		$feitos[] = 'marca';
	}

	// Categoria.
	if ( ! empty( $dados['categoria'] ) ) {
		$term = get_term( (int) $dados['categoria'], 'product_cat' );
		if ( $term && ! is_wp_error( $term ) ) {
			wp_set_object_terms( (int) $id, array( (int) $term->term_id ), 'product_cat', false );
			$feitos[] = 'categoria';
		}
	}

	// Imagem: ID da biblioteca ou URL (baixada para a biblioteca).
	if ( isset( $dados['imagem'] ) && '' !== trim( (string) $dados['imagem'] ) ) {
		$img = trim( (string) $dados['imagem'] );
		if ( ctype_digit( $img ) && wp_attachment_is_image( (int) $img ) ) {
			$prod->set_image_id( (int) $img );
			$feitos[] = 'imagem';
		} elseif ( preg_match( '#^https?://#i', $img ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$novo = media_sideload_image( esc_url_raw( $img ), (int) $id, null, 'id' );
			if ( is_wp_error( $novo ) ) {
				return 'Imagem não pôde ser baixada: ' . $novo->get_error_message();
			}
			$prod->set_image_id( (int) $novo );
			$feitos[] = 'imagem';
		} else {
			return 'Imagem inválida: informe o ID da biblioteca ou um endereço https.';
		}
	}

	$prod->save();
	if ( function_exists( 'awr_flush_product_cache' ) ) { awr_flush_product_cache(); }
	if ( function_exists( 'awr_flush_shop_cache' ) ) { awr_flush_shop_cache(); }

	return $feitos ? 'Atualizado: ' . implode( ', ', $feitos ) . '.' : 'Nada foi alterado.';
}

/* ---------------------------------------------------------------------
   4) Correção automática do que dá para deduzir com segurança
   --------------------------------------------------------------------- */

/**
 * v4.2.0 — Grava a marca do fabricante em todo o catálogo.
 * Reconhece prefixos de fábrica (12MN/12MF = Moura, DF = Freedom,
 * MBTX = Motobatt, UP/UN = Unipower, RTX = Route, BTX = Baterisa, ER = Eletran)
 * e substitui qualquer marca de revendedor ("AWR Baterias") já gravada.
 *
 * @return array{gravados:int,ja_ok:int,corrigidos:int,sem_marca:array}
 */
function awr_aplicar_marcas_fabricante() {
	$out = array( 'gravados' => 0, 'ja_ok' => 0, 'corrigidos' => 0, 'sem_marca' => array() );
	if ( ! function_exists( 'wc_get_product' ) ) { return $out; }

	global $wpdb;
	$ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type='product' AND post_status='publish' LIMIT 2000" ); // phpcs:ignore WordPress.DB

	$tax = '';
	foreach ( array( 'product_brand', 'pwb-brand', 'pa_marca', 'yith_product_brand' ) as $t ) {
		if ( taxonomy_exists( $t ) ) { $tax = $t; break; }
	}

	foreach ( $ids as $id ) {
		$id   = (int) $id;
		$prod = wc_get_product( $id );
		if ( ! $prod ) { continue; }

		$atual = awr_produto_marca_salva( $prod );
		if ( $atual ) { $out['ja_ok']++; continue; }

		$sku   = (string) $prod->get_sku();
		$marca = awr_resolve_brand( $sku, $prod->get_name(), $prod );
		if ( ! $marca || 0 === stripos( $marca, 'AWR' ) ) {
			$out['sem_marca'][] = $sku ? $sku : ( '#' . $id );
			continue;
		}

		// Remove marca de revendedor gravada por engano antes de escrever a correta.
		$tinha_awr = false;
		if ( $tax ) {
			$terms = get_the_terms( $id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					if ( 0 === stripos( $term->name, 'AWR' ) ) { $tinha_awr = true; }
				}
			}
			wp_set_object_terms( $id, $marca, $tax, false );
		} else {
			$meta = trim( (string) $prod->get_meta( '_awr_marca', true ) );
			if ( $meta && 0 === stripos( $meta, 'AWR' ) ) { $tinha_awr = true; }
			$prod->update_meta_data( '_awr_marca', $marca );
			$prod->save();
		}

		$out['gravados']++;
		if ( $tinha_awr ) { $out['corrigidos']++; }
	}

	if ( function_exists( 'awr_flush_product_cache' ) ) { awr_flush_product_cache(); }
	if ( function_exists( 'awr_flush_shop_cache' ) ) { awr_flush_shop_cache(); }
	return $out;
}



/**
 * Corrige sozinho o que não depende de informação nova:
 * SKU fora do padrão, GTIN com caracteres estranhos, marca dedutível,
 * canonical do produto, produto com preço marcado como fora de estoque
 * sem controle de estoque, e caches do tema.
 *
 * @return array Lista de linhas de relatório.
 */
function awr_merchant_autofix() {
	$rel = array();

	// Canonical dos produtos precisa apontar para o permalink do próprio produto.
	if ( 'produto' !== awr_produto_canonical_modo() ) {
		update_option( 'awr_produto_canonical', 'produto' );
		$rel[] = 'Canonical dos produtos ajustado para o permalink do produto (o feed passa a bater com a página).';
	}

	if ( ! function_exists( 'wc_get_product' ) ) {
		$rel[] = 'WooCommerce inativo — nenhuma correção de produto aplicada.';
		return $rel;
	}

	global $wpdb;
	$ids   = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type='product' AND post_status='publish' LIMIT 2000" ); // phpcs:ignore WordPress.DB
	$n_sku = 0; $n_gtin = 0; $n_marca = 0; $n_est = 0;

	foreach ( $ids as $id ) {
		$prod = wc_get_product( (int) $id );
		if ( ! $prod ) { continue; }
		$mudou = false;

		$sku  = (string) $prod->get_sku();
		$novo = strtoupper( trim( $sku ) );
		if ( $sku && $novo !== $sku ) {
			try {
				$prod->set_sku( $novo );
				$mudou = true;
				$n_sku++;
			} catch ( Exception $e ) { // SKU duplicado: fica para correção manual.
				$mudou = $mudou;
			}
		}

		foreach ( array( '_global_unique_id', '_gtin', '_ean', '_upc' ) as $chave ) {
			$bruto = (string) $prod->get_meta( $chave, true );
			if ( '' === $bruto ) { continue; }
			$limpo = preg_replace( '/\D+/', '', $bruto );
			if ( $limpo !== $bruto && in_array( strlen( (string) $limpo ), array( 8, 12, 13, 14 ), true ) ) {
				$prod->update_meta_data( $chave, $limpo );
				$mudou = true;
				$n_gtin++;
			}
		}

		if ( '' === awr_produto_marca_salva( $prod ) ) {
			$marca = awr_resolve_brand( $prod->get_sku(), $prod->get_name(), $prod );
			if ( $marca ) {
				$tax = '';
				foreach ( array( 'product_brand', 'pwb-brand', 'pa_marca', 'yith_product_brand' ) as $t ) {
					if ( taxonomy_exists( $t ) ) { $tax = $t; break; }
				}
				if ( $tax ) {
					wp_set_object_terms( (int) $id, $marca, $tax, false );
				} else {
					$prod->update_meta_data( '_awr_marca', $marca );
					$mudou = true;
				}
				$n_marca++;
			}
		}

		// Produto com preço, sem controle de estoque e marcado como esgotado:
		// é erro de cadastro, não falta real de produto.
		if ( (float) $prod->get_price() > 0 && ! $prod->get_manage_stock() && 'outofstock' === $prod->get_stock_status() && 'publish' === $prod->get_status() ) {
			$prod->set_stock_status( 'instock' );
			$mudou = true;
			$n_est++;
		}

		if ( $mudou ) { $prod->save(); }
	}

	if ( $n_sku )   { $rel[] = $n_sku . ' SKU(s) padronizados em maiúsculas e sem espaços.'; }
	if ( $n_gtin )  { $rel[] = $n_gtin . ' código(s) de barras limpos (apenas dígitos).'; }
	if ( $n_marca ) { $rel[] = $n_marca . ' produto(s) receberam a marca deduzida do SKU/nome.'; }
	if ( $n_est )   { $rel[] = $n_est . ' produto(s) com preço voltaram para "em estoque".'; }

	if ( function_exists( 'awr_flush_product_cache' ) ) { awr_flush_product_cache(); }
	if ( function_exists( 'awr_flush_shop_cache' ) ) { awr_flush_shop_cache(); }
	$rel[] = 'Caches de produto e de loja do tema limpos.';

	if ( ! $n_sku && ! $n_gtin && ! $n_marca && ! $n_est ) {
		$rel[] = 'Nada mais podia ser deduzido automaticamente — o que sobrou precisa de informação nova (preço, foto, GTIN, categoria).';
	}
	return $rel;
}

/* ---------------------------------------------------------------------
   5) Tela
   --------------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_options_page( 'AWR Produtos (Merchant)', 'AWR Produtos (Merchant)', 'manage_options', 'awr-merchant-produtos', 'awr_merchant_produtos_page' );
} );

/** Tela de produtos reprovados / em risco. */
function awr_merchant_produtos_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }

	$aviso = '';
	if ( isset( $_POST['awr_mp_acao'] ) && check_admin_referer( 'awr_mp' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$acao = sanitize_key( wp_unslash( $_POST['awr_mp_acao'] ) );
		if ( 'salvar' === $acao ) {
			$dados = array();
			foreach ( array( 'preco', 'estoque', 'sku', 'marca', 'gtin', 'categoria', 'imagem' ) as $campo ) {
				$dados[ $campo ] = isset( $_POST[ $campo ] ) ? wp_unslash( $_POST[ $campo ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			}
			$aviso = awr_merchant_salvar_produto( (int) ( $_POST['produto_id'] ?? 0 ), $dados );
		} elseif ( 'autofix' === $acao ) {
			$aviso = implode( ' ', array_merge( awr_merchant_autofix_integracao(), awr_merchant_autofix() ) );
		} elseif ( 'gtins' === $acao ) {
			$r     = awr_aplicar_gtins_tabela();
			$aviso = $r['preenchidos'] . ' produto(s) receberam o código de barras da tabela. '
				. $r['ja_tinham'] . ' já tinham código. '
				. $r['sem_tabela'] . ' seguem sem código e vão ao Google com marca + código do modelo'
				. ( $r['faltando'] ? ' (ex.: ' . implode( ', ', array_slice( $r['faltando'], 0, 15 ) ) . ')' : '' ) . '.';
		} elseif ( 'marcas' === $acao ) {
			$m     = awr_aplicar_marcas_fabricante();
			$aviso = $m['gravados'] . ' produto(s) receberam a marca do fabricante ('
				. $m['corrigidos'] . ' estavam com "AWR Baterias"). '
				. $m['ja_ok'] . ' já estavam certos. '
				. count( $m['sem_marca'] ) . ' seguem sem marca reconhecida'
				. ( $m['sem_marca'] ? ' (ex.: ' . implode( ', ', array_slice( $m['sem_marca'], 0, 15 ) ) . ')' : '' ) . '.';
		}
	}

	$filtro = isset( $_GET['pendencia'] ) ? sanitize_key( wp_unslash( $_GET['pendencia'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$editar = isset( $_GET['editar'] ) ? (int) $_GET['editar'] : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$lista  = awr_merchant_produtos_pendentes( $filtro );
	$cats   = taxonomy_exists( 'product_cat' ) ? get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'number' => 200 ) ) : array();

	echo '<div class="wrap"><h1>AWR Produtos (Merchant)</h1>';
	if ( $aviso ) { echo '<div class="notice notice-info"><p>' . esc_html( $aviso ) . '</p></div>'; }

	echo '<p>' . ( awr_gla_issues_table()
		? 'Motivos oficiais do Merchant Center + checagens do tema.'
		: 'A extensão Google for WooCommerce ainda não gravou motivos oficiais. Abaixo estão as checagens do tema — são os mesmos itens que o Merchant recusa.' ) . '</p>';

	echo '<form method="post" style="margin:12px 0;display:inline-block">';
	wp_nonce_field( 'awr_mp' );
	echo '<input type="hidden" name="awr_mp_acao" value="autofix">';
	submit_button( 'Corrigir automaticamente o que for possível', 'primary', 'submit', false );
	echo '</form> ';

	echo '<form method="post" style="margin:12px 0;display:inline-block">';
	wp_nonce_field( 'awr_mp' );
	echo '<input type="hidden" name="awr_mp_acao" value="gtins">';
	submit_button( 'Aplicar códigos de barras da tabela (' . count( awr_gtin_tabela() ) . ' modelos)', 'secondary', 'submit', false );
	echo '</form> ';

	echo '<form method="post" style="margin:12px 0;display:inline-block">';
	wp_nonce_field( 'awr_mp' );
	echo '<input type="hidden" name="awr_mp_acao" value="marcas">';
	submit_button( 'Detectar e gravar a marca do fabricante em todo o catálogo', 'secondary', 'submit', false );
	echo '</form>';
	echo '<p class="description">Códigos de barras só são gravados quando o modelo consta na tabela oficial. Um código nunca é copiado de outro modelo: isso reprovaria o produto no Merchant Center.</p>';
	echo '<p class="description">A marca é sempre a do fabricante (Moura, Heliar, Freedom, Motobatt, Unipower…). "AWR Baterias" é a loja e aparece apenas como vendedor — marca de revendedor reprova o item.</p>';

	$filtros = array(
		''          => 'Todos',
		'merchant'  => 'Reprovados pelo Merchant',
		'preco'     => 'Sem preço',
		'foto'      => 'Sem foto',
		'imagem'    => 'Foto pequena',
		'sku'       => 'Sem SKU',
		'categoria' => 'Sem categoria',
		'marca'     => 'Sem marca',
		'gtin'      => 'Sem GTIN',
		'estoque'   => 'Fora de estoque',
	);
	echo '<p>';
	foreach ( $filtros as $k => $rotulo ) {
		$url = add_query_arg( array( 'page' => 'awr-merchant-produtos', 'pendencia' => $k ), admin_url( 'options-general.php' ) );
		printf(
			'<a href="%s" class="button %s" style="margin-right:6px">%s</a>',
			esc_url( $url ),
			$filtro === $k ? 'button-primary' : '',
			esc_html( $rotulo )
		);
	}
	echo '</p>';

	printf( '<p><strong>%d</strong> produto(s) com pendência.</p>', count( $lista ) );

	echo '<table class="widefat striped"><thead><tr><th>Produto</th><th>SKU</th><th>Preço</th><th>Motivo</th><th></th></tr></thead><tbody>';
	foreach ( array_slice( $lista, 0, 200 ) as $p ) {
		$url_edit = add_query_arg(
			array( 'page' => 'awr-merchant-produtos', 'pendencia' => $filtro, 'editar' => $p['id'] ),
			admin_url( 'options-general.php' )
		);

		echo '<tr>';
		printf(
			'<td>%s<strong>%s</strong><br><a href="%s">abrir no WooCommerce</a></td>',
			$p['imagem'] ? '<img src="' . esc_url( $p['imagem'] ) . '" width="40" height="40" style="float:left;margin-right:8px;object-fit:cover">' : '',
			esc_html( $p['nome'] ),
			esc_url( (string) $p['editar'] )
		);
		printf( '<td>%s</td>', esc_html( $p['sku'] ? $p['sku'] : '—' ) );
		printf( '<td>%s</td>', $p['preco'] > 0 ? esc_html( 'R$ ' . number_format( $p['preco'], 2, ',', '.' ) ) : '—' );

		echo '<td>';
		foreach ( $p['motivos'] as $m ) {
			printf( '<div>%s %s</div>', $m['grave'] ? '⛔' : '⚠️', esc_html( $m['texto'] ) );
		}
		echo '</td>';
		printf( '<td><a class="button" href="%s">Corrigir</a></td>', esc_url( $url_edit ) );
		echo '</tr>';

		if ( $editar === $p['id'] ) {
			echo '<tr><td colspan="5" style="background:#fff8e5">';
			echo '<form method="post"><table class="form-table"><tbody>';
			wp_nonce_field( 'awr_mp' );
			echo '<input type="hidden" name="awr_mp_acao" value="salvar">';
			printf( '<input type="hidden" name="produto_id" value="%d">', (int) $p['id'] );

			printf( '<tr><th>Preço (R$)</th><td><input type="text" name="preco" value="%s" placeholder="299,90"></td></tr>', esc_attr( $p['preco'] > 0 ? number_format( $p['preco'], 2, ',', '' ) : '' ) );

			echo '<tr><th>Estoque</th><td><select name="estoque">';
			foreach ( array( 'instock' => 'Em estoque', 'outofstock' => 'Fora de estoque', 'onbackorder' => 'Sob encomenda' ) as $v => $r ) {
				printf( '<option value="%s" %s>%s</option>', esc_attr( $v ), selected( $v, $p['estoque'], false ), esc_html( $r ) );
			}
			echo '</select></td></tr>';

			printf( '<tr><th>SKU</th><td><input type="text" name="sku" value="%s"></td></tr>', esc_attr( $p['sku'] ) );
			printf( '<tr><th>Marca</th><td><input type="text" name="marca" value="%s" placeholder="Moura"></td></tr>', esc_attr( $p['marca'] ) );
			printf( '<tr><th>GTIN / EAN</th><td><input type="text" name="gtin" value="%s" placeholder="7891234567895"></td></tr>', esc_attr( $p['gtin'] ) );

			echo '<tr><th>Categoria</th><td><select name="categoria"><option value="">— manter —</option>';
			foreach ( (array) $cats as $c ) {
				if ( is_wp_error( $c ) ) { continue; }
				printf(
					'<option value="%d" %s>%s</option>',
					(int) $c->term_id,
					selected( $c->name, $p['categoria'], false ),
					esc_html( $c->name )
				);
			}
			echo '</select></td></tr>';

			echo '<tr><th>Imagem</th><td><input type="text" name="imagem" class="regular-text" placeholder="ID da biblioteca ou https://..."><p class="description">Informe o ID de uma imagem já na biblioteca ou um endereço https — a foto é baixada e definida como principal.</p></td></tr>';

			echo '</tbody></table>';
			submit_button( 'Salvar correções', 'primary', 'submit', false );
			echo '</form></td></tr>';
		}
	}
	if ( ! $lista ) {
		echo '<tr><td colspan="5">Nenhuma pendência encontrada.</td></tr>';
	}
	echo '</tbody></table>';

	echo '<h2 style="margin-top:28px">Integração WooCommerce ↔ Merchant Center</h2>';
	echo '<table class="widefat striped"><tbody>';
	foreach ( awr_merchant_validar_integracao() as $item ) {
		printf(
			'<tr><td style="width:28px">%s</td><td style="width:260px"><strong>%s</strong></td><td>%s</td></tr>',
			$item['ok'] ? '✅' : '⚠️',
			esc_html( $item['titulo'] ),
			esc_html( $item['detalhe'] )
		);
	}
	echo '</tbody></table>';
	echo '<p class="description">O botão acima também corrige sozinho indexação bloqueada, links permanentes simples, canonical do produto e endereços internos desatualizados.</p>';
	echo '</div>';
}

/* ---------------------------------------------------------------------
   6) Validação da integração (autenticação, URLs, schema, feed, permissões)
   --------------------------------------------------------------------- */

/**
 * Checa os pontos que costumam quebrar a ligação WooCommerce ↔ Merchant Center.
 *
 * @return array<int,array{ok:bool,titulo:string,detalhe:string}>
 */
function awr_merchant_validar_integracao() {
	$l = array();
	$add = function ( $ok, $titulo, $detalhe ) use ( &$l ) {
		$l[] = array( 'ok' => (bool) $ok, 'titulo' => $titulo, 'detalhe' => $detalhe );
	};

	// Autenticação / extensão.
	$gla = defined( 'WC_GLA_VERSION' ) || class_exists( '\\Automattic\\WooCommerce\\GoogleListingsAndAds\\PluginFactory' );
	$add( $gla, 'Extensão Google for WooCommerce', $gla ? 'Instalada e ativa.' : 'Instale e ative a extensão oficial para enviar o feed.' );

	$jp_ok = false;
	if ( class_exists( 'Jetpack_Options' ) ) {
		$jp_ok = (bool) Jetpack_Options::get_option( 'id' ) && (bool) Jetpack_Options::get_option( 'blog_token' );
	}
	$add( $jp_ok, 'Conexão WordPress.com (Jetpack)', $jp_ok ? 'Site registrado — a extensão consegue autenticar.' : 'Site ainda não registrado. Veja o bloco "Conexão WordPress.com" em Ajustes → AWR Merchant Center.' );

	$mc_id = (string) get_option( 'gla_merchant_id', '' );
	$add( '' !== $mc_id, 'Conta do Merchant Center vinculada', '' !== $mc_id ? 'ID ' . $mc_id . '.' : 'Nenhuma conta vinculada ainda pela extensão.' );

	// URLs.
	$home = home_url( '/' );
	$site = site_url( '/' );
	$add( untrailingslashit( $home ) === untrailingslashit( $site ), 'Endereço do site coerente', 'Endereço do site: ' . $site . ' | Endereço do WordPress: ' . $home );
	$add( 0 === strpos( $home, 'https://' ), 'HTTPS', 0 === strpos( $home, 'https://' ) ? 'O site usa https.' : 'O Merchant Center exige https na loja.' );
	$add( '' !== (string) get_option( 'permalink_structure' ), 'Links permanentes', '' !== (string) get_option( 'permalink_structure' ) ? 'Estrutura amigável ativa.' : 'Links "simples" quebram as rotas do feed e da API.' );
	$add( 'produto' === awr_produto_canonical_modo(), 'Canonical dos produtos', 'produto' === awr_produto_canonical_modo() ? 'A página do produto aponta para ela mesma.' : 'O canonical aponta para outra URL — o Merchant recusa por página de destino divergente.' );

	// Permissões / rastreamento.
	$publico = (bool) get_option( 'blog_public' );
	$add( $publico, 'Site visível para buscadores', $publico ? 'Indexação liberada.' : 'A opção "desencorajar mecanismos de busca" está ligada e bloqueia o robô de compras.' );

	$rest = awr_http_probe( rest_url( 'wc/v3' ) );
	$ok_rest = in_array( (int) $rest['code'], array( 200, 401, 403 ), true );
	$add( $ok_rest, 'API do WooCommerce acessível', $ok_rest ? 'Rota wc/v3 responde (código ' . (int) $rest['code'] . ').' : awr_http_motivo( (int) $rest['code'], $rest['erro'] ) );

	// Schema e feed.
	$total = function_exists( 'wc_get_product' ) ? (int) wp_count_posts( 'product' )->publish : 0;
	$pend  = count( awr_merchant_produtos_pendentes() );
	$add( 0 === $pend, 'Produtos prontos para o feed', $pend ? $pend . ' de ' . $total . ' produtos têm pendência — veja a lista acima.' : $total . ' produtos sem pendência.' );

	// Endereço da loja (exigido no cadastro do Merchant).
	$end = trim( (string) get_option( 'woocommerce_store_address', '' ) );
	$cep = trim( (string) get_option( 'woocommerce_store_postcode', '' ) );
	$pais = trim( (string) get_option( 'woocommerce_default_country', '' ) );
	$ok_end = $end && $cep && $pais;
	$add( $ok_end, 'Endereço da loja no WooCommerce', $ok_end ? $end . ' — ' . $cep . ' (' . $pais . ')' : 'Preencha endereço, CEP e país em WooCommerce → Definições.' );

	return $l;
}

/**
 * Corrige sozinho os itens de integração que não dependem de terceiros.
 *
 * @return array Linhas de relatório.
 */
function awr_merchant_autofix_integracao() {
	$rel = array();

	if ( ! get_option( 'blog_public' ) ) {
		update_option( 'blog_public', 1 );
		$rel[] = 'Indexação liberada: o site voltou a ficar visível para o Google.';
	}

	if ( '' === (string) get_option( 'permalink_structure' ) ) {
		update_option( 'permalink_structure', '/%postname%/' );
		$rel[] = 'Links permanentes mudados para o formato amigável (exigido pela API e pelo feed).';
	}

	if ( function_exists( 'flush_rewrite_rules' ) ) {
		flush_rewrite_rules( false );
		$rel[] = 'Endereços internos regravados.';
	}

	delete_transient( 'awr_jetpack_checks' );
	return $rel;
}
