<?php
/**
 * Tabela de códigos de barras (GTIN/EAN) por modelo + atributos técnicos usados
 * pelo Google Merchant Center.
 *
 * Regra de identificador (política do Google):
 *  - GTIN real quando o modelo está na tabela ou já está cadastrado no produto;
 *  - caso contrário, marca + MPN (o próprio código do modelo) e o item é
 *    declarado sem GTIN. Nunca repetir o GTIN de outro modelo: cada código
 *    pertence a um único produto e a duplicação reprova o item.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Normaliza um código de modelo para comparação (maiúsculas, só alfanumérico). */
function awr_gtin_norm( $codigo ) {
	return strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $codigo ) );
}

/**
 * Tabela oficial de modelos com GTIN conhecido.
 *
 * @return array<string,array{marca:string,linha:string,ah:int,gtin:string,nome:string}>
 */
function awr_gtin_tabela() {
	static $tab = null;
	if ( null !== $tab ) { return $tab; }

	$linhas = array(
		// Heliar.
		array( 'HGR60DD', 'HELIAR', 'SLI', 60, '07891676263065', 'Bateria Heliar 60Ah HGR60DD' ),
		array( 'HGR50LD', 'HELIAR', 'SLI', 50, '7891676262983', 'Bateria Heliar 50Ah HGR50LD' ),
		array( 'HGR70LE', 'HELIAR', 'SLI', 70, '7891676263103', 'Bateria Heliar 70Ah HGR70LE' ),
		array( 'HEFB60D', 'HELIAR', 'EFB', 60, '7891676264506', 'Bateria Heliar EFB 60Ah Start-Stop' ),
		array( 'HAGM60D', 'HELIAR', 'AGM', 60, '7891676264520', 'Bateria Heliar AGM 60Ah Start-Stop' ),
		// Moura.
		array( 'M60GD', 'MOURA', 'SLI', 60, '07897154296761', 'Bateria Moura 60Ah M60GD' ),
		array( 'M60GE', 'MOURA', 'SLI', 60, '7897154287417', 'Bateria Moura 60Ah M60GE' ),
		array( 'M50LD', 'MOURA', 'SLI', 50, '7897154287127', 'Bateria Moura 50Ah M50LD' ),
		array( 'M70LD', 'MOURA', 'SLI', 70, '7897154287707', 'Bateria Moura 70Ah M70LD' ),
		array( 'M75PD', 'MOURA', 'SLI', 75, '7897154287806', 'Bateria Moura 75Ah M75PD' ),
		array( 'M90RD', 'MOURA', 'SLI', 90, '7897154288001', 'Bateria Moura 90Ah M90RD' ),
		array( 'MEFB60D', 'MOURA', 'EFB', 60, '7897154289503', 'Bateria Moura EFB 60Ah Start-Stop' ),
		array( 'MAGM70D', 'MOURA', 'AGM', 70, '7897154289701', 'Bateria Moura AGM 70Ah Start-Stop' ),
		// Freedom (estacionária / nobreak / solar). GTINs conferidos na loja em 06/10/2026.
		array( 'DF500', 'FREEDOM', 'ESTACIONARIA', 40, '7891676070090', 'Bateria Estacionária Freedom DF500 40Ah' ),
		array( 'DF700', 'FREEDOM', 'ESTACIONARIA', 50, '7891676070106', 'Bateria Estacionária Freedom DF700 50Ah' ),
		array( 'DF1000', 'FREEDOM', 'ESTACIONARIA', 70, '7891676070113', 'Bateria Estacionária Freedom DF1000 70Ah' ),
		array( 'DF1500', 'FREEDOM', 'ESTACIONARIA', 93, '7891676070182', 'Bateria Estacionária Freedom DF1500 93Ah' ),
		array( 'DF2000', 'FREEDOM', 'ESTACIONARIA', 115, '7897154292527', 'Bateria Estacionária Freedom DF2000 115Ah' ),
		array( 'DF2500', 'FREEDOM', 'ESTACIONARIA', 165, '7893125000098', 'Bateria Estacionária Freedom DF2500 165Ah' ),
		array( 'DF3000', 'FREEDOM', 'ESTACIONARIA', 185, '7893125000111', 'Bateria Estacionária Freedom DF3000 185Ah' ),
		array( 'DF4100', 'FREEDOM', 'ESTACIONARIA', 240, '7891676070175', 'Bateria Estacionária Freedom DF4100 240Ah' ),
		array( 'DF4001', 'FREEDOM', 'ESTACIONARIA', 115, '7893125000135', 'Bateria Estacionária Freedom DF4001 115Ah' ),
		array( 'DF220', 'FREEDOM', 'ESTACIONARIA', 150, '7893125000159', 'Bateria Estacionária Freedom DF220 150Ah' ),
		array( 'DF250', 'FREEDOM', 'ESTACIONARIA', 165, '7893125000173', 'Bateria Estacionária Freedom DF250 165Ah' ),
		array( 'DF300', 'FREEDOM', 'ESTACIONARIA', 220, '7893125000197', 'Bateria Estacionária Freedom DF300 220Ah' ),
	);

	$tab = array();
	foreach ( $linhas as $l ) {
		$tab[ awr_gtin_norm( $l[0] ) ] = array(
			'modelo' => $l[0],
			'marca'  => $l[1],
			'linha'  => $l[2],
			'ah'     => (int) $l[3],
			'gtin'   => preg_replace( '/\D+/', '', $l[4] ),
			'nome'   => $l[5],
		);
	}

	/** Permite acrescentar modelos sem editar o tema. */
	return apply_filters( 'awr_gtin_tabela', $tab );
}

/** Dados da tabela para um SKU (null quando o modelo não está listado). */
function awr_gtin_info( $sku ) {
	$chave = awr_gtin_norm( $sku );
	if ( '' === $chave ) { return null; }
	$tab = awr_gtin_tabela();
	return isset( $tab[ $chave ] ) ? $tab[ $chave ] : null;
}

/** GTIN da tabela para um SKU ('' quando não houver). */
function awr_gtin_por_modelo( $sku ) {
	$info = awr_gtin_info( $sku );
	return $info ? $info['gtin'] : '';
}

/**
 * Tecnologia da bateria deduzida do modelo/nome: AGM, EFB, Estacionária ou SLI.
 */
function awr_bateria_tecnologia( $sku, $nome = '' ) {
	$info = awr_gtin_info( $sku );
	if ( $info ) {
		$mapa = array( 'AGM' => 'AGM', 'EFB' => 'EFB', 'ESTACIONARIA' => 'Estacionária', 'SLI' => 'Convencional' );
		return $mapa[ $info['linha'] ] ?? '';
	}
	$txt = strtoupper( (string) $sku . ' ' . (string) $nome );
	if ( false !== strpos( $txt, 'AGM' ) ) { return 'AGM'; }
	if ( false !== strpos( $txt, 'EFB' ) ) { return 'EFB'; }
	if ( false !== strpos( $txt, 'ESTACION' ) || preg_match( '/\bDF\s?\d{3,4}\b/', $txt ) ) { return 'Estacionária'; }
	return 'Convencional';
}

/** Polaridade pelo final do código: D = polo direito, E = polo esquerdo. */
function awr_bateria_polaridade( $sku ) {
	$s = awr_gtin_norm( $sku );
	if ( '' === $s ) { return ''; }
	$ultima = substr( $s, -1 );
	if ( 'D' === $ultima ) { return 'Polo positivo à direita'; }
	if ( 'E' === $ultima ) { return 'Polo positivo à esquerda'; }
	return '';
}

/**
 * Título no padrão do feed do Merchant Center:
 * [Marca] + [Linha] + [Capacidade] + [Modelo] + [Especificação].
 */
function awr_merchant_feed_title( $sku, $nome = '', $marca = '', $ah = 0 ) {
	$sku   = strtoupper( trim( (string) $sku ) );
	$info  = awr_gtin_info( $sku );
	$marca = trim( (string) $marca );
	if ( '' === $marca && $info ) { $marca = ucfirst( strtolower( $info['marca'] ) ); }
	if ( '' === $marca && function_exists( 'awr_resolve_brand' ) ) { $marca = (string) awr_resolve_brand( $sku, $nome ); }
	$ah   = (int) $ah ? (int) $ah : ( $info ? $info['ah'] : 0 );
	$tec  = awr_bateria_tecnologia( $sku, $nome );

	$tipo = 'Estacionária' === $tec ? 'Bateria Estacionária' : 'Bateria Automotiva';
	$p    = array( $tipo );
	if ( 'AGM' === $tec || 'EFB' === $tec ) { $p[] = $tec; }
	if ( $marca ) { $p[] = $marca; }
	if ( $ah ) { $p[] = $ah . 'Ah'; }
	if ( $sku ) { $p[] = $sku; }
	if ( 'AGM' === $tec || 'EFB' === $tec ) { $p[] = 'Start-Stop'; }

	return trim( preg_replace( '/\s+/', ' ', implode( ' ', $p ) ) );
}

/**
 * Descrição do feed: atributos técnicos primeiro, depois serviço.
 * Sem termos promocionais na primeira linha (exigência de qualidade do feed).
 */
function awr_merchant_feed_description( $sku, $nome = '', $marca = '', $ah = 0 ) {
	$sku  = strtoupper( trim( (string) $sku ) );
	$info = awr_gtin_info( $sku );
	$ah   = (int) $ah ? (int) $ah : ( $info ? $info['ah'] : 0 );
	$tec  = awr_bateria_tecnologia( $sku, $nome );
	if ( '' === $marca && $info ) { $marca = ucfirst( strtolower( $info['marca'] ) ); }

	$ficha = array();
	if ( $marca ) { $ficha[] = 'Marca ' . $marca; }
	$ficha[] = 'modelo ' . $sku;
	if ( $ah ) { $ficha[] = 'capacidade ' . $ah . 'Ah'; }
	$ficha[] = 'tensão 12V';
	if ( $tec ) { $ficha[] = 'tecnologia ' . $tec; }
	$pol = awr_bateria_polaridade( $sku );
	if ( $pol ) { $ficha[] = strtolower( $pol ); }

	$txt = ucfirst( implode( ', ', $ficha ) ) . '. Bateria nova, selada, com garantia de fábrica e nota fiscal. ';
	if ( 'Estacionária' === $tec ) {
		$txt .= 'Indicada para nobreak, sistemas solares e uso de ciclo profundo. ';
	} elseif ( 'AGM' === $tec || 'EFB' === $tec ) {
		$txt .= 'Indicada para veículos com sistema Start-Stop e alta demanda elétrica. ';
	} else {
		$txt .= 'Indicada para veículos de passeio e utilitários leves. ';
	}
	$txt .= 'Preço à vista válido com a devolução do casco (bateria usada) no ato da entrega.';

	return $txt;
}

/* ---------------------------------------------------------------------
   Aplicação em massa nos produtos do WooCommerce
   --------------------------------------------------------------------- */

/**
 * Preenche o GTIN dos produtos cujo SKU está na tabela.
 *
 * @return array{preenchidos:int,ja_tinham:int,sem_tabela:int,faltando:array<int,string>}
 */
function awr_aplicar_gtins_tabela() {
	$res = array( 'preenchidos' => 0, 'ja_tinham' => 0, 'sem_tabela' => 0, 'faltando' => array() );
	if ( ! function_exists( 'wc_get_product' ) ) { return $res; }

	global $wpdb;
	$ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type='product' AND post_status='publish' LIMIT 2000" ); // phpcs:ignore WordPress.DB

	foreach ( $ids as $id ) {
		$prod = wc_get_product( (int) $id );
		if ( ! $prod ) { continue; }
		$sku = (string) $prod->get_sku();

		if ( awr_produto_gtin( $prod ) ) { $res['ja_tinham']++; continue; }

		$gtin = awr_gtin_por_modelo( $sku );
		if ( '' === $gtin ) {
			$res['sem_tabela']++;
			if ( count( $res['faltando'] ) < 60 && $sku ) { $res['faltando'][] = strtoupper( $sku ); }
			continue;
		}

		$prod->update_meta_data( '_global_unique_id', $gtin );
		$prod->save();
		$res['preenchidos']++;
	}

	if ( function_exists( 'awr_flush_product_cache' ) ) { awr_flush_product_cache(); }
	if ( function_exists( 'awr_flush_shop_cache' ) ) { awr_flush_shop_cache(); }
	return $res;
}

/* ---------------------------------------------------------------------
   Título e descrição enviados pela extensão Google for WooCommerce
   --------------------------------------------------------------------- */

add_filter( 'woocommerce_gla_product_attribute_value_title', function ( $valor, $produto ) {
	if ( ! $produto || ! method_exists( $produto, 'get_sku' ) ) { return $valor; }
	$sku = (string) $produto->get_sku();
	if ( '' === $sku ) { return $valor; }
	$marca = function_exists( 'awr_produto_marca_salva' ) ? awr_produto_marca_salva( $produto ) : '';
	$novo  = awr_merchant_feed_title( $sku, $produto->get_name(), $marca );
	return $novo ? $novo : $valor;
}, 10, 2 );

add_filter( 'woocommerce_gla_product_attribute_value_description', function ( $valor, $produto ) {
	if ( ! $produto || ! method_exists( $produto, 'get_sku' ) ) { return $valor; }
	$sku = (string) $produto->get_sku();
	if ( '' === $sku ) { return $valor; }
	$marca = function_exists( 'awr_produto_marca_salva' ) ? awr_produto_marca_salva( $produto ) : '';
	$novo  = awr_merchant_feed_description( $sku, $produto->get_name(), $marca );
	return $novo ? $novo : $valor;
}, 10, 2 );
