<?php
/**
 * Validação SEO — wp-admin.
 *
 * Ajustes → AWR Validação SEO:
 *  A) Validação em lote das rotas do tema (status HTTP, redirect, canonical,
 *     og:url), executada em lotes via AJAX com relatório exportável em CSV.
 *  B) Comparativo de canonical/og:url entre domínios (principal × satélites),
 *     destacando divergências de consolidação.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'AWR_VAL_BATCH', 25 );
define( 'AWR_VAL_UA', 'AWR-Validacao/1.0 (+https://awrbaterias.com.br)' );

/* ---------------------------------------------------------------------
   Lista de URLs para a validação em lote
   --------------------------------------------------------------------- */

/**
 * Amostra determinística e distribuída de uma lista grande
 * (primeiro, último e pontos intermediários equidistantes).
 */
function awr_val_amostra( $urls, $n ) {
	$urls = array_values( array_unique( $urls ) );
	$total = count( $urls );
	if ( $total <= $n ) { return $urls; }
	$out = array();
	for ( $i = 0; $i < $n; $i++ ) {
		$out[] = $urls[ (int) floor( $i * ( $total - 1 ) / ( $n - 1 ) ) ];
	}
	return array_values( array_unique( $out ) );
}

/** Monta a lista completa de URLs locais a validar. */
function awr_validacao_urls() {
	$urls = array();

	// Rotas corrigidas nas v3.48.2/v3.48.3 — prioridade máxima.
	$urls[] = home_url( '/baterias/amperagem/' );
	foreach ( awr_amperagens_disponiveis() as $ah ) {
		$urls[] = home_url( '/baterias/amperagem/' . $ah . '/' );
	}
	$urls[] = home_url( '/baterias-para-moto/marca/' );
	foreach ( awr_moto_brands() as $mb ) {
		$urls[] = awr_moto_brand_url( $mb['slug'] );
	}
	// Todas as combinações segmento × cidade (sem bairros).
	foreach ( awr_segmentos() as $sg ) {
		$urls[] = awr_segmento_url( $sg );
		foreach ( awr_segmento_cidades( $sg ) as $sc ) {
			$urls[] = awr_segmento_url( $sg, $sc['slug'] );
		}
	}

	// Seções leves completas.
	foreach ( array( 'conteudo', 'cidades', 'marcas', 'lojas' ) as $secao ) {
		foreach ( awr_sitemap_urls( $secao ) as $u ) { $urls[] = $u; }
	}
	// Bairros são numerosos: amostra distribuída suficiente para detectar regressões.
	$urls = array_merge( $urls, awr_val_amostra( awr_sitemap_urls( 'bairros' ), 30 ) );

	// Amostras das seções pesadas.
	$urls = array_merge( $urls, awr_val_amostra( awr_sitemap_urls( 'skus' ), 30 ) );
	$urls = array_merge( $urls, awr_val_amostra( awr_sitemap_urls( 'veiculos' ), 30 ) );
	if ( function_exists( 'awr_vc_sitemap_page' ) ) {
		$urls = array_merge( $urls, (array) awr_vc_sitemap_page( 1, 30 ) );
	}

	// Cobertura veículo × cidade: 1 URL por cidade com página ativa (todas),
	// usando modelos populares em rotação — garante que cada cidade esteja
	// representada na validação.
	if ( function_exists( 'awr_vc_cidades' ) && function_exists( 'awr_vc_models_sitemap' ) ) {
		$modelos = awr_vc_models_sitemap();
		$nm      = max( 1, count( $modelos ) );
		$i       = 0;
		foreach ( awr_vc_cidades() as $vc ) {
			$m      = $modelos[ $i % $nm ];
			$urls[] = awr_vc_url( $m['slug'], $vc['c']['slug'] );
			$i++;
		}
	}

	return array_values( array_unique( $urls ) );
}

/* ---------------------------------------------------------------------
   Fetch concorrente + extração de canonical / og:url
   --------------------------------------------------------------------- */

/* ---------------------------------------------------------------------
   3. Checagem do sitemap ativo + canônicas prioritárias
   --------------------------------------------------------------------- */

/** Sitemaps públicos do tema. */
function awr_val_sitemaps() {
	return array( 'conteudo', 'cidades', 'bairros', 'marcas', 'segmentos', 'lojas', 'skus', 'veiculos' );
}

/**
 * Verifica se cada sitemap responde 200 e conta os <loc>.
 * Depois confere as canônicas prioritárias (status 200, canonical == URL,
 * og:url == canonical). Resultado em cache por 10 minutos.
 */
function awr_val_sitemap_check( $force = false ) {
	$key = 'awr_val_sitemap_check';
	if ( ! $force ) {
		$cache = get_transient( $key );
		if ( is_array( $cache ) ) { return $cache; }
	}

	$out = array( 'gerado_em' => gmdate( 'Y-m-d H:i' ) . ' UTC', 'sitemaps' => array(), 'prioritarias' => array() );

	foreach ( awr_val_sitemaps() as $secao ) {
		$url = home_url( '/awr-sitemap-' . $secao . '.xml' );
		$r   = wp_remote_get( $url, array( 'timeout' => 15 ) );
		$st  = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
		$loc = 0;
		if ( 200 === $st ) {
			$body = wp_remote_retrieve_body( $r );
			$loc  = preg_match_all( '/<loc>/i', (string) $body );
		}
		$out['sitemaps'][] = array( 'secao' => $secao, 'url' => $url, 'status' => $st, 'urls' => (int) $loc );
	}

	// /sitemap.xml é o endereço enviado ao Search Console: precisa terminar no
	// índice do tema, não no sitemap nativo do WordPress.
	$alias = wp_remote_get( home_url( '/sitemap.xml' ), array( 'timeout' => 15, 'redirection' => 5 ) );
	$abody = is_wp_error( $alias ) ? '' : (string) wp_remote_retrieve_body( $alias );
	$out['alias'] = array(
		'url'    => home_url( '/sitemap.xml' ),
		'status' => is_wp_error( $alias ) ? 0 : (int) wp_remote_retrieve_response_code( $alias ),
		'ok'     => false !== strpos( $abody, 'awr-sitemap-' ),
	);

	// Um robots.txt físico na raiz vence o robots dinâmico do WordPress: se ele
	// existir e estiver vazio, o Google fica sem a linha Sitemap.
	$rb   = wp_remote_get( home_url( '/robots.txt' ), array( 'timeout' => 15 ) );
	$rtxt = is_wp_error( $rb ) ? '' : (string) wp_remote_retrieve_body( $rb );
	$out['robots'] = array(
		'status'  => is_wp_error( $rb ) ? 0 : (int) wp_remote_retrieve_response_code( $rb ),
		'bytes'   => strlen( $rtxt ),
		'sitemap' => false !== stripos( $rtxt, 'sitemap:' ),
		'estatico' => '' === trim( $rtxt ) || false === stripos( $rtxt, 'user-agent' ),
	);

	// Amostra prioritária coerente: 1 URL por seção de conteúdo indexável.
	$prio = array( home_url( '/' ) );
	foreach ( array( 'conteudo', 'cidades', 'marcas', 'segmentos', 'lojas' ) as $secao ) {
		$lista = awr_sitemap_urls( $secao );
		if ( $lista ) { $prio[] = $lista[0]; }
	}
	$prio = array_values( array_unique( $prio ) );

	foreach ( awr_val_fetch_many( $prio ) as $row ) {
		$row['ok'] = 200 === $row['status']
			&& $row['canonical']
			&& untrailingslashit( $row['canonical'] ) === untrailingslashit( $row['url'] )
			&& ( ! $row['og'] || untrailingslashit( $row['og'] ) === untrailingslashit( $row['canonical'] ) );
		$out['prioritarias'][] = $row;
	}

	set_transient( $key, $out, 10 * MINUTE_IN_SECONDS );
	return $out;
}

/** Extrai canonical e og:url do HTML. */
function awr_val_extract( $html ) {
	$out = array( 'canonical' => '', 'og' => '' );
	if ( ! is_string( $html ) || '' === $html ) { return $out; }
	if ( preg_match( '/<link[^>]+rel=["\']canonical["\'][^>]*>/i', $html, $m )
		|| preg_match( '/<link[^>]+rel=canonical[^>]*>/i', $html, $m ) ) {
		if ( preg_match( '/href=["\']([^"\']+)["\']/i', $m[0], $h ) ) {
			$out['canonical'] = html_entity_decode( $h[1], ENT_QUOTES, 'UTF-8' );
		}
	}
	if ( preg_match( '/<meta[^>]+property=["\']og:url["\'][^>]*>/i', $html, $m ) ) {
		if ( preg_match( '/content=["\']([^"\']+)["\']/i', $m[0], $c ) ) {
			$out['og'] = html_entity_decode( $c[1], ENT_QUOTES, 'UTF-8' );
		}
	}
	return $out;
}

/** Normaliza a resposta bruta em uma linha de relatório. */
function awr_val_row( $url, $status, $location, $body, $ms ) {
	$meta = awr_val_extract( $body );
	return array(
		'url'       => $url,
		'status'    => (int) $status,
		'location'  => (string) $location,
		'canonical' => $meta['canonical'],
		'og'        => $meta['og'],
		'ms'        => (int) $ms,
	);
}

/**
 * Busca um lote de URLs em paralelo (Requests::request_multiple) com
 * fallback sequencial via wp_remote_get. Nunca segue redirects — o
 * redirect é um dado do relatório, não algo a transparentar.
 */
function awr_val_fetch_many( $urls ) {
	$rows = array();
	$urls = array_values( $urls );
	if ( ! $urls ) { return $rows; }

	if ( class_exists( 'WpOrg\\Requests\\Requests' ) ) {
		$reqs = array();
		foreach ( $urls as $u ) {
			$reqs[] = array( 'url' => $u, 'type' => 'GET' );
		}
		$t0  = microtime( true );
		$res = WpOrg\Requests\Requests::request_multiple( $reqs, array(
			'timeout'   => 10,
			'redirects' => 0,
			'useragent' => AWR_VAL_UA,
		) );
		$avg = (int) round( ( microtime( true ) - $t0 ) * 1000 / max( 1, count( $urls ) ) );
		foreach ( $urls as $i => $u ) {
			$r = isset( $res[ $i ] ) ? $res[ $i ] : null;
			if ( $r instanceof Exception ) {
				$rows[] = awr_val_row( $u, 0, '', '', 0 );
				continue;
			}
			$loc = '';
			if ( isset( $r->headers['location'] ) ) { $loc = (string) $r->headers['location']; }
			$rows[] = awr_val_row( $u, (int) $r->status_code, $loc, (string) $r->body, $avg );
		}
		return $rows;
	}

	// Fallback sequencial.
	foreach ( $urls as $u ) {
		$t0 = microtime( true );
		$r  = wp_remote_get( $u, array(
			'timeout'     => 10,
			'redirection' => 0,
			'user-agent'  => AWR_VAL_UA,
		) );
		$ms = (int) round( ( microtime( true ) - $t0 ) * 1000 );
		if ( is_wp_error( $r ) ) {
			$rows[] = awr_val_row( $u, 0, '', '', $ms );
			continue;
		}
		$rows[] = awr_val_row(
			$u,
			(int) wp_remote_retrieve_response_code( $r ),
			(string) wp_remote_retrieve_header( $r, 'location' ),
			(string) wp_remote_retrieve_body( $r ),
			$ms
		);
	}
	return $rows;
}

/** Classifica a linha: ok | redirect | aviso | erro. */
function awr_val_classify( $row ) {
	if ( $row['status'] !== 200 ) {
		return ( $row['status'] >= 300 && $row['status'] < 400 ) ? 'redirect' : 'erro';
	}
	$esperado = awr_canonical_url( $row['url'] );
	if ( $row['canonical'] && untrailingslashit( $row['canonical'] ) !== untrailingslashit( $esperado ) ) {
		return 'aviso';
	}
	return 'ok';
}

/* ---------------------------------------------------------------------
   Seção A — validação em lote via AJAX
   --------------------------------------------------------------------- */

add_action( 'wp_ajax_awr_val_batch', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'forbidden', 403 ); }
	check_ajax_referer( 'awr_val', 'nonce' );

	$offset = max( 0, (int) ( $_POST['offset'] ?? 0 ) ); // phpcs:ignore
	$hash   = sanitize_key( (string) ( $_POST['hash'] ?? '' ) ); // phpcs:ignore

	if ( $hash ) {
		$urls = get_transient( 'awr_val_list_' . $hash );
		if ( ! is_array( $urls ) ) { wp_send_json_error( 'lista expirada — reinicie a validação' ); }
	} else {
		$urls = awr_validacao_urls();
		$hash = substr( md5( wp_json_encode( $urls ) . microtime() ), 0, 12 );
		set_transient( 'awr_val_list_' . $hash, $urls, HOUR_IN_SECONDS );
		set_transient( 'awr_val_run_' . $hash, array(), HOUR_IN_SECONDS );
	}

	$total = count( $urls );
	$slice = array_slice( $urls, $offset, AWR_VAL_BATCH );
	$rows  = awr_val_fetch_many( $slice );

	$run = get_transient( 'awr_val_run_' . $hash );
	$run = is_array( $run ) ? $run : array();
	foreach ( $rows as $r ) { $run[] = $r; }
	set_transient( 'awr_val_run_' . $hash, $run, HOUR_IN_SECONDS );

	$next = $offset + count( $slice );
	$done = $next >= $total;

	if ( $done ) {
		update_option( 'awr_validacao_relatorio', array(
			'gerado_em' => current_time( 'mysql' ),
			'total'     => $total,
			'rows'      => $run,
		), false );
		delete_transient( 'awr_val_list_' . $hash );
		delete_transient( 'awr_val_run_' . $hash );
	}

	$counts = array( 'ok' => 0, 'redirect' => 0, 'aviso' => 0, 'erro' => 0 );
	foreach ( $run as $r ) { $counts[ awr_val_classify( $r ) ]++; }

	wp_send_json_success( array(
		'hash'   => $hash,
		'rows'   => $rows,
		'next'   => $next,
		'total'  => $total,
		'done'   => $done,
		'counts' => $counts,
	) );
} );

/** Exporta o último relatório em CSV. */
add_action( 'admin_init', function () {
	if ( empty( $_GET['awr_val_csv'] ) || ! current_user_can( 'manage_options' ) ) { return; } // phpcs:ignore
	check_admin_referer( 'awr_val_csv' );
	$rel = get_option( 'awr_validacao_relatorio' );
	if ( empty( $rel['rows'] ) ) { wp_safe_redirect( admin_url( 'options-general.php?page=awr-validacao' ) ); exit; }

	nocache_headers();
	header( 'Content-Type: text/csv; charset=UTF-8' );
	header( 'Content-Disposition: attachment; filename="awr-validacao-' . gmdate( 'Ymd-His' ) . '.csv"' );
	$out = fopen( 'php://output', 'w' );
	fprintf( $out, "\xEF\xBB\xBF" ); // BOM para o Excel reconhecer UTF-8.
	fputcsv( $out, array( 'url', 'status', 'redirect_para', 'canonical', 'og_url', 'situacao' ) );
	foreach ( $rel['rows'] as $r ) {
		fputcsv( $out, array( $r['url'], $r['status'], $r['location'], $r['canonical'], $r['og'], awr_val_classify( $r ) ) );
	}
	fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
} );

/* ---------------------------------------------------------------------
   Seção B — comparativo entre domínios
   --------------------------------------------------------------------- */

/** Domínios comparados (primeiro = principal). */
function awr_val_dominios() {
	$raw = (string) get_option( 'awr_val_dominios', '' );
	if ( ! trim( $raw ) ) {
		$raw = "https://awrbaterias.com.br\nhttps://bateriasportoalegre.com.br\nhttps://bateriasgravatai.com.br";
	}
	$out = array();
	foreach ( preg_split( '/[\r\n]+/', $raw ) as $line ) {
		$line = trim( $line );
		if ( $line && preg_match( '#^https?://#i', $line ) ) { $out[] = untrailingslashit( $line ); }
	}
	return array_values( array_unique( $out ) );
}

/** Paths representativos comparados entre os domínios. */
function awr_val_paths() {
	$raw = (string) get_option( 'awr_val_paths', '' );
	if ( ! trim( $raw ) ) {
		$raw = "/\n/baterias-em/gravatai/\n/baterias-em/viamao/\n/baterias-em/esteio/\n/baterias-em/campo-bom/\n/baterias-em/sapiranga/\n/baterias-em/estancia-velha/\n/baterias-em/ivoti/\n/baterias-estacionarias/\n/baterias/amperagem/\n/baterias-para-moto/marca/honda/";
	}
	$out = array();
	foreach ( preg_split( '/[\r\n]+/', $raw ) as $line ) {
		$line = trim( $line );
		if ( $line && str_starts_with( $line, '/' ) ) { $out[] = $line; }
	}
	return array_values( array_unique( $out ) );
}

/** Salva a configuração do comparativo. */
add_action( 'admin_post_awr_val_save_cfg', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'forbidden' ); }
	check_admin_referer( 'awr_val_cfg' );
	update_option( 'awr_val_dominios', sanitize_textarea_field( (string) ( $_POST['dominios'] ?? '' ) ), false ); // phpcs:ignore
	update_option( 'awr_val_paths', sanitize_textarea_field( (string) ( $_POST['paths'] ?? '' ) ), false ); // phpcs:ignore
	delete_transient( 'awr_val_compare' );
	wp_safe_redirect( admin_url( 'options-general.php?page=awr-validacao#comparativo' ) );
	exit;
} );

/** Executa o comparativo (botão "Revalidar agora"). */
add_action( 'admin_post_awr_val_compare', function () {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'forbidden' ); }
	check_admin_referer( 'awr_val_compare' );
	delete_transient( 'awr_val_compare' );
	awr_val_compare_run(); // repopula o transient
	wp_safe_redirect( admin_url( 'options-general.php?page=awr-validacao#comparativo' ) );
	exit;
} );

/**
 * Roda (ou lê do cache de 10 min) a matriz path × domínio.
 *
 * @return array<string, array<string, array>> [path][dominio] => row
 */
function awr_val_compare_run() {
	$cache = get_transient( 'awr_val_compare' );
	if ( is_array( $cache ) ) { return $cache; }

	$dominios = awr_val_dominios();
	$paths    = awr_val_paths();
	$targets  = array();
	foreach ( $paths as $p ) {
		foreach ( $dominios as $d ) { $targets[] = array( 'path' => $p, 'dominio' => $d, 'url' => $d . $p ); }
	}
	$rows = awr_val_fetch_many( wp_list_pluck( $targets, 'url' ) );

	$matrix = array();
	foreach ( $targets as $i => $t ) {
		$matrix[ $t['path'] ][ $t['dominio'] ] = isset( $rows[ $i ] ) ? $rows[ $i ] : awr_val_row( $t['url'], 0, '', '', 0 );
	}
	set_transient( 'awr_val_compare', $matrix, 10 * MINUTE_IN_SECONDS );
	return $matrix;
}

/** Host de uma URL (minúsculo, sem www). */
function awr_val_host( $url ) {
	$h = (string) wp_parse_url( (string) $url, PHP_URL_HOST );
	return strtolower( preg_replace( '/^www\./', '', $h ) );
}

/* ---------------------------------------------------------------------
   Página do admin
   --------------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_options_page( 'AWR Validação SEO', 'AWR Validação SEO', 'manage_options', 'awr-validacao', 'awr_validacao_page' );
} );

/** Renderiza uma linha do relatório da Seção A (servidor, para o último relatório salvo). */
function awr_val_row_html( $row ) {
	$cls   = awr_val_classify( $row );
	$cor   = array( 'ok' => '', 'redirect' => 'background:#fcf9e8', 'aviso' => 'background:#fcf9e8', 'erro' => 'background:#fdeaea' );
	$badge = array( 'ok' => '<span style="color:#008a20">●</span> 200', 'redirect' => '<span style="color:#dba617">●</span> ' . (int) $row['status'], 'aviso' => '<span style="color:#dba617">●</span> 200', 'erro' => '<span style="color:#d63638">●</span> ' . (int) $row['status'] );
	echo '<tr style="' . esc_attr( $cor[ $cls ] ) . '">';
	echo '<td style="word-break:break-all"><a href="' . esc_url( $row['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $row['url'] ) . '</a></td>';
	echo '<td>' . wp_kses_post( $badge[ $cls ] ) . '</td>';
	echo '<td style="word-break:break-all">' . ( $row['location'] ? esc_html( $row['location'] ) : '—' ) . '</td>';
	echo '<td style="word-break:break-all">' . ( $row['canonical'] ? esc_html( $row['canonical'] ) : '—' ) . '</td>';
	echo '<td style="word-break:break-all">' . ( $row['og'] ? esc_html( $row['og'] ) : '—' ) . '</td>';
	echo '</tr>';
}

/** Página Ajustes → AWR Validação SEO. */
/**
 * Diagnóstico de performance do servidor/tema — aba "Performance" da validação.
 * Retorna linhas [checagem, valor, ok(null=info), dica].
 */
function awr_perf_diagnostics() {
	global $wpdb;
	$rows = array();

	// PHP
	$php    = PHP_VERSION;
	$php_ok = version_compare( $php, '8.0', '>=' );
	$rows[] = array( 'Versão do PHP', $php, $php_ok,
		$php_ok ? '' : 'Peça à hospedagem o PHP 8.0+ (7.x é bem mais lento).' );

	// Cloudflare Rocket Loader — atrasa a pintura do título do hero (LCP).
	if ( function_exists( 'awr_rocket_loader_status' ) ) {
		$rl = awr_rocket_loader_status();
		if ( $rl['erro'] ) {
			$rows[] = array( 'Cloudflare Rocket Loader', 'não foi possível checar', null,
				'Confira manualmente em Cloudflare → Speed → Optimization → Rocket Loader.' );
		} else {
			$rows[] = array( 'Cloudflare Rocket Loader', $rl['ativo'] ? 'ATIVO (' . $rl['checado_em'] . ')' : 'desligado (' . $rl['checado_em'] . ')', ! $rl['ativo'],
				$rl['ativo'] ? 'Desligue em Cloudflare → Speed → Optimization → Content Optimization → Rocket Loader → Off e depois Caching → Purge Everything. Ele atrasa a exibição do título principal.' : '' );
		}
	}

	// OPcache
	$op = function_exists( 'opcache_get_status' ) && @opcache_get_status( false );
	$rows[] = array( 'OPcache (cache de bytecode PHP)', $op ? 'ativo' : 'inativo/indisponível', $op,
		$op ? '' : 'Sem OPcache cada requisição recompila todo o PHP. Peça a ativação à hospedagem — é o maior ganho de TTFB.' );

	// Compressão gzip/brotli na resposta da home (loopback).
	$gz = wp_remote_head( home_url( '/' ), array(
		'timeout'    => 8,
		'sslverify'  => false,
		'headers'    => array( 'Accept-Encoding' => 'gzip, br' ),
		'user-agent' => 'awr-perf-check',
	) );
	$enc = is_wp_error( $gz ) ? '' : strtolower( (string) wp_remote_retrieve_header( $gz, 'content-encoding' ) );
	$gz_ok = ( false !== strpos( $enc, 'br' ) || false !== strpos( $enc, 'gzip' ) );
	$rows[] = array( 'Compressão do HTML (gzip/brotli)', $enc ? $enc : ( is_wp_error( $gz ) ? 'falha no teste' : 'nenhuma' ), $gz_ok,
		$gz_ok ? '' : 'HTML sem compressão pesa 4-8× mais. Ative mod_deflate/brotli na hospedagem ou no plugin de cache.' );

	// mod_expires / cache de assets estáticos.
	$exp = function_exists( 'apache_get_modules' )
		? in_array( 'mod_expires', apache_get_modules(), true )
		: null;
	$rows[] = array( 'mod_expires (cache longo de CSS/JS/fontes)',
		null === $exp ? 'não detectável (nginx?)' : ( $exp ? 'ativo' : 'inativo' ),
		null === $exp ? null : $exp,
		false === $exp ? 'Sem mod_expires, CSS/JS/fontes voltam a ser baixados a cada visita. Copie o .htaccess-exemplo do tema.' : 'Confirme as regras do .htaccess-exemplo do tema no servidor.' );

	// Plugin de cache de página.
	$plugins = array();
	if ( defined( 'WP_ROCKET_VERSION' ) ) { $plugins[] = 'WP Rocket'; }
	if ( defined( 'LSCWP_V' ) ) { $plugins[] = 'LiteSpeed Cache'; }
	if ( defined( 'W3TC' ) ) { $plugins[] = 'W3 Total Cache'; }
	if ( defined( 'SPEEDYCACHE_VERSION' ) || class_exists( 'SpeedyCache' ) ) { $plugins[] = 'SpeedyCache'; }
	if ( function_exists( 'wp_cache_clear_cache' ) && defined( 'WP_CACHE' ) && WP_CACHE ) { $plugins[] = 'WP Super Cache'; }
	if ( class_exists( 'Breeze_Public' ) || defined( 'BREEZE_VERSION' ) ) { $plugins[] = 'Breeze'; }
	$cache_ok = ! empty( $plugins );
	$rows[] = array( 'Cache de página (HTML pronto)', $cache_ok ? implode( ', ', $plugins ) : 'nenhum detectado', $cache_ok,
		$cache_ok ? '' : 'Sem cache de página o PHP monta o HTML a cada visita (TTFB alto). Ative um plugin de cache ou o cache da hospedagem.' );

	// Assets do tema (tamanhos que o visitante baixa).
	$fmt_kb  = function ( $rel ) {
		$p = AWR_DIR . '/' . $rel;
		return file_exists( $p ) ? number_format_i18n( filesize( $p ) / 1024, 1 ) . ' KB' : 'ausente';
	};
	$bundle = awr_css_bundle();
	$rows[] = array( 'CSS crítico (bundle único)', $bundle ? $fmt_kb( $bundle ) : 'bundle não gerado (5 arquivos separados)', (bool) $bundle,
		$bundle ? '' : 'Rode o empacotamento do tema (build-theme.py) para servir 1 CSS só.' );
	$rows[] = array( 'JS inicial (awr-core.js)', $fmt_kb( 'assets/js/awr-core.js' ), null,
		'Busca/checkout (awr-search.js, ' . $fmt_kb( 'assets/js/awr-search.js' ) . ') carrega sob demanda, fora do caminho crítico.' );
	$rows[] = array( 'CSS do checkout (sob demanda)', $fmt_kb( 'assets/css/awr-checkout-app.css' ), null,
		'Só baixa quando o visitante interage com busca/checkout.' );

	// Transients do tema acumulados.
	$like   = $wpdb->esc_like( '_transient_awr_' ) . '%';
	$count  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '{$like}'" );
	$rows[] = array( 'Transients do tema no banco', number_format_i18n( $count ), $count < 2000,
		$count < 2000 ? '' : 'Muitos transients acumulados — use "Limpar caches do tema" acima.' );

	return $rows;
}

/* ======================================================================
   v3.53.0 — Validador de headers HTTP reais + checklist para hospedagem
   ====================================================================== */

/** Requisição loopback padronizada para os testes de header. */
function awr_hdr_get( $url ) {
	return wp_remote_get( $url, array(
		'timeout'     => 8,
		'sslverify'   => false,
		'redirection' => 3,
		'headers'     => array( 'Accept-Encoding' => 'gzip, br' ),
		'user-agent'  => 'awr-header-check/' . AWR_VERSION,
	) );
}

/** Extrai max-age (segundos) de um Cache-Control; null se ausente. */
function awr_hdr_max_age( $cc ) {
	return preg_match( '/max-age=(\d+)/i', (string) $cc, $m ) ? (int) $m[1] : null;
}

/** Resumo dos headers observados para a coluna "valor". */
function awr_hdr_resumo( $resp ) {
	$cc  = strtolower( (string) wp_remote_retrieve_header( $resp, 'cache-control' ) );
	$enc = strtolower( (string) wp_remote_retrieve_header( $resp, 'content-encoding' ) );
	$out = array( $cc ? $cc : 'sem cache-control' );
	if ( $enc ) { $out[] = 'encoding: ' . $enc; }
	if ( wp_remote_retrieve_header( $resp, 'etag' ) ) { $out[] = 'etag'; }
	return implode( ' · ', $out );
}

/**
 * Valida os headers HTTP reais que o visitante recebe (cache e compressão),
 * chamando o próprio site em loopback. Linhas: [checagem, valor, status, dica]
 * com status 'ok' | 'aviso' | 'erro'. Resultado em cache por 10 minutos.
 *
 * @param bool $force Ignora o cache e refaz as requisições.
 * @return array
 */
function awr_header_checks( $force = false ) {
	$key = 'awr_header_checks_v1';
	if ( ! $force ) {
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) { return $cached; }
	}
	$rows = array();

	/* ---- Home (HTML) ---- */
	$home = awr_hdr_get( home_url( '/' ) );
	if ( is_wp_error( $home ) ) {
		$rows[] = array( 'HTML da home', 'loopback falhou: ' . $home->get_error_message(), 'aviso',
			'O servidor não conseguiu chamar o próprio site. Pode ser bloqueio de loopback da hospedagem — confirme externamente pelo PageSpeed.' );
	} else {
		$code = (int) wp_remote_retrieve_response_code( $home );
		$cc   = strtolower( (string) wp_remote_retrieve_header( $home, 'cache-control' ) );
		$enc  = strtolower( (string) wp_remote_retrieve_header( $home, 'content-encoding' ) );

		if ( 200 !== $code ) {
			$rows[] = array( 'HTML — status da home', 'HTTP ' . $code, 'erro',
				'A home precisa responder 200 para visitantes anônimos.' );
		}

		$gz = ( false !== strpos( $enc, 'br' ) || false !== strpos( $enc, 'gzip' ) );
		$rows[] = array( 'HTML — compressão gzip/brotli', awr_hdr_resumo( $home ), $gz ? 'ok' : 'erro',
			$gz ? '' : 'HTML viaja 4-8× maior sem compressão. Peça à hospedagem para ativar brotli/gzip (mod_deflate) para text/html.' );

		$sm = false !== strpos( $cc, 's-maxage' );
		$rows[] = array( 'HTML — cache compartilhado (s-maxage)', $cc ? $cc : 'ausente', $sm ? 'ok' : 'aviso',
			$sm ? '' : 'Sem s-maxage, CDN/proxy da hospedagem não guarda o HTML. O tema envia esse header — se não chega, algo no caminho o remove.' );

		$etag = (bool) wp_remote_retrieve_header( $home, 'etag' );
		$rows[] = array( 'HTML — ETag (resposta 304)', $etag ? 'presente' : 'ausente', $etag ? 'ok' : 'aviso',
			$etag ? '' : 'ETag permite resposta 304 (quase zero bytes) nas revisitas. O tema envia — se não chega, a hospedagem o remove.' );
	}

	/* ---- Tags específicas e únicas por família de rota — v3.87.0 ---- */
	$amostra_seo = array();
	$cids        = function_exists( 'awr_cidades' ) ? awr_cidades() : array();
	if ( $cids ) { $amostra_seo['cidade'] = home_url( '/baterias-em/' . $cids[0]['slug'] . '/' ); }
	$bairros = awr_sitemap_urls( 'bairros' );
	if ( $bairros ) {
		foreach ( $bairros as $ub ) { if ( preg_match( '#/baterias-bairro/[^/]+/[^/]+/$#', $ub ) ) { $amostra_seo['bairro'] = $ub; break; } }
	}
	$cidades_urls = awr_sitemap_urls( 'cidades' );
	foreach ( $cidades_urls as $umc ) { if ( preg_match( '#/bateria/[^/]+/[^/]+/$#', $umc ) ) { $amostra_seo['marca+cidade'] = $umc; break; } }
	$skus = awr_sitemap_urls( 'skus' );
	if ( $skus ) { $amostra_seo['SKU'] = $skus[0]; }
	$amps = function_exists( 'awr_amperagens_disponiveis' ) ? awr_amperagens_disponiveis() : array();
	if ( $amps ) { $amostra_seo['amperagem'] = home_url( '/baterias/amperagem/' . $amps[0] . '/' ); }
	$home_head = '';
	if ( ! is_wp_error( $home ) ) {
		$home_html = (string) wp_remote_retrieve_body( $home );
		$home_head = substr( $home_html, 0, (int) max( 1, strpos( $home_html . '</head>', '</head>' ) ) );
	}
	preg_match( '#<meta[^>]+name=([\'\"])description\1[^>]+content=([\'\"])(.*?)\2#i', $home_head, $home_desc_m );
	$home_desc = html_entity_decode( $home_desc_m[3] ?? '', ENT_QUOTES, 'UTF-8' );
	foreach ( $amostra_seo as $tipo_seo => $u_seo ) {
		$r_seo = wp_remote_get( $u_seo, array( 'timeout' => 15, 'sslverify' => false ) );
		if ( is_wp_error( $r_seo ) ) {
			$rows[] = array( 'SEO — tags únicas em ' . $u_seo, 'loopback falhou', 'aviso', 'Confira o código-fonte da página manualmente.' );
			continue;
		}
		$h_seo  = (string) wp_remote_retrieve_body( $r_seo );
		$head   = substr( $h_seo, 0, (int) max( 1, strpos( $h_seo . '</head>', '</head>' ) ) );
		$n_can  = preg_match_all( '#<link[^>]+rel=([\'"])canonical\1#i', $head );
		$n_desc = preg_match_all( '#<meta[^>]+name=([\'"])description\1#i', $head );
		$n_og   = preg_match_all( '#<meta[^>]+property=([\'"])og:title\1#i', $head );
		preg_match( '#<title[^>]*>(.*?)</title>#is', $head, $mt );
		preg_match( '#<meta[^>]+name=([\'\"])description\1[^>]+content=([\'\"])(.*?)\2#i', $head, $md );
		preg_match( '#<link[^>]+rel=([\'\"])canonical\1[^>]+href=([\'\"])(.*?)\2#i', $head, $mc );
		$title_v = trim( wp_strip_all_tags( html_entity_decode( $mt[1] ?? '', ENT_QUOTES, 'UTF-8' ) ) );
		$desc_v  = html_entity_decode( $md[3] ?? '', ENT_QUOTES, 'UTF-8' );
		$can_v   = html_entity_decode( $mc[3] ?? '', ENT_QUOTES, 'UTF-8' );
		$dup     = ( 1 !== $n_can || 1 !== $n_desc || 1 !== $n_og );
		$self    = $can_v && untrailingslashit( $can_v ) === untrailingslashit( awr_canonical_url( $u_seo ) );
		$unica   = ! $home_desc || $desc_v !== $home_desc;
		$limites = mb_strlen( $title_v ) <= 60 && mb_strlen( $desc_v ) <= 155;
		$ok_seo  = ! $dup && $self && $unica && $limites;
		$rows[] = array(
			'SEO ' . $tipo_seo . ' — tags únicas e específicas',
			$n_can . ' canonical · ' . $n_desc . ' description · ' . $n_og . ' og:title · ' . mb_strlen( $title_v ) . '/60 · ' . mb_strlen( $desc_v ) . '/155',
			$ok_seo ? 'ok' : 'erro',
			$ok_seo ? '' : 'Confira duplicidade, canonical autorreferenciado, texto herdado da home e limites. Limpe o cache do plugin de performance e da CDN antes de repetir.',
		);
	}

	/* ---- Assets estáticos (CSS/JS) ---- */
	$bundle = awr_css_bundle();
	$estaticos = array(
		'CSS (' . ( $bundle ? $bundle : 'assets/css/awr.css' ) . ')' => AWR_URI . '/' . ( $bundle ? $bundle : 'assets/css/awr.css' ),
		'JS (assets/js/awr-core.js)'                                 => AWR_URI . '/assets/js/awr-core.js',
		'JS (assets/js/awr-search.js)'                               => AWR_URI . '/assets/js/awr-search.js',
	);

	/* Rota imutável do tema: é por ela que CSS/JS saem quando as rewrites estão ok.
	   Barra final obrigatória: sem ela o WordPress responde 301 com cache de 1h
	   e o teste acusa falso positivo. */
	$rota_asset = home_url( '/awr-asset/js/awr-core/' );
	$ra         = awr_hdr_get( $rota_asset );
	if ( is_wp_error( $ra ) ) {
		$rows[] = array( 'Rota /awr-asset/ — cache imutável', 'loopback falhou', 'aviso', 'Teste a URL externamente: ' . $rota_asset );
	} else {
		$rc  = (int) wp_remote_retrieve_response_code( $ra );
		$rcc = strtolower( (string) wp_remote_retrieve_header( $ra, 'cache-control' ) );
		$rag = awr_hdr_max_age( $rcc );
		$rim = false !== strpos( $rcc, 'immutable' );
		if ( 200 === $rc && $rim && null !== $rag && $rag >= 31536000 ) {
			$rows[] = array( 'Rota /awr-asset/ — cache imutável de CSS/JS',
				'HTTP ' . $rc . ' · ' . $rcc, 'ok', '' );
		} elseif ( 200 === $rc && $rim && null !== $rag && $rag >= 604800 ) {
			/* Cloudflare (ou outro CDN) reduziu o TTL do navegador: o tema envia
			   1 ano, mas a borda reescreve. Com `immutable` e >= 7 dias o navegador
			   já não revalida — é aviso, não erro. */
			$rows[] = array( 'Rota /awr-asset/ — cache imutável de CSS/JS',
				'HTTP ' . $rc . ' · ' . $rcc . ' (CDN limitou a ' . round( $rag / 86400 ) . ' dias)', 'aviso',
				'O tema envia 1 ano de cache, mas a Cloudflare/CDN reescreveu o prazo. Para 1 ano de ponta a ponta, crie uma Cache Rule para /awr-asset/* com Browser TTL de 1 ano. Com immutable + 7 dias o navegador já não revalida.' );
		} else {
			$rows[] = array( 'Rota /awr-asset/ — cache imutável de CSS/JS',
				'HTTP ' . $rc . ' · ' . ( $rcc ? $rcc : 'sem cache-control' ), 'erro',
				'É esta rota que dá 1 ano de cache ao CSS/JS do tema, mesmo com TTL curto na hospedagem. Rode "Limpar caches do tema e regravar rotas"; persistindo, peça à hospedagem para liberar as rewrites e não sobrescrever Cache-Control.' );
		}
	}
	foreach ( $estaticos as $label => $url ) {
		$r = awr_hdr_get( $url );
		if ( is_wp_error( $r ) ) {
			$rows[] = array( $label, 'loopback falhou', 'aviso', 'Teste a URL externamente: ' . $url );
			continue;
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		$cc   = strtolower( (string) wp_remote_retrieve_header( $r, 'cache-control' ) );
		$enc  = strtolower( (string) wp_remote_retrieve_header( $r, 'content-encoding' ) );
		$age  = awr_hdr_max_age( $cc );

		if ( 200 !== $code ) {
			$rows[] = array( $label . ' — disponibilidade', 'HTTP ' . $code, 'erro',
				'O asset não responde 200. Verifique se o tema foi enviado completo e se não há regra de segurança bloqueando /wp-content/themes/.' );
			continue;
		}
		$cache_ok = null !== $age && $age >= 2592000; // 30 dias
		$rows[] = array( $label . ' — cache no navegador', $cc ? $cc : 'sem cache-control', $cache_ok ? 'ok' : 'erro',
			$cache_ok ? '' : 'Sem cache longo, CSS/JS são baixados de novo a cada visita (derruba a nota do PageSpeed). Aplique as regras do .htaccess-exemplo do tema (mod_expires/mod_headers, 1 ano).' );
		$gz = ( false !== strpos( $enc, 'br' ) || false !== strpos( $enc, 'gzip' ) );
		$rows[] = array( $label . ' — compressão de texto', $enc ? $enc : 'nenhuma', $gz ? 'ok' : 'aviso',
			$gz ? '' : 'Muita hospedagem só comprime HTML. Inclua text/css e application/javascript no brotli/gzip.' );
	}

	/* ---- Fonte via rota /awr-font/ (cache imutável) ---- */
	$font = awr_hdr_get( home_url( '/awr-font/Inter' ) );
	if ( is_wp_error( $font ) ) {
		$rows[] = array( 'Fonte /awr-font/Inter', 'loopback falhou', 'aviso', 'Teste a URL externamente.' );
	} else {
		$code = (int) wp_remote_retrieve_response_code( $font );
		if ( 200 !== $code ) {
			$rows[] = array( 'Fonte /awr-font/ — rota ativa', 'HTTP ' . $code, 'erro',
				'A rota imutável de fontes não responde. Rode "Limpar caches do tema e regravar rotas" acima; persistindo, peça à hospedagem para liberar as rewrites.' );
		} else {
			$cc    = strtolower( (string) wp_remote_retrieve_header( $font, 'cache-control' ) );
			$acao  = (string) wp_remote_retrieve_header( $font, 'access-control-allow-origin' );
			$age   = awr_hdr_max_age( $cc );
			$imut  = false !== strpos( $cc, 'immutable' ) && null !== $age && $age >= 31536000;
			$ok    = $imut && '' !== $acao;
			$rows[] = array( 'Fonte /awr-font/ — cache imutável + CORS',
				( $cc ? $cc : 'sem cache-control' ) . ( '' !== $acao ? ' · CORS: ' . $acao : ' · sem CORS' ),
				$ok ? 'ok' : 'aviso',
				$ok ? '' : 'A rota envia cache de 1 ano e Access-Control-Allow-Origin — se não chegam, a hospedagem está sobrescrevendo os headers de fontes.' );
		}
	}

	/* ---- REST pública (busca) ---- */
	$rest = awr_hdr_get( rest_url( 'awr/v1/sugestoes?q=moura' ) );
	if ( is_wp_error( $rest ) ) {
		$rows[] = array( 'REST /awr/v1 — cache curto', 'loopback falhou', 'aviso', 'Teste a URL externamente.' );
	} else {
		$code = (int) wp_remote_retrieve_response_code( $rest );
		$cc   = strtolower( (string) wp_remote_retrieve_header( $rest, 'cache-control' ) );
		$ok   = 200 === $code && '' !== $cc && false === strpos( $cc, 'no-store' );
		$rows[] = array( 'REST /awr/v1 — cache curto em GET público', 'HTTP ' . $code . ' · ' . ( $cc ? $cc : 'sem cache-control' ), $ok ? 'ok' : 'aviso',
			$ok ? '' : 'O tema envia cache curto nas respostas públicas da busca; se chega no-store/ausente, algum plugin ou a hospedagem marca o REST como totalmente dinâmico.' );
	}

	set_transient( $key, $rows, 10 * MINUTE_IN_SECONDS );
	return $rows;
}

/**
 * Monta o texto pronto para abrir chamado no suporte da hospedagem,
 * agregando as falhas do diagnóstico de performance e dos headers HTTP.
 *
 * @param array $perf_rows Linhas de awr_perf_diagnostics().
 * @param array $hdr_rows  Linhas de awr_header_checks().
 * @return string
 */
function awr_hosting_checklist( $perf_rows, $hdr_rows ) {
	$pend = array();
	foreach ( (array) $perf_rows as $r ) {
		if ( false === $r[2] && ! empty( $r[3] ) ) { $pend[] = $r[3]; }
	}
	foreach ( (array) $hdr_rows as $r ) {
		if ( in_array( $r[2], array( 'erro', 'aviso' ), true ) && ! empty( $r[3] ) ) {
			$pend[] = '[' . $r[0] . '] ' . $r[3];
		}
	}
	$pend = array_values( array_unique( array_filter( $pend ) ) );

	if ( ! $pend ) {
		return 'Diagnóstico AWR v' . AWR_VERSION . ' — nenhuma pendência de servidor detectada. Nada a solicitar à hospedagem.';
	}

	$server = isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : 'não identificado';

	$out  = "Olá, equipe de suporte!\n\n";
	$out .= 'Rodamos um diagnóstico de performance no site ' . home_url( '/' ) . " e identificamos os ajustes abaixo, que só podem ser aplicados no servidor:\n\n";
	$i = 1;
	foreach ( $pend as $p ) {
		$out .= $i++ . '. [ ] ' . $p . "\n";
	}
	$out .= "\nAmbiente:\n";
	$out .= '- PHP: ' . PHP_VERSION . "\n";
	$out .= '- Servidor: ' . $server . "\n";
	$out .= '- WordPress: ' . get_bloginfo( 'version' ) . ' | Tema AWR v' . AWR_VERSION . "\n";
	$out .= '- Data do diagnóstico: ' . current_time( 'd/m/Y H:i' ) . "\n\n";
	$out .= "Referência: as regras de cache esperadas estão no arquivo .htaccess-exemplo do tema.\n\nObrigado!";
	return $out;
}

/** Cron diário: revalida os headers e marca regressões (ok → erro). */
add_action( 'awr_header_check_cron', function () {
	$rows    = awr_header_checks( true );
	$failing = array();
	foreach ( $rows as $r ) {
		if ( 'erro' === $r[2] ) { $failing[] = $r[0]; }
	}
	$prev = (array) get_option( 'awr_header_check_last', array() );
	update_option( 'awr_header_check_last', $failing, false );
	$new = array_diff( $failing, $prev );
	if ( $new ) { set_transient( 'awr_header_regress', array_values( $new ), WEEK_IN_SECONDS ); }
} );

/** Aviso de regressão de headers no painel (com dispensa). */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$reg = get_transient( 'awr_header_regress' );
	if ( ! $reg ) { return; }
	echo '<div class="notice notice-error"><p><strong>AWR — regressão de performance detectada:</strong> '
		. esc_html( implode( ', ', $reg ) )
		. '. Veja <a href="' . esc_url( admin_url( 'options-general.php?page=awr-validacao#performance' ) ) . '">Ajustes → AWR Validação SEO → Performance</a>. '
		. '<a href="' . esc_url( wp_nonce_url( admin_url( '?awr_hdr_dismiss=1' ), 'awr_hdr_dismiss' ) ) . '">Dispensar</a></p></div>';
} );

/** Dispensa o aviso de regressão. */
add_action( 'admin_init', function () {
	if ( empty( $_GET['awr_hdr_dismiss'] ) || ! current_user_can( 'manage_options' ) ) { return; } // phpcs:ignore
	check_admin_referer( 'awr_hdr_dismiss' );
	delete_transient( 'awr_header_regress' );
	wp_safe_redirect( admin_url( 'options-general.php?page=awr-validacao#performance' ) );
	exit;
} );

/**
 * v3.78.0 — checagens da primeira tela: asset em cache sem 301 e busca por
 * veículo presente nas páginas internas. Cache de 10 minutos.
 *
 * @return array Lista de array( rótulo, valor, status, orientação ).
 */
function awr_lcp_checks() {
	$cache = get_transient( 'awr_lcp_checks' );
	if ( is_array( $cache ) ) { return $cache; }

	$rows = array();

	$asset = home_url( '/awr-asset/css/awr-bundle/' );
	$res   = wp_remote_get( $asset, array( 'timeout' => 12, 'redirection' => 0 ) );
	if ( is_wp_error( $res ) ) {
		$rows[] = array( 'CSS em cache (/awr-asset/)', $res->get_error_message(), 'aviso', 'Não foi possível checar pelo servidor; confirme pelo PageSpeed.' );
	} else {
		$code = (int) wp_remote_retrieve_response_code( $res );
		$rows[] = array(
			'CSS em cache (/awr-asset/)',
			'HTTP ' . $code,
			200 === $code ? 'ok' : 'erro',
			200 === $code ? 'Responde direto, sem ida e volta extra.' : 'Redirecionamento antes do CSS: use "Limpar caches do tema e regravar rotas".',
		);
	}

	$cidade = awr_cidades();
	$slug   = ! empty( $cidade[0]['slug'] ) ? $cidade[0]['slug'] : '';
	if ( $slug ) {
		$page = wp_remote_get( home_url( '/baterias-em/' . $slug . '/' ), array( 'timeout' => 15, 'headers' => array( 'Cache-Control' => 'no-cache' ) ) );
		if ( is_wp_error( $page ) ) {
			$rows[] = array( 'Busca na página de cidade', $page->get_error_message(), 'aviso', 'Não foi possível checar pelo servidor; abra a página e confirme o campo de busca.' );
		} else {
			$html = (string) wp_remote_retrieve_body( $page );
			$tem  = false !== strpos( $html, 'data-awr-search' );
			$rows[] = array(
				'Busca na página de cidade',
				'/baterias-em/' . $slug . '/ — ' . ( $tem ? 'campo presente' : 'campo ausente' ),
				$tem ? 'ok' : 'erro',
				$tem ? 'Visitante consegue buscar o veículo na página local.' : 'Limpe os caches do tema e da Cloudflare e recheque.',
			);
		}
	}

	// v3.79.0 — Zaraz (Cloudflare) e pedido em 1 clique na home.
	$home = wp_remote_get( home_url( '/' ), array( 'timeout' => 15, 'headers' => array( 'Cache-Control' => 'no-cache' ) ) );
	if ( ! is_wp_error( $home ) ) {
		$html_home = (string) wp_remote_retrieve_body( $home );
		$zaraz     = false !== strpos( $html_home, '/28lc/' ) || false !== stripos( $html_home, 'zaraz' );
		$rows[]    = array(
			'Cloudflare Zaraz',
			$zaraz ? 'ativo na página' : 'ausente',
			$zaraz ? 'erro' : 'ok',
			$zaraz ? 'Desative o Zaraz no painel da Cloudflare: são ~360 KB e 715 ms de bloqueio. O tema já entrega GTM, GA4 e Ads.' : 'Nenhum script extra da Cloudflare na página.',
		);
		$um_clique = false !== strpos( $html_home, 'pedido_1clique' );
		$rows[]    = array(
			'Pedido em 1 clique',
			$um_clique ? 'botão presente' : 'não encontrado',
			$um_clique ? 'ok' : 'aviso',
			$um_clique ? 'O botão verde do card abre o WhatsApp com o pedido escrito.' : 'Aparece nas páginas com cards de bateria; na home só depois de uma busca.',
		);
	}

	set_transient( 'awr_lcp_checks', $rows, 10 * MINUTE_IN_SECONDS );

	return $rows;
}

function awr_validacao_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$nonce   = wp_create_nonce( 'awr_val' );
	$ajax    = admin_url( 'admin-ajax.php' );
	$rel     = get_option( 'awr_validacao_relatorio' );
	$csv_url = wp_nonce_url( admin_url( 'options-general.php?page=awr-validacao&awr_val_csv=1' ), 'awr_val_csv' );
	?>
	<div class="wrap">
		<h1>AWR — Validação SEO</h1>

		<?php if ( ! get_option( 'blog_public' ) ) : ?>
			<div class="notice notice-error" style="padding:12px 16px">
				<p style="margin:0"><strong>Indexação bloqueada:</strong> a opção <em>"Impedir que mecanismos de busca indexem este site"</em> está marcada em
				<a href="<?php echo esc_url( admin_url( 'options-reading.php' ) ); ?>">Configurações → Leitura</a>.
				Enquanto estiver ativa, o WordPress envia <code>noindex</code> em todas as páginas. Desmarque para liberar a indexação.</p>
			</div>
		<?php endif; ?>

		<?php if ( isset( $_GET['awr_flushed'] ) ) : // phpcs:ignore ?>
			<div class="notice notice-success" style="padding:12px 16px">
				<p style="margin:0"><strong>Cache do tema limpo:</strong> rotas regravadas e <?php echo (int) $_GET['awr_flushed']; // phpcs:ignore ?> transients removidos. Os sitemaps serão regenerados na próxima visita.</p>
			</div>
		<?php endif; ?>

		<h2 style="margin-top:28px">0. Cache e rotas</h2>
		<p>Limpa os caches do tema (busca, produtos, avaliações, sitemaps) e regrava as rotas. Após atualizar o tema ou alterar conteúdo, rode esta limpeza.
			<strong>Importante:</strong> se você usa plugin de cache de página (SpeedyCache, WP Rocket…), limpe o cache dele também — esta ação não alcança o HTML guardado pelo plugin.</p>
		<p><a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( '?awr_flush=1' ), 'awr_flush' ) ); ?>" onclick="return confirm('Limpar todos os caches do tema e regravar as rotas?');">Limpar caches do tema e regravar rotas</a></p>

		<h2 id="duplicadas" style="margin-top:28px">0.1. Páginas antigas redirecionadas</h2>
		<p>Páginas publicadas cujo endereço já é atendido por uma rota nova do tema. Cada uma responde <strong>301</strong> para o destino abaixo, para que apenas uma URL dispute a mesma busca no Google.</p>
		<?php
		$legacy = function_exists( 'awr_redirect_legacy_scan' ) ? awr_redirect_legacy_scan( isset( $_GET['awr_val_red'] ) ) : array(); // phpcs:ignore
		$red_url = admin_url( 'options-general.php?page=awr-validacao&awr_val_red=1#duplicadas' );
		?>
		<p><a class="button" href="<?php echo esc_url( $red_url ); ?>">Reprocessar lista</a>
			<span class="description"><?php echo count( $legacy ); ?> página(s) antigas redirecionando.</span></p>
		<table class="widefat striped" style="max-width:960px">
			<thead><tr><th>Endereço antigo</th><th>Destino (301)</th></tr></thead>
			<tbody>
			<?php if ( ! $legacy ) : ?>
				<tr><td colspan="2">Nenhuma página antiga duplicada encontrada.</td></tr>
			<?php else : ?>
				<?php foreach ( $legacy as $slug => $destino ) : ?>
					<tr>
						<td><code>/<?php echo esc_html( $slug ); ?>/</code></td>
						<td><a href="<?php echo esc_url( home_url( $destino ) ); ?>" target="_blank" rel="noopener"><code><?php echo esc_html( $destino ); ?></code></a></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>


		<h2 style="margin-top:28px">1. Validação em lote das rotas</h2>
		<p>Percorre as rotas do tema (amperagens, marcas de moto, segmento × cidade, conteúdo, cidades, marcas, lojas, amostras de SKUs/veículos e <strong>1 URL veículo × cidade para cada cidade ativa</strong>) e gera relatório com status HTTP, redirect, canonical e og:url.</p>
		<p>
			<button class="button button-primary" id="awr-val-start">Iniciar validação</button>
			<?php if ( ! empty( $rel['rows'] ) ) : ?>
				<a class="button" href="<?php echo esc_url( $csv_url ); ?>">Exportar CSV</a>
				<span class="description">Último relatório: <?php echo esc_html( $rel['gerado_em'] ); ?> — <?php echo (int) $rel['total']; ?> URLs.</span>
			<?php endif; ?>
		</p>
		<div id="awr-val-progress" style="display:none;margin:12px 0;max-width:960px">
			<div style="background:#e2e2e2;height:18px;border-radius:9px;overflow:hidden"><div id="awr-val-bar" style="background:#2271b1;height:18px;width:0%"></div></div>
			<p id="awr-val-status" class="description"></p>
		</div>
		<div id="awr-val-summary" style="margin:8px 0"></div>
		<table class="widefat striped" id="awr-val-table" style="max-width:1280px;display:none">
			<thead><tr><th>URL</th><th>Status</th><th>Redirect</th><th>Canonical</th><th>og:url</th></tr></thead>
			<tbody></tbody>
		</table>

		<hr style="margin:36px 0">
		<h2 id="sitemap">2. Sitemap ativo e canônicas prioritárias</h2>
		<p>Verifica se cada sitemap público responde 200 (com contagem de URLs) e se as canônicas prioritárias retornam 200 com canonical igual à URL e og:url coerente. Resultado em cache por 10 minutos.</p>
		<?php
		$force_sm = isset( $_GET['awr_val_sm'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['awr_val_sm'] ) ), 'awr_val_sm' );
		$sm       = awr_val_sitemap_check( $force_sm );
		$sm_url   = wp_nonce_url( admin_url( 'options-general.php?page=awr-validacao#sitemap' ), 'awr_val_sm', 'awr_val_sm' );
		?>
		<p><a class="button" href="<?php echo esc_url( $sm_url ); ?>">Rechecar agora</a>
			<span class="description">Última checagem: <?php echo esc_html( $sm['gerado_em'] ); ?></span></p>
		<table class="widefat striped" style="max-width:960px">
			<thead><tr><th>Sitemap</th><th>Status</th><th>URLs</th></tr></thead>
			<tbody>
				<?php foreach ( $sm['sitemaps'] as $s ) : ?>
					<tr style="<?php echo 200 === $s['status'] ? '' : 'background:#fdeaea'; ?>">
						<td><a href="<?php echo esc_url( $s['url'] ); ?>" target="_blank" rel="noopener"><code><?php echo esc_html( $s['secao'] ); ?></code></a></td>
						<td><?php echo (int) $s['status'] ? esc_html( (string) $s['status'] ) : 'sem resposta'; ?></td>
						<td><?php echo esc_html( number_format_i18n( $s['urls'] ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		$alias_ok  = ! empty( $sm['alias']['ok'] );
		$robots    = isset( $sm['robots'] ) ? $sm['robots'] : array( 'bytes' => 0, 'sitemap' => false, 'estatico' => true );
		$robots_ok = ! empty( $robots['sitemap'] );
		?>
		<table class="widefat striped" style="max-width:960px;margin-top:12px">
			<thead><tr><th>Descoberta pelo Google</th><th>Situação</th><th>O que fazer</th></tr></thead>
			<tbody>
				<tr style="<?php echo $alias_ok ? '' : 'background:#fdeaea'; ?>">
					<td><code>/sitemap.xml</code> (endereço enviado ao Search Console)</td>
					<td><?php echo $alias_ok ? '✅ chega ao índice do tema' : '⚠️ não chega ao índice do tema'; ?></td>
					<td><?php echo $alias_ok ? '—' : 'Limpe os caches (plugin, servidor e Cloudflare) e recheque. Persistindo, envie <code>/awr-sitemap.xml</code> no Search Console.'; // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
				</tr>
				<tr style="<?php echo $robots_ok ? '' : 'background:#fdeaea'; ?>">
					<td><code>/robots.txt</code></td>
					<td><?php echo $robots_ok ? '✅ com linha Sitemap' : '⚠️ sem linha Sitemap (' . (int) $robots['bytes'] . ' bytes)'; // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
					<td><?php echo $robots_ok ? '—' : 'Existe um arquivo robots.txt físico na raiz do site sobrepondo o do WordPress. Apague esse arquivo pelo gerenciador de arquivos/FTP: o tema volta a gerar o robots com a linha Sitemap.'; ?></td>
				</tr>
			</tbody>
		</table>
		<h3 style="margin-top:16px">Canônicas prioritárias</h3>
		<table class="widefat striped" style="max-width:1280px">
			<thead><tr><th>URL</th><th>Status</th><th>Canonical</th><th>og:url</th><th>Coerente</th></tr></thead>
			<tbody>
				<?php foreach ( $sm['prioritarias'] as $p ) : ?>
					<tr style="<?php echo $p['ok'] ? '' : 'background:#fdeaea'; ?>">
						<td style="word-break:break-all"><?php echo esc_html( $p['url'] ); ?></td>
						<td><?php echo (int) $p['status'] ? esc_html( (string) $p['status'] ) : 'sem resposta'; ?></td>
						<td style="word-break:break-all"><?php echo $p['canonical'] ? esc_html( $p['canonical'] ) : '—'; ?></td>
						<td style="word-break:break-all"><?php echo $p['og'] ? esc_html( $p['og'] ) : '—'; ?></td>
						<td><?php echo $p['ok'] ? '✅' : '❌'; ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<hr style="margin:36px 0">
		<h2 id="comparativo">3. Comparativo de canonical entre domínios</h2>
		<p>Compara canonical e og:url de cada path entre o domínio principal (primeiro da lista) e os satélites. <strong>Vermelho</strong>: status ≠ 200 ou canonical divergente do principal. <strong>Amarelo</strong>: og:url diferente do canonical.</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:960px">
			<input type="hidden" name="action" value="awr_val_save_cfg">
			<?php wp_nonce_field( 'awr_val_cfg' ); ?>
			<table class="form-table">
				<tr>
					<th scope="row"><label for="awr-val-dominios">Domínios (1 por linha; o 1º é o principal)</label></th>
					<td><textarea id="awr-val-dominios" name="dominios" rows="4" class="large-text code"><?php echo esc_textarea( implode( "\n", awr_val_dominios() ) ); ?></textarea></td>
				</tr>
				<tr>
					<th scope="row"><label for="awr-val-paths">Paths comparados (1 por linha)</label></th>
					<td><textarea id="awr-val-paths" name="paths" rows="8" class="large-text code"><?php echo esc_textarea( implode( "\n", awr_val_paths() ) ); ?></textarea></td>
				</tr>
			</table>
			<?php submit_button( 'Salvar configuração', 'secondary' ); ?>
		</form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:12px 0">
			<input type="hidden" name="action" value="awr_val_compare">
			<?php wp_nonce_field( 'awr_val_compare' ); ?>
			<?php submit_button( 'Revalidar agora', 'primary', 'submit', false ); ?>
			<span class="description">Resultado em cache por 10 minutos.</span>
		</form>

		<?php
		$matrix   = awr_val_compare_run();
		$dominios = awr_val_dominios();
		$principal = $dominios ? $dominios[0] : '';
		if ( $matrix && $dominios ) :
			?>
			<table class="widefat striped" style="max-width:1280px">
				<thead><tr><th style="min-width:220px">Path</th><?php foreach ( $dominios as $d ) : ?><th><?php echo esc_html( awr_val_host( $d ) ); ?><?php echo $d === $principal ? ' <span class="description">(principal)</span>' : ''; ?></th><?php endforeach; ?></tr></thead>
				<tbody>
				<?php foreach ( $matrix as $path => $cells ) :
					$canon_principal = isset( $cells[ $principal ] ) ? $cells[ $principal ]['canonical'] : '';
					?>
					<tr>
						<td><code><?php echo esc_html( $path ); ?></code></td>
						<?php foreach ( $dominios as $d ) :
							$c     = isset( $cells[ $d ] ) ? $cells[ $d ] : null;
							if ( ! $c ) { echo '<td>—</td>'; continue; }
							$erro  = ( 200 !== $c['status'] && ! ( $c['status'] >= 300 && $c['status'] < 400 && $principal && awr_val_host( $c['location'] ) === awr_val_host( $principal ) ) );
							$div_c = $c['canonical'] && $canon_principal && untrailingslashit( $c['canonical'] ) !== untrailingslashit( $canon_principal );
							$div_g = $c['og'] && $c['canonical'] && untrailingslashit( $c['og'] ) !== untrailingslashit( $c['canonical'] );
							$bg    = ( $erro || $div_c ) ? 'background:#fdeaea' : ( $div_g ? 'background:#fcf9e8' : '' );
							?>
							<td style="<?php echo esc_attr( $bg ); ?>;word-break:break-all;vertical-align:top">
								<strong><?php echo (int) $c['status'] ? esc_html( (string) $c['status'] ) : 'sem resposta'; ?></strong>
								<?php if ( $c['location'] ) : ?><br><span class="description">→ <?php echo esc_html( $c['location'] ); ?></span><?php endif; ?>
								<br><span class="description">canonical:</span> <?php echo $c['canonical'] ? esc_html( $c['canonical'] ) : '—'; ?>
								<br><span class="description">og:url:</span> <?php echo $c['og'] ? esc_html( $c['og'] ) : '—'; ?>
							</td>
						<?php endforeach; ?>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<hr style="margin:36px 0">
		<h2 id="performance">4. Performance do servidor</h2>
		<p>Diagnóstico do que mais impacta o tempo de abertura (TTFB e download de assets). Itens em vermelho valem um chamado à hospedagem.</p>
		<table class="widefat striped" style="max-width:1280px">
			<thead><tr><th>Checagem</th><th>Valor</th><th>Situação</th><th>O que fazer</th></tr></thead>
			<tbody>
				<?php foreach ( awr_perf_diagnostics() as $r ) : ?>
					<tr style="<?php echo false === $r[2] ? 'background:#fdeaea' : ''; ?>">
						<td><?php echo esc_html( $r[0] ); ?></td>
						<td><code><?php echo esc_html( $r[1] ); ?></code></td>
						<td><?php echo null === $r[2] ? 'ℹ️' : ( $r[2] ? '✅' : '❌' ); ?></td>
						<td class="description"><?php echo esc_html( $r[3] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h3 style="margin-top:24px">Headers HTTP reais (cache e compressão)</h3>
		<p>O tema chama o próprio site e confere os headers que o visitante realmente recebe — HTML, CSS, JS, fontes e API de busca. Resultado em cache por 10 minutos.
			<span class="description">Se a hospedagem bloquear loopback, o item aparece como aviso — confirme externamente pelo PageSpeed.</span>
			Uma checagem automática roda 1× ao dia e avisa aqui no painel se algo que estava OK regredir.</p>
		<?php
		$force_hdr = isset( $_GET['awr_val_hdr'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['awr_val_hdr'] ) ), 'awr_val_hdr' );
		$hdr_rows  = awr_header_checks( $force_hdr );
		$hdr_url   = wp_nonce_url( admin_url( 'options-general.php?page=awr-validacao#performance' ), 'awr_val_hdr', 'awr_val_hdr' );
		$st_badge  = array( 'ok' => '✅', 'aviso' => '⚠️', 'erro' => '❌' );
		$st_bg     = array( 'ok' => '', 'aviso' => 'background:#fcf9e8', 'erro' => 'background:#fdeaea' );
		?>
		<p><a class="button" href="<?php echo esc_url( $hdr_url ); ?>">Rechecar agora</a></p>
		<table class="widefat striped" style="max-width:1280px">
			<thead><tr><th>Checagem</th><th>Valor observado</th><th>Situação</th><th>Orientação</th></tr></thead>
			<tbody>
				<?php foreach ( $hdr_rows as $r ) : ?>
					<tr style="<?php echo esc_attr( $st_bg[ $r[2] ] ); ?>">
						<td><?php echo esc_html( $r[0] ); ?></td>
						<td><code style="word-break:break-all"><?php echo esc_html( $r[1] ); ?></code></td>
						<td><?php echo esc_html( $st_badge[ $r[2] ] ); ?></td>
						<td class="description"><?php echo esc_html( $r[3] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h3 style="margin-top:24px">Primeira tela (LCP) e busca nas páginas internas</h3>
		<p>Checagens da versão 3.78.0: o CSS/JS em cache deve responder direto (sem redirecionamento 301) e a busca por veículo precisa existir nas páginas internas.</p>
		<table class="widefat striped" style="max-width:1280px">
			<thead><tr><th>Checagem</th><th>Valor observado</th><th>Situação</th><th>Orientação</th></tr></thead>
			<tbody>
				<?php foreach ( awr_lcp_checks() as $r ) : ?>
					<tr style="<?php echo esc_attr( $st_bg[ $r[2] ] ); ?>">
						<td><?php echo esc_html( $r[0] ); ?></td>
						<td><code style="word-break:break-all"><?php echo esc_html( $r[1] ); ?></code></td>
						<td><?php echo esc_html( $st_badge[ $r[2] ] ); ?></td>
						<td class="description"><?php echo esc_html( $r[3] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<h3 id="catalogo" style="margin-top:24px">Catálogo de produtos (v3.82.0)</h3>
		<p>Varredura de todos os produtos publicados no WooCommerce. Produto sem categoria, sem SKU, sem preço ou sem imagem não gera dados estruturados válidos e perde espaço na busca do Google. Também apontamos produtos <strong>sem marca do fabricante</strong> (a marca nunca é preenchida com “AWR Baterias”) e <strong>sem avaliação própria</strong> — sem avaliação real o produto não mostra estrelas no Google, e copiar a nota da empresa em todos os produtos é proibido pelas diretrizes do Google.</p>
		<?php $awr_cat = awr_catalogo_scan( isset( $_GET['awr_val_cat'] ) ); // phpcs:ignore ?>
		<p><a class="button" href="<?php echo esc_url( admin_url( 'options-general.php?page=awr-validacao&awr_val_cat=1#catalogo' ) ); ?>">Reprocessar catálogo</a>
			<span class="description"><?php echo (int) $awr_cat['total']; ?> produto(s) publicado(s) · <?php echo (int) count( $awr_cat['problemas'] ); ?> com pendência.</span></p>
		<table class="widefat striped" style="max-width:1280px">
			<thead><tr><th>Produto</th><th>SKU</th><th>Pendências</th><th></th></tr></thead>
			<tbody>
			<?php if ( ! $awr_cat['problemas'] ) : ?>
				<tr><td colspan="4">✅ Todos os produtos publicados têm categoria, SKU, preço e imagem.</td></tr>
			<?php else : ?>
				<?php foreach ( $awr_cat['problemas'] as $item ) : ?>
					<tr>
						<td><a href="<?php echo esc_url( $item['edit'] ); ?>"><?php echo esc_html( $item['nome'] ); ?></a></td>
						<td><code><?php echo esc_html( $item['sku'] ?: '—' ); ?></code></td>
						<td><?php echo esc_html( implode( ' · ', $item['faltas'] ) ); ?></td>
						<td><a href="<?php echo esc_url( $item['url'] ); ?>" target="_blank" rel="noopener">ver</a></td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>

		<h3 style="margin-top:24px">Checklist para a hospedagem</h3>
		<p>Texto pronto com tudo que está falhando no servidor — copie e abra um chamado no suporte da hospedagem.</p>
		<textarea id="awr-hosting-checklist" readonly rows="12" class="large-text code" style="max-width:960px"><?php echo esc_textarea( awr_hosting_checklist( awr_perf_diagnostics(), $hdr_rows ) ); ?></textarea>
		<p>
			<button type="button" class="button button-primary" id="awr-copy-checklist">Copiar checklist</button>
			<span id="awr-copy-feedback" class="description" style="margin-left:8px"></span>
		</p>
	</div>

	<script>
	(function () {
		var btn = document.getElementById('awr-copy-checklist'),
			ta = document.getElementById('awr-hosting-checklist'),
			fb = document.getElementById('awr-copy-feedback');
		if (!btn || !ta) return;
		btn.addEventListener('click', function () {
			function done() { fb.textContent = 'Copiado!'; setTimeout(function () { fb.textContent = ''; }, 2500); }
			if (navigator.clipboard && navigator.clipboard.writeText) {
				navigator.clipboard.writeText(ta.value).then(done, function () { ta.select(); document.execCommand('copy'); done(); });
			} else {
				ta.select(); document.execCommand('copy'); done();
			}
		});
	})();
	</script>

	<script>
	(function () {
		var btn = document.getElementById('awr-val-start');
		if (!btn) return;
		var bar = document.getElementById('awr-val-bar'),
			prog = document.getElementById('awr-val-progress'),
			stat = document.getElementById('awr-val-status'),
			sum = document.getElementById('awr-val-summary'),
			table = document.getElementById('awr-val-table'),
			tbody = table.querySelector('tbody');

		function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }

		function badge(row) {
			if (row.status === 200) {
				var esperadoDiff = row.canonical && row.canonical.replace(/\/$/, '') !== row.url.replace(/\/$/, '');
				return esperadoDiff
					? '<span style="color:#dba617">●</span> 200'
					: '<span style="color:#008a20">●</span> 200';
			}
			if (row.status >= 300 && row.status < 400) return '<span style="color:#dba617">●</span> ' + row.status;
			return '<span style="color:#d63638">●</span> ' + (row.status || 'erro');
		}

		function rowHtml(row) {
			var aviso = row.status === 200 && row.canonical && row.canonical.replace(/\/$/, '') !== row.url.replace(/\/$/, '');
			var bg = row.status !== 200
				? (row.status >= 300 && row.status < 400 ? 'background:#fcf9e8' : 'background:#fdeaea')
				: (aviso ? 'background:#fcf9e8' : '');
			return '<tr style="' + bg + '"><td style="word-break:break-all"><a href="' + esc(row.url) + '" target="_blank" rel="noopener">' + esc(row.url) + '</a></td>' +
				'<td>' + badge(row) + '</td>' +
				'<td style="word-break:break-all">' + (row.location ? esc(row.location) : '—') + '</td>' +
				'<td style="word-break:break-all">' + (row.canonical ? esc(row.canonical) : '—') + '</td>' +
				'<td style="word-break:break-all">' + (row.og ? esc(row.og) : '—') + '</td></tr>';
		}

		btn.addEventListener('click', function () {
			btn.disabled = true;
			prog.style.display = 'block';
			table.style.display = 'table';
			tbody.innerHTML = '';
			sum.innerHTML = '';
			var offset = 0, hash = '';

			function step() {
				var body = new URLSearchParams({
					action: 'awr_val_batch',
					nonce: <?php echo wp_json_encode( $nonce ); ?>,
					offset: String(offset),
					hash: hash
				});
				fetch(<?php echo wp_json_encode( $ajax ); ?>, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() })
					.then(function (r) { return r.json(); })
					.then(function (res) {
						if (!res || !res.success) { throw new Error(res && res.data ? res.data : 'falha na validação'); }
						hash = res.data.hash;
						offset = res.data.next;
						res.data.rows.forEach(function (row) { tbody.insertAdjacentHTML('beforeend', rowHtml(row)); });
						var pct = Math.round(100 * offset / res.data.total);
						bar.style.width = pct + '%';
						stat.textContent = offset + ' de ' + res.data.total + ' URLs (' + pct + '%)';
						var c = res.data.counts;
						sum.innerHTML = '<strong>Parcial:</strong> ' +
							'<span style="color:#008a20">' + c.ok + ' ok</span> · ' +
							'<span style="color:#dba617">' + c.redirect + ' redirects</span> · ' +
							'<span style="color:#dba617">' + c.aviso + ' avisos</span> · ' +
							'<span style="color:#d63638">' + c.erro + ' erros</span>';
						if (res.data.done) {
							stat.textContent = 'Concluído — ' + res.data.total + ' URLs validadas. Recarregue a página para exportar o CSV.';
							btn.disabled = false;
						} else {
							step();
						}
					})
					.catch(function (err) {
						stat.textContent = 'Erro: ' + err.message;
						btn.disabled = false;
					});
			}
			step();
		});
	})();
	</script>
	<?php
}
