<?php
/**
 * Performance — dequeue de peso morto, defer de scripts, delay de terceiros,
 * preconnect e headers de cache. Porte de docs/wordpress-perf-snippets.md.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', function () {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'wp_oembed_add_host_js' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	add_filter( 'emoji_svg_url', '__return_false' );
} );

add_action( 'wp_default_scripts', function ( $scripts ) {
	if ( ! is_admin() && isset( $scripts->registered['jquery'] ) ) {
		$scripts->registered['jquery']->deps = array_diff( $scripts->registered['jquery']->deps, array( 'jquery-migrate' ) );
	}
} );

/** Defer em tudo, exceto handles críticos. */
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( is_admin() ) { return $tag; }
	$critical = array( 'jquery-core' );
	if ( in_array( $handle, $critical, true ) ) { return $tag; }
	if ( false !== strpos( $tag, ' defer' ) || false !== strpos( $tag, ' async' ) ) { return $tag; }
	return str_replace( ' src=', ' defer src=', $tag );
}, 10, 2 );

/** Sem Google Fonts: nada de preconnect/dns-prefetch para fonts.gstatic.com. */
add_filter( 'wp_resource_hints', function ( $hints, $relation ) {
	foreach ( $hints as $i => $h ) {
		$href = is_array( $h ) ? ( $h['href'] ?? '' ) : $h;
		if ( is_string( $href ) && false !== strpos( $href, 'fonts.g' ) ) { unset( $hints[ $i ] ); }
	}
	return array_values( $hints );
}, 10, 2 );


/**
 * Google tags. O gtag.js (GA4 + Ads) agora é um snippet FIXO no header.php
 * (v3.58.0), impresso direto no HTML — aqui só fica o GTM (mais pesado),
 * carregado após a 1ª interação / idle. Imprimir o gtag via hook fazia
 * plugins de cache/otimização adiarem ou removerem a tag e o Google
 * reportava "coleta de dados não ativa".
 */
add_action( 'wp_head', function () {
	$gtm = apply_filters( 'awr_gtm_id', get_theme_mod( 'awr_gtm_id', 'GTM-5JTRM2L' ) );
	if ( ! $gtm ) { return; }
	?>
<script data-cfasync="false">
(function(){
  var loaded=false;
  function load(){
    if(loaded) return; loaded=true;
    var GTM=<?php echo wp_json_encode( $gtm ); ?>;
    window.dataLayer = window.dataLayer || [];
    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});
      var f=d.getElementsByTagName(s)[0],j=d.createElement(s);j.async=true;j.setAttribute('data-cfasync','false');
      j.src='https://www.googletagmanager.com/gtm.js?id='+i;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer',GTM);
  }
  var ev=['pointerdown','keydown','scroll','touchstart'];
  function on(){ ev.forEach(function(e){window.removeEventListener(e,on);}); load(); }
  ev.forEach(function(e){ window.addEventListener(e,on,{passive:true,once:true}); });
  // Sessões curtas (sem interação) também precisam do GTM: idle curto + teto.
  // v3.79.0 — o GTM só entra depois da primeira tela pintada: era 258 ms de
  // bloqueio medido no PageSpeed. pagehide/visibilitychange garantem a coleta.
  if('requestIdleCallback' in window) requestIdleCallback(load,{timeout:3500}); else setTimeout(load,3000);
  setTimeout(load,4000);
  document.addEventListener('visibilitychange',function(){ if(document.visibilityState==='hidden') load(); });
  window.addEventListener('pagehide',load);
})();
</script>
	<?php
}, 1 );

/**
 * Sem IDs duplicados: qualquer gtag.js/gtm.js enfileirado por plugin
 * (Site Kit, etc.) com ID diferente dos oficiais do tema é removido, para
 * não haver dupla contagem de pageview/conversão.
 */
function awr_official_tag_ids() {
	// GA4 e Ads vêm das constantes do tema (inc/analytics.php): um Customizer
	// antigo com outro ID não pode mais sobrescrever a propriedade oficial.
	return array_values( array_filter( array(
		apply_filters( 'awr_gtm_id', get_theme_mod( 'awr_gtm_id', 'GTM-5JTRM2L' ) ),
		defined( 'AWR_GA4_ID' ) ? AWR_GA4_ID : 'G-85HXPD5121',
		defined( 'AWR_ADS_ID' ) ? AWR_ADS_ID : 'AW-994517528',
	) ) );
}

add_filter( 'script_loader_tag', function ( $tag, $handle, $src ) {
	if ( is_admin() || ! is_string( $src ) || '' === $src ) { return $tag; }
	if ( false === strpos( $src, 'googletagmanager.com/gtag/js' ) && false === strpos( $src, 'googletagmanager.com/gtm.js' ) ) {
		return $tag;
	}
	// O tema já imprime o gtag.js oficial no <head>; qualquer outra cópia sai.
	return '<!-- awr: tag duplicada removida (' . esc_html( $handle ) . ') -->' . "\n";
}, 30, 3 );

/** Log de diagnóstico: IDs oficiais expostos para a checklist/admin. */
add_action( 'wp_head', function () {
	$ids = awr_official_tag_ids();
	echo "\n<!-- awr-tags: " . esc_html( implode( ', ', $ids ) ) . " -->\n";
}, 2 );



/** Campos de configuração no Customizer. */
add_action( 'customize_register', function ( $wp_customize ) {
	$wp_customize->add_section( 'awr_section', array( 'title' => 'AWR — Integrações', 'priority' => 30 ) );
	foreach ( array( 'awr_gtm_id' => 'GTM ID (GTM-XXXX)', 'awr_ga4_id' => 'GA4 ID (G-XXXX)', 'awr_ads_id' => 'Google Ads (AW-XXXX)' ) as $id => $label ) {
		$wp_customize->add_setting( $id, array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
		$wp_customize->add_control( $id, array( 'label' => $label, 'section' => 'awr_section', 'type' => 'text' ) );
	}
} );

/* ======================================================================
   v3.5.0 — LCP
   ====================================================================== */

/* Fontes agora são locais (assets/fonts) e o CSS crítico é inline — ver inc/assets.php. */


/** Primeira imagem do conteúdo entra como LCP (sem lazy). */
add_filter( 'wp_img_tag_add_loading_attr', function ( $value, $image, $context ) {
	static $first = true;
	if ( 'the_content' === $context && $first ) { $first = false; return false; }
	return $value;
}, 10, 3 );


/**
 * Compatibilidade com zlib.output_compression.
 *
 * Com a compressão do PHP ativa, `wp_ob_end_flush_all()` tenta esvaziar um
 * buffer que o próprio PHP controla e gera o Notice:
 * "ob_end_flush(): Failed to send buffer of zlib output compression (0)".
 * Trocamos o flush do WordPress por uma versão que fecha apenas os buffers
 * realmente esvaziáveis, ignorando o handler da compressão.
 */
function awr_zlib_compression_on() {
	$flag = ini_get( 'zlib.output_compression' );
	return ( $flag && 'off' !== strtolower( (string) $flag ) && '0' !== (string) $flag );
}

/** Substituto seguro de wp_ob_end_flush_all(). */
function awr_ob_end_flush_all() {
	$status = ob_get_status( true );
	if ( ! is_array( $status ) ) { return; }
	foreach ( array_reverse( $status ) as $buffer ) {
		$name = isset( $buffer['name'] ) ? (string) $buffer['name'] : '';
		if ( 'zlib output compression' === $name || 'ob_gzhandler' === $name ) { continue; }
		$flags     = isset( $buffer['flags'] ) ? (int) $buffer['flags'] : 0;
		$flushable = ( $flags & PHP_OUTPUT_HANDLER_FLUSHABLE ) && ( $flags & PHP_OUTPUT_HANDLER_REMOVABLE );
		$del       = isset( $buffer['del'] ) ? (bool) $buffer['del'] : $flushable;
		if ( $flushable && $del && ob_get_level() > 0 ) {
			ob_end_flush();
		}
	}
}

/** Desliga o flush padrão apenas quando a compressão zlib está ligada. */
function awr_fix_ob_flush() {
	if ( ! awr_zlib_compression_on() ) { return; }
	remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );
	if ( ! has_action( 'shutdown', 'awr_ob_end_flush_all' ) ) {
		add_action( 'shutdown', 'awr_ob_end_flush_all', 1 );
	}
}
add_action( 'init', 'awr_fix_ob_flush', 1 );
add_action( 'template_redirect', 'awr_fix_ob_flush', 0 );

/* ======================================================================
   v3.22.0 — CPU: desliga redimensionamento de imagem que o tema não usa
   ====================================================================== */

/** Remove tamanhos intermediários que nenhum template do tema exibe. */
add_filter( 'intermediate_image_sizes_advanced', function ( $sizes ) {
	foreach ( array( 'medium_large', '1536x1536', '2048x2048' ) as $s ) {
		unset( $sizes[ $s ] );
	}
	return $sizes;
} );

/** Nada de "big image": evita reprocessar cada upload grande. */
add_filter( 'big_image_size_threshold', '__return_false' );

/** WooCommerce não precisa gerar recortes extras para o layout do tema. */
add_filter( 'woocommerce_get_image_size_gallery_thumbnail', function ( $size ) {
	$size['crop'] = 0;
	return $size;
} );
add_filter( 'woocommerce_background_image_regeneration', '__return_false' );

/* ======================================================================
   v3.23.0 — lazy load global de imagens e cache HTTP
   ====================================================================== */

/** Lazy load ligado em qualquer contexto (o WP desliga em alguns filtros). */
add_filter( 'wp_lazy_loading_enabled', '__return_true', 20 );

/**
 * Toda imagem do tema entra com lazy + decoding async; só a primeira imagem
 * da página (candidata a LCP) fica eager/fetchpriority alto.
 */
function awr_img_defaults( $attr ) {
	static $first = true;
	if ( is_admin() ) { return $attr; }
	if ( $first ) {
		$first                  = false;
		$attr['loading']        = 'eager';
		$attr['fetchpriority']  = 'high';
		$attr['decoding']       = 'async';
		return $attr;
	}
	$attr['loading']  = 'lazy';
	$attr['decoding'] = 'async';
	unset( $attr['fetchpriority'] );
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'awr_img_defaults', 30 );

/** Iframes (mapas/vídeos) só carregam ao entrar na tela. */
add_filter( 'wp_iframe_tag_add_loading_attr', function () { return 'lazy'; }, 20 );
add_filter( 'the_content', function ( $html ) {
	if ( is_admin() || '' === $html ) { return $html; }
	if ( false !== strpos( $html, '<iframe' ) && false === strpos( $html, 'loading=' ) ) {
		$html = str_replace( '<iframe ', '<iframe loading="lazy" ', $html );
	}
	return $html;
}, 20 );

/* ---------------------------------------------------------------------
   Cache HTTP: páginas públicas com ETag/304 e assets do tema imutáveis
   --------------------------------------------------------------------- */

/** Rotas que nunca podem ser cacheadas (carrinho, checkout, conta, pedido). */
function awr_no_store_request() {
	if ( is_user_logged_in() || is_admin() || is_preview() || is_customize_preview() ) { return true; }
	if ( ! empty( $_POST ) ) { return true; } // phpcs:ignore WordPress.Security.NonceVerification
	if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) { return true; }
	if ( in_array( awr_current_route(), array( 'pedido' ), true ) ) { return true; }
	if ( function_exists( 'WC' ) && WC() && WC()->cart && ! WC()->cart->is_empty() ) { return true; }
	return false;
}

/** Cabeçalhos de cache das páginas públicas. */
add_action( 'template_redirect', function () {
	if ( ! headers_sent() ) { header( 'X-AWR-Theme-Version: ' . AWR_VERSION ); }
	if ( is_robots() || is_feed() ) { return; }
	if ( awr_no_store_request() ) {
		nocache_headers();
		return;
	}
	// v5.25.0: 1 h no CDN + atualização em segundo plano (TTFB baixo para visitantes).
	$ttl = (int) apply_filters( 'awr_html_s_maxage', 14400 );
	header( 'Cache-Control: public, max-age=0, s-maxage=' . $ttl . ', stale-while-revalidate=86400' );
	header( 'Vary: Accept-Encoding' );

	// ETag do HTML gerado + resposta 304 quando o navegador já tem a versão.
	ob_start( function ( $html ) {
		if ( '' === $html || headers_sent() ) { return $html; }
		// gtag.js do Google for WooCommerce (Ads) carregado cedo: o tema já
		// configura o mesmo AW- e sobe o gtag.js depois da interação/idle.
		$html = preg_replace( '#<script async src="https://www\.googletagmanager\.com/gtag/js\?id=AW-\d+"></script>#', '<!-- awr: gtag Ads adiado pelo tema -->', $html );
		$etag = '"awr-' . md5( AWR_VERSION . $html ) . '"';
		header( 'ETag: ' . $etag );
		$sent = isset( $_SERVER['HTTP_IF_NONE_MATCH'] ) ? trim( wp_unslash( $_SERVER['HTTP_IF_NONE_MATCH'] ) ) : '';
		if ( $sent && false !== strpos( $sent, $etag ) ) {
			status_header( 304 );
			return '';
		}
		return $html;
	} );
}, 1 );

/** Endpoints REST públicos do tema: cache curto no navegador/CDN. */
add_filter( 'rest_post_dispatch', function ( $response, $server, $request ) {
	if ( ! is_object( $response ) || 0 !== strpos( ltrim( $request->get_route(), '/' ), 'awr/v1' ) ) { return $response; }
	if ( 'GET' !== $request->get_method() || is_user_logged_in() ) { return $response; }

	// Resposta incompleta (algum produto sem preço) não pode ficar presa em cache.
	$data = $response->get_data();
	if ( is_array( $data ) && ! empty( $data['produtos'] ) && is_array( $data['produtos'] ) ) {
		foreach ( $data['produtos'] as $p ) {
			if ( is_array( $p ) && ( ! empty( $p['sob_consulta'] ) || empty( $p['price'] ) ) ) {
				$response->header( 'Cache-Control', 'no-store, max-age=0' );
				return $response;
			}
		}
	}

	$response->header( 'Cache-Control', 'public, max-age=60, s-maxage=300, stale-while-revalidate=600' );
	return $response;
}, 10, 3 );


/* ======================================================================
   v3.76.0 — Cloudflare Rocket Loader
   ====================================================================== */

/**
 * O Rocket Loader reescreve <script> e adia a execução — no nosso caso ele
 * segura a pintura do H1 do hero. Enquanto ele não for desligado no painel da
 * Cloudflare, todos os scripts do tema saem marcados para serem ignorados.
 */
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( is_admin() || false !== strpos( $tag, 'data-cfasync' ) ) { return $tag; }
	if ( 0 !== strpos( $handle, 'awr-' ) && ! in_array( $handle, array( 'jquery-core', 'jquery' ), true ) ) { return $tag; }
	return str_replace( '<script ', '<script data-cfasync="false" ', $tag );
}, 25, 2 );

/** Mesma proteção para os <style>/<link> do tema. */
add_filter( 'style_loader_tag', function ( $tag, $handle ) {
	if ( is_admin() || 0 !== strpos( $handle, 'awr-' ) || false !== strpos( $tag, 'data-cfasync' ) ) { return $tag; }
	return str_replace( '<link ', '<link data-cfasync="false" ', $tag );
}, 25, 2 );

/**
 * Detecta o Rocket Loader no HTML entregue ao visitante.
 *
 * @param bool $force Ignora o cache de 12h.
 * @return array {ativo:bool, checado_em:string, erro:string}
 */
function awr_rocket_loader_status( $force = false ) {
	$cache = get_transient( 'awr_rocket_loader' );
	if ( ! $force && is_array( $cache ) ) { return $cache; }

	$res  = wp_remote_get( home_url( '/' ), array( 'timeout' => 12, 'headers' => array( 'Cache-Control' => 'no-cache' ) ) );
	$out  = array( 'ativo' => false, 'checado_em' => current_time( 'd/m/Y H:i' ), 'erro' => '' );
	if ( is_wp_error( $res ) ) {
		$out['erro'] = $res->get_error_message();
	} else {
		$html = (string) wp_remote_retrieve_body( $res );
		$out['ativo'] = ( false !== stripos( $html, 'rocket-loader' ) || false !== stripos( $html, 'text/rocketscript' ) );
	}
	set_transient( 'awr_rocket_loader', $out, 12 * HOUR_IN_SECONDS );
	return $out;
}


/* v5.35.1 — bloco de remoção de cookies retirado (causava bloqueio 429). */
