<?php
/**
 * Garantia de fábrica e valor de casco por modelo — paridade com
 * src/data/garantia.ts e src/data/casco.ts do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

const AWR_CASCO_RS_POR_KG = 5.7;
const AWR_ACRESCIMO_FORA_RS = 0.04;

/** Meses de garantia por código de bateria. */
function awr_garantia_tabela() {
	static $t = null;
	if ( null !== $t ) { return $t; }
	$t = array(
		'M40SD' => 24,
		'M40SR' => 24,
		'M48FD' => 24,
		'M48FE' => 24,
		'M50ED' => 24,
		'M50JD' => 24,
		'M50JE' => 24,
		'M60AD' => 24,
		'M60GD' => 24,
		'M60GE' => 24,
		'M70KD' => 24,
		'M70KE' => 24,
		'M75LD' => 24,
		'M78LE' => 24,
		'MA60AD' => 24,
		'MA70LD' => 24,
		'MA95QD' => 24,
		'MA105DD' => 24,
		'MF50ED' => 24,
		'MF60AD' => 24,
		'MF72LD' => 24,
		'H40JD' => 24,
		'H45BE' => 24,
		'H45JE' => 24,
		'H48BD' => 24,
		'H50JD' => 24,
		'H65HD' => 24,
		'H70ND' => 24,
		'H70NE' => 24,
		'H75LD' => 24,
		'H75LE' => 24,
		'H75PD' => 24,
		'H75PE' => 24,
		'HE50GD' => 24,
		'HE60DD' => 24,
		'HE60DE' => 24,
		'HE60HD' => 24,
		'HEFB50GD' => 24,
		'HEFB60HD' => 24,
		'HEFB72PD' => 24,
		'HEFB225TD/TE' => 24,
		'HEFB225TD' => 24,
		'HEFB225TE' => 24,
		'HAGM60HD' => 24,
		'HAGM70PD' => 24,
		'HAGM80KD' => 24,
		'HAGM95MD' => 24,
		'HAGM105SD' => 24,
		'ECON60' => 24,
		'ECON72' => 24,
		'12MN300' => 24,
		'12MN500' => 24,
		'12MN700' => 24,
		'12MN1000' => 24,
		'12MN1300' => 24,
		'12MN1500' => 24,
		'12MN2000' => 24,
		'12MN2500' => 24,
		'12MN3000' => 24,
		'12MN4100' => 24,
		'DF300' => 24,
		'DF500' => 24,
		'DF700' => 24,
		'DF1000' => 24,
		'DF1500' => 24,
		'DF2000' => 24,
		'DF2500' => 24,
		'DF3000' => 24,
		'DF4100' => 24,
		'H90LD' => 18,
		'H90LE' => 18,
		'H95MD' => 18,
		'Z50ED' => 18,
		'EXF40JD' => 18,
		'EXF45BD' => 18,
		'EXF45BE' => 18,
		'EXF50JD' => 18,
		'EXF50JE' => 18,
		'EXF60DPD' => 18,
		'EXF60DPE' => 18,
		'EXF70ND' => 18,
		'EXF70NE' => 18,
		'EXF75ND' => 18,
		'EXF75NE' => 18,
		'EXF80TCD' => 18,
		'EXF80TCE' => 18,
		'EXF95MD' => 18,
		'EXF95TPD' => 18,
		'EXF95TPE' => 18,
		'ECON60AGM' => 18,
		'ECON70AGM' => 18,
		'ECON80AGM' => 18,
		'H100LE' => 15,
		'HC100LE' => 15,
		'H150TD' => 15,
		'H180TD' => 15,
		'HS100LE' => 15,
		'HS150TD' => 15,
		'HS180TD' => 15,
		'HS180TE' => 15,
		'HS200TD' => 15,
		'HT180TE' => 15,
		'M100HE' => 15,
		'M150BD' => 15,
		'M180TD' => 15,
		'M180TE' => 15,
		'M80CD' => 15,
		'M80RD' => 15,
		'M80RE' => 15,
		'M90TD' => 15,
		'M90TE' => 15,
		'M95QD' => 15,
		'Z100E' => 12,
		'Z150D' => 12,
		'Z180D' => 12,
		'Z180E' => 12,
		'Z70D' => 12,
		'60APD' => 12,
		'MA3-DI' => 6,
		'MA5-DI-MMV' => 6,
		'MA6-DI-MMV' => 6,
		'MA6-EI' => 6,
		'MA8-EI' => 6,
		'MA8,6-EI' => 6,
		'MA9-EI' => 6,
		'MA10-EI' => 6,
		'MA11-EI' => 6,
		'MA12-EI' => 6,
		'MA12-D' => 6,
		'MA18-DI' => 6,
		'MA30-DI' => 6,
		'MA10-EX' => 6,
		'MV5-DI' => 6,
		'MV5,5-DI' => 6,
		'MV7X-EI' => 6,
		'MV8-EI' => 6,
		'MV11-DI' => 6,
		'MV12-EI' => 6,
		'MV12-DI' => 6,
		'MV14-EI' => 6,
		'MV19-DI' => 6,
		'MX10-EI' => 6,
		'MX12-EI' => 6,
	);
	return $t;
}

/** Peso aproximado (kg) por código — base do valor de casco. */
function awr_peso_tabela() {
	static $t = null;
	if ( null !== $t ) { return $t; }
	$t = array(
		'H100LE' => 24.9,
		'M100HE' => 24.9,
		'EXF100LE' => 24.9,
		'Z100E' => 24.9,
		'H150TD' => 40.2,
		'M150BD' => 40.2,
		'EXF150BD' => 40.2,
		'Z150D' => 40.2,
		'HS150TD' => 40.2,
		'H180TD' => 44.5,
		'M180TD' => 44.5,
		'EXF180TD' => 44.5,
		'Z180D' => 44.5,
		'HS180TD' => 44.5,
		'HT180TE' => 45.1,
		'M180TE' => 45.1,
		'EXF180TE' => 45.1,
		'Z180E' => 45.1,
		'HS180TE' => 45.1,
		'HS100LE' => 25.8,
		'HC100LE' => 26.6,
		'HS200TD' => 54.3,
		'HEFB225TD/TE' => 57.4,
		'HEFB225TD' => 57.4,
		'HEFB225TE' => 57.4,
		'H40JD' => 9.7,
		'M40SD' => 9.7,
		'EXF40JD' => 9.7,
		'M40SR' => 9.7,
		'H45BE' => 11.5,
		'EXF45BE' => 11.5,
		'H45JE' => 12,
		'M50JE' => 12,
		'EXF50JE' => 12,
		'H48BD' => 11.9,
		'M48FD' => 11.9,
		'EXF45BD' => 11.9,
		'H50JD' => 12.4,
		'M50JD' => 12.4,
		'EXF50JD' => 12.4,
		'HE50GD' => 12.5,
		'M50ED' => 12.5,
		'Z50ED' => 12.5,
		'HE60DD' => 13.6,
		'M60GD' => 13.6,
		'EXF60DPD' => 13.6,
		'60APD' => 13.6,
		'Z60D' => 13.6,
		'HE60HD' => 14.2,
		'M60AD' => 14.2,
		'HE60DE' => 13.5,
		'M60GE' => 13.5,
		'EXF60DPE' => 13.5,
		'H65HD' => 15.5,
		'H70ND' => 16.2,
		'M70KD' => 16.2,
		'EXF70ND' => 16.2,
		'Z70D' => 16.2,
		'H70NE' => 16.2,
		'M70KE' => 16.2,
		'EXF70NE' => 16.2,
		'H75PD' => 17.6,
		'M75LD' => 17.6,
		'EXF75ND' => 17.6,
		'H75PE' => 17.6,
		'M78LE' => 17.6,
		'EXF75NE' => 17.6,
		'H75LD' => 18,
		'M80RD' => 18,
		'EXF80TCD' => 18,
		'H75LE' => 18,
		'M80RE' => 18,
		'EXF80TCE' => 18,
		'H90LD' => 22,
		'M90TD' => 22,
		'EXF95TPD' => 22,
		'H90LE' => 22,
		'M90TE' => 22,
		'EXF95TPE' => 22,
		'H95MD' => 22.6,
		'M95QD' => 22.6,
		'EXF95MD' => 22.6,
		'HAGM60HD' => 17.4,
		'MA60AD' => 17.4,
		'ECON60AGM' => 17.4,
		'HAGM70PD' => 20.3,
		'MA70LD' => 20.3,
		'ECON70AGM' => 20.3,
		'HAGM80KD' => 23,
		'M80CD' => 23,
		'ECON80AGM' => 23,
		'HAGM95MD' => 26.4,
		'MA95QD' => 26.4,
		'HAGM105SD' => 29.2,
		'MA105DD' => 29.2,
		'HEFB50GD' => 15,
		'MF50ED' => 15,
		'HEFB60HD' => 16.2,
		'MF60AD' => 16.2,
		'ECON60' => 16.2,
		'HEFB72PD' => 18.9,
		'MF72LD' => 18.9,
		'ECON72' => 18.9,
		'12MN300' => 9.2,
		'DF300' => 9.2,
		'12MN500' => 10.6,
		'DF500' => 10.6,
		'12MN700' => 11.8,
		'DF700' => 11.8,
		'12MN1000' => 14.4,
		'DF1000' => 14.4,
		'12MN1300' => 16,
		'12MN1500' => 23,
		'DF1500' => 23,
		'12MN2000' => 26,
		'DF2000' => 26,
		'12MN2500' => 40.4,
		'DF2500' => 40.4,
		'12MN3000' => 51,
		'DF3000' => 51,
		'12MN4100' => 58,
		'DF4100' => 58,
	);
	return $t;
}

/** Modelos que nunca exibem selo de garantia. */
function awr_sem_garantia( $hay ) {
	$re = array(
		'/motobatt/i', '/\bglobal\b/i',
		'/12MVA\s*-?\s*18/i', '/12MVA\s*-?\s*12/i', '/12MVA\s*-?\s*9/i', '/12MVA9/i',
		'/jogo\s+(com\s+)?(de\s+)?4\s+bateria/i',
		'/12\s*v\s*7\s*ah/i', '/12\s*v\s*9\s*ah/i',
	);
	foreach ( $re as $r ) { if ( preg_match( $r, $hay ) ) { return true; } }
	return false;
}

function awr_norm_codigo( $s ) {
	$s = strtoupper( preg_replace( '/\s+/', '', (string) $s ) );
	return preg_replace( '/^BATERIA/', '', $s );
}

/** Busca em tabela por código exato ou prefixo. */
function awr_lookup_codigo( $tabela, $sku, $nome = '' ) {
	$k = awr_norm_codigo( $sku );
	if ( '' !== $k && isset( $tabela[ $k ] ) ) { return $tabela[ $k ]; }
	$n = awr_norm_codigo( $nome );
	foreach ( $tabela as $cod => $val ) {
		if ( ( '' !== $k && 0 === strpos( $k, $cod ) ) || ( '' !== $n && false !== strpos( $n, $cod ) ) ) { return $val; }
	}
	return null;
}

/** Meses de garantia, ou null quando não houver. */
function awr_garantia_meses( $sku, $nome = '' ) {
	$estacionaria = awr_garantia_estacionaria( $sku, $nome );
	if ( $estacionaria ) { return (int) $estacionaria['meses']; }
	// Planilha oficial de garantias (28/09) vem antes de tudo.
	if ( function_exists( 'awr_garantia_oficial' ) ) {
		$o = awr_garantia_oficial( $sku, $nome );
		if ( $o ) { return (int) $o; }
	}
	if ( awr_sem_garantia( $sku . ' ' . $nome ) ) { return null; }
	// A tabela de especificações tem prioridade sobre a tabela legada.
	$e = function_exists( 'awr_espec_bateria' ) ? awr_espec_bateria( $sku, $nome ) : null;
	if ( $e ) { return (int) $e['garantia']; }
	$m = awr_lookup_codigo( awr_garantia_tabela(), $sku, $nome );
	return $m ? (int) $m : null;
}

/** Rótulo "Garantia 24 meses" ou string vazia. */
function awr_garantia_label( $sku, $nome = '' ) {
	$estacionaria = awr_garantia_estacionaria( $sku, $nome );
	if ( $estacionaria ) { return 'Garantia ' . $estacionaria['prazo']; }
	$m = awr_garantia_meses( $sku, $nome );
	return $m ? 'Garantia ' . $m . ' meses' : '';
}

/** Peso (kg) do modelo, ou null. */
function awr_peso_kg( $sku, $nome = '' ) {
	$e = function_exists( 'awr_espec_bateria' ) ? awr_espec_bateria( $sku, $nome ) : null;
	if ( $e ) { return (float) $e['peso']; }
	$p = awr_lookup_codigo( awr_peso_tabela(), $sku, $nome );
	return $p ? (float) $p : null;
}

/** Valor do casco (R$) quando o cliente não devolve a bateria velha. */
function awr_valor_casco( $sku, $nome = '' ) {
	// Valor fechado da planilha; só calculamos por kg fora dela.
	$e = function_exists( 'awr_espec_bateria' ) ? awr_espec_bateria( $sku, $nome ) : null;
	if ( $e ) { return (float) $e['casco']; }
	$kg = awr_peso_kg( $sku, $nome );
	if ( ! $kg ) { return 0; }
	return round( $kg * AWR_CASCO_RS_POR_KG, 2 );
}
