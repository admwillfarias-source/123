<?php
/**
 * Fonte única de preços "a partir de" usados em textos de SEO, FAQs e schema.
 * Valores conferidos na planilha oficial de preços AWR em 26/09/2026.
 * Espelha src/data/precos.ts do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Tabela de preços mínimos por linha. */
function awr_precos() {
	return array(
		'carro_entrada'       => 329,   // Eletra 60APD 60Ah
		'carro_entrada_label' => '60Ah Eletra',
		'populares'           => 339,   // Excell Evolution 45Ah
		'sedans_suv'          => 499,   // Excell Evolution 70ND/E
		'suv_picape'          => 600,   // Excell Evolution 75ND/E
		'start_stop_efb'      => 499,   // Excell EFB 60HD
		'agm'                 => 1479,  // Moura AGM MA60AD
		'agm_label'           => 'Moura AGM 60Ah',
		'moto'                => 199,   // Moura MA5D 5Ah
		'moto_label'          => 'Moura MA5D 5Ah',
		'estacionaria'        => 339,   // Moura Nobreak 12MN300
		'teto'                => 3200,
	);
}

/** Valor de uma chave da tabela. */
function awr_preco( $chave ) {
	$p = awr_precos();
	return isset( $p[ $chave ] ) ? $p[ $chave ] : 0;
}

/** Formata em reais sem centavos: 1129 → "R$ 1.129". */
function awr_preco_brl( $v ) {
	return 'R$ ' . number_format( (float) $v, 0, ',', '.' );
}

/** "R$ 329" — piso do catálogo. */
function awr_preco_min() {
	return awr_preco_brl( awr_preco( 'carro_entrada' ) );
}

/** "R$ 329 (60Ah Eletra)". */
function awr_preco_a_partir() {
	return awr_preco_min() . ' (' . awr_preco( 'carro_entrada_label' ) . ')';
}

/** Faixa para schema.org priceRange. */
function awr_price_range() {
	return awr_preco_min() . ' - ' . awr_preco_brl( awr_preco( 'teto' ) );
}
