<?php
/**
 * Auditoria T02 (5.17.1): URLs antigas de produto que retornavam 404 e
 * perderam cliques. 301 para o produto atual equivalente (resolvido pelo SKU
 * no WooCommerce em tempo de execução) ou, sem equivalente, para a categoria.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function awr_produtos_perdidos_map() {
	// slug antigo => [ SKUs candidatos em ordem, fallback ]
	return array(
		'bateria-novatech-60ah-n60pd-entrega-e-instalacao-gratis' => array( array(), '/baterias/amperagem/60/' ),
		'bateria-excell-free-12v-60ah-exf60dd'                   => array( array( 'EXF60DPD', 'EXF60DPE' ), '/baterias/amperagem/60/' ),
		'bateria-strada-60ah-st60dd'                             => array( array(), '/baterias/amperagem/60/' ),
		'bateria-heliar-super-free-60ah-hf60dd'                  => array( array( 'HF60HD', 'HF60DD' ), '/baterias/amperagem/60/' ),
		'bateria-excell-free-12v-50ah-exf50jd'                   => array( array( 'EXF50JD', 'EXF50JE' ), '/baterias/amperagem/50/' ),
		'bateria-moura-40ah-m40sr-12v-m40sr'                     => array( array( 'M40SR' ), '/baterias/amperagem/40/' ),
		'bateria-excell-free-150ah-exf-150-td'                   => array( array( 'EXF150TD', 'EX150TD' ), '/baterias-para-caminhao/' ),
		'bateria-moura-50ah-12v-m50ed'                           => array( array( 'M50ED' ), '/baterias/amperagem/50/' ),
		'bateria-moura-75ah-12v-m75lx'                           => array( array( 'M75LX', 'M75LD' ), '/baterias/amperagem/75/' ),
		'bateria-heliar-original-38ah-hg38jd'                    => array( array( 'HG38JD' ), '/baterias/amperagem/40/' ),
		'heliar-agm-ag-80kd'                                     => array( array( 'HAGM80KD' ), '/loja/' ),
		'bateria-excell-evolution-exf-210od-12v-210ah'           => array( array( 'EXF210OD' ), '/baterias-para-caminhao/' ),
		'bateria-estacionaria-freedom-df4100-12v-240ah-estacionaria' => array( array( 'DF4100' ), '/loja/c/estacionaria/' ),
		'bateria-excell-super-premium-exp-48bsd-12v-48ah'        => array( array( 'EXP48BSD' ), '/baterias/amperagem/48/' ),
		'bateria-zetta-50ah-z50ed'                               => array( array( 'Z50ED' ), '/baterias/amperagem/50/' ),
		'bateria-excell-super-premium-exp-60dsd-12v-60ah'        => array( array( 'EXP60DSD', 'EXF60DPD' ), '/baterias/amperagem/60/' ),
		'bateria-moura-agm-92ah-start-stop'                      => array( array( 'MA92QD' ), '/loja/' ),
		'bateria-america-70ah'                                   => array( array(), '/baterias/amperagem/70/' ),
		'heliar-frota-super-free-rtp100le'                       => array( array( 'RTP100LE' ), '/baterias-para-caminhao/' ),
		'bateria-excell-free-45ah-12v-exf-45bd'                  => array( array( 'EXF45BD', 'EXF45BE' ), '/baterias/amperagem/45/' ),
		'bateria-moura-60ah-m60ad'                               => array( array( 'M60AD' ), '/baterias/amperagem/60/' ),
		'bateria-heliar-super-free-52ah-hf52gd'                  => array( array( 'HF52GD' ), '/baterias/amperagem/50/' ),
		'bateria-excell-free-180ah-exf-180-td'                   => array( array( 'EX180TD' ), '/baterias-para-caminhao/' ),
		'bateria-excell-super-premium-exp-52gsd-12v-52ah'        => array( array( 'EXP52GSD' ), '/baterias/amperagem/50/' ),
	);
}

function awr_produtos_perdidos_destino( $slug ) {
	$map = awr_produtos_perdidos_map();
	if ( empty( $map[ $slug ] ) ) { return ''; }
	list( $skus, $fallback ) = $map[ $slug ];
	if ( function_exists( 'wc_get_product_id_by_sku' ) ) {
		foreach ( $skus as $sku ) {
			$id = (int) wc_get_product_id_by_sku( $sku );
			if ( $id && 'publish' === get_post_status( $id ) ) {
				$url = get_permalink( $id );
				if ( $url && false === strpos( $url, '/' . $slug . '/' ) ) { return $url; }
			}
		}
	}
	return home_url( $fallback );
}

add_action( 'template_redirect', function () {
	if ( is_admin() || ! is_404() ) { return; }
	$path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
	if ( 0 !== strpos( $path, 'produto/' ) ) { return; }
	$slug = trim( substr( $path, 8 ), '/' );
	$dest = awr_produtos_perdidos_destino( $slug );
	if ( ! $dest ) { return; }
	wp_safe_redirect( $dest, 301, 'AWR T02' );
	exit;
}, 0 );
