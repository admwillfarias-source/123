<?php
/** Isolamento das rotas integralmente controladas pelo tema AWR. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function awr_is_native_screen() {
	if ( is_admin() || wp_doing_ajax() || is_feed() || is_embed() ) { return false; }
	if ( isset( $_GET['elementor-preview'] ) || isset( $_GET['preview'] ) ) { return false; } // phpcs:ignore
	// O tema controla cabeçalho/rodapé de TODAS as telas do site — assim as
	// páginas internas usam o mesmo header/footer da home, sem Elementor.
	return (bool) apply_filters( 'awr_is_native_screen', true );
}

/** Tela transacional do WooCommerce (carrinho, finalização, conta, produto, loja). */
function awr_is_woo_screen() {
	if ( ! function_exists( 'is_woocommerce' ) ) { return false; }
	return is_cart() || is_checkout() || is_account_page() || is_product() || is_shop() || is_product_category() || is_product_tag();
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! awr_is_native_screen() ) { return; }
	$styles = array( 'elementor-icons', 'elementor-frontend', 'elementor-pro', 'elementor-global', 'e-animations', 'global-styles', 'wp-block-library', 'wp-block-library-theme', 'classic-theme-styles', 'wc-blocks-style' );
	// Carrinho/finalização/produto precisam dos blocos do Woo: o Google
	// (Storebot) rastreia essas telas para validar preço e disponibilidade.
	if ( awr_is_woo_screen() ) {
		$styles = array_diff( $styles, array( 'wp-block-library', 'wp-block-library-theme', 'wc-blocks-style' ) );
	}
	$id = get_queried_object_id();
	if ( $id ) { $styles[] = 'elementor-post-' . $id; }
	foreach ( $styles as $handle ) { wp_dequeue_style( $handle ); }
	wp_dequeue_script( 'elementor-frontend' );
}, PHP_INT_MAX );

/** Remove o CSS inline de global-styles (theme.json) nas telas nativas do tema. */
add_action( 'init', function () {
	add_action( 'wp_head', function () {
		if ( awr_is_native_screen() ) { remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' ); }
	}, 0 );
} );


add_filter( 'elementor/theme/need_override_location', function ( $need ) {
	return awr_is_native_screen() ? false : $need;
}, PHP_INT_MAX );

add_filter( 'elementor/theme/need_override_location/header', function ( $need ) {
	return awr_is_native_screen() ? false : $need;
}, PHP_INT_MAX );

add_filter( 'elementor/theme/need_override_location/footer', function ( $need ) {
	return awr_is_native_screen() ? false : $need;
}, PHP_INT_MAX );