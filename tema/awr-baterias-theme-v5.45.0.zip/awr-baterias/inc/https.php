<?php
/**
 * Normalização de esquema (HTTPS) — carregado antes de tudo.
 *
 * Em hospedagens atrás de proxy/CDN o WordPress não enxerga a conexão como
 * segura e passa a gerar URLs em http:// dentro de páginas https://. O
 * navegador bloqueia esses arquivos por Mixed Content — foi o que derrubava
 * o awr-search.js (busca sem sugestões) e as fontes do tema no mobile.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** A requisição atual chegou por HTTPS (considerando cabeçalhos de proxy)? */
function awr_request_is_https() {
	static $cache = null;
	if ( null !== $cache ) { return $cache; }

	$cache = false;

	if ( function_exists( 'is_ssl' ) && is_ssl() ) {
		$cache = true;
	} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && 'https' === strtolower( explode( ',', (string) $_SERVER['HTTP_X_FORWARDED_PROTO'] )[0] ) ) {
		$cache = true;
	} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_SSL'] ) && in_array( strtolower( (string) $_SERVER['HTTP_X_FORWARDED_SSL'] ), array( 'on', '1' ), true ) ) {
		$cache = true;
	} elseif ( ! empty( $_SERVER['HTTP_CF_VISITOR'] ) && false !== strpos( (string) $_SERVER['HTTP_CF_VISITOR'], 'https' ) ) {
		$cache = true;
	} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_PORT'] ) && '443' === (string) $_SERVER['HTTP_X_FORWARDED_PORT'] ) {
		$cache = true;
	}

	return $cache;
}

// Faz o próprio núcleo do WordPress reconhecer a conexão segura.
if ( awr_request_is_https() && empty( $_SERVER['HTTPS'] ) ) {
	$_SERVER['HTTPS'] = 'on';
}

/** Reescreve http:// → https:// para URLs do próprio site. */
function awr_force_https( $url ) {
	if ( ! is_string( $url ) || '' === $url ) { return $url; }
	if ( 0 !== strpos( $url, 'http://' ) ) { return $url; }
	if ( ! awr_request_is_https() ) { return $url; }

	$host = wp_parse_url( $url, PHP_URL_HOST );
	if ( ! $host ) { return $url; }

	$site = wp_parse_url( get_option( 'home' ), PHP_URL_HOST );
	if ( $site && 0 !== strcasecmp( ltrim( (string) $host, 'w.' ), ltrim( (string) $site, 'w.' ) )
		&& 0 !== strcasecmp( (string) $host, (string) $site ) ) {
		// Domínio de terceiros: não mexemos.
		return $url;
	}

	return 'https://' . substr( $url, 7 );
}

$awr_https_url_filters = array(
	'home_url', 'site_url', 'admin_url', 'includes_url', 'content_url', 'plugins_url',
	'theme_root_uri', 'template_directory_uri', 'stylesheet_directory_uri',
	'script_loader_src', 'style_loader_src', 'rest_url', 'wp_get_attachment_url',
	'upload_dir', 'the_permalink', 'post_link', 'page_link', 'wp_get_canonical_url',
);
foreach ( $awr_https_url_filters as $awr_https_filter ) {
	add_filter( $awr_https_filter, function ( $value ) {
		if ( is_array( $value ) ) {
			foreach ( array( 'url', 'baseurl' ) as $key ) {
				if ( isset( $value[ $key ] ) ) { $value[ $key ] = awr_force_https( $value[ $key ] ); }
			}
			return $value;
		}
		return awr_force_https( $value );
	}, 1 );
}
unset( $awr_https_url_filters, $awr_https_filter );

/*
 * v5.36.3 — Visitante chegou por http:// (o Cloudflare informa o esquema real
 * em CF-Visitor) → 301 para https://, mantendo caminho. Só usa o cabeçalho do
 * visitante, então não entra em laço com SSL "Flexible" no Cloudflare.
 */
add_action( 'init', function () {
	if ( is_admin() || ( defined( 'WP_CLI' ) && WP_CLI ) || PHP_SAPI === 'cli' ) { return; }
	$v = isset( $_SERVER['HTTP_CF_VISITOR'] ) ? (string) $_SERVER['HTTP_CF_VISITOR'] : '';
	if ( '' === $v || false === strpos( $v, '"http"' ) ) { return; }
	$host = wp_parse_url( home_url(), PHP_URL_HOST );
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '/';
	if ( ! $host ) { return; }
	header( 'Location: https://' . $host . $uri, true, 301 );
	exit;
}, 0 );

/** Tag de verificação do Google fixa no tema — não depende de plugin. */
if ( ! defined( 'AWR_GOOGLE_SITE_VERIFICATION' ) ) {
	define( 'AWR_GOOGLE_SITE_VERIFICATION', 'NUwpyVpxYMA-re5sBfYmxshrrTy0YIVYkuKts6-O34s' );
}
add_action( 'wp_head', function () {
	$t = apply_filters( 'awr_google_site_verification', AWR_GOOGLE_SITE_VERIFICATION );
	if ( $t ) { echo '<meta name="google-site-verification" content="' . esc_attr( $t ) . '" />' . "\n"; }
}, 1 );
