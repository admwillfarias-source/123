<?php
/**
 * Controle automático do feed do Google for WooCommerce.
 * - Exclui produtos com tags/categorias bloqueadas ou com imagem abaixo do mínimo.
 * - Preenche o peso de envio a partir da tabela oficial quando estiver vazio.
 * Opções em Ajustes → AWR Feed Google.
 */
defined( 'ABSPATH' ) || exit;

function awr_feed_opts() {
	$o = get_option( 'awr_feed_filtro', array() );
	return wp_parse_args( is_array( $o ) ? $o : array(), array(
		'tags'      => 'teste, rascunho, nao-sincronizar',
		'cats'      => '',
		'min_img'   => 100,
		'peso_auto' => 1,
	) );
}

function awr_feed_lista( $txt ) {
	return array_filter( array_map( 'sanitize_title', array_map( 'trim', explode( ',', (string) $txt ) ) ) );
}

/** Retorna o motivo da exclusão ou '' se o produto pode ir para o feed. */
function awr_feed_motivo_exclusao( $product ) {
	if ( ! $product instanceof WC_Product ) { return ''; }
	$id   = $product->get_parent_id() ?: $product->get_id();
	$opts = awr_feed_opts();

	$tags = awr_feed_lista( $opts['tags'] );
	if ( $tags && has_term( $tags, 'product_tag', $id ) ) { return 'tag bloqueada'; }
	$cats = awr_feed_lista( $opts['cats'] );
	if ( $cats && has_term( $cats, 'product_cat', $id ) ) { return 'categoria bloqueada'; }

	$min = (int) $opts['min_img'];
	if ( $min > 0 ) {
		$img = $product->get_image_id() ?: get_post_thumbnail_id( $id );
		if ( ! $img ) { return 'sem imagem'; }
		$meta = wp_get_attachment_metadata( $img );
		if ( ! empty( $meta['width'] ) && ( $meta['width'] < $min || $meta['height'] < $min ) ) {
			return 'imagem menor que ' . $min . 'px';
		}
	}
	return '';
}

/** Marca o produto como "não sincronizar" no Google for WooCommerce. */
function awr_feed_aplicar( $post_id ) {
	$p = wc_get_product( $post_id );
	if ( ! $p ) { return ''; }
	$motivo = awr_feed_motivo_exclusao( $p );
	if ( $motivo ) {
		update_post_meta( $post_id, '_wc_gla_visibility', 'dont-sync-and-show' );
		update_post_meta( $post_id, '_awr_feed_excluido', $motivo );
	} elseif ( get_post_meta( $post_id, '_awr_feed_excluido', true ) ) {
		// Só reverte o que o próprio tema excluiu.
		update_post_meta( $post_id, '_wc_gla_visibility', 'sync-and-show' );
		delete_post_meta( $post_id, '_awr_feed_excluido' );
	}
	return $motivo;
}
add_action( 'woocommerce_update_product', 'awr_feed_aplicar', 5 );
add_action( 'woocommerce_new_product', 'awr_feed_aplicar', 5 );

/** Barreira extra no momento da sincronização. */
add_filter( 'woocommerce_gla_get_sync_ready_products_pre_filter', function ( $products ) {
	if ( ! is_array( $products ) ) { return $products; }
	return array_values( array_filter( $products, function ( $p ) {
		return '' === awr_feed_motivo_exclusao( $p );
	} ) );
} );

/** Peso de envio automático pela tabela oficial quando vazio. */
add_filter( 'woocommerce_product_get_weight', 'awr_feed_peso_auto', 10, 2 );
add_filter( 'woocommerce_product_variation_get_weight', 'awr_feed_peso_auto', 10, 2 );
function awr_feed_peso_auto( $peso, $product ) {
	if ( '' !== (string) $peso || is_admin() && ! wp_doing_ajax() && ! wp_doing_cron() ) { return $peso; }
	$o = awr_feed_opts();
	if ( empty( $o['peso_auto'] ) || ! function_exists( 'awr_espec_bateria' ) ) { return $peso; }
	$e = awr_espec_bateria( $product->get_sku(), $product->get_name() );
	return ( $e && ! empty( $e['peso'] ) ) ? (string) $e['peso'] : $peso;
}

/* ---------- Painel ---------- */
add_action( 'admin_menu', function () {
	add_options_page( 'AWR Feed Google', 'AWR Feed Google', 'manage_woocommerce', 'awr-feed-google', 'awr_feed_painel' );
} );

function awr_feed_painel() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
	$msg = '';
	if ( isset( $_POST['awr_feed_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['awr_feed_nonce'] ), 'awr_feed' ) ) {
		update_option( 'awr_feed_filtro', array(
			'tags'      => sanitize_text_field( wp_unslash( $_POST['tags'] ?? '' ) ),
			'cats'      => sanitize_text_field( wp_unslash( $_POST['cats'] ?? '' ) ),
			'min_img'   => max( 0, min( 2000, absint( $_POST['min_img'] ?? 100 ) ) ),
			'peso_auto' => empty( $_POST['peso_auto'] ) ? 0 : 1,
		) );
		$msg = 'Configurações salvas.';
		if ( ! empty( $_POST['revisar'] ) ) {
			$ids = get_posts( array( 'post_type' => 'product', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids' ) );
			$exc = array();
			foreach ( $ids as $id ) {
				$m = awr_feed_aplicar( $id );
				if ( $m ) { $exc[] = get_the_title( $id ) . ' — ' . $m; }
			}
			$msg .= ' Revisados ' . count( $ids ) . ' produtos; ' . count( $exc ) . ' retirados do feed.';
			if ( $exc ) { $msg .= '<br>' . implode( '<br>', array_map( 'esc_html', $exc ) ); }
		}
	}
	$o = awr_feed_opts();
	?>
	<div class="wrap"><h1>AWR Feed Google</h1>
	<?php if ( $msg ) { echo '<div class="notice notice-success"><p>' . wp_kses( $msg, array( 'br' => array() ) ) . '</p></div>'; } ?>
	<form method="post"><?php wp_nonce_field( 'awr_feed', 'awr_feed_nonce' ); ?>
	<table class="form-table">
	<tr><th>Tags que não vão para o Google</th><td><input class="regular-text" name="tags" value="<?php echo esc_attr( $o['tags'] ); ?>"><p class="description">Separe por vírgula (nome ou slug da tag).</p></td></tr>
	<tr><th>Categorias que não vão para o Google</th><td><input class="regular-text" name="cats" value="<?php echo esc_attr( $o['cats'] ); ?>"></td></tr>
	<tr><th>Tamanho mínimo da foto (px)</th><td><input type="number" name="min_img" value="<?php echo esc_attr( $o['min_img'] ); ?>"><p class="description">Produtos com foto menor ficam fora do feed até trocar a foto. Recomendado pelo Google: 800.</p></td></tr>
	<tr><th>Peso automático</th><td><label><input type="checkbox" name="peso_auto" value="1" <?php checked( $o['peso_auto'] ); ?>> Usar o peso da tabela oficial quando o produto estiver sem peso</label></td></tr>
	</table>
	<p><button class="button button-primary" name="salvar" value="1">Salvar</button>
	<button class="button" name="revisar" value="1">Salvar e revisar todos os produtos agora</button></p>
	</form></div>
	<?php
}
