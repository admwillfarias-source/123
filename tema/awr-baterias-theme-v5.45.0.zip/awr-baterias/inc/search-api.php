<?php
/**
 * Canal público da busca, independente da REST API do WordPress.
 *
 * Algumas hospedagens bloqueiam /wp-json/ e admin-ajax.php no ModSecurity.
 * Este endpoint aceita somente POST JSON e executa operações de leitura.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** URL estável usada pelo JavaScript do tema. */
function awr_search_api_url() {
	return home_url( '/awr-busca/' );
}

/** Lê e valida o corpo do canal público (POST JSON ou GET com query string). */
function awr_search_api_payload() {
	if ( 'POST' === strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) ) {
		$raw = file_get_contents( 'php://input' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( is_string( $raw ) && strlen( $raw ) <= 4096 ) {
			$data = json_decode( $raw, true );
			if ( is_array( $data ) && $data ) { return $data; }
		}
		// Alguns proxies convertem o corpo em formulário.
		return is_array( $_POST ) ? wp_unslash( $_POST ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
	}

	$out  = array();
	$keys = array( 'action', 'q', 'veiculo', 'ano', 'sku', 'skus', 'ah', 'uso', 'sintomas', 'observacao' );
	foreach ( $keys as $key ) {
		if ( isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$out[ $key ] = substr( (string) wp_unslash( $_GET[ $key ] ), 0, 200 ); // phpcs:ignore WordPress.Security.NonceVerification
		}
	}
	return $out;
}


/** Resposta de sugestões compartilhável com o endpoint REST legado. */
function awr_search_suggestions_response( $query ) {
	$q = sanitize_text_field( (string) $query );
	if ( function_exists( 'mb_substr' ) ) { $q = mb_substr( $q, 0, 100 ); }
	else { $q = substr( $q, 0, 100 ); }
	return array(
		'veiculos' => awr_search_suggestions( $q, 8 ),
		'skus'     => awr_search_by_sku( $q, 5 ),
	);
}

/** Resposta de produtos compartilhável com o endpoint REST legado. */
function awr_search_products_response( $data ) {
	$veiculo = sanitize_title( (string) ( $data['veiculo'] ?? '' ) );
	$ano     = (int) ( $data['ano'] ?? 0 );
	$sku     = sanitize_text_field( (string) ( $data['sku'] ?? '' ) );
	$skus    = sanitize_text_field( (string) ( $data['skus'] ?? '' ) );
	$ah      = (int) ( $data['ah'] ?? 0 );

	if ( $ano && ( $ano < 1950 || $ano > ( (int) gmdate( 'Y' ) + 2 ) ) ) { $ano = 0; }
	if ( $ah < 0 || $ah > 300 ) { $ah = 0; }

	if ( $skus ) {
		$list = array();
		foreach ( array_slice( array_filter( array_map( 'trim', explode( ',', $skus ) ) ), 0, 12 ) as $item ) {
			$list[] = array( 'sku' => sanitize_text_field( $item ), 'brand' => '' );
		}
		return array( 'produtos' => awr_products_by_skus( $list ) );
	}
	if ( $sku ) {
		return array( 'produtos' => awr_products_by_skus( array( array( 'sku' => $sku, 'brand' => '' ) ) ) );
	}
	if ( $ah ) {
		return array( 'produtos' => awr_products_by_skus( array_slice( awr_search_by_amperage( $ah ), 0, 12 ) ) );
	}
	if ( $veiculo ) {
		$items = awr_vehicle_by_slug( $veiculo, $ano );
		return array(
			'veiculo'  => $items ? $items[0]['ma'] . ' ' . $items[0]['mo'] : '',
			'ano'      => $ano,
			'produtos' => awr_products_by_skus( awr_skus_from_items( $items ) ),
		);
	}
	return array( 'produtos' => array() );
}

/** Endpoint do motor de diagnóstico (server-to-server, nunca exposto ao navegador). */
function awr_diag_endpoint() {
	$url = trim( (string) get_option( 'awr_diag_endpoint', '' ) );
	if ( '' === $url ) { $url = 'https://quick-battery-hero.lovable.app/api/public/diagnostico'; }
	return apply_filters( 'awr_diag_endpoint', $url );
}

/** Baterias homologadas do veículo, na ordem de preferência da AWR. */
function awr_diag_candidatos( $items ) {
	$out  = array();
	$seen = array();
	foreach ( (array) $items as $it ) {
		foreach ( AWR_BRAND_KEYS as $k => $marca ) {
			$sku = isset( $it[ $k ] ) ? trim( (string) $it[ $k ] ) : '';
			if ( '' === $sku ) { continue; }
			$chave = $marca . '|' . strtoupper( $sku );
			if ( isset( $seen[ $chave ] ) ) { continue; }
			$seen[ $chave ] = true;
			$out[]          = array( 'marca' => $marca, 'sku' => strtoupper( $sku ), 'amperagem' => awr_extract_amperage( $sku ) );
		}
	}
	return $out;
}

/**
 * Laudo técnico gerado dentro do próprio tema.
 * Usado quando o motor de IA não responde, para o cliente nunca ver erro.
 */
function awr_diag_laudo_local( $candidatos, $sintomas, $uso ) {
	$baixa = function ( $s ) { return function_exists( 'mb_strtolower' ) ? mb_strtolower( (string) $s, 'UTF-8' ) : strtolower( (string) $s ); };
	$txt   = $baixa( implode( ' ', (array) $sintomas ) );
	$tem   = function ( $agulha ) use ( $txt ) { return '' !== $agulha && false !== strpos( $txt, $agulha ); };
	$idade = $tem( '3 anos' ) || $tem( 'mais de 3' );

	if ( $tem( 'não liga' ) || $tem( 'nao liga' ) || $tem( 'clique' ) || $tem( 'arriou' ) || $tem( 'chupeta' ) ) {
		$grav  = 'urgente';
		$laudo = 'Os sinais indicam que a bateria já não segura carga suficiente para a partida. Nesse estágio o carro costuma deixar o motorista na mão a qualquer momento, e a troca é o caminho mais seguro.';
	} elseif ( $tem( 'motor pesado' ) || $tem( 'start-stop' ) || $tem( 'start stop' ) || $idade ) {
		$grav  = 'urgente';
		$laudo = 'A partida pesada e a perda de força elétrica são o aviso clássico de bateria no fim da vida útil. Vale antecipar a troca antes que o carro pare de vez.';
	} elseif ( $tem( 'luzes' ) || $tem( 'painel' ) || $tem( 'vidro' ) || $tem( 'trava' ) ) {
		$grav  = 'atencao';
		$laudo = 'A queda de brilho das luzes e a lentidão dos vidros mostram tensão baixa. Geralmente é bateria enfraquecida, mas o alternador também precisa ser testado.';
	} elseif ( $tem( 'parado' ) ) {
		$grav  = 'atencao';
		$laudo = 'Ficar muitos dias parado descarrega a bateria aos poucos e encurta a vida dela. Um teste rápido mostra se ainda dá para recuperar a carga ou se já é hora de trocar.';
	} else {
		$grav  = 'preventivo';
		$laudo = 'Não há sinal de falha grave agora. É um bom momento para conferir a carga e a saúde do sistema elétrico e evitar surpresas.';
	}

	$usoTxt  = $baixa( $uso );
	$intenso = false !== strpos( $usoTxt, 'aplicativo' ) || false !== strpos( $usoTxt, 'frota' ) || false !== strpos( $usoTxt, 'taxi' ) || false !== strpos( $usoTxt, 'táxi' );

	$rec = $candidatos[0];
	$alt = isset( $candidatos[1] ) ? $candidatos[1] : null;

	$dicas = array( 'Peça um teste da bateria e do alternador na hora da visita.' );
	if ( $tem( 'parado' ) ) { $dicas[] = 'Se o carro fica dias parado, rode pelo menos 20 minutos por semana.' ; }
	if ( $idade ) { $dicas[] = 'Bateria com mais de 3 anos costuma falhar sem aviso, principalmente no frio.'; }
	$dicas[] = 'Confira se os polos estão limpos e bem apertados.';

	return array(
		'diagnostico'       => $laudo,
		'gravidade'         => $grav,
		'recomendadaSku'    => $rec['sku'],
		'recomendadaMarca'  => $rec['marca'],
		'porqueEssa'        => 'É a bateria homologada para o seu veículo' . ( $rec['amperagem'] ? ', com ' . $rec['amperagem'] . 'Ah' : '' ) . ( $intenso ? ', indicada para quem roda o dia inteiro.' : ', com o melhor equilíbrio de durabilidade para o seu uso.' ),
		'alternativaSku'    => $alt ? $alt['sku'] : null,
		'alternativaMarca'  => $alt ? $alt['marca'] : null,
		'porqueAlternativa' => $alt ? 'Mesma aplicação homologada, opção de melhor custo-benefício.' : null,
		'precisaEfbAgm'     => $tem( 'start-stop' ) || $tem( 'start stop' ),
		'dicas'             => array_slice( $dicas, 0, 3 ),
		'candidatos'        => $candidatos,
		'fonte'             => 'tema',
	);
}


/**
 * Diagnóstico com IA — o PHP fala com o motor e devolve o laudo pronto.
 * O navegador do cliente nunca sai de awrbaterias.com.br.
 */
function awr_diagnostico_response( $data ) {
	$veiculo = sanitize_title( (string) ( $data['veiculo'] ?? '' ) );
	$ano     = (int) ( $data['ano'] ?? 0 );
	$uso     = sanitize_key( (string) ( $data['uso'] ?? 'diario' ) );
	$obs     = sanitize_text_field( (string) ( $data['observacao'] ?? '' ) );
	$obs     = function_exists( 'mb_substr' ) ? mb_substr( $obs, 0, 300 ) : substr( $obs, 0, 300 );

	$sintomas = array();
	$brutos   = $data['sintomas'] ?? array();
	if ( is_string( $brutos ) ) { $brutos = explode( '|', $brutos ); }
	if ( is_array( $brutos ) ) {
		foreach ( array_slice( $brutos, 0, 8 ) as $s ) {
			$s = sanitize_text_field( (string) $s );
			if ( '' !== $s ) { $sintomas[] = $s; }
		}
	}

	if ( ! $veiculo || $ano < 1950 || $ano > ( (int) gmdate( 'Y' ) + 2 ) ) {
		return array( 'error' => 'Escolha o veículo e o ano para fazer o diagnóstico.' );
	}

	$items = awr_vehicle_by_slug( $veiculo, $ano );
	if ( ! $items ) {
		return array( 'error' => 'Não encontramos esse veículo na nossa tabela. Fale com a equipe no WhatsApp que indicamos na hora.' );
	}

	$candidatos = awr_diag_candidatos( $items );
	if ( ! $candidatos ) {
		return array( 'error' => 'Não encontramos bateria homologada para esse veículo. Fale com a equipe no WhatsApp que indicamos na hora.' );
	}

	$laudo    = null;
	$resposta = wp_remote_post(
		awr_diag_endpoint(),
		array(
			'timeout' => 20,
			'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ),
			'body'    => wp_json_encode(
				array(
					'marca'      => $items[0]['ma'],
					'modelo'     => $items[0]['mo'],
					'ano'        => $ano,
					'sintomas'   => $sintomas,
					'uso'        => $uso,
					'observacao' => $obs,
				)
			),
		)
	);

	if ( ! is_wp_error( $resposta ) && 200 === (int) wp_remote_retrieve_response_code( $resposta ) ) {
		$json = json_decode( (string) wp_remote_retrieve_body( $resposta ), true );
		if ( is_array( $json ) && empty( $json['error'] ) && ! empty( $json['recomendadaSku'] ) ) {
			$laudo = $json;
		}
	}

	// Rede de segurança: o próprio tema monta o laudo se o motor de IA falhar.
	if ( null === $laudo ) {
		$laudo = awr_diag_laudo_local( $candidatos, $sintomas, $uso );
	}

	// Mostra TODAS as baterias compatíveis (igual à busca por veículo), com a
	// indicada pela IA em primeiro lugar e a econômica logo em seguida.
	$rec = strtoupper( trim( (string) ( $laudo['recomendadaSku'] ?? '' ) ) );
	$alt = strtoupper( trim( (string) ( $laudo['alternativaSku'] ?? '' ) ) );

	$lista = awr_skus_from_items( $items );
	usort(
		$lista,
		function ( $a, $b ) use ( $rec, $alt ) {
			$peso = function ( $x ) use ( $rec, $alt ) {
				$s = strtoupper( (string) $x['sku'] );
				if ( $rec && $s === $rec ) { return 0; }
				if ( $alt && $s === $alt ) { return 1; }
				return 2;
			};
			return $peso( $a ) <=> $peso( $b );
		}
	);

	$produtos = awr_products_by_skus( $lista );
	foreach ( $produtos as $i => $p ) {
		$s = strtoupper( (string) ( $p['sku'] ?? '' ) );
		if ( $rec && $s === $rec ) {
			$produtos[ $i ]['destaque'] = 'Recomendada pela IA';
		} elseif ( $alt && $s === $alt ) {
			$produtos[ $i ]['destaque'] = 'Melhor custo-benefício';
		}
	}

	$laudo['veiculo']  = $items[0]['ma'] . ' ' . $items[0]['mo'];
	$laudo['ano']      = $ano;
	$laudo['produtos'] = $produtos;



	return $laudo;
}


/** Intercepta /awr-busca/ antes de redirects, templates e cache HTML. */
add_action( 'template_redirect', function () {
	$path      = trim( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' );
	$home_path = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $home_path && 0 === strpos( $path, $home_path . '/' ) ) {
		$path = substr( $path, strlen( $home_path ) + 1 );
	}
	if ( 'awr-busca' !== $path ) { return; }

	$method = strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) );
	if ( 'POST' !== $method && 'GET' !== $method ) {
		wp_send_json_error( array( 'message' => 'Método não permitido.' ), 405 );
	}


	$payload = awr_search_api_payload();
	$action  = sanitize_key( (string) ( $payload['action'] ?? '' ) );
	header( 'X-Robots-Tag: noindex, nofollow', true );
	header( 'X-Content-Type-Options: nosniff', true );
	header( 'Cache-Control: no-store, max-age=0', true );

	if ( 'sugestoes' === $action ) {
		wp_send_json( awr_search_suggestions_response( $payload['q'] ?? '' ), 200 );
	}
	if ( 'produtos' === $action ) {
		wp_send_json( awr_search_products_response( $payload ), 200 );
	}
	if ( 'diagnostico' === $action ) {
		wp_send_json( awr_diagnostico_response( $payload ), 200 );
	}

	wp_send_json_error( array( 'message' => 'Ação de busca inválida.' ), 400 );
}, -100 );