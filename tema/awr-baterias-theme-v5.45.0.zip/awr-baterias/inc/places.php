<?php
/**
 * Google Places — paridade com src/lib/gmb.functions.ts e
 * src/routes/api/public/store-photo.$.ts do app.
 *
 * Resolve dados reais de cada loja (nota, endereço formatado, telefone,
 * horários, place_id e fotos) e serve as fotos por um proxy próprio, para
 * nunca expor a chave da API no HTML.
 *
 * Configuração: defina no wp-config.php
 *   define( 'AWR_GOOGLE_MAPS_KEY', 'sua-chave-com-places-api-new' );
 * ou salve em Ajustes → opção "awr_google_maps_key".
 *
 * Sem chave, todas as funções degradam para os dados locais de stores.json.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

const AWR_PLACES_TTL = 6 * HOUR_IN_SECONDS;

function awr_places_key() {
	if ( defined( 'AWR_GOOGLE_MAPS_KEY' ) && AWR_GOOGLE_MAPS_KEY ) { return (string) AWR_GOOGLE_MAPS_KEY; }
	$opt = get_option( 'awr_google_maps_key' );
	return $opt ? (string) $opt : '';
}

function awr_places_field_mask() {
	return 'places.id,places.displayName,places.formattedAddress,places.nationalPhoneNumber,'
		. 'places.rating,places.userRatingCount,places.googleMapsUri,places.photos,places.location,'
		. 'places.regularOpeningHours';
}

/**
 * Dados do Google para uma loja (com cache em transient de 6h).
 *
 * @param array $s Loja de stores.json.
 * @return array {rating,reviews,address,phone,maps_uri,place_id,photos[],hours[],open_now,source}
 */
function awr_place_data( $s ) {
	$fallback = array(
		'rating'    => null,
		'reviews'   => null,
		'address'   => $s['enderecoCompleto'] ?? '',
		'phone'     => $s['telefone'] ?? '',
		'maps_uri'  => $s['mapsUrl'] ?? '',
		'place_id'  => '',
		'photos'    => array(),
		'hours'     => array_values( array_filter( array( $s['horarios']['semana'] ?? '', $s['horarios']['sabado'] ?? '' ) ) ),
		'open_now'  => null,
		'lat'       => $s['geo']['lat'] ?? 0,
		'lng'       => $s['geo']['lng'] ?? 0,
		'source'    => 'local',
	);

	$key = awr_places_key();
	if ( ! $key ) { return $fallback; }

	$cache_key = 'awr_place_' . md5( $s['slug'] . '|' . AWR_VERSION );
	$cached    = get_transient( $cache_key );
	if ( is_array( $cached ) ) { return $cached; }

	$query = 'AWR Baterias ' . ( $s['nome'] ?? '' ) . ' ' . ( $s['endereco'] ?? '' ) . ' ' . ( $s['cidade'] ?? '' ) . ' RS';
	$res   = wp_remote_post( 'https://places.googleapis.com/v1/places:searchText', array(
		'timeout' => 3,

		'headers' => array(
			'Content-Type'     => 'application/json',
			'X-Goog-Api-Key'   => $key,
			'X-Goog-FieldMask' => awr_places_field_mask(),
		),
		'body'    => wp_json_encode( array(
			'textQuery'      => $query,
			'languageCode'   => 'pt-BR',
			'regionCode'     => 'BR',
			'maxResultCount' => 1,
			'locationBias'   => array(
				'circle' => array(
					'center' => array( 'latitude' => (float) $fallback['lat'], 'longitude' => (float) $fallback['lng'] ),
					'radius' => 2000.0,
				),
			),
		) ),
	) );

	if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		set_transient( $cache_key, $fallback, 15 * MINUTE_IN_SECONDS );
		return $fallback;
	}

	$body  = json_decode( wp_remote_retrieve_body( $res ), true );
	$place = $body['places'][0] ?? null;
	if ( ! $place ) {
		set_transient( $cache_key, $fallback, HOUR_IN_SECONDS );
		return $fallback;
	}

	$photos = array();
	foreach ( (array) ( $place['photos'] ?? array() ) as $p ) {
		if ( ! empty( $p['name'] ) ) { $photos[] = $p['name']; }
	}

	$data = array(
		'rating'   => isset( $place['rating'] ) ? (float) $place['rating'] : $fallback['rating'],
		'reviews'  => isset( $place['userRatingCount'] ) ? (int) $place['userRatingCount'] : $fallback['reviews'],
		'address'  => $place['formattedAddress'] ?? $fallback['address'],
		'phone'    => $place['nationalPhoneNumber'] ?? $fallback['phone'],
		'maps_uri' => $place['googleMapsUri'] ?? $fallback['maps_uri'],
		'place_id' => $place['id'] ?? '',
		'photos'   => array_slice( $photos, 0, 6 ),
		'hours'    => ! empty( $place['regularOpeningHours']['weekdayDescriptions'] )
			? array_values( (array) $place['regularOpeningHours']['weekdayDescriptions'] )
			: $fallback['hours'],
		'open_now' => isset( $place['regularOpeningHours']['openNow'] ) ? (bool) $place['regularOpeningHours']['openNow'] : null,
		'lat'      => isset( $place['location']['latitude'] ) ? (float) $place['location']['latitude'] : $fallback['lat'],
		'lng'      => isset( $place['location']['longitude'] ) ? (float) $place['location']['longitude'] : $fallback['lng'],
		'source'   => 'google',
	);

	set_transient( $cache_key, $data, AWR_PLACES_TTL );
	return $data;
}

/** URL da foto (proxy do tema). Vazio quando não houver foto do Google. */
function awr_place_photo_url( $photo_name, $w = 1200 ) {
	if ( ! $photo_name ) { return ''; }
	return add_query_arg(
		array( 'name' => rawurlencode( $photo_name ), 'w' => (int) $w ),
		rest_url( 'awr/v1/store-photo' )
	);
}

/** Origem do app (proxy público de fotos das lojas). */
function awr_app_origin() {
	if ( defined( 'AWR_APP_ORIGIN' ) && AWR_APP_ORIGIN ) { return untrailingslashit( (string) AWR_APP_ORIGIN ); }
	$opt = get_option( 'awr_app_origin' );
	return untrailingslashit( $opt ? (string) $opt : 'https://quick-battery-hero.lovable.app' );
}

/**
 * Capa da loja: foto do Google → mesma foto do app → foto local {slug}.jpg → cover.jpg.
 *
 * @param array $s Loja.
 * @param array $g Dados do Google (awr_place_data).
 * @param int   $w Largura desejada.
 */
function awr_store_cover( $s, $g = null, $w = 1200 ) {
	if ( is_array( $g ) && ! empty( $g['photos'][0] ) ) {
		return awr_place_photo_url( $g['photos'][0], $w );
	}

	$rel = 'assets/img/lojas/' . $s['slug'] . '.jpg';
	if ( file_exists( get_theme_file_path( $rel ) ) ) { return get_theme_file_uri( $rel ); }

	// Sem chave do Google no WordPress: usa o mesmo proxy de fotos do app.
	if ( ! empty( $s['slug'] ) ) {
		return awr_app_origin() . '/api/public/store-cover/' . rawurlencode( $s['slug'] ) . '?w=' . (int) $w;
	}

	return get_theme_file_uri( 'assets/img/lojas/cover.jpg' );
}


/** Embed do mapa com a localização exata (place_id quando disponível). */
function awr_store_map_embed( $s, $g = null ) {
	$key = awr_places_key();
	if ( $key && is_array( $g ) && ! empty( $g['place_id'] ) ) {
		return 'https://www.google.com/maps/embed/v1/place?key=' . rawurlencode( $key )
			. '&q=place_id:' . rawurlencode( $g['place_id'] ) . '&language=pt-BR&region=BR&zoom=17';
	}
	// Sem chave: consulta pelo endereço completo (pino no local certo, não em coordenadas aproximadas).
	$q = trim( ( $s['nome'] ? 'AWR Baterias ' . $s['nome'] . ' ' : '' ) . ( $s['enderecoCompleto'] ?? '' ) );
	if ( ! $q ) { return ''; }
	return 'https://maps.google.com/maps?q=' . rawurlencode( $q ) . '&z=17&hl=pt-BR&output=embed';
}

/** Link "Traçar rota" — usa o URI real do Google quando existir. */
function awr_store_maps_link( $s, $g = null ) {
	if ( is_array( $g ) && ! empty( $g['maps_uri'] ) ) { return $g['maps_uri']; }
	if ( ! empty( $s['enderecoCompleto'] ) ) {
		return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( 'AWR Baterias ' . $s['enderecoCompleto'] );
	}
	return $s['mapsUrl'] ?? '';
}

/** Proxy de imagem — nunca expõe a chave da API no HTML. */
add_action( 'rest_api_init', function () {
	register_rest_route( 'awr/v1', '/store-photo', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$name = (string) $req->get_param( 'name' );
			$w    = min( 1600, max( 200, (int) $req->get_param( 'w' ) ?: 1200 ) );
			$key  = awr_places_key();

			if ( ! $key || 0 !== strpos( $name, 'places/' ) || false === strpos( $name, '/photos/' ) ) {
				return new WP_REST_Response( array( 'error' => 'invalid_request' ), 400 );
			}

			$meta_key = 'awr_photo_' . md5( $name . '|' . $w );
			$uri      = get_transient( $meta_key );

			if ( ! $uri ) {
				$meta = wp_remote_get(
					'https://places.googleapis.com/v1/' . $name . '/media?maxWidthPx=' . $w . '&skipHttpRedirect=true',
					array( 'timeout' => 3, 'headers' => array( 'X-Goog-Api-Key' => $key ) )
				);
				if ( is_wp_error( $meta ) || 200 !== (int) wp_remote_retrieve_response_code( $meta ) ) {
					return new WP_REST_Response( array( 'error' => 'upstream_error' ), 502 );
				}
				$json = json_decode( wp_remote_retrieve_body( $meta ), true );
				$uri  = $json['photoUri'] ?? '';
				if ( ! $uri ) { return new WP_REST_Response( array( 'error' => 'no_photo_uri' ), 502 ); }
				set_transient( $meta_key, $uri, 7 * DAY_IN_SECONDS );
			}

			// Redireciona para a URL final do Google: o PHP não baixa nem repassa
			// bytes de imagem (era o maior consumo de CPU/processo por foto).
			header( 'Cache-Control: public, max-age=86400, s-maxage=604800' );
			wp_redirect( $uri, 302 ); // phpcs:ignore WordPress.Security.SafeRedirect
			exit;
		},
	) );
} );

/**
 * Ajustes → AWR Baterias: chave do Google Maps e origem do app (fotos das lojas).
 */
add_action( 'admin_menu', function () {
	add_options_page( 'AWR Baterias', 'AWR Baterias', 'manage_options', 'awr-baterias', function () {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		echo '<div class="wrap"><h1>AWR Baterias</h1><form method="post" action="options.php">';
		settings_fields( 'awr_baterias' );
		do_settings_sections( 'awr-baterias' );
		submit_button();
		echo '</form></div>';
	} );
} );

add_action( 'admin_init', function () {
	register_setting( 'awr_baterias', 'awr_google_maps_key', array( 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ) );
	register_setting( 'awr_baterias', 'awr_app_origin', array( 'sanitize_callback' => 'esc_url_raw', 'default' => '' ) );

	add_settings_section( 'awr_baterias_main', 'Integrações', function () {
		echo '<p>Sem a chave do Google, as fotos das lojas vêm do mesmo proxy usado pelo app.</p>';
	}, 'awr-baterias' );

	add_settings_field( 'awr_google_maps_key', 'Google Maps API Key', function () {
		printf(
			'<input type="text" class="regular-text" name="awr_google_maps_key" value="%s" autocomplete="off">',
			esc_attr( (string) get_option( 'awr_google_maps_key', '' ) )
		);
	}, 'awr-baterias', 'awr_baterias_main' );

	add_settings_field( 'awr_app_origin', 'Origem do app (fotos das lojas)', function () {
		printf(
			'<input type="url" class="regular-text" name="awr_app_origin" value="%s" placeholder="%s">',
			esc_attr( (string) get_option( 'awr_app_origin', '' ) ),
			esc_attr( awr_app_origin() )
		);
	}, 'awr-baterias', 'awr_baterias_main' );

	register_setting( 'awr_baterias', 'awr_canonical_domain', array( 'sanitize_callback' => 'esc_url_raw', 'default' => '' ) );
	register_setting( 'awr_baterias', 'awr_canonical_redirect', array( 'sanitize_callback' => 'absint', 'default' => 0 ) );

	add_settings_section( 'awr_baterias_seo', 'Consolidação de domínios (SEO)', function () {
		echo '<p>Para instalações satélite (domínios secundários com o mesmo tema): preencha o domínio principal para que canonical, og:url e sitemap apontem para ele, consolidando a indexação. No domínio principal, deixe em branco.</p>';
	}, 'awr-baterias' );

	add_settings_field( 'awr_canonical_domain', 'Domínio canônico principal', function () {
		printf(
			'<input type="url" class="regular-text" name="awr_canonical_domain" value="%s" placeholder="https://awrbaterias.com.br">',
			esc_attr( (string) get_option( 'awr_canonical_domain', '' ) )
		);
	}, 'awr-baterias', 'awr_baterias_seo' );

	add_settings_field( 'awr_canonical_redirect', 'Modo consolidação total', function () {
		printf(
			'<label><input type="checkbox" name="awr_canonical_redirect" value="1" %s> Redirecionar (301) todas as páginas para o domínio canônico</label>',
			checked( 1, (int) get_option( 'awr_canonical_redirect', 0 ), false )
		);
	}, 'awr-baterias', 'awr_baterias_seo' );
} );

/**
 * Link para o cliente avaliar a AWR no Google.
 *
 * Usa o place_id real quando a API do Google está configurada (abre direto o
 * formulário de nota); caso contrário cai no perfil da loja principal.
 */
function awr_google_review_url() {
	$stores = awr_stores();
	$s      = is_array( $stores ) && $stores ? reset( $stores ) : array();
	$place  = '';
	if ( $s && awr_places_key() ) {
		$g = awr_place_data( $s );
		if ( ! empty( $g['place_id'] ) ) { $place = $g['place_id']; }
	}
	if ( $place ) {
		return 'https://search.google.com/local/writereview?placeid=' . rawurlencode( $place );
	}
	return $s ? awr_store_maps_link( $s ) : 'https://www.google.com/maps/search/?api=1&query=AWR+Baterias';
}
