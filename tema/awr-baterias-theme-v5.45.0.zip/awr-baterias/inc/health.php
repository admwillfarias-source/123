<?php
/**
 * Diagnóstico do tema — detecta as causas mais comuns de "links não funcionam"
 * e de "layout diferente do app" (permalinks simples, cache antigo, Elementor
 * Theme Builder sobrescrevendo header/footer/home).
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Problemas detectados no ambiente atual. */
function awr_health_issues() {
	$issues = array();

	if ( ! get_option( 'permalink_structure' ) ) {
		$issues[] = sprintf(
			'Os <strong>links permanentes</strong> estão em "Simples". Todas as rotas do tema (/buscar/, /marca/…, /baterias-em/…) retornam 404 nesse modo. Vá em <a href="%s">Configurações → Links permanentes</a> e escolha <strong>Nome do post</strong>.',
			esc_url( admin_url( 'options-permalink.php' ) )
		);
	}

	static $rules = null;
	if ( null === $rules ) { $rules = get_option( 'rewrite_rules' ); }
	if ( is_array( $rules ) && ! isset( $rules['^buscar/?$'] ) ) {
		$issues[] = sprintf(
			'As regras de reescrita do tema não estão salvas. <a href="%s">Clique aqui para regravar</a>.',
			esc_url( wp_nonce_url( admin_url( '?awr_flush=1' ), 'awr_flush' ) )
		);
	}


	if ( did_action( 'elementor/loaded' ) && function_exists( 'get_page_on_front' ) ) {
		if ( 'page' === get_option( 'show_on_front' ) && get_option( 'page_on_front' ) ) {
			$issues[] = sprintf(
				'A home está definida como <strong>página estática</strong>. Para a home nativa do tema (idêntica ao app), vá em <a href="%s">Configurações → Leitura</a> e selecione <strong>Seus posts mais recentes</strong>.',
				esc_url( admin_url( 'options-reading.php' ) )
			);
		}
		$issues[] = 'Elementor detectado: em <strong>Templates → Theme Builder</strong>, desative/exclua os modelos de <em>Header</em>, <em>Footer</em> e <em>Single/Archive</em> que se aplicam ao site inteiro — eles substituem o layout do tema.';
	}

	return $issues;
}

/** Aviso no painel. */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$issues = awr_health_issues();
	if ( ! $issues ) { return; }
	echo '<div class="notice notice-warning"><p><strong>AWR Baterias — ajustes pendentes:</strong></p><ul style="list-style:disc;padding-left:20px">';
	foreach ( $issues as $i ) {
		echo '<li>' . wp_kses_post( $i ) . '</li>';
	}
	echo '</ul></div>';
} );

/**
 * Limpeza completa de cache do tema:
 * 1. Regrava as regras de reescrita (rotas /buscar/, /marca/…, /awr-font/…);
 * 2. Remove todos os transients awr_* (busca, produtos, places, sitemaps, consultas);
 * 3. Marca a versão de reescrita como atual (mantém as URLs imutáveis /awr-font/ ativas);
 * 4. Limpa o object cache, se houver.
 *
 * Cache de página de plugins (SpeedyCache, WP Rocket etc.) precisa ser limpo
 * no próprio plugin — a página AWR Validação SEO lembra disso.
 *
 * @return int Quantidade de transients removidos.
 */
function awr_full_cache_flush() {
	global $wpdb;

	flush_rewrite_rules( false );

	$deleted = (int) $wpdb->query(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_awr%' OR option_name LIKE '_transient_timeout_awr%'"
	);

	update_option( 'awr_rewrite_version', AWR_VERSION, false );

	if ( function_exists( 'wp_cache_flush' ) ) { wp_cache_flush(); }

	awr_purge_page_caches();

	return (int) floor( $deleted / 2 ); // cada transient grava 2 linhas (valor + timeout).
}

/**
 * Limpa o cache de página dos plugins mais comuns (quando instalados).
 * Cloudflare/edge continua exigindo purge no painel do provedor.
 */
function awr_purge_page_caches() {
	if ( class_exists( 'LiteSpeed\Purge' ) && method_exists( 'LiteSpeed\Purge', 'purge_all' ) ) {
		LiteSpeed\Purge::purge_all( 'awr-theme-update' );
	} elseif ( class_exists( 'LiteSpeed_Cache_API' ) && method_exists( 'LiteSpeed_Cache_API', 'purge_all' ) ) {
		LiteSpeed_Cache_API::purge_all();
	}
	if ( function_exists( 'rocket_clean_domain' ) ) { rocket_clean_domain(); }
	if ( function_exists( 'w3tc_flush_all' ) ) { w3tc_flush_all(); }
	if ( function_exists( 'wp_cache_clear_cache' ) ) { wp_cache_clear_cache(); } // WP Super Cache.
	if ( function_exists( 'wpfc_clear_all_cache' ) ) { wpfc_clear_all_cache( true ); } // WP Fastest Cache.
	if ( class_exists( 'SpeedyCache\Cache' ) && method_exists( 'SpeedyCache\Cache', 'delete_all' ) ) {
		SpeedyCache\Cache::delete_all();
	}
	if ( has_action( 'cachify_flush_cache' ) ) { do_action( 'cachify_flush_cache' ); }
	do_action( 'awr_page_cache_purged' );
}

/**
 * Ao subir uma nova versão do tema, limpa tudo automaticamente — evita que a
 * atualização fique invisível por causa de HTML antigo em cache.
 */
add_action( 'admin_init', function () {
	// v5.36.1 — era em `init`: a primeira visita de um cliente depois da
	// atualização pagava a regravação das rotas e a limpeza de todos os caches.
	if ( wp_doing_ajax() || ( defined( 'DOING_CRON' ) && DOING_CRON ) ) { return; }
	if ( get_option( 'awr_installed_version' ) === AWR_VERSION ) { return; }
	update_option( 'awr_installed_version', AWR_VERSION, false );
	awr_full_cache_flush();
}, 99 );

/** Regravação manual das rotas + limpeza completa de caches do tema. */
add_action( 'admin_init', function () {
	if ( empty( $_GET['awr_flush'] ) || ! current_user_can( 'manage_options' ) ) { return; } // phpcs:ignore
	check_admin_referer( 'awr_flush' );
	$n = awr_full_cache_flush();
	wp_safe_redirect( admin_url( 'options-general.php?page=awr-validacao&awr_flushed=' . $n ) );
	exit;
} );

/* ---------------------------------------------------------------------
   Chamadas antecipadas (wp_is_block_theme e afins)
   --------------------------------------------------------------------- */

/** Bloco no painel com as ocorrências capturadas por inc/debug-early.php. */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) || ! function_exists( 'awr_debug_early_entries' ) ) { return; }

	if ( ! awr_debug_early_on() ) {
		if ( ! isset( $_GET['awr_early'] ) ) { return; } // phpcs:ignore
		echo '<div class="notice notice-info"><p><strong>AWR — chamadas antecipadas:</strong> diagnóstico desligado. Adicione <code>define( \'AWR_DEBUG_EARLY\', true );</code> ao <code>wp-config.php</code>, abra uma página do site e volte aqui.</p></div>';
		return;
	}

	$entries = awr_debug_early_entries();
	if ( ! $entries ) {
		echo '<div class="notice notice-success"><p><strong>AWR — chamadas antecipadas:</strong> diagnóstico ativo e nenhuma ocorrência registrada até agora.</p></div>';
		return;
	}

	echo '<div class="notice notice-warning"><p><strong>AWR — chamadas antecipadas detectadas</strong> (log completo em <code>/wp-content/awr-early.log</code>):</p>';
	echo '<table class="widefat striped" style="max-width:960px"><thead><tr><th>Função</th><th>Origem</th><th>Arquivo</th><th>Ocorrências</th></tr></thead><tbody>';
	foreach ( $entries as $e ) {
		printf(
			'<tr><td><code>%s</code></td><td>%s <strong>%s</strong></td><td><code>%s</code></td><td>%d</td></tr>',
			esc_html( $e['funcao'] ),
			esc_html( $e['tipo'] ),
			esc_html( $e['nome'] ),
			esc_html( $e['arquivo'] ),
			(int) $e['vezes']
		);
	}
	echo '</tbody></table><p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( '?awr_early_clear=1' ), 'awr_early_clear' ) ) . '">Limpar registros</a></p></div>';
} );
