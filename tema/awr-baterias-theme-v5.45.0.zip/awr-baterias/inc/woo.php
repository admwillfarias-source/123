<?php
/**
 * Integração WooCommerce — preço, foto e criação de pedido.
 * No WordPress usamos as APIs nativas (sem proxy externo como no app).
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Memória do request compartilhada entre o lote e o produto individual. */
function &awr_prod_memo() {
	static $memo = array();
	return $memo;
}

/** Chave do pacote de uma lista de SKUs. */
function awr_prod_bundle_key( $list ) {
	sort( $list );
	return 'awr_prods_' . md5( AWR_VERSION . '|' . implode( ',', $list ) );
}

/**
 * Aquece, em UMA leitura de cache, tudo o que a página precisa para uma lista
 * de SKUs. Sem isso cada SKU custava ~10 consultas ao banco; com transient por
 * SKU ainda custava 2 linhas de options por bateria.
 *
 * @param array $skus Lista de SKUs (strings) ou de arrays com chave 'sku'.
 */
function awr_prime_products( $skus ) {
	global $wpdb;
	if ( ! function_exists( 'wc_get_product' ) ) { return; }

	$list = array();
	foreach ( (array) $skus as $entry ) {
		$s = strtoupper( trim( (string) ( is_array( $entry ) ? ( $entry['sku'] ?? '' ) : $entry ) ) );
		if ( '' !== $s ) { $list[ $s ] = true; }
	}
	$list = array_keys( $list );
	if ( ! $list ) { return; }

	$memo    = &awr_prod_memo();
	$pending = array();
	foreach ( $list as $s ) {
		if ( ! array_key_exists( $s, $memo ) ) { $pending[] = $s; }
	}
	if ( ! $pending ) { return; }

	// 1) Pacote único da lista (1 leitura de cache no lugar de N transients).
	$bundle_key = awr_prod_bundle_key( $pending );
	$bundle     = get_transient( $bundle_key );
	if ( is_array( $bundle ) ) {
		foreach ( $pending as $s ) {
			$memo[ $s ] = isset( $bundle[ $s ] ) && is_array( $bundle[ $s ] ) ? $bundle[ $s ] : null;
		}
		return;
	}

	// 2) IDs dos produtos numa única consulta por _sku.
	$ph  = implode( ',', array_fill( 0, count( $pending ), '%s' ) );
	$ids = $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_sku' AND meta_value IN ($ph)", $pending ) ); // phpcs:ignore WordPress.DB
	$ids = array_map( 'intval', (array) $ids );

	// 3) Posts, metadados e imagens em lote (inclui os permalinks/termos).
	if ( $ids ) {
		_prime_post_caches( $ids, true, true );
		$thumbs = array();
		foreach ( $ids as $id ) {
			$t = (int) get_post_thumbnail_id( $id );
			if ( $t ) { $thumbs[] = $t; }
		}
		if ( $thumbs ) { _prime_post_caches( array_unique( $thumbs ), false, true ); }
	}

	// 4) Monta o pacote uma vez e guarda tudo junto.
	$bundle  = array();
	$missing = false;
	foreach ( $pending as $s ) {
		$p          = awr_build_product( $s );
		$memo[ $s ] = $p;
		if ( is_array( $p ) ) {
			$bundle[ $s ] = $p;
		} else {
			$missing = true;
		}
	}
	// Resultado incompleto vive pouco: nunca prender "sob consulta" por 1 hora.
	set_transient( $bundle_key, $bundle, $missing ? 2 * MINUTE_IN_SECONDS : HOUR_IN_SECONDS );
}

/**
 * Localiza o ID do produto pelo SKU com planos de reserva.
 * Cobre lookup do Woo desatualizado, SKU com espaços/caixa diferente e variações.
 */
/**
 * v4.9.0 — Equivalência entre o código de fábrica da tabela de aplicação e o
 * código realmente cadastrado na loja. Conferido produto a produto: mesma
 * marca, mesma amperagem e mesma polaridade. Polaridade (D/E) nunca é trocada.
 * Espelha src/data/skuAliases.ts do app.
 */
function awr_sku_aliases() {
	return apply_filters(
		'awr_sku_aliases',
		array(
			// Heliar.
			// H95MD e H50JD existem na loja com o proprio codigo.
			'H60HD'     => 'HE60HD',
			'H75PE'     => 'H75LE',
			'H180TD'    => 'HS180TD-1',
			'H180TE'    => 'HS180TD-1-1',
			'HS180TE'   => 'HT180TE',
			'HR60DE'    => 'HE60DE',
			'HE45BE'    => 'H45JE',
			'HEFB225TD' => 'RT200TD',
			// Excell.
			'EXF150TD'  => 'EX150TD',
			'EXF180SE'  => 'EX180SE',
			'EXF180TD'  => 'EX180',
			'EXF180TE'  => 'EX180TE',
			// EXF95MD existe na loja (ID 90605) — sem desvio.
			// Moura.
			'M180TD'    => 'M180BD',
			'M180TE'    => 'M180BE',
			'MA8,6E'    => 'MA8,6EI',
			'MA8E'      => 'MA8EI',
			// Zetta.
			'Z100LE'    => 'Z100E',
		)
	);
}

/** Código cadastrado na loja para um código de fábrica. */
function awr_sku_alias( $sku ) {
	$key     = strtoupper( trim( (string) $sku ) );
	$aliases = awr_sku_aliases();
	return isset( $aliases[ $key ] ) ? $aliases[ $key ] : $key;
}

function awr_lookup_product_id( $sku ) {
	global $wpdb;
	$sku = trim( (string) $sku );
	if ( '' === $sku ) { return 0; }

	$alias = awr_sku_alias( $sku );
	if ( $alias !== strtoupper( $sku ) ) {
		$sku = $alias;
	}


	if ( function_exists( 'wc_get_product_id_by_sku' ) ) {
		$id = (int) wc_get_product_id_by_sku( $sku );
		if ( $id ) { return $id; }
		$id = (int) wc_get_product_id_by_sku( strtolower( $sku ) );
		if ( $id ) { return $id; }
	}

	// Reserva: postmeta direto, tolerante a espaços e caixa, incluindo variações.
	$id = (int) $wpdb->get_var( $wpdb->prepare( // phpcs:ignore WordPress.DB
		"SELECT pm.post_id FROM {$wpdb->postmeta} pm
		 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
		 WHERE pm.meta_key = '_sku' AND UPPER(TRIM(pm.meta_value)) = %s
		   AND p.post_type IN ('product','product_variation')
		   AND p.post_status IN ('publish','private')
		 ORDER BY ( p.post_type = 'product' ) DESC, p.ID ASC LIMIT 1",
		strtoupper( $sku )
	) );
	if ( ! $id ) { return 0; }

	// Variação: usa o produto pai quando ele existir.
	if ( 'product_variation' === get_post_type( $id ) ) {
		$parent = (int) wp_get_post_parent_id( $id );
		if ( $parent ) { return $parent; }
	}
	return $id;
}

/** Monta o array normalizado de um SKU, sem cache (uso interno). */
function awr_build_product( $sku ) {
	$sku = strtoupper( trim( (string) $sku ) );
	if ( '' === $sku || ! function_exists( 'wc_get_product' ) ) { return null; }

	$id = awr_lookup_product_id( $sku );
	if ( ! $id ) { return null; }


	$product = wc_get_product( $id );
	if ( ! $product ) { return null; }

	$image_id = $product->get_image_id();
	$img      = $image_id ? wp_get_attachment_image_src( $image_id, 'large' ) : null;
	$thumb    = $image_id ? wp_get_attachment_image_src( $image_id, 'woocommerce_thumbnail' ) : null;
	$price    = (float) $product->get_price();
	$ah       = awr_extract_amperage( $product->get_sku(), $product->get_name() );

	return array(
		'id'                => $id,
		'name'              => $product->get_name(),
		'sku'               => $product->get_sku() ? $product->get_sku() : $sku,
		'permalink'         => get_permalink( $id ),
		'price'             => $price,
		'price_html'        => $product->get_price_html(),
		'regular_price'     => (float) $product->get_regular_price(),
		'in_stock'          => $product->is_in_stock(),
		'image'             => $img ? $img[0] : '',
		'thumbnail'         => $thumb ? $thumb[0] : ( $img ? $img[0] : '' ),
		'short_description' => wp_strip_all_tags( $product->get_short_description() ),
		'description'       => wp_strip_all_tags( $product->get_description() ),
		'amperagem'         => $ah,
		'cca'               => function_exists( 'awr_cca' ) ? awr_cca( $product->get_sku() ? $product->get_sku() : $sku, $product->get_name() ) : 0,
		'desconto_casco'    => awr_desconto_casco( $ah ),
		'pix'               => round( $price * 0.95, 2 ),
		'parcela'           => $price > 0 ? round( $price / 10, 2 ) : 0,
	);
}


/** Produto por SKU, normalizado para o front (mesmo shape do app). */
function awr_product_by_sku( $sku ) {
	$sku = strtoupper( trim( (string) $sku ) );
	if ( '' === $sku || ! function_exists( 'wc_get_product' ) ) { return null; }

	$memo = &awr_prod_memo();
	if ( array_key_exists( $sku, $memo ) ) { return $memo[ $sku ]; }

	// Consulta avulsa: usa o mesmo pacote de cache de uma lista de 1 SKU.
	awr_prime_products( array( $sku ) );
	return array_key_exists( $sku, $memo ) ? $memo[ $sku ] : null;
}


/** SKU comercial válido para dados estruturados. */
function awr_schema_valid_sku( $sku ) {
	$sku = strtoupper( trim( (string) $sku ) );
	return '' !== $sku && (bool) preg_match( '/^[A-Z0-9][A-Z0-9._-]{1,99}$/', $sku );
}

/**
 * Resumo comercial curto do produto (usado no campo description do schema).
 * Nunca reproduz a lista de compatibilidades do fabricante.
 */
function awr_product_desc_resumo( $name, $brand = '', $ah = 0, $sku = '' ) {
	$name  = trim( wp_strip_all_tags( (string) $name ) );
	$brand = trim( (string) $brand );
	$ah    = (int) $ah;
	$sku   = strtoupper( trim( (string) $sku ) );

	$partes = array();
	if ( $ah ) { $partes[] = $ah . 'Ah'; }
	if ( $brand ) { $partes[] = 'marca ' . $brand; }
	if ( $sku ) { $partes[] = 'código ' . $sku; }
	$detalhe = $partes ? ' (' . implode( ', ', $partes ) . ')' : '';

	return $name . $detalhe . ': bateria nova, selada, com garantia de fábrica e nota fiscal. '
		. 'Entrega com instalação grátis em até 35 minutos em Porto Alegre e Região Metropolitana, '
		. 'pagamento na entrega no Pix, débito ou 10x sem juros. Demais cidades do RS por transportadora.';
}

/** Nome principal consistente para title, H1, descrição e FAQ. */
function awr_product_seo_name( $sku, $name = '', $brand = '', $ah = 0 ) {
	$sku   = strtoupper( trim( (string) $sku ) );
	$brand = trim( (string) $brand );
	$ah    = (int) $ah;
	if ( ! $brand ) { $brand = awr_resolve_brand( $sku, $name ); }
	return trim( 'Bateria ' . ( $brand ? $brand . ' ' : '' ) . ( $ah ? $ah . 'Ah ' : '' ) . $sku );
}

/**
 * Copy transacional de produto com dados reais. O ângulo Zetta usa a origem
 * Grupo Moura já cadastrada; prazo de garantia só entra quando o SKU está na tabela.
 */
function awr_product_seo_copy( $sku, $name = '', $brand = '', $ah = 0, $price = 0 ) {
	$produto  = awr_product_seo_name( $sku, $name, $brand, $ah );
	$brand_lc = strtolower( trim( (string) $brand ) );
	$garantia = function_exists( 'awr_garantia_meses' ) ? awr_garantia_meses( $sku, $name ) : null;
	$preco    = (float) $price > 0 ? awr_brl( (float) $price ) : '';

	if ( 'zetta' === $brand_lc ) {
		$title = "{$produto} | Preço e Instalação Grátis";
		$desc  = "Compre {$produto}" . ( $preco ? " por {$preco}" : '' ) . ' com custo-benefício do Grupo Moura, instalação grátis em até 35 min e ' . ( $garantia ? "{$garantia} meses de garantia" : 'garantia de fábrica' ) . '. Peça agora.';
	} elseif ( 'moura' === $brand_lc ) {
		$title = "{$produto} | Entrega e Instalação Grátis";
		$desc  = "Compre {$produto}" . ( $preco ? " por {$preco}" : '' ) . ': original, instalação grátis em até 35 min, nota fiscal e ' . ( $garantia ? "{$garantia} meses de garantia" : 'garantia de fábrica' ) . '. Peça agora no WhatsApp.';
	} elseif ( 'heliar' === $brand_lc ) {
		$title = "{$produto} | Preço e Instalação Grátis";
		$desc  = "Compre {$produto}" . ( $preco ? " por {$preco}" : '' ) . ' com instalação grátis em até 35 min, nota fiscal e ' . ( $garantia ? "{$garantia} meses de garantia" : 'garantia de fábrica' ) . '. Chame no WhatsApp e peça agora.';
	} else {
		$title = "{$produto} | Preço e Instalação Grátis";
		$desc  = "Compre {$produto}" . ( $preco ? " por {$preco}" : '' ) . ' com instalação grátis em até 35 min, nota fiscal e ' . ( $garantia ? "{$garantia} meses de garantia" : 'garantia de fábrica' ) . '. Peça agora pelo WhatsApp.';
	}

	return array( 'name' => $produto, 'title' => awr_seo_trim( $title, 60 ), 'desc' => awr_seo_trim( $desc, 155 ) );
}

/** Perguntas específicas do SKU, sem especificações ou compatibilidades inventadas. */
function awr_product_faq( $sku, $name = '', $brand = '', $ah = 0 ) {
	$produto  = awr_product_seo_name( $sku, $name, $brand, $ah );
	$garantia = function_exists( 'awr_garantia_meses' ) ? awr_garantia_meses( $sku, $name ) : null;
	$compat   = awr_product_compat_grouped( $sku );
	$modelos  = array();
	foreach ( $compat as $marca_veiculo => $lista ) {
		foreach ( $lista as $item ) {
			$modelos[] = trim( $marca_veiculo . ' ' . $item['modelo'] );
			if ( count( $modelos ) >= 4 ) { break 2; }
		}
	}
	$serve = $modelos
		? 'A ' . $produto . ' aparece no catálogo para versões de ' . implode( ', ', $modelos ) . '. Confirme o modelo e o ano na busca antes de comprar.'
		: 'A compatibilidade depende do modelo, versão e ano do veículo. Informe esses dados na busca ou no WhatsApp antes de comprar.';
	$garantia_txt = $garantia
		? "Este SKU tem {$garantia} meses de garantia de fábrica e acompanha nota fiscal."
		: 'Este produto acompanha nota fiscal e garantia de fábrica conforme as condições do fabricante.';
	return array(
		array( 'q' => "A {$produto} serve no meu carro?", 'r' => $serve ),
		array( 'q' => "Qual é a garantia da {$produto}?", 'r' => $garantia_txt ),
		array( 'q' => 'Como funciona a entrega e a instalação?', 'r' => 'Em Porto Alegre e nas cidades atendidas, a AWR entrega e instala no local. Para outras cidades do RS, o envio é feito por transportadora.' ),
	);
}

/** Publica o FAQPage correspondente ao bloco visível da página. */
function awr_product_faq_schema( $itens ) {
	$main = array();
	foreach ( (array) $itens as $item ) {
		$main[] = array( '@type' => 'Question', 'name' => $item['q'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $item['r'] ) );
	}
	if ( $main ) { awr_jsonld( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $main ) ); }
}

/**
 * Compatibilidades do SKU agrupadas por marca, com faixas de ano consolidadas por modelo.
 *
 * @param string $sku SKU comercial.
 * @return array marca => lista de array( modelo, de, ate, url ).
 */
function awr_product_compat_grouped( $sku ) {
	$sku = strtoupper( trim( (string) $sku ) );
	if ( '' === $sku || ! function_exists( 'awr_batteries' ) ) { return array(); }

	$grupos = array();
	foreach ( awr_batteries()['items'] as $it ) {
		$match = false;
		foreach ( AWR_BRAND_KEYS as $k => $b ) {
			if ( isset( $it[ $k ] ) && strtoupper( (string) $it[ $k ] ) === $sku ) { $match = true; break; }
		}
		if ( ! $match ) { continue; }

		$ma = trim( (string) ( $it['ma'] ?? '' ) );
		$mo = trim( (string) ( $it['mo'] ?? '' ) );
		if ( '' === $ma || '' === $mo ) { continue; }
		$de  = (int) ( $it['d'] ?? 0 );
		$ate = (int) ( $it['a'] ?? 0 );

		if ( ! isset( $grupos[ $ma ][ $mo ] ) ) {
			$grupos[ $ma ][ $mo ] = array(
				'modelo' => $mo,
				'de'     => $de,
				'ate'    => $ate,
				'url'    => function_exists( 'awr_vehicle_url' ) ? awr_vehicle_url( $ma, $mo, $ate ) : '',
			);
			continue;
		}
		$atual = $grupos[ $ma ][ $mo ];
		$grupos[ $ma ][ $mo ]['de']  = $de && $de < $atual['de'] ? $de : $atual['de'];
		$grupos[ $ma ][ $mo ]['ate'] = $ate > $atual['ate'] ? $ate : $atual['ate'];
	}

	ksort( $grupos, SORT_NATURAL | SORT_FLAG_CASE );
	foreach ( $grupos as $ma => $modelos ) {
		ksort( $modelos, SORT_NATURAL | SORT_FLAG_CASE );
		$grupos[ $ma ] = array_values( $modelos );
	}
	return $grupos;
}

/** Rótulo de anos: some quando a faixa cobre praticamente todos os anos. */
function awr_compat_anos( $de, $ate ) {
	$de  = (int) $de;
	$ate = (int) $ate;
	if ( ! $de || ! $ate ) { return ''; }
	if ( $de <= 1990 && $ate >= (int) gmdate( 'Y' ) ) { return 'todos os anos'; }
	if ( $de === $ate ) { return (string) $de; }
	return $de . '–' . $ate;
}

/**
 * Marcas de fabricante reconhecidas pelo tema (nunca a loja).
 * A loja aparece exclusivamente em offers.seller.
 */
function awr_marcas_fabricantes() {
	return apply_filters(
		'awr_marcas_fabricantes',
		array( 'Moura', 'Heliar', 'Zetta', 'Cral', 'Pioneiro', 'Tudor', 'Bosch', 'Duracell', 'ACDelco', 'Freedom', 'Route', 'Unipower', 'Baterisa', 'Motobatt', 'Eletran', 'Excell', 'Kondor', 'Bateria Fox', 'Yuasa', 'Varta', 'Cronos' )
	);
}

/**
 * v4.2.0 — Prefixos de SKU de fábrica → marca do fabricante.
 * Ordenado do mais específico para o mais genérico: a primeira correspondência vence.
 */
function awr_marca_prefixos_sku() {
	return apply_filters(
		'awr_marca_prefixos_sku',
		array(
			// Moura — automotiva, EFB/AGM, nobreak (12MN), clean/estacionária (12MF).
			'12MN'  => 'Moura',
			'12MF'  => 'Moura',
			'MAGM'  => 'Moura',
			'MEFB'  => 'Moura',
			'MA'    => 'Moura',
			// Heliar — SLI, EFB e AGM.
			'HAGM'  => 'Heliar',
			'HEFB'  => 'Heliar',
			'HGR'   => 'Heliar',
			'HS'    => 'Heliar',
			'HC'    => 'Heliar',
			// Freedom (Clarios) — linha DF estacionária/solar/nobreak.
			'DF'    => 'Freedom',
			// Motobatt — motocicletas.
			'MBTX'  => 'Motobatt',
			'MBTZ'  => 'Motobatt',
			'MBT'   => 'Motobatt',
			// Unipower — VRLA para alarme, CFTV e nobreak.
			'UP'    => 'Unipower',
			'UN'    => 'Unipower',
			// Route e Baterisa — motocicletas.
			'RTX'   => 'Route',
			'BTX'   => 'Baterisa',
			// Eletran.
			'ER'    => 'Eletran',
			// Zetta.
			'Z'     => 'Zetta',
		)
	);
}

/** Marca deduzida do prefixo de fábrica do SKU. */
function awr_marca_por_prefixo_sku( $sku ) {
	$sku = strtoupper( preg_replace( '/[^A-Z0-9]/', '', strtoupper( (string) $sku ) ) );
	if ( '' === $sku ) { return ''; }
	foreach ( awr_marca_prefixos_sku() as $prefixo => $marca ) {
		if ( 0 === strpos( $sku, $prefixo ) ) { return $marca; }
	}
	return '';
}

/**
 * v4.2.0 — Marca do fabricante (nunca a loja).
 * Ordem: índice de SKUs → tabela oficial de GTIN → taxonomia do Woo →
 * nome do produto → prefixo de fábrica do SKU.
 * Sem resultado devolve string vazia: melhor omitir do que declarar fabricante errado.
 */
function awr_resolve_brand( $sku, $name = '', $wc_product = null ) {
	$marca = function_exists( 'awr_brand_by_sku' ) ? trim( (string) awr_brand_by_sku( $sku ) ) : '';
	if ( $marca && 0 !== stripos( $marca, 'AWR' ) ) { return $marca; }

	if ( function_exists( 'awr_gtin_info' ) ) {
		$info = awr_gtin_info( $sku );
		if ( $info && ! empty( $info['marca'] ) ) {
			return ucfirst( strtolower( (string) $info['marca'] ) );
		}
	}

	if ( $wc_product && method_exists( $wc_product, 'get_id' ) ) {
		foreach ( array( 'product_brand', 'pwb-brand', 'pa_marca', 'yith_product_brand' ) as $tax ) {
			if ( ! taxonomy_exists( $tax ) ) { continue; }
			$terms = get_the_terms( $wc_product->get_id(), $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$t = trim( (string) $terms[0]->name );
				if ( $t && 0 !== stripos( $t, 'AWR' ) ) { return $t; }
			}
		}
	}

	$hay = ' ' . strtolower( (string) $name ) . ' ';
	foreach ( awr_marcas_fabricantes() as $c ) {
		if ( false !== strpos( $hay, ' ' . strtolower( $c ) . ' ' ) ) { return $c; }
	}

	// Último recurso legítimo: o prefixo de fábrica do próprio SKU.
	$pref = awr_marca_por_prefixo_sku( $sku );
	if ( $pref ) { return $pref; }

	return '';
}

/**
 * Schema Product completo, usado somente em páginas individuais.
 * Avaliações são lidas do próprio produto; a nota institucional não é copiada.
 */
function awr_product_schema( $p, $wc_product = null ) {
	$price = (float) ( $p['price'] ?? 0 );
	$sku   = strtoupper( trim( (string) ( $p['sku'] ?? '' ) ) );
	if ( $wc_product && method_exists( $wc_product, 'get_sku' ) && '' === trim( (string) $wc_product->get_sku() ) ) { return null; }
	if ( ! $price || ! awr_schema_valid_sku( $sku ) ) { return null; }

	$name  = trim( (string) ( $p['name'] ?? ( 'Bateria ' . $sku ) ) );
	$brand = trim( (string) ( $p['brand'] ?? '' ) );
	if ( '' === $brand ) { $brand = awr_resolve_brand( $sku, $name, $wc_product ); }
	// A rota pública por SKU é a fonte canônica; evita dividir sinais com o permalink nativo do Woo.
	$url   = home_url( '/bateria/' . strtolower( $sku ) . '/' );
	// v3.81.0 — resumo comercial curto no lugar do texto bruto do fabricante.
	$desc  = awr_product_desc_resumo( $name, $brand, (int) ( $p['amperagem'] ?? 0 ), $sku );

	$offer = array(
		'@type'         => 'Offer',
		'url'           => $url,
		'price'         => number_format( $price, 2, '.', '' ),
		'priceCurrency' => 'BRL',
		'itemCondition' => 'https://schema.org/NewCondition',
		'availability'  => ! isset( $p['in_stock'] ) || $p['in_stock'] ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
		'shippingDetails' => array(
			'@type'        => 'OfferShippingDetails',
			'shippingRate' => array( '@type' => 'MonetaryAmount', 'value' => '0.00', 'currency' => 'BRL' ),
			'shippingDestination' => array(
				'@type'           => 'DefinedRegion',
				'addressCountry'  => 'BR',
				'postalCodeRange' => array( '@type' => 'PostalCodeRangeSpecification', 'postalCodeBegin' => '90000-000', 'postalCodeEnd' => '91999-999' ),
			),
			'deliveryTime' => array(
				'@type'        => 'ShippingDeliveryTime',
				'handlingTime' => array( '@type' => 'QuantitativeValue', 'minValue' => 0, 'maxValue' => 1, 'unitCode' => 'DAY' ),
				'transitTime'  => array( '@type' => 'QuantitativeValue', 'minValue' => 0, 'maxValue' => 1, 'unitCode' => 'DAY' ),
			),
		),
		'hasMerchantReturnPolicy' => array(
			'@type'                => 'MerchantReturnPolicy',
			'applicableCountry'     => 'BR',
			'returnPolicyCategory'  => 'https://schema.org/MerchantReturnFiniteReturnWindow',
			'merchantReturnDays'    => 7,
			'returnMethod'          => 'https://schema.org/ReturnByMail',
		),
	);

	$schema = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'Product',
		'name'        => $name,
		'description' => $desc,
		'sku'         => $sku,
		'offers'      => $offer,
	);
	// MPN é diferente do SKU interno: só declarar quando o fabricante o cadastrou.
	if ( $wc_product && method_exists( $wc_product, 'get_meta' ) ) {
		$mpn = trim( (string) $wc_product->get_meta( '_mpn', true ) );
		if ( $mpn ) { $schema['mpn'] = $mpn; }
	}
	// v3.82.0 — marca é do fabricante; sem marca conhecida o campo é omitido.
	if ( $brand ) { $schema['brand'] = array( '@type' => 'Brand', 'name' => $brand ); }
	if ( function_exists( 'awr_cidades_produto' ) ) {
		$area = array();
		foreach ( awr_cidades_produto() as $c ) {
			$area[] = array( '@type' => 'City', 'name' => $c['nome'], 'address' => array( '@type' => 'PostalAddress', 'addressRegion' => 'RS', 'addressCountry' => 'BR' ) );
		}
		$area[] = array( '@type' => 'City', 'name' => 'Caxias do Sul', 'address' => array( '@type' => 'PostalAddress', 'addressRegion' => 'RS', 'addressCountry' => 'BR' ) );
		$schema['areaServed'] = $area;
	}
	if ( ! empty( $p['image'] ) ) { $schema['image'] = array( $p['image'] ); }

	if ( $wc_product && method_exists( $wc_product, 'get_review_count' ) ) {
		$count = (int) $wc_product->get_review_count();
		$avg   = (float) $wc_product->get_average_rating();
		if ( $count > 0 && $avg > 0 ) {
			$schema['aggregateRating'] = array( '@type' => 'AggregateRating', 'ratingValue' => $avg, 'reviewCount' => $count );
			$comments = get_comments( array( 'post_id' => $wc_product->get_id(), 'status' => 'approve', 'type' => 'review', 'number' => 5 ) );
			$reviews  = array();
			foreach ( $comments as $comment ) {
				$rating = (int) get_comment_meta( $comment->comment_ID, 'rating', true );
				if ( $rating < 1 ) { continue; }
				$reviews[] = array(
					'@type'        => 'Review',
					'author'       => array( '@type' => 'Person', 'name' => $comment->comment_author ),
					'datePublished'=> get_comment_date( 'c', $comment ),
					'reviewBody'   => wp_strip_all_tags( $comment->comment_content ),
					'reviewRating' => array( '@type' => 'Rating', 'ratingValue' => $rating, 'bestRating' => 5 ),
				);
			}
			if ( $reviews ) { $schema['review'] = $reviews; }
		}
	}
	/** Campos extras do Merchant Center (inc/merchant.php): url, GTIN, categoria, galeria. */
	return apply_filters( 'awr_product_schema', $schema, $p, $wc_product );
}

/** Impede que o schema padrão do Woo duplique o schema completo do tema. */
add_filter( 'woocommerce_structured_data_product', function ( $markup ) {
	return awr_seo_managed_context() || is_product() ? array() : $markup;
}, 99 );

/** Schema leve para vitrines/listagens, sem transformar cards em Product. */
function awr_product_item_list_schema( $produtos, $name = 'Baterias disponíveis' ) {
	$items = array();
	foreach ( array_values( (array) $produtos ) as $i => $p ) {
		$url = ! empty( $p['permalink'] ) ? $p['permalink'] : ( ! empty( $p['sku'] ) ? home_url( '/bateria/' . strtolower( $p['sku'] ) . '/' ) : '' );
		if ( ! $url ) { continue; }
		$items[] = array(
			'@type'    => 'ListItem',
			'position' => $i + 1,
			'name'     => (string) ( $p['name'] ?? $p['sku'] ?? '' ),
			'url'      => $url,
		);
	}
	if ( $items ) { awr_jsonld( array( '@context' => 'https://schema.org', '@type' => 'ItemList', 'name' => $name, 'itemListElement' => $items ) ); }
}

/** Lista de produtos a partir de uma lista de SKUs. */
function awr_products_by_skus( $skus ) {
	awr_prime_products( $skus );
	$out = array();
	foreach ( (array) $skus as $entry ) {
		$sku   = is_array( $entry ) ? $entry['sku'] : $entry;
		$brand = is_array( $entry ) && isset( $entry['brand'] ) ? $entry['brand'] : '';
		$p     = awr_product_by_sku( $sku );
		if ( $p ) {
			$p['brand']    = $brand;
			$p['garantia'] = awr_garantia_label( $p['sku'] ?? $sku, $p['name'] ?? '' );
			$p['casco']    = awr_valor_casco( $p['sku'] ?? $sku, $p['name'] ?? '' );
			$p['cca']      = awr_cca( $p['sku'] ?? $sku, $p['name'] ?? '' );
			$out[]         = $p;
		} else {
			$out[] = array(
				'sku'        => strtoupper( $sku ),
				'brand'      => $brand,
				'name'       => trim( $brand . ' ' . strtoupper( $sku ) ),
				'price'      => 0,
				'price_html' => '',
				'image'      => '',
				'permalink'  => '',
				'amperagem'  => awr_extract_amperage( $sku ),
				'cca'        => awr_cca( $sku, trim( $brand . ' ' . $sku ) ),
				'garantia'   => awr_garantia_label( $sku, trim( $brand . ' ' . $sku ) ),
				'casco'      => awr_valor_casco( $sku, trim( $brand . ' ' . $sku ) ),
				'sob_consulta' => true,
			);
		}
	}
	return $out;
}

/**
 * Cria um pedido WooCommerce (checkout rápido do app — desktop).
 * Retorna array com número do pedido.
 */
function awr_create_order( $payload ) {
	if ( ! function_exists( 'wc_create_order' ) ) {
		return new WP_Error( 'no_woo', 'WooCommerce não está ativo.', array( 'status' => 400 ) );
	}
	$sku        = strtoupper( sanitize_text_field( $payload['sku'] ?? '' ) );
	$product_id = (int) ( $payload['product_id'] ?? 0 );
	if ( $product_id && 'product' !== get_post_type( $product_id ) ) { $product_id = 0; }
	if ( '' === $sku && ! $product_id ) {
		return new WP_Error( 'no_sku', 'Produto obrigatório.', array( 'status' => 400 ) );
	}
	if ( ! $product_id ) { $product_id = awr_lookup_product_id( $sku ); }

	$order = wc_create_order();
	if ( $product_id ) {
		$order->add_product( wc_get_product( $product_id ), 1 );
	} else {
		// Sem produto cadastrado com esse SKU: cria item avulso para não travar o pedido.
		$item = new WC_Order_Item_Product();
		$item->set_name( sanitize_text_field( $payload['nome_produto'] ?? ( 'Bateria ' . $sku ) ) );
		$item->set_quantity( 1 );
		$valor = (float) ( $payload['preco'] ?? 0 );
		$item->set_subtotal( $valor );
		$item->set_total( $valor );
		$order->add_item( $item );
		$order->add_order_note( 'SKU ' . $sku . ' não encontrado no catálogo — item avulso.', false );
	}
	$taxa_entrega = (float) ( $payload['taxa_entrega'] ?? 0 );
	// Frete por CEP calculado no servidor (mesmo dia R$ 20 / transportadora R$ 50 ou R$ 75 > 20 kg).
	if ( function_exists( 'awr_frete_por_cep' ) && ! empty( $payload['cep'] ) ) {
		$peso_prod = $product_id ? (float) wc_get_product( $product_id )->get_weight() : 0;
		$fr = awr_frete_por_cep( $payload['cep'], $peso_prod );
		if ( in_array( $fr['tipo'], array( 'mesmo-dia', 'transportadora' ), true ) ) {
			$taxa_entrega = (float) $fr['valor'];
			$order->add_order_note( 'Frete por CEP: ' . $fr['prazo'] . ' — R$ ' . number_format( $taxa_entrega, 2, ',', '.' ), false );
		}
	}
	$fees = array(
		'Taxa de entrega'     => $taxa_entrega,
		'Casco (sem troca)'   => (float) ( $payload['casco'] ?? 0 ),
		'Acréscimo fora do RS' => (float) ( $payload['acrescimo_fora_rs'] ?? 0 ),
	);
	$desconto = (float) ( $payload['desconto_pct'] ?? 0 );
	if ( $desconto > 0 ) {
		$fees['Desconto à vista'] = -1 * round( (float) ( $payload['preco'] ?? 0 ) * ( $desconto / 100 ), 2 );
	}
	foreach ( $fees as $fee_name => $fee_total ) {
		if ( 0.0 === $fee_total ) { continue; }
		$fee = new WC_Order_Item_Fee();
		$fee->set_name( $fee_name );
		$fee->set_total( $fee_total );
		$order->add_item( $fee );
	}

	$order->set_address( array(
		'first_name' => sanitize_text_field( $payload['nome'] ?? '' ),
		'phone'      => sanitize_text_field( $payload['telefone'] ?? '' ),
		'email'      => sanitize_email( $payload['email'] ?? '' ),
		'address_1'  => sanitize_text_field( trim( ( $payload['endereco'] ?? '' ) . ', ' . ( $payload['numero'] ?? '' ) ) ),
		'address_2'  => sanitize_text_field( $payload['bairro'] ?? '' ),
		'city'       => sanitize_text_field( $payload['cidade'] ?? 'Porto Alegre' ),
		'postcode'   => sanitize_text_field( $payload['cep'] ?? '' ),
		'state'      => sanitize_text_field( $payload['uf'] ?? 'RS' ),
		'country'    => 'BR',
	), 'billing' );
	$order->set_payment_method_title( sanitize_text_field( $payload['pagamento'] ?? 'A combinar na entrega' ) );
	$order->update_meta_data( 'carro_ano', sanitize_text_field( $payload['carro_ano'] ?? '' ) );
	$order->update_meta_data( 'cpf_cnpj', sanitize_text_field( $payload['doc'] ?? '' ) );
	$order->update_meta_data( 'parcelas', (int) ( $payload['parcelas'] ?? 1 ) );
	$order->update_meta_data( 'tipo_entrega', sanitize_text_field( $payload['entrega_tipo'] ?? '' ) );
	$order->update_meta_data( 'itens_adicionais', sanitize_textarea_field( $payload['extras'] ?? '' ) );
	if ( ! empty( $payload['observacao'] ) ) {
		$order->add_order_note( sanitize_textarea_field( $payload['observacao'] ), false );
	}
	$order->add_order_note( 'Pedido criado pelo widget de busca AWR (' . ( $payload['origem'] ?? 'site' ) . ').', false );
	$order->calculate_totals();
	$order->update_status( 'processing', 'Pedido rápido AWR.' );

	return array(
		'ok'      => true,
		'pedido'  => $order->get_order_number(),
		'id'      => $order->get_id(),
		'total'   => (float) $order->get_total(),
		'redirect' => home_url( '/pedido-confirmado/?pedido=' . rawurlencode( $order->get_order_number() ) ),
	);
}

/* ======================================================================
   v3.5.0 — página de produto enxuta: só produto + descrição.
   ====================================================================== */
add_action( 'wp', function () {
	$is_produto = ( function_exists( 'is_product' ) && is_product() ) || 'sku' === awr_current_route();
	if ( ! $is_produto ) { return; }

	// Navegação anterior/próximo, produtos relacionados, upsells e abas extras.
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
	// Com ?review=1 (link enviado após a compra) a aba de avaliações volta,
	// para o cliente deixar a nota que alimenta as estrelas na busca do Google.
	$awr_pede_review = isset( $_GET['review'] ) && '1' === (string) wp_unslash( $_GET['review'] ); // phpcs:ignore WordPress.Security.NonceVerification
	add_filter( 'woocommerce_product_tabs', function ( $tabs ) use ( $awr_pede_review ) {
		unset( $tabs['additional_information'] );
		if ( ! $awr_pede_review ) { unset( $tabs['reviews'] ); }
		return $tabs;
	}, 98 );
	add_filter( 'next_post_link', '__return_empty_string' );
	add_filter( 'previous_post_link', '__return_empty_string' );
	add_filter( 'wp_link_pages', '__return_empty_string' );
	add_filter( 'navigation_markup_template', '__return_empty_string' );
}, 20 );

/* ======================================================================
   v3.5.2 — template nativo de produto: só produto + descrição.
   ====================================================================== */
add_filter( 'template_include', function ( $template ) {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) { return $template; }
	$file = AWR_DIR . '/routes/produto.php';
	return file_exists( $file ) ? $file : $template;
}, 98 );

/** Remove restos de paginação/navegação em qualquer página de produto. */
add_action( 'wp', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
	add_filter( 'the_posts_pagination', '__return_empty_string' );
	add_filter( 'the_post_navigation', '__return_empty_string' );
	add_filter( 'get_the_posts_pagination', '__return_empty_string' );
	add_filter( 'paginate_links', '__return_empty_array' );
}, 21 );

/* ---------------------------------------------------------------------
   Manutenção: limpeza dos pacotes de produto (transients awr_prods_*)
   --------------------------------------------------------------------- */

/** Apaga todos os pacotes de produto guardados em cache. */
function awr_flush_product_cache() {
	global $wpdb;
	$rows = $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_awr_prods_%' OR option_name LIKE '_transient_timeout_awr_prods_%'" ); // phpcs:ignore WordPress.DB
	if ( function_exists( 'wp_cache_flush_group' ) ) { wp_cache_flush_group( 'transient' ); }
	return (int) $rows;
}

// Administrador pode limpar na hora: /?awr_flush_produtos=1
add_action( 'template_redirect', function () {
	if ( empty( $_GET['awr_flush_produtos'] ) || ! current_user_can( 'manage_options' ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification
	$n = awr_flush_product_cache();
	wp_die( esc_html( 'Cache de produtos limpo (' . $n . ' registros).' ), 'AWR', array( 'response' => 200 ) );
}, 0 );

// Alteração de produto invalida os pacotes automaticamente.
add_action( 'woocommerce_update_product', 'awr_flush_product_cache' );
add_action( 'woocommerce_new_product', 'awr_flush_product_cache' );

/**
 * v3.81.0 — Descrição do fabricante formatada para leitura (especificações + aplicações).
 *
 * @param string $raw Texto bruto vindo do WooCommerce.
 * @return string HTML seguro.
 */
function awr_product_desc_html( $raw ) {
	$raw = str_ireplace( array( '<br>', '<br/>', '<br />', '</p>' ), "\n", (string) $raw );
	$raw = wp_strip_all_tags( $raw );
	$out = '';
	foreach ( preg_split( '/\R+/', $raw ) as $linha ) {
		$linha = trim( $linha );
		if ( '' === $linha ) { continue; }
		if ( substr_count( $linha, ' – ' ) >= 3 || substr_count( $linha, ' - ' ) >= 3 ) {
			$sep   = substr_count( $linha, ' – ' ) >= 3 ? ' – ' : ' - ';
			$itens = array_filter( array_map( 'trim', explode( $sep, $linha ) ) );
			$out  .= '<ul class="awr-prose__apps">';
			foreach ( $itens as $item ) { $out .= '<li>' . esc_html( $item ) . '</li>'; }
			$out  .= '</ul>';
			continue;
		}
		if ( preg_match( '/^([^:]{2,40}):\s*(.+)$/u', $linha, $m ) ) {
			$out .= '<p><strong>' . esc_html( $m[1] ) . ':</strong> ' . esc_html( $m[2] ) . '</p>';
			continue;
		}
		$out .= '<p>' . esc_html( $linha ) . '</p>';
	}
	return $out;
}

/**
 * v3.81.0 — Varredura do catálogo: produtos publicados sem categoria, SKU, preço ou imagem.
 *
 * @param bool $force Ignora o cache de 1 hora.
 * @return array array( 'total' => int, 'problemas' => array )
 */
function awr_catalogo_scan( $force = false ) {
	$cache = get_transient( 'awr_catalogo_scan' );
	if ( ! $force && is_array( $cache ) ) { return $cache; }
	if ( ! function_exists( 'wc_get_product' ) ) { return array( 'total' => 0, 'problemas' => array() ); }

	$ids = get_posts( array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => 1000,
		'fields'         => 'ids',
		'no_found_rows'  => true,
	) );

	$problemas = array();
	foreach ( $ids as $id ) {
		$wc = wc_get_product( $id );
		if ( ! $wc ) { continue; }
		$faltas = array();
		$terms  = get_the_terms( $id, 'product_cat' );
		if ( ! $terms || is_wp_error( $terms ) ) { $faltas[] = 'sem categoria'; }
		$sku = trim( (string) $wc->get_sku() );
		if ( '' === $sku || ! awr_schema_valid_sku( $sku ) ) { $faltas[] = 'sem SKU válido'; }
		if ( ! (float) $wc->get_price() ) { $faltas[] = 'sem preço'; }
		if ( ! get_post_thumbnail_id( $id ) ) { $faltas[] = 'sem imagem'; }
		$bloqueia = (bool) $faltas;
		// v3.82.0 — marca do fabricante e avaliação própria (estrelas no Google).
		if ( '' === awr_resolve_brand( $sku, get_the_title( $id ), $wc ) ) { $faltas[] = 'sem marca do fabricante'; }
		if ( (int) $wc->get_review_count() < 1 ) { $faltas[] = 'sem avaliação própria (sem estrelas)'; }
		if ( $faltas ) {
			if ( $bloqueia ) { $faltas[] = 'dados estruturados incompletos'; }
			$problemas[] = array(
				'id'     => (int) $id,
				'nome'   => get_the_title( $id ),
				'sku'    => $sku,
				'faltas' => $faltas,
				'url'    => get_permalink( $id ),
				'edit'   => get_edit_post_link( $id, '' ),
			);
		}
	}

	$out = array( 'total' => count( $ids ), 'problemas' => $problemas );
	set_transient( 'awr_catalogo_scan', $out, HOUR_IN_SECONDS );
	return $out;
}

/** Aviso no admin quando um produto é salvo/publicado sem categoria. */
add_action( 'admin_notices', function () {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'product' !== $screen->id || ! current_user_can( 'edit_products' ) ) { return; }
	$id = (int) get_the_ID();
	if ( ! $id ) { return; }
	$terms = get_the_terms( $id, 'product_cat' );
	if ( $terms && ! is_wp_error( $terms ) ) { return; }
	echo '<div class="notice notice-warning"><p><strong>Produto sem categoria.</strong> Escolha uma categoria antes de publicar: sem ela a trilha de navegação e os dados estruturados ficam incompletos no Google.</p></div>';
} );

/** O scan do catálogo é reprocessado quando um produto muda. */
add_action( 'save_post_product', function () { delete_transient( 'awr_catalogo_scan' ); } );

// v5.31.0 — pós-venda (avaliação + WhatsApp) na página de pedido recebido do WooCommerce.
add_action( 'woocommerce_thankyou', function () { if ( function_exists( 'awr_part' ) ) { awr_part( 'pos-venda' ); } }, 30 );
