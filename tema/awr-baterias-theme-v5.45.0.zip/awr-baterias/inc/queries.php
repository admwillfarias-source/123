<?php
/**
 * v3.24.0 — Redução de consultas ao banco no front-end.
 *
 * Cada item aqui corta consultas que o tema nunca usa (sessão/carrinho do
 * WooCommerce em páginas de conteúdo, heartbeat, oEmbed, action scheduler,
 * menus recalculados a cada request).
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Requisição que realmente precisa de carrinho/sessão do WooCommerce. */
function awr_needs_wc_session() {
	if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return true; }
	if ( is_user_logged_in() ) { return true; }
	if ( ! empty( $_POST ) ) { return true; } // phpcs:ignore WordPress.Security.NonceVerification
	foreach ( array_keys( $_COOKIE ) as $name ) {
		if ( 0 === strpos( $name, 'woocommerce_' ) || 0 === strpos( $name, 'wp_woocommerce_session' ) ) { return true; }
	}
	if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) { return true; }
	if ( function_exists( 'awr_current_route' ) && in_array( awr_current_route(), array( 'pedido', 'checkout' ), true ) ) { return true; }
	return false;
}

/**
 * Sem carrinho e sem sessão em páginas de conteúdo: o WooCommerce deixa de
 * criar/consultar a sessão do visitante (várias consultas por pageview).
 */
add_action( 'wp', function () {
	if ( ! function_exists( 'WC' ) || awr_needs_wc_session() ) { return; }

	// Fragmentos de carrinho fazem uma chamada AJAX (com queries) em toda visita.
	wp_dequeue_script( 'wc-cart-fragments' );
	add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

	// Geolocalização por IP dispara consultas/HTTP em cada request.
	add_filter( 'woocommerce_geolocation_update_database_periodically', '__return_false' );
	add_filter( 'pre_option_woocommerce_default_customer_address', function () { return 'base'; } );
}, 20 );

/** Heartbeat só no admin: evita polling com consultas no front. */
add_action( 'init', function () {
	if ( ! is_admin() ) { wp_deregister_script( 'heartbeat' ); }
}, 20 );

/** oEmbed do WP: rotas e script que o tema não usa. */
add_action( 'init', function () {
	remove_action( 'rest_api_init', 'wp_oembed_register_route' );
	add_filter( 'embed_oembed_discover', '__return_false' );
	remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );
}, 20 );

/**
 * Requisições internas do Woo/Google que precisam processar filas.
 *
 * Google for WooCommerce e Jetpack concluem autenticação e sincronização por
 * REST, AJAX, cron e callbacks no wp-admin. Bloquear o Action Scheduler nesses
 * contextos interrompe o assistente e ele volta para o início com “algo deu
 * errado”. A economia só é segura numa visita GET pública comum.
 */
function awr_allow_woocommerce_background_jobs() {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) { return true; }
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) { return true; }
	if ( defined( 'WP_CLI' ) && WP_CLI ) { return true; }
	if ( 'POST' === strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) ) { return true; }

	$uri = strtolower( (string) ( $_SERVER['REQUEST_URI'] ?? '' ) );
	foreach ( array( '/wp-json/', '/xmlrpc.php', 'wc-ajax=', 'google-listings', 'google/setup', 'jetpack' ) as $needle ) {
		if ( false !== strpos( $uri, $needle ) ) { return true; }
	}
	return false;
}

/** Action Scheduler não roda em pageviews públicos; integrações ficam intactas. */
add_filter( 'action_scheduler_allow_async_request_runner', function ( $allow ) {
	return awr_allow_woocommerce_background_jobs() ? $allow : false;
} );
add_filter( 'woocommerce_queue_flush_deferred_actions_on_shutdown', function ( $allow ) {
	return awr_allow_woocommerce_background_jobs() ? $allow : false;
} );

/**
 * Menus de navegação: HTML memorizado por localização/versão do tema.
 * Um menu médio custa de 10 a 30 consultas; aqui vira 1 leitura de cache.
 */
function awr_nav_menu_cache( $output, $args ) {
	if ( is_admin() || is_user_logged_in() || is_customize_preview() ) { return $output; }
	$loc = isset( $args->theme_location ) ? (string) $args->theme_location : '';
	if ( '' === $loc ) { return $output; }
	$key    = 'awr_menu_' . md5( AWR_VERSION . $loc . maybe_serialize( $args ) );
	$cached = get_transient( $key );
	if ( is_string( $cached ) && '' !== $cached ) { return $cached; }

	$clone       = clone $args;
	$clone->echo = false;
	remove_filter( 'pre_wp_nav_menu', 'awr_nav_menu_cache', 10 );
	$html = wp_nav_menu( (array) $clone );
	add_filter( 'pre_wp_nav_menu', 'awr_nav_menu_cache', 10, 2 );
	if ( is_string( $html ) && '' !== $html ) {
		set_transient( $key, $html, 12 * HOUR_IN_SECONDS );
		return $html;
	}
	return $output;
}
add_filter( 'pre_wp_nav_menu', 'awr_nav_menu_cache', 10, 2 );

/** Menu editado / tema atualizado limpa o cache de menus. */
add_action( 'wp_update_nav_menu', function () {
	global $wpdb;
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_awr_menu_%' OR option_name LIKE '_transient_timeout_awr_menu_%'" ); // phpcs:ignore
} );

/**
 * Consultas auxiliares do tema não precisam de cache de termos nem de
 * contagem total de linhas (SQL_CALC_FOUND_ROWS).
 */
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || $q->is_main_query() ) { return; }
	if ( ! $q->get( 'awr_needs_terms' ) ) { $q->set( 'update_post_term_cache', false ); }
	if ( ! $q->get( 'awr_needs_found_rows' ) ) { $q->set( 'no_found_rows', true ); }
} );

/**
 * Scripts/estilos de painel do WooCommerce que nenhuma tela do tema usa.
 * Cada um deles carrega settings via REST e consultas extras no front.
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( is_admin() || ! function_exists( 'awr_is_native_screen' ) || ! awr_is_native_screen() ) { return; }
	foreach ( array( 'wc-blocks-style', 'wc-blocks-vendors-style', 'wc-blocks-packages-style', 'wc-admin-app', 'wc-settings' ) as $h ) {
		wp_dequeue_style( $h );
		wp_deregister_style( $h );
	}
	foreach ( array( 'wc-admin-app', 'wc-blocks-registry', 'wc-blocks-middleware' ) as $h ) {
		wp_dequeue_script( $h );
	}
}, PHP_INT_MAX );

/** Preload de REST do editor de blocos não é usado no front. */
add_action( 'init', function () {
	if ( ! is_admin() ) { remove_action( 'wp_head', 'wp_preload_resources', 1 ); }
}, 20 );
