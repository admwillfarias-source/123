<?php
/**
 * Feed suplementar de inventário local (Google Merchant Center).
 *
 * O Merchant Center reclama "Você não tem dados de inventário dos produtos nas
 * suas lojas físicas" quando os complementos "Listagens locais gratuitas" e
 * "Anúncios de inventário local" estão ativos, mas nenhuma fonte de dados
 * informa store_code / item_id / quantity / availability por loja.
 *
 * Este arquivo publica duas fontes de dados, no formato TSV aceito pelo
 * Merchant Center como "feed suplementar":
 *
 *  /awr-inventario-local.tsv  — uma linha por produto × loja física ativa.
 *  /awr-exclusoes-locais.tsv  — produtos marcados como "não vendido em loja",
 *                               com excluded_destination preenchido
 *                               (free_local_listings, local_inventory_ads).
 *
 * Ajustes → AWR Inventário Local configura os códigos de loja (store_code),
 * quais unidades entram no feed e a quantidade padrão informada.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ---------------------------------------------------------------------
   1) Lojas físicas e códigos de loja
   --------------------------------------------------------------------- */

/** Código de loja padrão a partir do id da unidade (AWR-MEDIANEIRA). */
function awr_inv_store_code_padrao( $id ) {
	$c = strtoupper( remove_accents( (string) $id ) );
	$c = preg_replace( '/[^A-Z0-9]+/', '-', $c );
	return 'AWR-' . trim( (string) $c, '-' );
}

/** Mapa id da loja => array( code, ativo ). */
function awr_inv_config_lojas() {
	$salvo = (array) get_option( 'awr_inv_lojas', array() );
	$out   = array();
	foreach ( (array) awr_stores() as $s ) {
		$id = isset( $s['id'] ) ? (string) $s['id'] : '';
		if ( '' === $id ) { continue; }
		$cfg  = isset( $salvo[ $id ] ) && is_array( $salvo[ $id ] ) ? $salvo[ $id ] : array();
		$code = isset( $cfg['code'] ) ? trim( (string) $cfg['code'] ) : '';
		$out[ $id ] = array(
			'id'    => $id,
			'nome'  => isset( $s['nome'] ) ? (string) $s['nome'] : $id,
			'cidade'=> isset( $s['cidade'] ) ? (string) $s['cidade'] : '',
			'code'  => '' !== $code ? $code : awr_inv_store_code_padrao( $id ),
			'ativo' => ! isset( $cfg['ativo'] ) ? true : (bool) $cfg['ativo'],
		);
	}
	return $out;
}

/** Só as lojas marcadas para entrar no feed. */
function awr_inv_lojas_ativas() {
	return array_filter( awr_inv_config_lojas(), function ( $l ) { return ! empty( $l['ativo'] ); } );
}

/** Quantidade informada quando o produto não controla estoque. */
function awr_inv_quantidade_padrao() {
	$q = (int) get_option( 'awr_inv_quantidade', 5 );
	return $q > 0 ? $q : 5;
}

/** Produto marcado como "não vendido nas lojas físicas". */
function awr_inv_produto_excluido( $product_id ) {
	return 'sim' === get_post_meta( (int) $product_id, '_awr_sem_loja', true );
}

/** Formato do id usado no feed: gla (gla_209), sku (M60GD) ou id (209). */
function awr_inv_formato_id() {
	$f = (string) get_option( 'awr_inv_formato_id', 'gla' );
	return in_array( $f, array( 'gla', 'sku', 'id' ), true ) ? $f : 'gla';
}

/**
 * Id da oferta, no mesmo formato do feed principal.
 * O plugin Google for WooCommerce publica os produtos como gla_{ID}.
 */
function awr_inv_offer_id( $product_id, $sku ) {
	switch ( awr_inv_formato_id() ) {
		case 'sku':
			return (string) $sku;
		case 'id':
			return (string) (int) $product_id;
		default:
			return 'gla_' . (int) $product_id;
	}
}

/* ---------------------------------------------------------------------
   2) Linhas do feed
   --------------------------------------------------------------------- */

/** IDs de todos os produtos publicados e visíveis. */
function awr_inv_produto_ids() {
	$ids = get_posts( array(
		'post_type'        => 'product',
		'post_status'      => 'publish',
		'numberposts'      => -1,
		'fields'           => 'ids',
		'orderby'          => 'ID',
		'order'            => 'ASC',
		'suppress_filters' => true,
	) );
	return array_map( 'intval', (array) $ids );
}

/** Escapa um campo para TSV (o Merchant não aceita tab nem quebra de linha). */
function awr_inv_tsv( $v ) {
	$v = (string) $v;
	$v = str_replace( array( "\t", "\r", "\n" ), ' ', $v );
	return trim( preg_replace( '/\s+/', ' ', $v ) );
}

/** Cabeçalho + linhas do feed de inventário local. */
function awr_inv_feed_linhas() {
	$lojas = awr_inv_lojas_ativas();
	$linhas = array();
	if ( ! $lojas || ! function_exists( 'wc_get_product' ) ) { return $linhas; }

	$qpad = awr_inv_quantidade_padrao();

	foreach ( awr_inv_produto_ids() as $pid ) {
		if ( awr_inv_produto_excluido( $pid ) ) { continue; }
		$prod = wc_get_product( $pid );
		if ( ! $prod || ! $prod->is_purchasable() ) { continue; }

		$sku = trim( (string) $prod->get_sku() );
		$oferta = awr_inv_offer_id( $pid, $sku );
		if ( '' === $oferta ) { continue; }

		$preco = (float) wc_get_price_to_display( $prod );
		if ( $preco <= 0 ) { continue; }

		$em_estoque = $prod->is_in_stock();
		$qtd = $prod->managing_stock() ? max( 0, (int) $prod->get_stock_quantity() ) : ( $em_estoque ? $qpad : 0 );
		if ( ! $em_estoque ) { $qtd = 0; }

		foreach ( $lojas as $loja ) {
			// O Google pede somente id, store_code, availability e price.
			$linhas[] = array(
				'id'           => $oferta,
				'store_code'   => $loja['code'],
				'availability' => $qtd > 0 ? 'in_stock' : 'out_of_stock',
				'price'        => number_format( $preco, 2, '.', '' ) . ' BRL',
			);
		}
	}

	return $linhas;
}

/* ---------------------------------------------------------------------
   2b) Inventário regional (disponibilidade e preço por região)
   --------------------------------------------------------------------- */

/** IDs de região cadastrados em Merchant Center → Configurações → Regiões. */
function awr_inv_regioes() {
	$raw = (string) get_option( 'awr_inv_regioes', 'RS-METRO' );
	$out = array();
	foreach ( preg_split( '/[\s,;]+/', $raw ) as $r ) {
		$r = trim( (string) $r );
		if ( '' !== $r ) { $out[] = $r; }
	}
	return array_values( array_unique( $out ) );
}

/** Linhas do feed de inventário regional: id, region_id, availability, price. */
function awr_inv_regional_linhas() {
	$linhas  = array();
	$regioes = awr_inv_regioes();
	if ( ! $regioes || ! function_exists( 'wc_get_product' ) ) { return $linhas; }

	$qpad = awr_inv_quantidade_padrao();

	foreach ( awr_inv_produto_ids() as $pid ) {
		$prod = wc_get_product( $pid );
		if ( ! $prod || ! $prod->is_purchasable() ) { continue; }

		$sku    = trim( (string) $prod->get_sku() );
		$oferta = awr_inv_offer_id( $pid, $sku );
		if ( '' === $oferta ) { continue; }

		$preco = (float) wc_get_price_to_display( $prod );
		if ( $preco <= 0 ) { continue; }

		$em_estoque = $prod->is_in_stock();
		$qtd = $prod->managing_stock() ? max( 0, (int) $prod->get_stock_quantity() ) : ( $em_estoque ? $qpad : 0 );
		if ( ! $em_estoque ) { $qtd = 0; }

		foreach ( $regioes as $region_id ) {
			$linhas[] = array(
				'id'           => $oferta,
				'region_id'    => $region_id,
				'availability' => $qtd > 0 ? 'in_stock' : 'out_of_stock',
				'price'        => number_format( $preco, 2, '.', '' ) . ' BRL',
			);
		}
	}

	return $linhas;
}

/** Linhas do feed de exclusões (produtos que não existem em loja física). */
function awr_inv_exclusoes_linhas() {
	$linhas = array();
	if ( ! function_exists( 'wc_get_product' ) ) { return $linhas; }

	foreach ( awr_inv_produto_ids() as $pid ) {
		if ( ! awr_inv_produto_excluido( $pid ) ) { continue; }
		$prod = wc_get_product( $pid );
		if ( ! $prod ) { continue; }
		$sku = trim( (string) $prod->get_sku() );
		$oferta = awr_inv_offer_id( $pid, $sku );
		if ( '' === $oferta ) { continue; }
		$linhas[] = array(
			'id'                   => $oferta,
			'excluded_destination' => 'free_local_listings,local_inventory_ads',
		);
	}
	return $linhas;
}

/** Imprime um TSV a partir de uma lista de arrays associativos. */
function awr_inv_print_tsv( $linhas, $colunas ) {
	nocache_headers();
	header( 'Content-Type: text/tab-separated-values; charset=utf-8' );
	echo implode( "\t", $colunas ) . "\n";
	foreach ( $linhas as $l ) {
		$campos = array();
		foreach ( $colunas as $c ) { $campos[] = awr_inv_tsv( isset( $l[ $c ] ) ? $l[ $c ] : '' ); }
		echo implode( "\t", $campos ) . "\n";
	}
}

/* ---------------------------------------------------------------------
   3) Endpoints públicos
   --------------------------------------------------------------------- */

add_action( 'init', function () {
	add_rewrite_rule( '^awr-inventario-local\.tsv$', 'index.php?awr_inv_feed=inventario', 'top' );
	add_rewrite_rule( '^awr-inventario-regional\.tsv$', 'index.php?awr_inv_feed=regional', 'top' );
	add_rewrite_rule( '^awr-exclusoes-locais\.tsv$', 'index.php?awr_inv_feed=exclusoes', 'top' );
	add_rewrite_tag( '%awr_inv_feed%', '([a-z]+)' );
} );

add_filter( 'query_vars', function ( $v ) { $v[] = 'awr_inv_feed'; return $v; } );

// Funciona mesmo antes de os links permanentes serem regravados.
add_action( 'parse_request', function ( $wp ) {
	$path = trim( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' );
	if ( 'awr-inventario-local.tsv' === $path ) { $wp->query_vars['awr_inv_feed'] = 'inventario'; }
	if ( 'awr-inventario-regional.tsv' === $path ) { $wp->query_vars['awr_inv_feed'] = 'regional'; }
	if ( 'awr-exclusoes-locais.tsv' === $path ) { $wp->query_vars['awr_inv_feed'] = 'exclusoes'; }
}, 1 );

add_action( 'template_redirect', function () {
	$feed = get_query_var( 'awr_inv_feed' );
	if ( ! $feed ) { return; }

	if ( 'exclusoes' === $feed ) {
		awr_inv_print_tsv( awr_inv_exclusoes_linhas(), array( 'id', 'excluded_destination' ) );
		exit;
	}

	if ( 'regional' === $feed ) {
		awr_inv_print_tsv(
			awr_inv_regional_linhas(),
			array( 'id', 'region_id', 'availability', 'price' )
		);
		exit;
	}


	awr_inv_print_tsv(
		awr_inv_feed_linhas(),
		array( 'id', 'store_code', 'availability', 'price' )
	);
	exit;
}, 0 );

/* ---------------------------------------------------------------------
   4) Marcação por produto (não vendido em loja física)
   --------------------------------------------------------------------- */

add_action( 'woocommerce_product_options_inventory_product_data', function () {
	woocommerce_wp_checkbox( array(
		'id'          => '_awr_sem_loja',
		'label'       => 'Fora das lojas físicas',
		'description' => 'Excluir este produto das listagens locais gratuitas e dos anúncios de inventário local.',
		'value'       => awr_inv_produto_excluido( get_the_ID() ) ? 'sim' : 'nao',
		'cbvalue'     => 'sim',
	) );
} );

add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	$marcado = isset( $_POST['_awr_sem_loja'] ) ? 'sim' : 'nao'; // phpcs:ignore WordPress.Security.NonceVerification
	update_post_meta( $product->get_id(), '_awr_sem_loja', $marcado );
} );

/* ---------------------------------------------------------------------
   5) Tela Ajustes → AWR Inventário Local
   --------------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_options_page( 'AWR Inventário Local', 'AWR Inventário Local', 'manage_options', 'awr-inventario', 'awr_inventario_page' );
} );

function awr_inventario_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }

	if ( isset( $_POST['awr_inv_salvar'] ) && check_admin_referer( 'awr_inv' ) ) {
		$novo = array();
		foreach ( awr_inv_config_lojas() as $id => $loja ) {
			$code = isset( $_POST['code'][ $id ] ) ? sanitize_text_field( wp_unslash( $_POST['code'][ $id ] ) ) : '';
			$novo[ $id ] = array(
				'code'  => $code,
				'ativo' => ! empty( $_POST['ativo'][ $id ] ),
			);
		}
		update_option( 'awr_inv_lojas', $novo );
		update_option( 'awr_inv_quantidade', isset( $_POST['quantidade'] ) ? absint( wp_unslash( $_POST['quantidade'] ) ) : 5 );
		$fmt = isset( $_POST['formato_id'] ) ? sanitize_text_field( wp_unslash( $_POST['formato_id'] ) ) : 'gla';
		update_option( 'awr_inv_formato_id', in_array( $fmt, array( 'gla', 'sku', 'id' ), true ) ? $fmt : 'gla' );
		$regs = isset( $_POST['regioes'] ) ? sanitize_text_field( wp_unslash( $_POST['regioes'] ) ) : '';
		update_option( 'awr_inv_regioes', $regs );
		echo '<div class="notice notice-success"><p>Configuração salva.</p></div>';
	}

	$lojas  = awr_inv_config_lojas();
	$linhas = awr_inv_feed_linhas();
	$exclu  = awr_inv_exclusoes_linhas();
	$regio  = awr_inv_regional_linhas();


	echo '<div class="wrap"><h1>AWR Inventário Local</h1>';
	echo '<p>Este é o feed suplementar que o Google Merchant Center pede para liberar as listagens locais gratuitas e os anúncios de inventário local.</p>';

	echo '<h2>Endereços das fontes de dados</h2><table class="widefat striped"><tbody>';
	printf(
		'<tr><td><strong>Inventário local</strong><br><code>%s</code></td><td>%d linhas (%d produtos × %d lojas ativas)</td></tr>',
		esc_html( home_url( '/awr-inventario-local.tsv' ) ),
		count( $linhas ),
		count( awr_inv_lojas_ativas() ) ? (int) ( count( $linhas ) / max( 1, count( awr_inv_lojas_ativas() ) ) ) : 0,
		count( awr_inv_lojas_ativas() )
	);
	printf(
		'<tr><td><strong>Inventário regional</strong><br><code>%s</code></td><td>%d linhas (%d regiões: %s)</td></tr>',
		esc_html( home_url( '/awr-inventario-regional.tsv' ) ),
		count( $regio ),
		count( awr_inv_regioes() ),
		esc_html( implode( ', ', awr_inv_regioes() ) )
	);
	printf(
		'<tr><td><strong>Exclusões</strong><br><code>%s</code></td><td>%d produtos marcados como fora das lojas físicas</td></tr>',
		esc_html( home_url( '/awr-exclusoes-locais.tsv' ) ),
		count( $exclu )
	);
	echo '</tbody></table>';


	echo '<h2>Lojas e códigos</h2>';
	echo '<p>O mesmo código precisa estar preenchido no Perfil da Empresa (Google) de cada unidade, no campo "Código da loja".</p>';
	echo '<form method="post">';
	wp_nonce_field( 'awr_inv' );
	echo '<table class="widefat striped"><thead><tr><th>No feed</th><th>Loja</th><th>Cidade</th><th>Código da loja (store_code)</th></tr></thead><tbody>';
	foreach ( $lojas as $id => $l ) {
		printf(
			'<tr><td><input type="checkbox" name="ativo[%1$s]" value="1" %2$s></td><td><strong>%3$s</strong></td><td>%4$s</td><td><input type="text" class="regular-text" name="code[%1$s]" value="%5$s"></td></tr>',
			esc_attr( $id ),
			checked( true, (bool) $l['ativo'], false ),
			esc_html( $l['nome'] ),
			esc_html( $l['cidade'] ),
			esc_attr( $l['code'] )
		);
	}
	echo '</tbody></table>';
	foreach ( $lojas as $l ) {
		if ( preg_match( '/[^A-Z0-9_-]/', (string) $l['code'] ) ) {
			printf( '<p style="color:#b45309">⚠ O código <code>%s</code> (%s) tem espaço, minúscula ou acento. Funciona só se for idêntico no Perfil da Empresa; o mais seguro é usar só MAIÚSCULAS e hífen nos dois lugares.</p>', esc_html( $l['code'] ), esc_html( $l['nome'] ) );
		}
	}
	echo '<p><em>Se o Merchant aceitar só parte das lojas (ex.: 609 de 1218), as lojas que faltam não estão vinculadas a este Merchant Center: confira em Merchant → Configurações → Informações comerciais → Lojas / Perfil da Empresa.</em></p>';
	printf(
		'<p><label>Quantidade informada quando o produto não controla estoque: <input type="number" min="1" name="quantidade" value="%d" style="width:80px"></label></p>',
		awr_inv_quantidade_padrao()
	);

	$fmt = awr_inv_formato_id();
	echo '<h2>Formato do código do produto (id)</h2>';
	echo '<p>Precisa ser igual ao que aparece em Merchant Center → Produtos, no campo "ID". O plugin Google for WooCommerce usa <code>gla_209</code>.</p>';
	printf(
		'<p><label><input type="radio" name="formato_id" value="gla" %s> <code>gla_209</code> — padrão do Google for WooCommerce</label><br>'
		. '<label><input type="radio" name="formato_id" value="sku" %s> <code>M60GD</code> — código do produto (SKU)</label><br>'
		. '<label><input type="radio" name="formato_id" value="id" %s> <code>209</code> — número interno do WooCommerce</label></p>',
		checked( 'gla', $fmt, false ),
		checked( 'sku', $fmt, false ),
		checked( 'id', $fmt, false )
	);
	echo '<h2>Inventário regional (disponibilidade e preço por região)</h2>';
	echo '<p>Informe os IDs das regiões exatamente como foram criadas em <em>Merchant Center → Configurações → Regiões</em>. Separe por vírgula.</p>';
	printf(
		'<p><input type="text" class="regular-text" name="regioes" value="%s" placeholder="RS-METRO, RS-INTERIOR"></p>',
		esc_attr( (string) get_option( 'awr_inv_regioes', 'RS-METRO' ) )
	);

	submit_button( 'Salvar', 'primary', 'awr_inv_salvar' );
	echo '</form>';

	echo '<h2>Como cadastrar no Merchant Center</h2><ol>';
	echo '<li>No Perfil da Empresa do Google, preencha o "Código da loja" de cada unidade com o código da tabela acima — sem isso só aparece a loja já configurada.</li>';
	echo '<li>No Merchant Center, vincule o Perfil da Empresa em <em>Ferramentas → Lojas físicas</em>.</li>';
	echo '<li>Em <em>Fontes de dados → Adicionar fonte de dados suplementar</em>, escolha "Inventário de produtos locais", cole o endereço do inventário local e programe a atualização diária.</li>';
	echo '<li>Para o regional: crie as regiões em <em>Configurações → Regiões</em> (por CEP), depois adicione outra fonte suplementar do tipo "Disponibilidade e preço regionais" com o endereço do inventário regional.</li>';
	echo '<li>Se houver produtos que só existem para entrega, marque "Fora das lojas físicas" na aba Estoque do produto e cadastre também a fonte de exclusões.</li>';
	echo '</ol></div>';

}
