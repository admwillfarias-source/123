<?php
/**
 * Carregamento dos datasets exportados do app (assets/data/*.json).
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

function awr_data( $name ) {
	static $cache = array();
	if ( isset( $cache[ $name ] ) ) { return $cache[ $name ]; }

	// 1) Versão PHP pré-compilada (aproveita o OPcache: sem I/O nem json_decode).
	$php = AWR_DIR . '/assets/data-php/' . $name . '.php';
	if ( file_exists( $php ) ) {
		$data = include $php;
		if ( is_array( $data ) ) { $cache[ $name ] = $data; return $data; }
	}

	$ck  = 'data_' . $name . '_' . AWR_VERSION;
	$ext = function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache();
	if ( $ext ) {
		$hit = wp_cache_get( $ck, 'awr' );
		if ( is_array( $hit ) ) { $cache[ $name ] = $hit; return $hit; }
	}

	$file = AWR_DIR . '/assets/data/' . $name . '.json';
	if ( ! file_exists( $file ) ) { $cache[ $name ] = array(); return array(); }
	$raw  = file_get_contents( $file ); // phpcs:ignore
	$data = json_decode( $raw, true );
	if ( ! is_array( $data ) ) { $data = array(); }

	$cache[ $name ] = $data;
	if ( $ext ) { wp_cache_set( $ck, $data, 'awr', DAY_IN_SECONDS ); }
	return $data;
}

/**
 * Índice slug => item de uma lista, construído uma única vez por request.
 * Evita varrer arrays grandes (posts, cidades-venda, segmentos) a cada busca.
 */
function awr_index_by_slug( $list, $key = 'slug' ) {
	$idx = array();
	foreach ( (array) $list as $item ) {
		if ( is_array( $item ) && isset( $item[ $key ] ) ) { $idx[ (string) $item[ $key ] ] = $item; }
	}
	return $idx;
}


function awr_stores() { return awr_data( 'stores' ); }
function awr_cidades() { return awr_data( 'cidades' ); }
function awr_marcas() { return awr_data( 'marcas' ); }
function awr_aplicacoes() { return awr_data( 'aplicacoes' ); }
function awr_posts_data() {
	static $merged = null;
	if ( null !== $merged ) { return $merged; }
	$base = (array) awr_data( 'posts' );
	$wp   = function_exists( 'awr_ed_posts_publicados' ) ? awr_ed_posts_publicados() : array();
	$seen = array_column( $base, 'slug' );
	$wp   = array_values( array_filter( $wp, function ( $p ) use ( $seen ) { return ! in_array( $p['slug'], $seen, true ); } ) );
	$merged = array_merge( $wp, $base );
	return $merged;
}
/** Malha Blog ↔ Marcas ↔ Veículos (gerada de src/data/blogLinks.ts). */
function awr_blog_links() { $d = awr_data( 'blog-links' ); return is_array( $d ) ? $d : array(); }
/** Chips de guias do blog para uma lista de slugs. */
function awr_blog_chips_por( $chave, $slug ) {
	$d   = awr_blog_links();
	$out = array();
	foreach ( (array) ( $d[ $chave ][ $slug ] ?? array() ) as $ps ) {
		$p = awr_post_by_slug( $ps );
		if ( $p ) { $out[] = array( 'url' => home_url( '/blog/' . $p['slug'] . '/' ), 'label' => $p['h1'] ?? $p['titulo'] ); }
	}
	return $out;
}
/** Nome do veículo prioritário (veiculos-prioritarios.json). */
function awr_blog_veiculo_nome( $slug ) {
	foreach ( (array) awr_data( 'veiculos-prioritarios' ) as $v ) { if ( ( $v['slug'] ?? '' ) === $slug ) { return $v['nome']; } }
	return ucwords( str_replace( '-', ' ', $slug ) );
}
/** Bloco de chips de guias (independente de template-parts/links-internos). */
function awr_blog_guias_bloco( $titulo, $itens ) {
	if ( ! $itens ) { return; }
	echo '<section class="awr-block awr-links-internos"><h2 class="awr-section-title">' . esc_html( $titulo ) . '</h2><ul class="awr-chips">';
	foreach ( $itens as $it ) { echo '<li><a class="awr-chip" href="' . esc_url( $it['url'] ) . '">' . esc_html( $it['label'] ) . '</a></li>'; }
	echo '</ul></section>';
}
function awr_depoimentos() { return awr_data( 'depoimentos' ); }
function awr_google() { return awr_data( 'google-reviews' ); }
function awr_categorias() { return awr_data( 'categorias' ); }
function awr_ramos() { return awr_data( 'ramos' ); }
function awr_b2b() { return awr_data( 'b2b' ); }
function awr_bairros_data() { return awr_data( 'bairros' ); }
/** Zona de Porto Alegre ou Av. Protásio Alves (assets/data/zonas-poa.json). */
function awr_zona_poa( $slug ) {
	foreach ( (array) awr_data( 'zonas-poa' ) as $z ) { if ( isset( $z['slug'] ) && $z['slug'] === $slug ) { return $z; } }
	return null;
}
function awr_estacionaria() { return awr_data( 'estacionaria' ); }
function awr_categorias_seo() { return awr_data( 'categorias-seo' ); }
function awr_categoria_seo_by_slug( $slug ) { return awr_find_by_slug( awr_categorias_seo(), $slug ); }

/**
 * Loja da cidade da rota atual (cabeçalho local por cidade).
 * Só devolve loja quando a cidade tem unidade própria — do contrário null.
 */
function awr_local_store() {
	static $cache = null;
	if ( null !== $cache ) { return $cache ?: null; }
	$cache  = false;
	$route  = awr_current_route();
	$cidade = '';
	if ( in_array( $route, array( 'cidade', 'hub_bairros', 'bairro' ), true ) ) {
		$cidade = awr_param_a();
	} elseif ( 'marca_cidade' === $route || 'segmento_cidade' === $route || 'veiculo_cidade' === $route ) {
		$cidade = awr_param_b();
	}
	if ( ! $cidade ) { return null; }
	foreach ( awr_stores() as $s ) {
		if ( ! empty( $s['cidadeSlug'] ) && $s['cidadeSlug'] === $cidade ) { $cache = $s; break; }
	}
	return $cache ?: null;
}

/** Contato exibido na página: loja local quando houver, senão o contato geral. */
function awr_contact() {
	$c = awr_company();
	$s = awr_local_store();
	if ( $s ) {
		$c['phone']           = $s['telefone'];
		$c['phone_href']      = $s['telefoneHref'];
		$c['whatsapp']        = $s['whatsapp'];
		$c['whatsapp_number'] = $s['whatsappNumber'];
		$c['store_name']      = $s['nome'];
		$c['city']            = $s['cidade'];
	}
	return $c;
}

/** Bairros de uma cidade (lista de {slug,nome}). */
function awr_bairros_cidade( $cidade_slug ) {
	foreach ( awr_bairros_data() as $c ) {
		if ( isset( $c['cidadeSlug'] ) && $c['cidadeSlug'] === $cidade_slug ) { return (array) $c['bairros']; }
	}
	return array();
}

function awr_bairro_by_slug( $cidade_slug, $bairro_slug ) {
	return awr_find_by_slug( awr_bairros_cidade( $cidade_slug ), $bairro_slug );
}

/** Bairros vizinhos para links internos (exclui o atual). */
function awr_bairros_vizinhos( $cidade_slug, $bairro_slug, $limit = 12 ) {
	$list = array_values( awr_bairros_cidade( $cidade_slug ) );
	$i    = -1;
	foreach ( $list as $k => $b ) { if ( $b['slug'] === $bairro_slug ) { $i = $k; break; } }
	if ( $i < 0 ) { return array_slice( $list, 0, $limit ); }
	$rest = array_merge( array_slice( $list, $i + 1 ), array_slice( $list, 0, $i ) );
	return array_slice( $rest, 0, $limit );
}

/** Loja responsável pelo atendimento de um bairro/cidade. */
function awr_loja_do_bairro( $cidade_slug ) {
	$lojas = awr_stores_for_cidade( $cidade_slug );
	if ( $lojas ) { return $lojas[0]; }
	$all = awr_stores();
	return $all ? $all[0] : null;
}

function awr_batteries() {
	$d = awr_data( 'batteries' );
	return array(
		'brands' => isset( $d['brands'] ) ? $d['brands'] : array(),
		'items'  => isset( $d['items'] ) ? $d['items'] : array(),
	);
}

function awr_find_by_slug( $list, $slug, $key = 'slug' ) {
	$list = (array) $list;
	// Listas grandes usam índice memorizado (evita varredura linear repetida).
	if ( count( $list ) > 40 ) {
		static $idx_cache = array();
		$first = reset( $list );
		$last  = end( $list );
		$ck    = $key . '|' . count( $list ) . '|'
			. ( is_array( $first ) && isset( $first[ $key ] ) ? $first[ $key ] : '' ) . '|'
			. ( is_array( $last ) && isset( $last[ $key ] ) ? $last[ $key ] : '' );
		if ( ! isset( $idx_cache[ $ck ] ) ) { $idx_cache[ $ck ] = awr_index_by_slug( $list, $key ); }
		return isset( $idx_cache[ $ck ][ $slug ] ) ? $idx_cache[ $ck ][ $slug ] : null;
	}
	foreach ( $list as $item ) {
		if ( isset( $item[ $key ] ) && $item[ $key ] === $slug ) { return $item; }
	}
	return null;
}

function awr_store_by_slug( $slug ) { return awr_find_by_slug( awr_stores(), $slug ); }
function awr_cidade_by_slug( $slug ) { return awr_find_by_slug( awr_cidades(), $slug ); }

/**
 * Cidades de venda com envio por transportadora (fora da cobertura própria).
 * Estas páginas não têm link interno: são descobertas apenas pelo sitemap.
 */
function awr_cidades_venda() { return awr_data( 'cidades-venda' ); }
function awr_cidade_venda_by_slug( $slug ) { return awr_find_by_slug( awr_cidades_venda(), $slug ); }

/**
 * Cidades fora da cobertura própria que mesmo assim têm página marca×cidade
 * (demanda de busca e de anúncios dinâmicos; atendimento por envio).
 */
function awr_marca_cidades_envio() {
	return array( 'caxias-do-sul' );
}

function awr_marca_by_slug( $slug ) { return awr_find_by_slug( awr_marcas(), $slug ); }
function awr_aplicacao_by_slug( $slug ) { return awr_find_by_slug( awr_aplicacoes(), $slug ); }
function awr_ramo_by_slug( $slug ) { return awr_find_by_slug( awr_ramos(), $slug ); }
function awr_post_by_slug( $slug ) { return awr_find_by_slug( awr_posts_data(), $slug ); }

/** Lojas que atendem uma cidade (principal ou área de cobertura). */
function awr_stores_for_cidade( $cidade_slug ) {
	$out = array();
	foreach ( awr_stores() as $s ) {
		$atende = isset( $s['cidadesAtendidasSlugs'] ) && in_array( $cidade_slug, (array) $s['cidadesAtendidasSlugs'], true );
		if ( ( isset( $s['cidadeSlug'] ) && $s['cidadeSlug'] === $cidade_slug ) || $atende ) {
			$out[] = $s;
		}
	}
	return $out;
}

function awr_depoimentos_cidade( $slug ) {
	$d = awr_depoimentos();
	if ( isset( $d[ $slug ] ) ) { return $d[ $slug ]; }
	$all = array();
	foreach ( $d as $lista ) { foreach ( $lista as $item ) { $all[] = $item; } }
	return array_slice( $all, 0, 3 );
}

/* ------------------------------------------------------------------ */
/* Segmentos (categorias): estacionária, caminhão e moto              */
/* ------------------------------------------------------------------ */

function awr_segmentos_data() { return awr_data( 'segmentos' ); }

/** Lista de segmentos (categorias) na ordem do app. */
function awr_segmentos() {
	$d = awr_segmentos_data();
	return isset( $d['segmentos'] ) ? (array) $d['segmentos'] : array();
}

/**
 * Cidades atendidas. Sem segmento, devolve a lista global (cobertura + envio).
 * Com segmento, devolve apenas as cidades daquele segmento (estacionária vende
 * para fora do RS com envio; caminhão e moto usam só a cobertura própria).
 */
function awr_segmento_cidades( $seg = null ) {
	$d   = awr_segmentos_data();
	$all = isset( $d['cidades'] ) ? (array) $d['cidades'] : array();
	if ( ! $seg || empty( $seg['cidadesLista'] ) ) { return $all; }
	$out = array();
	foreach ( (array) $seg['cidadesLista'] as $c ) {
		$base = awr_find_by_slug( $all, $c['slug'] );
		$out[] = $base ? array_merge( (array) $base, (array) $c ) : (array) $c;
	}
	return $out;
}

/** Cidades de um segmento agrupadas por UF, na ordem em que aparecem. */
function awr_segmento_cidades_por_uf( $seg ) {
	$grupos = array();
	foreach ( awr_segmento_cidades( $seg ) as $c ) {
		$uf = isset( $c['estado'] ) ? (string) $c['estado'] : 'RS';
		if ( ! isset( $grupos[ $uf ] ) ) { $grupos[ $uf ] = array(); }
		$grupos[ $uf ][] = $c;
	}
	return $grupos;
}

/** Segmento pelo slug base da URL (ex.: "baterias-para-moto"). */
function awr_segmento_by_base( $base_slug ) {
	foreach ( awr_segmentos() as $s ) {
		if ( ltrim( (string) $s['base'], '/' ) === $base_slug ) { return $s; }
	}
	return null;
}

/** Cidade válida para o segmento informado (ou para qualquer segmento). */
function awr_segmento_cidade_by_slug( $slug, $seg = null ) {
	return awr_find_by_slug( awr_segmento_cidades( $seg ), $slug );
}


/** Conteúdo de um segmento em uma cidade (titulo, descricao, h1, intro, wa). */
function awr_segmento_conteudo_cidade( $seg, $cidade_slug ) {
	return isset( $seg['cidades'][ $cidade_slug ] ) ? (array) $seg['cidades'][ $cidade_slug ] : null;
}

/** URL do hub ou da cidade de um segmento. */
function awr_segmento_url( $seg, $cidade_slug = '' ) {
	$base = trim( (string) $seg['base'], '/' );
	return home_url( '/' . $base . '/' . ( $cidade_slug ? $cidade_slug . '/' : '' ) );
}

/** Regex com os slugs base dos segmentos (usado nas rewrites). */
function awr_segmentos_regex() {
	$bases = array();
	foreach ( awr_segmentos() as $s ) { $bases[] = preg_quote( trim( (string) $s['base'], '/' ), '#' ); }
	if ( ! $bases ) { $bases = array( 'baterias-estacionarias', 'baterias-para-caminhao', 'baterias-para-moto' ); }
	return implode( '|', $bases );
}

/** Landing pages de campanha (/lp/{slug}/) — espelha src/routes/lp.*.tsx. */
function awr_lps() {
	return array(
		'carro-nao-liga' => array(
			'kicker'     => 'ATENDIMENTO RÁPIDO EM PORTO ALEGRE',
			'h1'         => 'Carro não liga? Bateria nova em até 35 minutos',
			'sub'        => 'Vamos até você, testamos a bateria e instalamos uma nova no local. Sem guincho, sem dor de cabeça.',
			'wa'         => 'Olá! Meu carro não está ligando, preciso de uma bateria com urgência.',
			'cta_titulo' => 'Bateria arriada agora? Chame a AWR.',
			'beneficios' => array(
				array( 'Chegamos em 35 min', 'Porto Alegre e Grande Porto Alegre no horário comercial.' ),
				array( 'Instalação no local', 'Casa, trabalho ou rua, sem custo adicional.' ),
				array( 'Teste do alternador', 'Conferimos o sistema de carga antes de sair.' ),
				array( '10x sem juros', 'Pix com desconto, débito ou crédito na entrega.' ),
			),
		),
		'troca-no-local' => array(
			'kicker'     => 'TROCA DE BATERIA ONDE VOCÊ ESTIVER',
			'h1'         => 'Troca de bateria no local, com garantia de 24 meses',
			'sub'        => 'Você escolhe o modelo, a gente leva, instala e ainda dá desconto pela bateria velha.',
			'wa'         => 'Olá! Quero trocar a bateria do meu carro no local.',
			'cta_titulo' => 'Agende a troca agora mesmo',
			'beneficios' => array(
				array( 'Desconto no casco', 'Levamos a bateria velha e abatemos no preço.' ),
				array( 'Nota fiscal', 'Garantia de fábrica de 24 meses registrada.' ),
				array( 'Marcas líderes', 'Moura, Heliar, Zetta e Excell.' ),
				array( 'Sem agendamento longo', 'Atendimento no mesmo dia.' ),
			),
		),
		'bateria-moura' => array(
			'kicker'     => 'BATERIA MOURA COM ENTREGA E INSTALAÇÃO',
			'h1'         => 'Bateria Moura em Porto Alegre com instalação em 35 minutos',
			'sub'        => 'Linha completa Moura com nota fiscal, 24 meses de garantia e preço com desconto no Pix.',
			'wa'         => 'Olá! Quero o preço de uma bateria Moura para o meu carro.',
			'cta_titulo' => 'Peça a sua Moura hoje',
			'beneficios' => array(
				array( 'Moura original', 'Distribuição autorizada, com selo e nota fiscal.' ),
				array( 'Entrega em 35 min', 'Porto Alegre e Grande Porto Alegre.' ),
				array( 'Instalação inclusa', 'Técnico faz a troca e o teste no local.' ),
				array( '10x sem juros', 'Ou Pix com desconto na entrega.' ),
			),
		),
		'baterias-gravatai' => array(
			'kicker'     => 'BATERIA EM GRAVATAÍ COM ENTREGA NO LOCAL',
			'h1'         => 'Bateria em Gravataí com entrega e instalação em 35 minutos',
			'sub'        => 'Atendemos todos os bairros de Gravataí: você pede pelo WhatsApp ou pelo site, a gente leva a bateria nova, instala e testa o alternador no local.',
			'wa'         => 'Olá! Preciso de uma bateria em Gravataí com entrega no local.',
			'cta_titulo' => 'Bateria arriada em Gravataí? Chame a AWR.',
			'index'      => true,
			'beneficios' => array(
				array( 'Cobertura total em Gravataí', 'Centro, Parque dos Anjos, Barnabé, Morada do Vale e região.' ),
				array( 'Instalação grátis no local', 'Casa, trabalho ou na rua, sem custo adicional.' ),
				array( 'Moura, Heliar, Zetta e Excell', 'Linha completa com nota fiscal e 24 meses de garantia.' ),
				array( 'Pague na entrega', 'Pix com desconto, débito ou crédito em 10x sem juros.' ),
			),
		),
		'bateria-24h-porto-alegre' => array(
			'kicker'     => 'SOCORRO DE BATERIA EM PORTO ALEGRE',
			'h1'         => 'Socorro de bateria em Porto Alegre — troca no local em até 35 min',
			'sub'        => 'Plantão todos os dias das 06:30 às 22h. Enviamos um técnico com a bateria nova, fazemos o teste do sistema de carga e você paga só na entrega.',
			'wa'         => 'Olá! Preciso de socorro de bateria agora em Porto Alegre.',
			'cta_titulo' => 'Precisa agora? Fale com a AWR.',
			'index'      => false,
			'beneficios' => array(
				array( 'Plantão das 06:30 às 22h', 'Todos os dias, com chegada em até 35 minutos na capital.' ),
				array( 'Sem guincho', 'Resolvemos onde o carro estiver parado.' ),
				array( 'Teste do alternador', 'Conferimos o sistema de carga antes de sair.' ),
				array( 'Desconto pelo casco', 'Levamos a bateria velha e abatemos no preço.' ),
			),
		),
	);
}

/**
 * Cidades citadas no bloco "Onde entregamos e instalamos" das páginas de
 * produto. Espelha CIDADES_PRODUTO_35MIN do app.
 */
function awr_cidades_produto() {
	$slugs = array(
		'porto-alegre', 'canoas', 'gravatai', 'cachoeirinha', 'esteio',
		'sapucaia-do-sul', 'alvorada', 'viamao', 'campo-bom', 'novo-hamburgo',
		'sao-leopoldo', 'eldorado-do-sul', 'guaiba',
	);
	$out = array();
	foreach ( $slugs as $slug ) {
		$c     = awr_cidade_by_slug( $slug );
		$out[] = array( 'slug' => $slug, 'nome' => $c ? $c['nome'] : $slug );
	}
	return $out;
}
