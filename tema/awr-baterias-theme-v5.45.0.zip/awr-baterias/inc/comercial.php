<?php
/** Dados comerciais compartilhados e SKUs exatos WooCommerce. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function awr_garantia_estacionaria( $sku, $nome = '' ) {
 $dados = awr_data( 'comercial' );
 $linhas = $dados['garantiasEstacionarias'] ?? array();
 $codigo = strtoupper( preg_replace( '/\s+/', '', $sku ) );
 $texto = $sku . ' ' . $nome;
 $indice = null;
 if ( preg_match( '/^12MVA\d/', $codigo ) || preg_match( '/moura.*vrla|vrla.*moura/i', $texto ) ) { $indice = 2; }
 elseif ( preg_match( '/^DF\d/', $codigo ) || preg_match( '/\bfreedom\b/i', $texto ) ) { $indice = 0; }
 elseif ( preg_match( '/^12MN\d/', $codigo ) || preg_match( '/moura\s+nobreak/i', $texto ) ) { $indice = 1; }
 elseif ( preg_match( '/\bglobal\b/i', $texto ) ) { $indice = 3; }
 elseif ( preg_match( '/\bduran\b/i', $texto ) ) { $indice = 4; }
 return null !== $indice ? ( $linhas[ $indice ] ?? null ) : null;
}
function awr_mais_vendidos( $segmento ) {
 if ( ! function_exists( 'wc_get_product_id_by_sku' ) ) { return array(); }
 $dados = awr_data( 'comercial' );
 $ids = array();
 foreach ( $dados['maisVendidos'][ $segmento ] ?? array() as $sku ) {
  $id = wc_get_product_id_by_sku( $sku );
  $produto = $id ? wc_get_product( $id ) : null;
  if ( $produto && 'publish' === $produto->get_status() && strtoupper( $produto->get_sku() ) === $sku && $produto->is_visible() ) { $ids[] = $id; }
 }
 return awr_shop_hydrate( $ids );
}