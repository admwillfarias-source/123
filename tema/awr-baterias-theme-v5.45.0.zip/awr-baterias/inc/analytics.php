<?php
/**
 * GA4 / DebugView — helpers do modo debug e painel de verificação.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'AWR_GA4_ID', 'G-85HXPD5121' );
define( 'AWR_ADS_ID', 'AW-994517528' );

/**
 * Rótulos de conversão do Google Ads por tipo.
 *
 * Deixe vazio enquanto o rótulo não existir: o evento continua indo para o
 * GA4/GTM normalmente, só a conversão do Ads não dispara.
 * Filtro: add_filter( 'awr_ads_labels', ... ) para sobrescrever sem editar o tema.
 */
function awr_ads_labels_default() {
	return array(
		'whatsapp' => '4YHgCP_u2KkaEJjEnNoD', // ADS - Conversão WhatsApp
		'phone'    => 'LcD5CLmGte0cEJjEnNoD', // Clique no telefone - Site
		'busca'    => '4_QsCI6Mw-0cEJjEnNoD', // Buscar bateria - Site
		'pedido'   => 'A44FCN-_we0cEJjEnNoD', // Pedido concluído - Site
	);
}

function awr_ads_labels() {
	return apply_filters( 'awr_ads_labels', awr_ads_labels_default() );
}

/** Rótulo das conversões exibido no painel. */
function awr_conversion_map() {
	return array(
		'whatsapp' => array( 'Clique no WhatsApp', 'conversao_whatsapp, whatsapp_click, generate_lead' ),
		'phone'    => array( 'Ligação (tel:)', 'conversao_telefone, phone_click, generate_lead' ),
		'busca'    => array( 'Buscar Bateria', 'buscar_bateria, search' ),
		'pedido'   => array( 'Solicitar a Bateria', 'solicitar_bateria, generate_lead' ),
	);
}


/**
 * O modo debug do GA4 está ativo nesta requisição?
 *
 * Liga com ?awr_debug=1 (ou ?debug_mode=1 / ?gtm_debug=1), ou automaticamente
 * para administradores logados. Desliga com ?awr_debug=0.
 * Depois de ligado, um cookie de sessão mantém o modo enquanto o usuário navega.
 */
function awr_ga_debug_active() {
	static $cache = null;
	if ( null !== $cache ) { return $cache; }

	$param = null;
	foreach ( array( 'awr_debug', 'debug_mode', 'gtm_debug' ) as $key ) {
		if ( isset( $_GET[ $key ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$param = '1' === (string) sanitize_text_field( wp_unslash( $_GET[ $key ] ) ) || 'true' === (string) sanitize_text_field( wp_unslash( $_GET[ $key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			break;
		}
	}

	if ( true === $param ) {
		$cache = true;
	} elseif ( false === $param ) {
		$cache = false;
	} elseif ( ! empty( $_COOKIE['awr_ga_debug'] ) ) {
		$cache = true;
	} else {
		$cache = is_user_logged_in() && current_user_can( 'manage_options' );
	}

	// Persiste a escolha explícita para as próximas páginas (cookie de sessão).
	if ( null !== $param && ! headers_sent() ) {
		if ( $param ) {
			setcookie( 'awr_ga_debug', '1', 0, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), false );
		} else {
			setcookie( 'awr_ga_debug', '', time() - 3600, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), false );
		}
	}

	return $cache;
}

/** Expõe o flag e os rótulos de conversão para o JS do tema. */
add_action( 'wp_head', function () {
	printf(
		"<script>window.AWR_GA_DEBUG=%s;window.AWR_GA4_ID=%s;window.AWR_ADS=%s;</script>\n",
		awr_ga_debug_active() ? 'true' : 'false',
		wp_json_encode( AWR_GA4_ID ),
		wp_json_encode( array( 'id' => AWR_ADS_ID, 'labels' => awr_ads_labels() ) )
	);
}, 1 );


/* ---------------------------------------------------------------------
   Painel: Ajustes → AWR Analytics
   --------------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_options_page( 'AWR Analytics', 'AWR Analytics', 'manage_options', 'awr-analytics', 'awr_analytics_page' );
} );

/** Busca o HTML da home e procura IDs de medição carregados. */
function awr_analytics_scan_home() {
	$res = wp_remote_get( home_url( '/' ), array(
		'timeout'    => 12,
		'sslverify'  => false,
		'user-agent' => 'awr-analytics-check',
	) );
	if ( is_wp_error( $res ) ) {
		return array( 'erro' => $res->get_error_message(), 'ga4' => array(), 'gtm' => array(), 'ads' => array(), 'mc' => array(), 'consent' => 'desconhecido', 'labels' => null );
	}
	$html = (string) wp_remote_retrieve_body( $res );
	$find = function ( $regex ) use ( $html ) {
		preg_match_all( $regex, $html, $m );
		return array_values( array_unique( $m[1] ) );
	};

	// Consent Mode: procura o default mais próximo de analytics_storage.
	$consent = 'não declarado';
	if ( preg_match_all( "/analytics_storage['\"]?\s*:\s*['\"](granted|denied)['\"]/i", $html, $cm ) ) {
		$vals    = array_unique( array_map( 'strtolower', $cm[1] ) );
		$consent = in_array( 'denied', $vals, true ) ? ( count( $vals ) > 1 ? 'conflito (granted + denied)' : 'denied' ) : 'granted';
	}

	// Rótulos de conversão realmente entregues ao navegador na home.
	$labels_live = null;
	if ( preg_match( '/window\.AWR_ADS\s*=\s*(\{.*?\})\s*;/s', $html, $lm ) ) {
		$decoded = json_decode( $lm[1], true );
		if ( is_array( $decoded ) && isset( $decoded['labels'] ) && is_array( $decoded['labels'] ) ) {
			$labels_live = $decoded['labels'];
		}
	}

	return array(
		'erro'    => '',
		'ga4'     => $find( '/\b(G-[A-Z0-9]{6,12})\b/' ),
		'ads'     => $find( '/\b(AW-\d{6,12})\b/' ),
		'gtm'     => $find( '/\b(GTM-[A-Z0-9]{4,10})\b/' ),
		'mc'      => $find( '/\b(MC-[A-Z0-9]{6,12})\b/' ),
		'consent' => $consent,
		'labels'  => $labels_live,
	);
}

/** Página Ajustes → AWR Analytics. */
function awr_analytics_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$scan = isset( $_POST['awr_scan'] ) && check_admin_referer( 'awr_analytics' ) ? awr_analytics_scan_home() : null; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	$debug_url = add_query_arg( 'awr_debug', '1', home_url( '/' ) );
	$theme     = wp_get_theme( get_template() );
	$versao    = $theme ? (string) $theme->get( 'Version' ) : '';
	$defaults  = awr_ads_labels_default();
	$efetivos  = awr_ads_labels();
	$sobre     = array();
	foreach ( $defaults as $k => $v ) {
		if ( ! isset( $efetivos[ $k ] ) || $efetivos[ $k ] !== $v ) { $sobre[] = $k; }
	}
	?>
	<div class="wrap">
		<h1>AWR Analytics — GA4 &amp; DebugView</h1>

		<h2>Configuração ativa</h2>
		<table class="widefat striped" style="max-width:760px">
			<tbody>
				<tr><td>Versão do tema instalada</td><td><code><?php echo esc_html( $versao ? $versao : 'desconhecida' ); ?></code></td></tr>
				<tr><td>ID GA4 do tema</td><td><code><?php echo esc_html( AWR_GA4_ID ); ?></code></td></tr>
				<tr><td>Google Ads</td><td><code><?php echo esc_html( AWR_ADS_ID ); ?></code></td></tr>
				<tr><td>Modo debug para administradores</td><td>ativo (você vê seus próprios eventos no DebugView)</td></tr>
				<tr><td>Rótulos sobrescritos por outro código</td><td>
					<?php if ( $sobre ) : ?>
						<strong style="color:#d63638">sim — <?php echo esc_html( implode( ', ', $sobre ) ); ?>. Algum plugin, mu-plugin ou snippet usa <code>add_filter('awr_ads_labels', …)</code>; remova-o.</strong>
					<?php else : ?>
						não (os rótulos do tema estão valendo)
					<?php endif; ?>
				</td></tr>
			</tbody>
		</table>


		<h2>Conversões medidas (Analytics → GTM → Ads)</h2>
		<table class="widefat striped" style="max-width:900px">
			<thead><tr><th>Conversão</th><th>Eventos GA4 / dataLayer</th><th>Rótulo no Google Ads</th></tr></thead>
			<tbody>
			<?php $labels = awr_ads_labels(); foreach ( awr_conversion_map() as $tipo => $info ) : ?>
				<tr>
					<td><strong><?php echo esc_html( $info[0] ); ?></strong> <code><?php echo esc_html( $tipo ); ?></code></td>
					<td><code><?php echo esc_html( $info[1] ); ?></code></td>
					<td>
						<?php if ( ! empty( $labels[ $tipo ] ) ) : ?>
							<code><?php echo esc_html( AWR_ADS_ID . '/' . $labels[ $tipo ] ); ?></code>
						<?php else : ?>
							<span style="color:#d63638">pendente — cole o rótulo em <code>awr_ads_labels()</code></span>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p>
			<button class="button" onclick="['whatsapp','phone','busca','pedido'].forEach(function(t){window.awrConversion&&window.awrConversion(t,{source:'teste_admin'});});alert('Eventos de teste enviados. Confira no GA4 DebugView.');return false;">Disparar as 4 conversões de teste</button>
			<span class="description">Funciona nas páginas do site (o painel admin não carrega o gtag).</span>
		</p>



		<h2>Abrir o site em modo debug</h2>
		<p>
			<a class="button button-primary" href="<?php echo esc_url( $debug_url ); ?>" target="_blank" rel="noopener">Abrir home com ?awr_debug=1</a>
			<a class="button" href="https://analytics.google.com/analytics/web/#/debugview" target="_blank" rel="noopener">Abrir GA4 → DebugView</a>
		</p>
		<p class="description">Para desligar em um navegador, abra o site com <code>?awr_debug=0</code>.</p>

		<h2>Conferir IDs carregados (evitar duplicidade)</h2>
		<form method="post">
			<?php wp_nonce_field( 'awr_analytics' ); ?>
			<p><button class="button" name="awr_scan" value="1">Analisar HTML da home</button></p>
		</form>
		<?php if ( $scan ) : ?>
			<?php if ( $scan['erro'] ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $scan['erro'] ); ?></p></div>
			<?php else : ?>
				<table class="widefat striped" style="max-width:760px">
					<tbody>
						<tr><td>GA4 encontrados</td><td><code><?php echo esc_html( $scan['ga4'] ? implode( ', ', $scan['ga4'] ) : 'nenhum' ); ?></code>
							<?php if ( count( $scan['ga4'] ) > 1 ) : ?><strong style="color:#d63638"> — há mais de um ID GA4; remova o extra (plugin/GTM). Oficial: <?php echo esc_html( AWR_GA4_ID ); ?></strong><?php endif; ?></td></tr>
						<tr><td>Google Ads</td><td><code><?php echo esc_html( $scan['ads'] ? implode( ', ', $scan['ads'] ) : 'nenhum' ); ?></code></td></tr>
						<tr><td>GTM</td><td><code><?php echo esc_html( $scan['gtm'] ? implode( ', ', $scan['gtm'] ) : 'nenhum' ); ?></code></td></tr>
						<tr><td>Outros (MC-)</td><td><code><?php echo esc_html( $scan['mc'] ? implode( ', ', $scan['mc'] ) : 'nenhum' ); ?></code></td></tr>
						<tr><td>Consent Mode (<code>analytics_storage</code>)</td><td>
							<code><?php echo esc_html( $scan['consent'] ); ?></code>
							<?php if ( 'granted' !== $scan['consent'] ) : ?>
								<strong style="color:#d63638"> — com <code>denied</code> o GA4 não registra sessões. Ajuste ou desative o plugin de cookies/consentimento.</strong>
							<?php endif; ?>
						</td></tr>
						<tr><td>Rótulos de conversão entregues na home</td><td>
							<?php if ( ! is_array( $scan['labels'] ) ) : ?>
								<span style="color:#d63638">não encontrados no HTML — a home pode estar servindo uma versão antiga em cache.</span>
							<?php else : $vazios = array(); $difs = array(); foreach ( $defaults as $k => $v ) {
								$live = isset( $scan['labels'][ $k ] ) ? (string) $scan['labels'][ $k ] : '';
								if ( '' === $live ) { $vazios[] = $k; } elseif ( $live !== $v ) { $difs[] = $k; }
							} ?>
								<code><?php echo esc_html( wp_json_encode( $scan['labels'] ) ); ?></code>
								<?php if ( $vazios || $difs ) : ?>
									<strong style="color:#d63638"> — o site publicado está diferente deste tema<?php echo $vazios ? esc_html( ' (vazios: ' . implode( ', ', $vazios ) . ')' ) : ''; ?><?php echo $difs ? esc_html( ' (divergentes: ' . implode( ', ', $difs ) . ')' ) : ''; ?>. Reinstale o tema e limpe os caches de página, de opcode e da Cloudflare.</strong>
								<?php else : ?>
									<strong style="color:#00a32a"> — iguais aos do tema.</strong>
								<?php endif; ?>
							<?php endif; ?>
						</td></tr>
					</tbody>
				</table>


			<?php endif; ?>
		<?php endif; ?>

		<h2>Checklist de validação</h2>
		<ol>
			<li>Limpe o cache do plugin de performance e da CDN após publicar.</li>
			<li>Abra a home com <code>?awr_debug=1</code> em uma aba anônima.</li>
			<li>No GA4 → Admin → DebugView, confirme o <code>page_view</code>.</li>
			<li>Clique em um botão de WhatsApp: devem aparecer <code>whatsapp_click</code>, <code>conversao_whatsapp</code> e <code>generate_lead</code>.</li>
			<li>Clique em um telefone: <code>phone_click</code>, <code>conversao_telefone</code> e <code>generate_lead</code>.</li>
			<li>Envie um formulário: <code>form_submit</code> e <code>generate_lead</code>.</li>
			<li>Faça uma busca por veículo: <code>buscar_bateria</code>.</li>
			<li>Abra o checkout e finalize: <code>solicitar_bateria</code> (com <code>step</code> = intencao/concluido).</li>
			<li>Em GA4 → Admin → Eventos, marque <code>generate_lead</code>, <code>buscar_bateria</code> e <code>solicitar_bateria</code> como eventos-chave.</li>
			<li>No GTM, crie um acionador de <em>Evento personalizado</em> por nome para cada conversão e importe-as no Google Ads.</li>
		</ol>

	</div>
	<?php
}
