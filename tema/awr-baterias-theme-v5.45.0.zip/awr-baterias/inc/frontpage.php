<?php
/**
 * Home nativa do tema — garante que "/" use front-page.php do AWR,
 * sem iframe, sem página estática do construtor e sem Elementor Theme Builder.
 *
 * Para desligar (voltar a usar a home do construtor):
 *   add_filter( 'awr_force_front_page', '__return_false' );
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Deve o tema assumir o controle da home? */
function awr_should_force_front_page() {
	if ( is_admin() || wp_doing_ajax() ) { return false; }
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) { return false; }
	if ( ! is_front_page() ) { return false; }
	// Alguns construtores marcam a página estática como front page mesmo em
	// URLs virtuais. O takeover só pode acontecer no caminho raiz real.
	$request_path = untrailingslashit( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ), PHP_URL_PATH ) );
	$home_path    = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
	if ( $request_path !== $home_path ) { return false; }
	if ( is_feed() || is_robots() || is_trackback() ) { return false; }

	// Nunca interferir no editor/preview do Elementor.
	if ( isset( $_GET['elementor-preview'] ) ) { return false; } // phpcs:ignore WordPress.Security.NonceVerification
	if ( isset( $_GET['preview'] ) || isset( $_GET['customize_changeset_uuid'] ) ) { return false; } // phpcs:ignore WordPress.Security.NonceVerification
	if ( function_exists( 'elementor_is_edit_mode' ) && elementor_is_edit_mode() ) { return false; }
	if ( is_customize_preview() ) { return false; }

	return (bool) apply_filters( 'awr_force_front_page', true );
}

/** Registro interno do que foi bloqueado (usado pelo ?awr_debug_home=1). */
function awr_home_debug( $msg = null ) {
	static $log = array();
	if ( null !== $msg ) { $log[] = $msg; }
	return $log;
}

/**
 * Neutraliza construtores na home, o mais cedo possível.
 */
add_action( 'template_redirect', function () {
	if ( ! awr_should_force_front_page() ) { return; }

	awr_home_debug( 'takeover ativo' );

	// 1) Elementor Pro Theme Builder: nenhuma "location" na home (single/archive/header/footer).
	add_filter( 'elementor/theme/need_override_location', '__return_false', 99 );
	add_filter( 'elementor/theme/get_location_templates/template_id', '__return_false', 99 );
	add_filter( 'elementor/theme/before_do_single', function () {
		awr_home_debug( 'elementor: location single bloqueada' );
	} );

	// 2) Conteúdo da página estática (onde normalmente vive o iframe) não é impresso.
	add_filter( 'elementor/frontend/the_content', '__return_empty_string', 99 );
	add_filter( 'elementor/frontend/builder_content/before_print_css', '__return_false', 99 );

	// 3) Remove o CSS/estrutura específicos daquela página estática.
	add_action( 'wp_enqueue_scripts', function () {
		$page_id = (int) get_option( 'page_on_front' );
		if ( $page_id ) {
			wp_dequeue_style( 'elementor-post-' . $page_id );
			awr_home_debug( 'css elementor-post-' . $page_id . ' removido' );
		}
	}, 999 );

	// 4) Garante o loop do tema (evita "Página não encontrada" quando a home é estática).
	add_filter( 'body_class', function ( $classes ) {
		$classes[] = 'awr-home-native';
		return $classes;
	} );
}, 0 );

/**
 * Assume o "/" depois de todos os plugins (Elementor roda em prioridades bem menores).
 */
add_filter( 'template_include', function ( $template ) {
	if ( ! awr_should_force_front_page() ) { return $template; }
	$file = AWR_DIR . '/front-page.php';
	if ( ! file_exists( $file ) ) { return $template; }
	awr_home_debug( 'template forçado: front-page.php (era ' . basename( (string) $template ) . ')' );
	return $file;
}, PHP_INT_MAX );

/**
 * Segurança extra: se algum plugin ainda tentar imprimir o conteúdo da
 * página estática da home, devolvemos vazio (o layout vem do front-page.php).
 */
add_filter( 'the_content', function ( $content ) {
	if ( ! awr_should_force_front_page() ) { return $content; }
	if ( ! in_the_loop() || ! is_main_query() ) { return $content; }
	return '';
}, PHP_INT_MAX );

/**
 * Depuração para administradores: /?awr_debug_home=1
 */
add_action( 'wp_footer', function () {
	if ( empty( $_GET['awr_debug_home'] ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! current_user_can( 'manage_options' ) ) { return; }

	$log = awr_home_debug();
	echo '<pre style="position:fixed;z-index:99999;left:12px;bottom:12px;max-width:420px;background:#0b1220;color:#d7f5e0;padding:12px 14px;border-radius:10px;font:12px/1.5 ui-monospace,monospace;">';
	echo "AWR home debug\n";
	echo 'show_on_front: ' . esc_html( (string) get_option( 'show_on_front' ) ) . "\n";
	echo 'page_on_front: ' . esc_html( (string) get_option( 'page_on_front' ) ) . "\n";
	echo 'takeover: ' . ( awr_should_force_front_page() ? 'sim' : 'não' ) . "\n";
	foreach ( $log as $line ) { echo '- ' . esc_html( $line ) . "\n"; }
	echo '</pre>';
}, 99 );

/**
 * Aviso no admin quando a home ainda aponta para uma página do construtor,
 * com botão de 1 clique para voltar a home para o tema.
 */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	if ( get_user_meta( get_current_user_id(), 'awr_home_notice_off', true ) ) { return; }
	if ( 'page' !== get_option( 'show_on_front' ) ) { return; }

	$page_id = (int) get_option( 'page_on_front' );
	if ( ! $page_id ) { return; }

	$fix     = wp_nonce_url( add_query_arg( 'awr_fix_home', '1', admin_url() ), 'awr_home_notice' );
	$dismiss = wp_nonce_url( add_query_arg( 'awr_dismiss_home_notice', '1', admin_url() ), 'awr_home_notice' );

	echo '<div class="notice notice-info"><p><strong>AWR Baterias:</strong> a home do tema já está ativa em ' .
		esc_html( home_url( '/' ) ) . ' — a página estática <em>' . esc_html( get_the_title( $page_id ) ) .
		'</em> (com o iframe) não é mais usada.</p>' .
		'<p><a class="button button-primary" href="' . esc_url( $fix ) . '">Usar a home do tema (remover página estática)</a> ' .
		'<a class="button" href="' . esc_url( $dismiss ) . '">Entendi, não mostrar de novo</a></p></div>';
} );

add_action( 'admin_init', function () {
	if ( ! empty( $_GET['awr_fix_home'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		check_admin_referer( 'awr_home_notice' );
		if ( current_user_can( 'manage_options' ) ) {
			update_option( 'show_on_front', 'posts' );
			update_user_meta( get_current_user_id(), 'awr_home_notice_off', 1 );
		}
		wp_safe_redirect( admin_url() );
		exit;
	}

	if ( empty( $_GET['awr_dismiss_home_notice'] ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification
	check_admin_referer( 'awr_home_notice' );
	update_user_meta( get_current_user_id(), 'awr_home_notice_off', 1 );
} );
