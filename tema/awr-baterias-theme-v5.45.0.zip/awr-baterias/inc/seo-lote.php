<?php
/**
 * Plano SEO (planilha AWR_plano_SEO_Lovable):
 * - Metas por URL: título/descrição do lote 1 e 2.
 * - Redirects e canonical, etapa A: URLs concorrentes apontam canonical para a vencedora (reversível, sem 301).
 * - Fallback de SEO para posts/produtos/termos quando nenhum plugin de SEO está ativo (AIOSEO desligado).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function awr_seo_lote_map() {
	return array(
		'/blog/carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser' => array( 'title' => 'Carro Não Liga e Faz Estalo: Causas e Como Resolver', 'desc' => 'Carro não liga e faz estalo ao girar a chave? Veja as causas mais comuns, como testar a bateria e quando chamar a AWR para trocar no local.' ),
		'/entrega-de-baterias-on-line-peca-ja-a-sua' => array( 'title' => 'Comprar Bateria Online com Entrega e Instalação | AWR', 'desc' => 'Escolha a bateria do seu carro, veja o preço e peça online. Entrega e instalação em Porto Alegre e região metropolitana.' ),
		'/novo-hamburgo' => array( 'title' => 'Bateria em Novo Hamburgo: Entrega e Troca em 35 Min | AWR', 'desc' => 'Ficou sem bateria em Novo Hamburgo? Entregamos e instalamos em até 35 minutos. Veja modelos e preços e peça pelo WhatsApp.' ),
		'/baterias-em/novo-hamburgo' => array( 'title' => 'Bateria em Novo Hamburgo: Instalação em 35 Min | AWR', 'desc' => 'Bateria em Novo Hamburgo com entrega e instalação em até 35 minutos, teste do alternador, nota fiscal e garantia. Peça pelo WhatsApp.' ),
		'/bateria-novo-hamburgo' => array( 'title' => 'Bateria em Novo Hamburgo: Entrega e Troca em 35 Min | AWR', 'desc' => 'Ficou sem bateria em Novo Hamburgo? Entregamos e instalamos em até 35 minutos. Veja modelos e preços e peça pelo WhatsApp.' ),
		'/sao-leopoldo' => array( 'title' => 'Bateria em São Leopoldo: Entrega e Troca em 35 Min | AWR', 'desc' => 'Ficou sem bateria em São Leopoldo? Entregamos e instalamos em até 35 minutos. Veja modelos e preços e peça pelo WhatsApp.' ),
		'/baterias-em/sao-leopoldo' => array( 'title' => 'Bateria em São Leopoldo: Instalação em 35 Min | AWR', 'desc' => 'Bateria em São Leopoldo com entrega e instalação em até 35 minutos, teste do alternador, nota fiscal e garantia. Peça pelo WhatsApp.' ),
		'/baterias/jeep/renegade-com-start-stop/2019' => array( 'title' => 'Bateria Renegade Start-Stop 2019: Modelo Certo e Preço | AWR', 'desc' => 'Qual bateria vai no Jeep Renegade 2019 com start-stop? Veja amperagem, tecnologia e preço e peça com entrega e instalação em Porto Alegre.' ),
		'/blog/quanto-dura-bateria-do-corolla' => array( 'title' => 'Quanto Dura a Bateria do Corolla? Vida Útil e Quando Trocar', 'desc' => 'Descubra quanto dura a bateria do Corolla, os sinais de desgaste e quando trocar. Veja modelos compatíveis e peça com entrega em Porto Alegre.' ),
		'/blog/quando-trocar-bateria-do-onix' => array( 'title' => 'Quando Trocar a Bateria do Onix: Sinais e Vida Útil', 'desc' => 'Saiba quando trocar a bateria do Onix, os sinais de que ela está acabando e qual modelo comprar. Entrega e instalação em Porto Alegre e região.' ),
		'/baterias/peugeot/e-expert-eletrico/2025' => array( 'title' => 'Bateria Peugeot e-Expert Elétrico 2025: Modelo e Preço | AWR', 'desc' => 'Bateria para Peugeot e-Expert elétrico 2025: especificação, preço e troca com entrega e instalação em Porto Alegre e região.' ),
		'/' => array( 'title' => 'Baterias em Porto Alegre | Entrega e Troca em 35 Min | AWR', 'desc' => 'Baterias Moura, Heliar, Zetta e Excell com entrega e instalação grátis em até 35 min em Porto Alegre, Canoas, Gravataí e região. Pague na entrega.' ),
		'/produto/bateria-zetta-100ah' => array( 'title' => 'Bateria Zetta 100Ah: Preço e Entrega | AWR', 'desc' => 'Bateria Zetta 100Ah com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-zetta-50ah-z50ed' => array( 'title' => 'Bateria Zetta 50Ah Z50ED: Preço e Entrega | AWR', 'desc' => 'Bateria Zetta 50Ah Z50ED com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-zetta-180ah' => array( 'title' => 'Bateria Zetta 180Ah: Preço e Entrega | AWR', 'desc' => 'Bateria Zetta 180Ah com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-zetta-70ah-z70d' => array( 'title' => 'Bateria Zetta 70Ah Z70D: Preço e Entrega | AWR', 'desc' => 'Bateria Zetta 70Ah Z70D com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-eletran-60apd' => array( 'title' => 'Bateria Eletran 60Ah 60APD: Preço e Entrega | AWR', 'desc' => 'Bateria Eletran 60Ah 60APD com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-moura-180ah-12v-180bd' => array( 'title' => 'Bateria Moura 180Ah 180BD: Preço e Entrega | AWR', 'desc' => 'Bateria Moura 180Ah 180BD com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-econ-60ah-efb' => array( 'title' => 'Bateria Econ 60Ah EFB: Preço e Entrega | AWR', 'desc' => 'Bateria Econ 60Ah EFB com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-moura-50ah-amperes-12v-m50jd' => array( 'title' => 'Bateria Moura 50Ah M50JD: Preço e Entrega | AWR', 'desc' => 'Bateria Moura 50Ah M50JD com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-moura-60ah-m60ge' => array( 'title' => 'Bateria Moura 60Ah M60GE: Preço e Entrega | AWR', 'desc' => 'Bateria Moura 60Ah M60GE com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-excell-free-60ah-exf60de' => array( 'title' => 'Bateria Excell Free 60Ah EXF60DE: Preço e Entrega | AWR', 'desc' => 'Bateria Excell Free 60Ah EXF60DE com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-excell-super-premium-exp-75psd' => array( 'title' => 'Bateria Excell Super Premium 75Ah: Preço e Entrega | AWR', 'desc' => 'Bateria Excell Super Premium 75Ah EXP75PSD com entrega e instalação em Porto Alegre e região. Veja preço, garantia e compatibilidade e peça pelo WhatsApp.' ),
		'/produto/bateria-estacionaria-moura-nobreak-12mn1000-60ah' => array( 'title' => 'Bateria Estacionária Moura 60Ah: Preço e Entrega | AWR', 'desc' => 'Bateria Estacionária Moura 60Ah com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/baterias-moura-porto-alegre' => array( 'title' => 'Baterias Moura em Porto Alegre: Preços e Entrega | AWR', 'desc' => 'Compre bateria Moura em Porto Alegre com entrega e instalação. Veja modelos, preços e garantia e peça pelo WhatsApp.' ),
		'/categorias/moura-ou-heliar' => array( 'title' => 'Moura ou Heliar: Qual Bateria Escolher para o Seu Carro?', 'desc' => 'Compare Moura e Heliar em durabilidade, garantia e preço e descubra qual bateria combina com o seu carro. Entrega em Porto Alegre.' ),
		'/baterias-de-carro' => array( 'title' => 'Baterias de Carro em Porto Alegre: Preços e Entrega | AWR', 'desc' => 'Encontre a bateria certa para o seu carro: compare marcas e preços e peça com entrega e instalação em Porto Alegre e região.' ),
		'/blog/quanto-custa-a-bateria-nova-do-dolphin-mini' => array( 'title' => 'Bateria do BYD Dolphin Mini: Quanto Custa e Quando Trocar', 'desc' => 'Quanto custa a bateria 12V do BYD Dolphin Mini, quando trocar e onde comprar com entrega e instalação em Porto Alegre e região.' ),
		'/baterias/hyundai/creta-2-0/2019' => array( 'title' => 'Bateria Hyundai Creta 2.0 2019: Modelo Certo e Preço | AWR', 'desc' => 'Qual bateria usar no Hyundai Creta 2.0 2019? Veja amperagem, polo e tecnologia certos, compare preços e peça com entrega e instalação em Porto Alegre.' ),
		'/baterias/volkswagen/polo-exceto-gts/2024' => array( 'title' => 'Bateria VW Polo 2024: Modelo Certo e Preço | AWR', 'desc' => 'Qual bateria usar no VW Polo 2024? Veja amperagem, polo e tecnologia certos, compare preços e peça com entrega e instalação em Porto Alegre.' ),
		'/baterias/nissan/kicks' => array( 'title' => 'Bateria Nissan Kicks: Modelo Certo e Preço | AWR', 'desc' => 'Qual bateria usar no Nissan Kicks? Veja amperagem, polo e tecnologia certos, compare preços e peça com entrega e instalação em Porto Alegre.' ),
		'/baterias/renault/kwid-e-tech-eletrico/2024' => array( 'title' => 'Bateria Kwid E-Tech Elétrico 2024: Modelo e Preço | AWR', 'desc' => 'Qual bateria usar no Kwid E-Tech Elétrico 2024? Veja amperagem, polo e tecnologia certos, compare preços e peça com entrega e instalação em Porto Alegre.' ),
		'/baterias/renault/kwid/2023' => array( 'title' => 'Bateria Renault Kwid 2023: Modelo Certo e Preço | AWR', 'desc' => 'Qual bateria usar no Renault Kwid 2023? Veja amperagem, polo e tecnologia certos, compare preços e peça com entrega e instalação em Porto Alegre.' ),
		'/baterias/fiat/toro-sem-start-stop/2025' => array( 'title' => 'Bateria Fiat Toro 2025 sem Start-Stop: Modelo e Preço | AWR', 'desc' => 'Qual bateria usar no Fiat Toro 2025 sem Start-Stop? Veja amperagem, polo e tecnologia, compare preços e peça com entrega e instalação em Porto Alegre.' ),
		'/baterias/toyota/hilux-flex/2022' => array( 'title' => 'Bateria Toyota Hilux Flex 2022: Modelo Certo e Preço | AWR', 'desc' => 'Qual bateria usar no Toyota Hilux Flex 2022? Veja amperagem, polo e tecnologia certos, compare preços e peça com entrega e instalação em Porto Alegre.' ),
		'/baterias/toyota/yaris/2020' => array( 'title' => 'Bateria Toyota Yaris 2020: Modelo Certo e Preço | AWR', 'desc' => 'Qual bateria usar no Toyota Yaris 2020? Veja amperagem, polo e tecnologia certos, compare preços e peça com entrega e instalação em Porto Alegre.' ),
		'/baterias/ford/ka/2018' => array( 'title' => 'Bateria Ford Ka 2018: Modelo Certo e Preço | AWR', 'desc' => 'Qual bateria usar no Ford Ka 2018? Veja amperagem, polo e tecnologia certos, compare preços e peça com entrega e instalação em Porto Alegre.' ),
		'/baterias/ford/ecosport-1-5-e-1-6a-partir-de-junho-2017/2021' => array( 'title' => 'Bateria Ford EcoSport 2021: Modelo Certo e Preço | AWR', 'desc' => 'Qual bateria usar no Ford EcoSport 2021? Veja amperagem, polo e tecnologia certos, compare preços e peça com entrega e instalação em Porto Alegre.' ),
		'/produto/bateria-heliar-super-free-60ah-hf60hd' => array( 'title' => 'Bateria Heliar Super Free 60Ah HF60HD: Preço e Entrega | AWR', 'desc' => 'Bateria Heliar Super Free 60Ah HF60HD com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-heliar-super-free-65ah-hf65hd' => array( 'title' => 'Bateria Heliar Super Free 65Ah HF65HD: Preço e Entrega | AWR', 'desc' => 'Bateria Heliar Super Free 65Ah HF65HD com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-heliar-super-free-52ah-hf52gd' => array( 'title' => 'Bateria Heliar Super Free 52Ah HF52GD: Preço e Entrega | AWR', 'desc' => 'Bateria Heliar Super Free 52Ah HF52GD com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-heliar-super-free-48ah-hf48bd' => array( 'title' => 'Bateria Heliar Super Free 48Ah HF48BD: Preço e Entrega | AWR', 'desc' => 'Bateria Heliar Super Free 48Ah HF48BD com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-heliar-original-75ah-hg75ld' => array( 'title' => 'Bateria Heliar Original 75Ah HG75LD: Preço e Entrega | AWR', 'desc' => 'Bateria Heliar Original 75Ah HG75LD com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-moura-48ah-m48fd' => array( 'title' => 'Bateria Moura 48Ah M48FD: Preço e Entrega | AWR', 'desc' => 'Bateria Moura 48Ah M48FD com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-zetta-45ah-z45d' => array( 'title' => 'Bateria Zetta 45Ah Z45D: Preço e Entrega | AWR', 'desc' => 'Bateria Zetta 45Ah Z45D com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/produto/bateria-excell-free-12v-70ah-exf75nd' => array( 'title' => 'Bateria Excell Free 70Ah EXF75ND: Preço e Entrega | AWR', 'desc' => 'Bateria Excell Free 70Ah EXF75ND com entrega e instalação em Porto Alegre e região. Veja preço, garantia e veículos compatíveis e peça pelo WhatsApp.' ),
		'/baterias-em/canoas' => array( 'title' => 'Bateria em Canoas: Entrega e Troca em 35 Min | AWR', 'desc' => 'Ficou sem bateria em Canoas? Entregamos e instalamos em até 35 minutos. Veja modelos e preços e peça pelo WhatsApp.' ),
		'/baterias-em/gravatai' => array( 'title' => 'Bateria em Gravataí: Entrega e Troca em 35 Min | AWR', 'desc' => 'Ficou sem bateria em Gravataí? Entregamos e instalamos em até 35 minutos. Veja modelos e preços e peça pelo WhatsApp.' ),
		'/bateria-gravatai' => array( 'title' => 'Bateria em Gravataí: Entrega e Troca em 35 Min | AWR', 'desc' => 'Ficou sem bateria em Gravataí? Entregamos e instalamos em até 35 minutos. Veja modelos e preços e peça pelo WhatsApp.' ),
		'/baterias-em/alvorada' => array( 'title' => 'Bateria em Alvorada: Entrega e Instalação | AWR', 'desc' => 'Bateria para carro em Alvorada com entrega e instalação. Veja modelos, preços e garantia e peça pelo WhatsApp.' ),
		'/baterias-automotivas-em-caxias-do-sul' => array( 'title' => 'Bateria em Caxias do Sul: Envio por Transportadora | AWR', 'desc' => 'Bateria Moura, Heliar e Zetta para Caxias do Sul com nota fiscal e garantia. Envio por transportadora em 2 a 3 dias úteis. Peça pelo WhatsApp.' ),
		'/baterias-em-gravatai-e-cachoeirinha-2' => array( 'title' => 'Bateria em Gravataí: Entrega e Troca em 35 Min | AWR', 'desc' => 'Ficou sem bateria em Gravataí? Entregamos e instalamos em até 35 minutos. Veja modelos e preços e peça pelo WhatsApp.' ),
	);
}

/**
 * Etapa A: origem => URL canônica (reversível, sem 301).
 * v5.15.0: o padrão é /baterias-em/{cidade}/ para TODAS as cidades. Antes, São Leopoldo, Novo Hamburgo
 * e Guaíba apontavam o canonical para a URL antiga, enquanto inc/redirects.php mandava 301 no sentido
 * contrário (laço canonical x redirect).
 */
function awr_seo_canonical_cruzado_map() {
	return array(
		'/sao-leopoldo' => '/baterias-em/sao-leopoldo/',
		'/bateria-sao-leopoldo' => '/baterias-em/sao-leopoldo/',
		'/novo-hamburgo' => '/baterias-em/novo-hamburgo/',
		'/bateria-novo-hamburgo' => '/baterias-em/novo-hamburgo/',
		'/baterias-em-novo-hamburgo' => '/baterias-em/novo-hamburgo/',
		'/canoas' => '/baterias-em/canoas/',
		'/baterias-em-canoas' => '/baterias-em/canoas/',
		'/bateria-canoas' => '/baterias-em/canoas/',
		'/awr-baterias-canoas-home' => '/baterias-em/canoas/',
		'/bateria-gravatai' => '/baterias-em/gravatai/',
		'/baterias-em-gravatai-e-cachoeirinha-2' => '/baterias-em/gravatai/',
		'/bateria-guaiba' => '/baterias-em/guaiba/',
		'/bateria-viamao' => '/baterias-em/viamao/',
		'/produto-tag/baterias-caxias-do-sul' => '/baterias-em/caxias-do-sul/',
		// Mesmo destino do 301 de inc/redirects.php (evita sinais contraditórios).
		'/baterias-automotivas-moura-em-caxias-do-sul' => '/bateria/moura/caxias-do-sul/',
		'/baterias-automotivas-em-caxias-do-sul' => '/baterias-em/caxias-do-sul/',
		'/produto-tag/casa-das-baterias-caxias-do-sul' => '/baterias-em/caxias-do-sul/',
		'/produto-tag/baterias-porto-alegre' => '/baterias-em/porto-alegre/',
		'/produto-tag/baterias-moura-porto-alegre' => '/baterias-moura-porto-alegre/',
	);
}

function awr_seo_lote_path() {
	$p = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/', PHP_URL_PATH );
	return '/' . trim( rawurldecode( (string) $p ), '/' );
}

function awr_seo_lote_match() {
	$map = awr_seo_lote_map();
	$p   = awr_seo_lote_path();
	return isset( $map[ $p ] ) ? $map[ $p ] : false;
}

function awr_seo_canonical_cruzado() {
	$map = awr_seo_canonical_cruzado_map();
	$p   = awr_seo_lote_path();
	return isset( $map[ $p ] ) ? home_url( $map[ $p ] ) : '';
}

function awr_seo_sem_plugin() {
	return ! defined( 'AIOSEO_VERSION' ) && ! defined( 'WPSEO_VERSION' ) && ! defined( 'RANK_MATH_VERSION' );
}

/** Contexto genérico de páginas nativas quando não há plugin de SEO. */
function awr_seo_fallback_ctx() {
	if ( ! awr_seo_sem_plugin() || is_admin() ) { return false; }
	if ( is_singular() ) {
		$id   = get_queried_object_id();
		$desc = has_excerpt( $id ) ? get_the_excerpt( $id ) : wp_strip_all_tags( (string) get_post_field( 'post_content', $id ) );
		return array(
			'title'     => get_the_title( $id ) . ' | AWR Baterias',
			'desc'      => $desc ? $desc : get_the_title( $id ) . ' com entrega e instalação em Porto Alegre e região. Peça pelo WhatsApp.',
			'canonical' => get_permalink( $id ),
		);
	}
	if ( is_category() || is_tag() || is_tax() ) {
		$t = get_queried_object();
		if ( ! $t || empty( $t->term_id ) ) { return false; }
		$link = get_term_link( $t );
		return array(
			'title'     => $t->name . ' | AWR Baterias',
			'desc'      => $t->description ? $t->description : $t->name . ': baterias com entrega e instalação em Porto Alegre e região.',
			'canonical' => is_wp_error( $link ) ? '' : $link,
		);
	}
	return false;
}


/** H1 sugerido pela planilha (Metas por URL) para o path atual, ou '' quando não há. */
function awr_seo_lote_h1() {
	static $map = null;
	if ( null === $map ) {
		$map = array(
		'/blog/carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser' => 'Carro Não Liga e Faz Estalo: Causas e Como Resolver',
		'/entrega-de-baterias-on-line-peca-ja-a-sua' => 'Comprar Bateria Online com Entrega e Instalação',
		'/novo-hamburgo' => 'Bateria em Novo Hamburgo: Entrega e Troca em 35 Min',
		'/baterias-em/novo-hamburgo' => 'Troca de bateria em Novo Hamburgo com instalação em até 35 min',
		'/bateria-novo-hamburgo' => 'Bateria em Novo Hamburgo: Entrega e Troca em 35 Min',
		'/sao-leopoldo' => 'Bateria em São Leopoldo: Entrega e Troca em 35 Min',
		'/baterias-em/sao-leopoldo' => 'Troca de bateria em São Leopoldo com instalação em até 35 min',
		'/baterias/jeep/renegade-com-start-stop/2019' => 'Bateria Renegade Start-Stop 2019: Modelo Certo e Preço',
		'/blog/quanto-dura-bateria-do-corolla' => 'Quanto Dura a Bateria do Corolla? Vida Útil e Quando Trocar',
		'/blog/quando-trocar-bateria-do-onix' => 'Quando Trocar a Bateria do Onix: Sinais e Vida Útil',
		'/baterias/peugeot/e-expert-eletrico/2025' => 'Bateria Peugeot e-Expert Elétrico 2025: Modelo e Preço',
		'/produto/bateria-zetta-100ah' => 'Bateria Zetta 100Ah: Preço e Entrega',
		'/produto/bateria-zetta-50ah-z50ed' => 'Bateria Zetta 50Ah Z50ED: Preço e Entrega',
		'/produto/bateria-zetta-180ah' => 'Bateria Zetta 180Ah: Preço e Entrega',
		'/produto/bateria-zetta-70ah-z70d' => 'Bateria Zetta 70Ah Z70D: Preço e Entrega',
		'/produto/bateria-eletran-60apd' => 'Bateria Eletran 60Ah 60APD: Preço e Entrega',
		'/produto/bateria-moura-180ah-12v-180bd' => 'Bateria Moura 180Ah 180BD: Preço e Entrega',
		'/produto/bateria-econ-60ah-efb' => 'Bateria Econ 60Ah EFB: Preço e Entrega',
		'/produto/bateria-moura-50ah-amperes-12v-m50jd' => 'Bateria Moura 50Ah M50JD: Preço e Entrega',
		'/produto/bateria-moura-60ah-m60ge' => 'Bateria Moura 60Ah M60GE: Preço e Entrega',
		'/produto/bateria-excell-free-60ah-exf60de' => 'Bateria Excell Free 60Ah EXF60DE: Preço e Entrega',
		'/produto/bateria-excell-super-premium-exp-75psd' => 'Bateria Excell Super Premium 75Ah: Preço e Entrega',
		'/produto/bateria-estacionaria-moura-nobreak-12mn1000-60ah' => 'Bateria Estacionária Moura 60Ah: Preço e Entrega',
		'/baterias-moura-porto-alegre' => 'Baterias Moura em Porto Alegre: Preços e Entrega',
		'/categorias/moura-ou-heliar' => 'Moura ou Heliar: Qual Bateria Escolher para o Seu Carro?',
		'/baterias-de-carro' => 'Baterias de Carro em Porto Alegre: Preços e Entrega',
		'/blog/quanto-custa-a-bateria-nova-do-dolphin-mini' => 'Bateria do BYD Dolphin Mini: Quanto Custa e Quando Trocar',
		'/baterias/hyundai/creta-2-0/2019' => 'Bateria Hyundai Creta 2.0 2019: Modelo Certo e Preço',
		'/baterias/volkswagen/polo-exceto-gts/2024' => 'Bateria VW Polo 2024: Modelo Certo e Preço',
		'/baterias/nissan/kicks' => 'Bateria Nissan Kicks: Modelo Certo e Preço',
		'/baterias/renault/kwid-e-tech-eletrico/2024' => 'Bateria Kwid E-Tech Elétrico 2024: Modelo e Preço',
		'/baterias/renault/kwid/2023' => 'Bateria Renault Kwid 2023: Modelo Certo e Preço',
		'/baterias/fiat/toro-sem-start-stop/2025' => 'Bateria Fiat Toro 2025 sem Start-Stop: Modelo e Preço',
		'/baterias/toyota/hilux-flex/2022' => 'Bateria Toyota Hilux Flex 2022: Modelo Certo e Preço',
		'/baterias/toyota/yaris/2020' => 'Bateria Toyota Yaris 2020: Modelo Certo e Preço',
		'/baterias/ford/ka/2018' => 'Bateria Ford Ka 2018: Modelo Certo e Preço',
		'/baterias/ford/ecosport-1-5-e-1-6a-partir-de-junho-2017/2021' => 'Bateria Ford EcoSport 2021: Modelo Certo e Preço',
		'/produto/bateria-heliar-super-free-60ah-hf60hd' => 'Bateria Heliar Super Free 60Ah HF60HD: Preço e Entrega',
		'/produto/bateria-heliar-super-free-65ah-hf65hd' => 'Bateria Heliar Super Free 65Ah HF65HD: Preço e Entrega',
		'/produto/bateria-heliar-super-free-52ah-hf52gd' => 'Bateria Heliar Super Free 52Ah HF52GD: Preço e Entrega',
		'/produto/bateria-heliar-super-free-48ah-hf48bd' => 'Bateria Heliar Super Free 48Ah HF48BD: Preço e Entrega',
		'/produto/bateria-heliar-original-75ah-hg75ld' => 'Bateria Heliar Original 75Ah HG75LD: Preço e Entrega',
		'/produto/bateria-moura-48ah-m48fd' => 'Bateria Moura 48Ah M48FD: Preço e Entrega',
		'/produto/bateria-zetta-45ah-z45d' => 'Bateria Zetta 45Ah Z45D: Preço e Entrega',
		'/produto/bateria-excell-free-12v-70ah-exf75nd' => 'Bateria Excell Free 70Ah EXF75ND: Preço e Entrega',
		'/baterias-em/canoas' => 'Troca de bateria em Canoas com instalação em até 35 min',
		'/baterias-em/gravatai' => 'Troca de bateria em Gravataí com instalação em até 35 min',
		'/bateria-gravatai' => 'Bateria em Gravataí: Entrega e Troca em 35 Min',
		'/baterias-em/alvorada' => 'Bateria em Alvorada com entrega durante o dia',
		'/baterias-automotivas-em-caxias-do-sul' => 'Bateria em Caxias do Sul: Entrega e Instalação',
		'/baterias-em-gravatai-e-cachoeirinha-2' => 'Bateria em Gravataí: Entrega e Troca em 35 Min',
		);
	}
	$p = awr_seo_lote_path();
	return isset( $map[ $p ] ) ? $map[ $p ] : '';
}

function awr_seo_lote_managed() {
	return awr_seo_lote_match() || awr_seo_canonical_cruzado() || awr_seo_fallback_ctx();
}

add_filter( 'awr_seo_context', function ( $base ) {
	$route = function_exists( 'awr_current_route' ) ? awr_current_route() : '';
	$nativo = function_exists( 'awr_seo_native_context' ) && awr_seo_native_context();
	if ( ! $route && ! $nativo && ! is_front_page() ) {
		$f = awr_seo_fallback_ctx();
		if ( $f ) { $base = array_merge( $base, $f ); $base['noindex'] = false; }
	}
	$m = awr_seo_lote_match();
	if ( $m ) {
		$base['title'] = $m['title'];
		$base['desc']  = $m['desc'];
		$p = awr_seo_lote_path();
		if ( '/' !== $p && ( empty( $base['canonical'] ) || untrailingslashit( $base['canonical'] ) === untrailingslashit( home_url( '/' ) ) ) ) {
			$base['canonical'] = home_url( trailingslashit( $p ) );
		}
	}
	$c = awr_seo_canonical_cruzado();
	if ( $c ) { $base['canonical'] = $c; $base['noindex'] = false; }
	return $base;
}, 99 );
