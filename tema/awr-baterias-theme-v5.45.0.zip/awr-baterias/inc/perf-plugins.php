<?php
/**
 * v5.11.0 — corta scripts de medição de plugins fora da loja/checkout.
 * O tema já envia GA4, Google Ads e GTM; as cópias do Jetpack/Site Kit/Woo
 * Analytics só disputavam a linha de execução do celular (tarefas longas).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function awr_perf_plugin_handles() {
	return apply_filters( 'awr_perf_plugin_handles', array(
		'jetpack-stats', 'woocommerce-analytics-client', 'woocommerce-analytics', 'wc-analytics',
		'googlesitekit-events-provider-content-events', 'googlesitekit-events-provider-woocommerce',
		'googlesitekit-consent-mode',
	) );
}

function awr_perf_light_screen() {
	if ( is_admin() ) { return false; }
	return function_exists( 'awr_screen_needs_woo' ) ? ! awr_screen_needs_woo() : true;
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! awr_perf_light_screen() ) { return; }
	foreach ( awr_perf_plugin_handles() as $h ) {
		wp_dequeue_script( $h );
		wp_deregister_script( $h );
	}
}, 9999 );

add_action( 'wp_print_footer_scripts', function () {
	if ( ! awr_perf_light_screen() ) { return; }
	foreach ( awr_perf_plugin_handles() as $h ) { wp_dequeue_script( $h ); }
}, 1 );

/* Troca woocommerce-no-js → woocommerce-js reescreve a classe do <body> e
   invalida todo o layout no carregamento (reflow forçado). Fora da loja não
   há nada que dependa dessa classe. */
add_action( 'wp', function () {
	if ( awr_perf_light_screen() ) {
		remove_action( 'wp_footer', 'wc_no_js' );
	}
} );

/* Bloco inline do WooCommerce Analytics (window.wcAnalytics) fora da loja. */
add_action( 'template_redirect', function () {
	if ( ! awr_perf_light_screen() ) { return; }
	ob_start( function ( $html ) {
		return preg_replace( '#<script type="text/javascript">\s*\(function\(\) \{\s*window\.wcAnalytics.*?</script>\s*#s', '', $html, 1 );
	} );
}, 99 );
