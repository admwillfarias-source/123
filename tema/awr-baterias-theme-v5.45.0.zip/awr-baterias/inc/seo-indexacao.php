<?php
/**
 * Indexação por dados (T28) — v5.15.0.
 *
 * Problema: o tema publica ~190 mil URLs "veículo × cidade" (1.794 modelos × 106 cidades), todas no
 * sitemap e indexáveis, com texto que varia pouco. Em 3 meses só 28 delas apareceram no Search Console.
 * Páginas assim podem ser tratadas como doorway/conteúdo em escala.
 *
 * Esta camada NÃO apaga nada: as páginas continuam abrindo. Ela decide, por regra, o que é indexável
 * e o que entra no sitemap.
 *
 *  Modos (Ajustes > AWR Indexação, opção awr_idx_modo):
 *   - off     : comportamento anterior (padrão).
 *   - envio   : cidades de ENVIO (sem loja) só ficam indexáveis para (a) URLs da lista de permissão
 *               (assets/data/indexaveis.json = URLs com impressões) ou (b) mercados de foco x modelos
 *               populares. As cidades de COBERTURA (35 min) seguem todas indexáveis.
 *   - estrito : como "envio" e, nas cidades de cobertura, só os N modelos mais populares (padrão 400)
 *               ou URLs da lista de permissão.
 *  Páginas fora da regra recebem noindex,follow e saem do sitemap. Nada é removido do site.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

function awr_idx_modo() {
	$m = (string) get_option( 'awr_idx_modo', 'envio' );
	return in_array( $m, array( 'off', 'envio', 'estrito' ), true ) ? $m : 'off';
}

function awr_idx_ativo() {
	return 'off' !== awr_idx_modo();
}

function awr_idx_cobertura_top() {
	return max( 50, (int) get_option( 'awr_idx_cobertura_top', 400 ) );
}

/** Mercados de envio com prioridade (mesma lista usada na ordem do sitemap). */
function awr_idx_cidades_foco() {
	return apply_filters( 'awr_idx_cidades_foco', array(
		'caxias-do-sul', 'pelotas', 'santa-maria', 'passo-fundo', 'rio-grande',
		'florianopolis', 'joinville', 'blumenau', 'chapeco', 'sao-jose', 'criciuma',
		'sao-paulo', 'campinas', 'guarulhos', 'sao-bernardo-do-campo', 'osasco',
		'sorocaba', 'ribeirao-preto', 'sao-jose-dos-campos', 'santos',
		'curitiba', 'londrina', 'maringa', 'ponta-grossa', 'cascavel', 'foz-do-iguacu',
	) );
}

/** Lista de permissão: conjunto "modelo|cidade" com impressões no Search Console. */
function awr_idx_allowlist() {
	static $set = null;
	if ( null !== $set ) { return $set; }
	$set  = array();
	$file = AWR_DIR . '/assets/data/indexaveis.json';
	if ( is_readable( $file ) ) {
		$j = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		foreach ( (array) ( isset( $j['paths'] ) ? $j['paths'] : array() ) as $p ) {
			if ( preg_match( '#^/baterias-para/([^/]+)/([^/]+)/?$#', (string) $p, $m ) ) {
				$set[ $m[1] . '|' . $m[2] ] = true;
			}
		}
	}
	foreach ( (array) apply_filters( 'awr_idx_allowlist_extra', array() ) as $k ) {
		$set[ (string) $k ] = true;
	}
	return $set;
}

/** Posição de cada modelo na ordem de popularidade do sitemap. */
function awr_idx_model_rank() {
	static $r = null;
	if ( null !== $r ) { return $r; }
	$r = array();
	foreach ( awr_vc_models_sitemap() as $i => $m ) { $r[ $m['slug'] ] = $i; }
	return $r;
}

/** Nomes dos modelos mais buscados (mesma lista de awr_vc_populares). */
function awr_idx_populares_nomes() {
	return apply_filters( 'awr_idx_populares_nomes', array(
		'Chevrolet Onix', 'Hyundai HB20', 'Volkswagen Gol', 'Toyota Corolla',
		'Honda Civic', 'Ford Ka', 'Fiat Uno', 'Fiat Palio', 'Fiat Strada',
		'Volkswagen Polo', 'Jeep Renegade', 'Toyota Hilux', 'Ford Ranger',
		'Chevrolet S10', 'Honda HR-V', 'Hyundai Creta', 'Nissan Kicks',
		'Volkswagen T-Cross', 'Chevrolet Tracker', 'Fiat Argo', 'Renault Kwid',
		'Fiat Toro', 'Fiat Mobi', 'Volkswagen Saveiro',
	) );
}

/**
 * Slugs de modelo considerados "populares".
 * awr_vc_populares() só casa slug exato e perde Onix, HB20, Corolla, Renegade, Creta, T-Cross, Argo, Toro
 * (no catálogo eles têm sufixo de versão). Aqui o casamento é por slug exato OU prefixo "{nome}-".
 */
function awr_idx_populares_set() {
	static $s = null;
	if ( null !== $s ) { return $s; }
	$s    = array();
	$base = array();
	foreach ( awr_idx_populares_nomes() as $nome ) { $base[] = awr_slugify( $nome ); }
	foreach ( awr_vc_models_sitemap() as $m ) {
		foreach ( $base as $b ) {
			if ( $m['slug'] === $b || 0 === strpos( $m['slug'], $b . '-' ) ) { $s[ $m['slug'] ] = true; break; }
		}
	}
	return $s;
}

/** A página veículo × cidade deve ser indexável? */
function awr_idx_vc_indexavel( $model_slug, $city_slug ) {
	if ( ! awr_idx_ativo() ) { return true; }
	$allow = awr_idx_allowlist();
	if ( isset( $allow[ $model_slug . '|' . $city_slug ] ) ) { return true; }
	$vcc = awr_vc_cidade( $city_slug );
	if ( ! $vcc ) { return true; } // rota inválida: tratada por outra regra.
	if ( 'cobertura' === $vcc['mode'] ) {
		if ( 'estrito' !== awr_idx_modo() ) { return true; }
		$rank = awr_idx_model_rank();
		return isset( $rank[ $model_slug ] ) && $rank[ $model_slug ] < awr_idx_cobertura_top();
	}
	return in_array( $city_slug, awr_idx_cidades_foco(), true ) && isset( awr_idx_populares_set()[ $model_slug ] );
}

/** noindex,follow nas páginas veículo × cidade fora da regra (o conteúdo continua acessível). */
add_filter( 'awr_seo_context', function ( $base, $route = '' ) {
	if ( 'veiculo_cidade' !== $route || ! awr_idx_ativo() ) { return $base; }
	if ( ! awr_idx_vc_indexavel( awr_param_a(), awr_param_b() ) ) { $base['noindex'] = 'follow'; }
	return $base;
}, 100, 2 );

/* ---------------------------------------------------------------------
   Sitemap veículo × cidade filtrado (sem materializar as 190 mil URLs)
   --------------------------------------------------------------------- */

/** Bloco principal: modelos (ordem de popularidade) × cidades de cobertura. */
function awr_idx_vc_bloco() {
	static $b = null;
	if ( null !== $b ) { return $b; }
	$cob = array();
	foreach ( awr_vc_cidades_sitemap() as $c ) {
		if ( 'cobertura' === $c['mode'] ) { $cob[] = $c['c']['slug']; }
	}
	$models = awr_vc_models_sitemap();
	$n      = count( $models );
	if ( 'estrito' === awr_idx_modo() ) { $n = min( $n, awr_idx_cobertura_top() ); }
	$b = array( 'cob' => $cob, 'models' => array_slice( $models, 0, $n ) );
	return $b;
}

/** URLs extras fora do bloco principal: lista de permissão e mercados de foco x populares. */
function awr_idx_vc_extras() {
	static $e = null;
	if ( null !== $e ) { return $e; }
	$bloco    = awr_idx_vc_bloco();
	$cob_set  = array_flip( $bloco['cob'] );
	$mod_set  = array();
	foreach ( $bloco['models'] as $m ) { $mod_set[ $m['slug'] ] = true; }

	$candidatos = array();
	foreach ( array_keys( awr_idx_allowlist() ) as $k ) { $candidatos[] = explode( '|', $k, 2 ); }
	foreach ( awr_idx_cidades_foco() as $cs ) {
		foreach ( array_keys( awr_idx_populares_set() ) as $ms ) { $candidatos[] = array( $ms, $cs ); }
	}

	$e      = array();
	$vistos = array();
	foreach ( $candidatos as $par ) {
		if ( 2 !== count( $par ) ) { continue; }
		list( $ms, $cs ) = $par;
		if ( ! awr_vc_model( $ms ) || ! awr_vc_cidade( $cs ) ) { continue; }
		if ( isset( $cob_set[ $cs ] ) && isset( $mod_set[ $ms ] ) ) { continue; } // já no bloco principal.
		$chave = $ms . '|' . $cs;
		if ( isset( $vistos[ $chave ] ) ) { continue; }
		$vistos[ $chave ] = true;
		$e[] = awr_vc_url( $ms, $cs );
	}
	return $e;
}

function awr_idx_vc_total() {
	$b = awr_idx_vc_bloco();
	return ( count( $b['models'] ) * count( $b['cob'] ) ) + count( awr_idx_vc_extras() );
}

/** Fatia paginada do sitemap filtrado. */
function awr_idx_vc_page( $page, $per ) {
	$b     = awr_idx_vc_bloco();
	$nc    = count( $b['cob'] );
	$bloco = count( $b['models'] ) * $nc;
	$ext   = awr_idx_vc_extras();
	$start = max( 0, ( (int) $page - 1 ) * (int) $per );
	$end   = min( $start + (int) $per, $bloco + count( $ext ) );
	$urls  = array();
	for ( $i = $start; $i < $end; $i++ ) {
		if ( $i < $bloco && $nc > 0 ) {
			$m      = $b['models'][ intdiv( $i, $nc ) ];
			$urls[] = awr_vc_url( $m['slug'], $b['cob'][ $i % $nc ] );
		} else {
			$urls[] = $ext[ $i - $bloco ];
		}
	}
	return $urls;
}

/* ---------------------------------------------------------------------
   Tela de ajuste: Ajustes > AWR Indexação
   --------------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_options_page( 'AWR Indexação', 'AWR Indexação', 'manage_options', 'awr-indexacao', 'awr_idx_pagina' );
} );

function awr_idx_pagina() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	if ( isset( $_POST['awr_idx_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['awr_idx_nonce'] ) ), 'awr_idx_salvar' ) ) {
		$modo = isset( $_POST['awr_idx_modo'] ) ? sanitize_key( wp_unslash( $_POST['awr_idx_modo'] ) ) : 'envio';
		update_option( 'awr_idx_modo', in_array( $modo, array( 'off', 'envio', 'estrito' ), true ) ? $modo : 'off' );
		update_option( 'awr_idx_cobertura_top', max( 50, isset( $_POST['awr_idx_top'] ) ? (int) $_POST['awr_idx_top'] : 400 ) );
		// v5.16.1: pausar a Etapa B também pausa o relógio (antes, ao religar depois de semanas, as 3 cidades saíam juntas).
		$etb_antes = (int) get_option( 'awr_etapa_b_301', 1 );
		$etb_novo  = ! empty( $_POST['awr_etapa_b_301'] ) ? 1 : 0;
		if ( $etb_antes && ! $etb_novo ) { update_option( 'awr_etapa_b_pausa', time(), false ); }
		if ( ! $etb_antes && $etb_novo ) {
			$pausa = (int) get_option( 'awr_etapa_b_pausa', 0 );
			$ini   = (int) get_option( 'awr_etapa_b_inicio', 0 );
			if ( $pausa && $ini ) { update_option( 'awr_etapa_b_inicio', $ini + max( 0, time() - $pausa ), false ); }
			delete_option( 'awr_etapa_b_pausa' );
		}
		update_option( 'awr_etapa_b_301', $etb_novo );
		delete_transient( 'awr_legacy_redirects' ); // refaz o mapa de 301 com o novo estado.
		echo '<div class="notice notice-success"><p>Ajustes salvos. O sitemap é recalculado no próximo acesso.</p></div>';
	}
	$modo = awr_idx_modo();
	$top  = awr_idx_cobertura_top();
	$etb  = (int) get_option( 'awr_etapa_b_301', 1 );
	$total = awr_idx_ativo() ? awr_idx_vc_total() : awr_vc_total_urls();
	?>
	<div class="wrap">
		<h1>AWR Indexação</h1>
		<p>URLs veículo × cidade hoje no sitemap: <strong><?php echo esc_html( number_format_i18n( $total ) ); ?></strong>.
		Lista de permissão (com impressões no Search Console): <strong><?php echo esc_html( count( awr_idx_allowlist() ) ); ?></strong> URLs.</p>
		<form method="post">
			<?php wp_nonce_field( 'awr_idx_salvar', 'awr_idx_nonce' ); ?>
			<table class="form-table">
				<tr><th>Modo</th><td>
					<select name="awr_idx_modo">
						<option value="off" <?php selected( $modo, 'off' ); ?>>off — como antes (tudo indexável)</option>
						<option value="envio" <?php selected( $modo, 'envio' ); ?>>envio — poda só as cidades sem loja</option>
						<option value="estrito" <?php selected( $modo, 'estrito' ); ?>>estrito — poda também modelos pouco populares nas cidades com loja</option>
					</select>
					<p class="description">Recomendado: ligar "envio" primeiro, esperar 14 dias, comparar cliques e posição e só então avaliar "estrito".</p>
				</td></tr>
				<tr><th>Modelos populares nas cidades com loja (modo estrito)</th><td><input type="number" name="awr_idx_top" min="50" value="<?php echo esc_attr( $top ); ?>"></td></tr>
				<tr><th>Etapa B: 301 das URLs antigas de cidade</th><td>
					<label><input type="checkbox" name="awr_etapa_b_301" value="1" <?php checked( $etb, 1 ); ?>> Ativar 301, uma cidade a cada 21 dias: Guaíba → Novo Hamburgo → São Leopoldo</label>
					<p class="description">Liberadas agora: <strong><?php echo (int) awr_redirect_etapa_b_liberadas(); ?> de 3</strong>.</p>
					<p class="description">Só depois de ~3 semanas com o canonical (Etapa A) e impressões estáveis. Reversível: desmarque para voltar.</p>
				</td></tr>
			</table>
			<?php submit_button( 'Salvar' ); ?>
		</form>
	</div>
	<?php
}
