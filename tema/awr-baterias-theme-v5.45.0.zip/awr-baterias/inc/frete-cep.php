<?php
/**
 * Frete por CEP (regras do cliente, out/2026).
 * Prioridade: mesmo dia R$ 20 > grátis 35 min > transportadora (R$ 50; R$ 75 acima de 20 kg; 2–3 dias úteis).
 * CEPs com entrega local nunca usam transportadora.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$awr_cep_faixas_file = __DIR__ . '/cep-faixas.php';
if ( file_exists( $awr_cep_faixas_file ) ) { require_once $awr_cep_faixas_file; }

function awr_cep_dentro( $n, $faixas ) {
	foreach ( (array) $faixas as $f ) {
		if ( $n >= $f[0] && $n <= $f[1] ) { return true; }
	}
	return false;
}

/** @return array{tipo:string,valor:float|null,prazo:string} */
function awr_frete_por_cep( $cep, $peso_kg = 0 ) {
	$d = preg_replace( '/\D/', '', (string) $cep );
	if ( 8 !== strlen( $d ) || ! function_exists( 'awr_cep_faixas' ) ) {
		return array( 'tipo' => 'sem-cobertura', 'valor' => null, 'prazo' => 'Informe um CEP válido' );
	}
	$n = (int) $d;
	$f = awr_cep_faixas();
	if ( awr_cep_dentro( $n, $f['mesmo_dia'] ) ) {
		return array( 'tipo' => 'mesmo-dia', 'valor' => 20.0, 'prazo' => 'Entrega no mesmo dia' );
	}
	if ( awr_cep_dentro( $n, $f['gratis35'] ) ) {
		return array( 'tipo' => 'gratis-35', 'valor' => 0.0, 'prazo' => 'Entrega grátis em até 35 min' );
	}
	if ( awr_cep_dentro( $n, $f['transportadora'] ) ) {
		return array( 'tipo' => 'transportadora', 'valor' => ( (float) $peso_kg > 20 ? 75.0 : 50.0 ), 'prazo' => 'Transportadora: 2 a 3 dias úteis' );
	}
	return array( 'tipo' => 'sem-cobertura', 'valor' => null, 'prazo' => 'Consulte a entrega no WhatsApp' );
}

/** Peso total do carrinho/pacote (kg). */
function awr_frete_peso_pacote( $package ) {
	$peso = 0.0;
	foreach ( (array) ( $package['contents'] ?? array() ) as $item ) {
		$p = isset( $item['data'] ) && is_object( $item['data'] ) ? (float) $item['data']->get_weight() : 0;
		$peso = max( $peso, $p ); // regra por bateria: a mais pesada define a faixa
	}
	return $peso;
}

/** Checkout padrão do WooCommerce: substitui as opções de frete pela regra de CEP. */
add_filter( 'woocommerce_package_rates', function ( $rates, $package ) {
	if ( ! class_exists( 'WC_Shipping_Rate' ) ) { return $rates; }
	$cep = $package['destination']['postcode'] ?? '';
	$r   = awr_frete_por_cep( $cep, awr_frete_peso_pacote( $package ) );
	if ( null === $r['valor'] ) { return $rates; }
	$rate = new WC_Shipping_Rate( 'awr_cep:' . $r['tipo'], $r['prazo'], $r['valor'], array(), 'awr_cep' );
	return array( $rate->get_id() => $rate );
}, 100, 2 );
