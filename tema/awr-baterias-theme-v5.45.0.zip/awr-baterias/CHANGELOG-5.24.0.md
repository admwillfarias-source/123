# AWR Baterias 5.24.0

- Página /baterias-de-carro/ ampliada: preços por amperagem, marcas, cidades e perguntas frequentes.
- Post de Gravataí atualizado (sem datas antigas, preços de R$ 329 a R$ 2.575, prazo de 35 min).
- Garantia Heliar padronizada (15 a 24 meses conforme o modelo) e Pix com 3% em todo o blog.
- robots.txt reorganizado: linhas Sitemap agrupadas no final.
