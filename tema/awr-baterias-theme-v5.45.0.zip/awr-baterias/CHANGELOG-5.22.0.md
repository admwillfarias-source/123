# 5.22.0

- Caminhão: seletor mostra produtos reais do WooCommerce por amperagem (corrige 150Ah aparecendo com 100Ah); funciona sem JS via ?ah=.
- Moto: busca sugere CG 150, Z900 e Tiger 800.
- Estacionária: lista da categoria estacionaria do WooCommerce na página e atalho [awr_estacionarias] para páginas do painel.
