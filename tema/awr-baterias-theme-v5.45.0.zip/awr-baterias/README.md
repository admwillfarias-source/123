# AWR Baterias — Tema WordPress

Porte completo do app **Speedy Battery Connect** (TanStack Start) para um tema
WordPress nativo. Todas as funções do app rodam aqui **sem iframe**: busca de
bateria por veículo/SKU/amperagem, preços e fotos reais do WooCommerce, páginas
de cidade, lojas, marcas, aplicações, blog, checkout rápido e medição GTM/GA4.

## Instalação (e o que fazer se o WordPress recusar o ZIP)

Envie por **Aparência > Temas > Adicionar novo > Enviar tema**. Se der erro:

1. **"A pasta de destino já existe"** — o tema já está instalado. Na tela que
   aparece, escolha **"Substituir o atual pelo enviado"**. O WordPress só oferece
   a atualização quando a versão do pacote é maior que a instalada — por isso
   cada build sobe o número da versão.
2. **"Não foi encontrado nenhum tema válido" / "O pacote não pôde ser instalado"**
   — o arquivo foi descompactado e recompactado (Mac/Windows criam uma pasta
   extra e arquivos ocultos como `__MACOSX`). Baixe o ZIP e envie **sem abrir**.
3. **"O arquivo enviado excede o tamanho máximo" ou tela em branco no upload** —
   limite da hospedagem. Use o pacote **`awr-baterias-theme-vX-leve.zip`**
   (~1,0 MB, sem os JSON já compilados em `assets/data-php`), ou peça para a
   hospedagem elevar `upload_max_filesize` e `post_max_size` para 8M.
4. **Instalação manual (sempre funciona)** — descompacte no seu computador e
   envie a pasta `awr-baterias/` por FTP ou Gerenciador de Arquivos para
   `wp-content/themes/`, substituindo a existente. Depois ative em
   Aparência > Temas e limpe o cache do site.

O empacotamento valida automaticamente cada ZIP antes de publicar: raiz única
`awr-baterias/`, `style.css` presente com `Version:` igual à do tema, nenhum
arquivo oculto/`__MACOSX`, sem pasta aninhada e tamanho abaixo de 2 MB.

## Versão 3.55.4

- **Build à prova de recusa do WordPress:** nova verificação `verify_zip()` no
  `build-theme.py` aborta o empacotamento se o pacote tiver pasta aninhada,
  dotfiles, `style.css` fora da raiz ou com versão dessincronizada, ou passar de
  2 MB. Publicado também um pacote **leve** (`-leve.zip`) para hospedagens com
  limite baixo de upload — mantém `stores.json` (único JSON lido pelo JS) e
  descarta os demais, já compilados em `assets/data-php`.
- Sem qualquer alteração de layout, CSS ou JS em relação à v3.55.3.

## Versão 3.54.0

- **Faixa de plantão removida (mobile e desktop):** o bloco `.awr-emergency` ("● Plantão ativo") saiu do `header.php`; o cabeçalho fixo (`.awr-header`) é agora o primeiro elemento da página. Handlers `data-awr-emergency` removidos de `awr-core.js`/`awr-search.js` e todo o CSS correspondente limpo em `awr.css`, `awr-critical.css`, `awr-parity.css` e `awr-overrides.css` (sem CSS morto nem espaço fantasma).
- **Busca 25px mais alta no mobile:** `.awr-searchband` passou de `padding-top:30px` para `10px` e o encaixe `hero + searchband` de `-8px` para `-13px` em telas ≤767px. O selo "Busque sua bateria aqui" mantém a folga reservada (`padding-top:22px` no card) e o cabeçalho sticky continua sem sobrepor o campo.
- Telefone e WhatsApp seguem disponíveis no cabeçalho, no hero, na barra fixa mobile e no rodapé.

## Versão 3.53.5

- **Corrigido erro fatal no `header.php`:** a remoção da faixa de boas-vindas deixou um `if ( ! $awr_embed ) :` aberto e vazio antes do `<div id="awr-app">`, com apenas um `endif` no arquivo. O PHP acusava "fim de arquivo inesperado, esperava-se elseif/else/endif" na linha 111 e o site caía com erro crítico. O bloco vazio foi removido; o condicional legítimo (skip link, plantão, cabeçalho e menu lateral) segue intacto.
- Lint de balanceamento de sintaxe alternativa rodado em todos os arquivos PHP do tema: OK.

## Versão 3.53.4


- **Sem sobreposição no mobile:** `.awr-emergency` recebeu `position:relative;z-index:1`, altura mínima flexível (56px no mobile) e padding vertical próprio, então o plantão ativo nunca fica sob o cabeçalho fixo nem colide com o bloco de busca.
- **Espaçamentos consistentes:** hero → `.awr-searchband` usa `margin-top:-12px` (desktop) e `-8px` (mobile) para todas as variantes de hero (home, hubs/serviços, contatos, moto, cidade), com `padding-top` de 26px/30px que reserva espaço para o selo absoluto "Busque sua bateria aqui".
- **Acessibilidade:** botão de fechar do plantão com alvo de 44×44px, `:focus-visible` visível em links/botões/campos do topo, skip link acima dos overlays e limpeza do CSS morto da faixa removida (`.awr-intro`) em `awr-critical.css`, `awr-parity.css` e `awr-overrides.css`.

## Versão 3.53.3


- **Removida a faixa de boas-vindas do cabeçalho:** o `.awr-intro` ("AWR BATERIAS — A sua bateria entregue e instalada rapidamente em até 35 minutos!") foi removido do `header.php`. Com isso o plantão ativo (`awr-emergency`) e o cabeçalho fixo (`awr-header`) passam a ser os primeiros elementos visíveis da página, sem faixa azul acima.
- **CSS ajustado para colar o topo e subir a busca:** `awr-overrides.css` reforça `margin-top:0` e `padding-top:0` no `body`, `#awr-app`, `.awr-emergency` e `.awr-header`. `awr.css` reduz o `padding-top` do hero de `50px` para `34px` (e `24px` no mobile) e aplica `margin-top:-28px` em `.awr-hero + .awr-searchband`, puxando o bloco "Busque sua bateria aqui" para mais próximo do hero na home.

## Versão 3.53.2

- **Correção crítica do checkout sem estilo (regressão da v3.52.0):** o `awr-checkout-app.css` (layout 2 colunas, stepper, resumo, casco — paridade com o app) ficou fora do bundle CSS para carregar sob demanda, mas nenhum JS injetava a folha — `AWR.checkoutCss` era exposta e nunca consumida. O modal abria como texto puro. Novo `loadCheckoutCss()` no `awr-core.js`: injeta o `<link rel="stylesheet">` uma única vez, aguardado junto com o módulo de busca antes de abrir o checkout/modal (sem flash sem estilo), aquecido no idle em páginas com checkout e chamado defensivamente dentro do `openCheckout`. Falha do CSS não bloqueia o pedido.
- **Modal de checkout não abre mais duplicado:** o `awr-search.js` registrava a mesma delegação global de clique/tecla que o `awr-core.js` — depois que o módulo carregava, um único clique no card abria dois modais empilhados. A delegação passou a existir só no núcleo.
- **Fontes param de dar 404:** a rota `/awr-font/{arquivo}` não usa mais a extensão `.woff2` na URL — hospedagens que servem `.woff2` como arquivo estático respondiam 404 antes de o WordPress executar a reescrita. Headers de cache imutável de 1 ano + CORS mantidos; fallback para o caminho físico até as rotas serem regravadas (automático no bump de versão). Checagem do painel AWR Validação SEO atualizada para a nova URL.

## Versão 3.53.1

- **Correção crítica da busca (regressão da v3.52.0):** com o split de JS, o `awr-search.js` passou a ser carregado sob demanda — depois do `DOMContentLoaded` — mas seu bootstrap só rodava nesse evento, então o autocomplete, o seletor de ano e os resultados nunca inicializavam no widget inline. O bootstrap agora é ciente de `document.readyState` e inicializa imediatamente quando o documento já está pronto.
- **API do módulo exportada:** `awr-search.js` passa a definir `window.AWRSearch = { initSearch, openCheckout, openModal }`, que o `awr-core.js` já esperava — sem isso, os botões de checkout e o modal de busca também ficavam sem ação.
- **Init idempotente:** o widget de busca marca `data-awr-init` para não registrar listeners duplicados se o script for avaliado mais de uma vez.
- Nada muda em PHP, CSS, rotas ou no canal `/awr-busca/`.

## Versão 3.53.0

- **Validador de headers HTTP reais:** nova tabela "Headers HTTP reais (cache e compressão)" na aba Performance (Ajustes → AWR Validação SEO) chama o próprio site em loopback e confere o que o visitante recebe de verdade: compressão gzip/brotli do HTML, `s-maxage` e `ETag` da home, cache longo (≥30 dias) e compressão de texto do CSS/JS, rota `/awr-font/` com cache imutável de 1 ano + CORS, e cache curto do REST público. Resultado em cache por 10 min com botão "Rechecar agora"; falha de loopback vira aviso (não erro).
- **Checklist automático para a hospedagem:** botão "Copiar checklist" gera um texto pronto para abrir chamado no suporte, agregando todas as pendências do diagnóstico de performance + headers, com dados do ambiente (PHP, servidor, versões) no rodapé. Sem pendências, avisa que não há nada a pedir.
- **Checagem agendada com alerta de regressão:** cron diário `awr_header_check_cron` revalida os headers em background; se algum item que estava OK passa a falhar, um notice vermelho (dispensável) aparece no admin apontando os itens. Agendamento na ativação do tema (com fallback no `init`) e limpeza ao trocar de tema.
- Nada muda no front-end: todo o diagnóstico roda apenas no admin/cron.

## Versão 3.52.0

- **JS modular (maior ganho mobile):** o monólito `awr-app.js` (~85 KB) foi dividido em `awr-core.js` (~20 KB fonte; header, menu, slider, lojas, tracking) carregado em toda página com `defer`, e `awr-search.js` (~68 KB fonte; autocomplete, resultados, checkout completo) carregado **sob demanda** — no 1º foco/toque no buscador, no clique de qualquer botão de compra/checkout, ou pré-carregado no `requestIdleCallback`. Parsing/execução de ~70% do JS sai do carregamento inicial.
- **CSS do checkout sob demanda:** `awr-checkout-app.css` (~10 KB) saiu do bundle global e do enqueue; o `awr-search.js` injeta a folha só quando o módulo sobe. O bundle `awr-bundle.css` fica ~10 KB mais leve em todas as páginas.
- **Seções abaixo da dobra com `content-visibility: auto`** (`contain-intrinsic-size` sem CLS): benefícios, depoimentos, cidades, blog, FAQ, CTA final e cobertura só são layoutados/pintados ao se aproximarem do viewport.
- **Imagens do blog em WebP:** os 8 JPEGs (~695 KB) viraram WebP (~450 KB, -35%) e as referências em `posts.json` apontam para os novos arquivos; os JPEGs saíram do pacote.
- **Aba Performance no admin:** nova seção "4. Performance do servidor" em **Ajustes → AWR Validação SEO** checa PHP 8+, OPcache, compressão gzip/brotli do HTML, mod_expires, plugin de cache de página, tamanhos dos assets do tema e transients acumulados — com orientação do que pedir à hospedagem.
- **Build:** `build-theme.py` minifica todos os módulos JS (não só um) e o `parity-check.mjs` valida core+search combinados; a checagem do site publicado agora procura `awr-core.js`.
- Nada muda visualmente para o visitante; rotas, slugs e SEO intactos.

## Versão 3.51.0

- **Correção de layout em páginas internas:** rotas cujo CSS específico não era enfileirado passam a receber os arquivos `pages-*.css` corretos — `/bateria/{marca}/{cidade}/` (pages-marca), `/baterias-em/{cidade}/` de venda e `/solucoes-b2b/` (pages-hubs), hub de bairros (pages-lojas) e loja (pages-hubs). O print de página "crua" sem hero/cards estilizados era causado por esse enqueue ausente.
- **Trava de regressão no parity-check** (`node scripts/parity-check.mjs`): cada rota tem os prefixos de classe usados cruzados com o mapa de enqueue do `functions.php`, e toda rota pública precisa ter hero com H1.
- **Limpeza completa de cache no admin:** a ação "regravar rotas" agora também remove todos os transients `awr_*` (busca, produtos, avaliações, sitemaps) e limpa o object cache. Botão na página **Ajustes → AWR Validação SEO** com lembrete de limpar o cache do plugin de página (SpeedyCache etc.).
- **Validação do sitemap publicado:** novo `node scripts/validate-sitemap.mjs` percorre o índice e todos os sub-sitemaps do site ao vivo, aponta URLs duplicadas entre seções, URLs bloqueadas pelo robots.txt e amostra canonical/og:url por seção.

## Versão 3.50.0

- Fallback 404 e `index.php` com hero navy padrão, busca integrada e chips rápidos (cidades, veículos, marcas, estacionárias, lojas); rotas inválidas retornam 404 real.
- Sitemap veículo×cidade liberado para as 115 cidades ativas, com prioridade por popularidade (variantes × 2 + faixa de anos + bônus) — capitais e cobertura 35 min primeiro.
- AWR Validação SEO: aviso vermelho quando "Desencorajar mecanismos de busca" está ativo, notice global no admin e validação em lote amostrando todas as 115 cidades.
- Títulos e descrições dos hubs de marca refinados com foco em Porto Alegre.
- App: JSON-LD renomeado para "AWR Baterias — Busca de Bateria por Veículo" e hierarquia de headings corrigida (H1 → H2 na busca).

## Instalação

1. Baixe o repositório pelo GitHub (**Code → Download ZIP**) ou clone.
2. Copie a pasta `wordpress-theme/awr-baterias` para `wp-content/themes/`.
3. No painel: **Aparência → Temas → Ativar “AWR Baterias”**.
4. Vá em **Configurações → Links permanentes** e clique em *Salvar* (registra as rotas).
5. **Aparência → Personalizar → AWR — Integrações**: informe GTM ID, GA4 ID e Google Ads ID.

Requisitos: WordPress 6.2+, PHP 8.0+, WooCommerce (opcional, mas necessário para
preço/foto/pedido).

## O que já vem pronto

| Função do app | No tema |
|---|---|
| Busca por modelo + ano (autocomplete e ano automático) | `assets/js/awr-app.js` + `inc/search.php` |
| Busca por SKU (M60GD) e por amperagem (60Ah) | idem |
| Preço, foto, Pix, 10x e desconto do casco | `inc/woo.php` (usa produtos reais do WooCommerce) |
| Pedido no site (desktop) + `/pedido-confirmado?pedido=` | `inc/rest.php` + `routes/pedido.php` |
| Páginas de cidade `/baterias-em/{cidade}/` | `routes/cidade.php` |
| Lojas `/lojas/` e `/lojas/{slug}/` | `routes/lojas.php`, `routes/loja.php` |
| Marcas, marca+cidade, aplicações | `routes/marca*.php`, `routes/aplicacao.php` |
| Blog/guias com FAQ e schema Article | `routes/blog.php`, `routes/post.php` |
| Widget isolado para iframe | `/widget-busca/` (`routes/widget.php`) |
| SEO: title/description, canonical, OG, JSON-LD, sitemap | `inc/seo.php` + `/awr-sitemap.xml` |
| Performance: defer, dequeue, terceiros no idle | `inc/perf.php` |
| WhatsApp saindo do iframe (`window.top`) | `assets/js/awr-app.js` |

## Rotas registradas

```
/                            home
/buscar/?veiculo=&ano=       resultados
/baterias-em/{cidade}/       LP de cidade
/baterias/{cidade}/          301 → /baterias-em/{cidade}/
/bateria/{sku}/              página do SKU
/bateria/{marca}/{cidade}/   marca + cidade
/baterias/amperagem/{ah}/    listagem por amperagem
/bateria-para/{aplicacao}/   LP de aplicação
/marca/{marca}/              LP de marca
/lojas/  /lojas/{slug}/      lojas
/blog/   /blog/{slug}/       conteúdo
/widget-busca/               widget para iframe (noindex)
/pedido-confirmado/          confirmação (noindex, dispara purchase_confirm)
/awr-sitemap.xml             sitemap das rotas do tema
```

Envie `/awr-sitemap.xml` no Google Search Console junto ao sitemap nativo.

## API REST do tema

```
GET  /wp-json/awr/v1/sugestoes?q=onix 2018
GET  /wp-json/awr/v1/produtos?veiculo=chevrolet-onix&ano=2018
GET  /wp-json/awr/v1/produtos?sku=M60GD
GET  /wp-json/awr/v1/produtos?ah=60
POST /wp-json/awr/v1/pedido   { nome, telefone, endereco, cidade, sku, ... }
```

O POST tem honeypot e rate-limit por IP (8 tentativas / 10 min).

## Dados

Os catálogos ficam em `assets/data/*.json`, exportados do app:
`batteries.json` (veículos × SKU), `stores.json`, `cidades.json`, `marcas.json`,
`aplicacoes.json`, `posts.json`, `depoimentos.json`, `google-reviews.json`.
Para atualizar, basta substituir o JSON — nenhum código precisa mudar.

Preço e foto **não** vêm do JSON: são lidos do WooCommerce por SKU
(`wc_get_product_id_by_sku`), com cache de 1 hora. Cadastre o SKU exatamente
como no catálogo (ex.: `M60GD`) para o casamento funcionar.

## Medição (GTM / GA4)

Eventos disparados no `dataLayer`: `search_submit`, `search_select`,
`view_item_list`, `whatsapp_click`, `begin_checkout` e `purchase_confirm`
(com `transaction_id`). Crie no GTM um gatilho *Custom Event* para
`purchase_confirm` e conecte às tags GA4 Purchase e Google Ads Conversion.

O tema já adia GTM e Google tag (1ª interação / idle, com envio garantido na
saída da página) e remove tags duplicadas de plugins. O peso restante vem das
tags configuradas **dentro do painel do GTM** — revise e desative as que não
estão em uso (Snapchat Pixel, Reddit Pixel, Site Kit/WooCommerce events e
tags antigas de campanhas encerradas). Isso é feito no GTM, não no tema.

### Cache de CSS/JS (v3.75.0)

Estilos e scripts do tema saem por `/awr-asset/{css|js}/{nome}`, que envia
`Cache-Control: public, max-age=31536000, immutable`. Como a versão do arquivo
segue na URL (`?ver=`), toda atualização do tema gera um endereço novo. Se a
rota não estiver ativa (rewrites ainda não gravadas), o tema volta sozinho ao
caminho padrão `/wp-content/themes/...`. Em **AWR → Validação** há a linha
"Rota /awr-asset/ — cache imutável de CSS/JS" para conferir.

**Cloudflare:** a borda pode reescrever o `max-age` conforme o Browser TTL
configurado nela (ex.: 7 dias). Com `immutable` + 7 dias o navegador já não
revalida — o painel marca como aviso, não erro. Para 1 ano de ponta a ponta,
crie na Cloudflare uma **Cache Rule** para `/awr-asset/*` com Browser TTL de
1 ano (Cache → Cache Rules).

## Personalização rápida

- Cores e espaçamentos: variáveis `--awr-*` no topo de `assets/css/awr.css`.
- Textos de contato: função `awr_company()` em `functions.php`.
- Menus: **Aparência → Menus** (localizações `primary` e `footer`).
- Logo: **Personalizar → Identidade do site → Logo**.

## Home nativa do tema (sem iframe)

A partir da v1.2.0 o tema assume o `/` automaticamente com `front-page.php`
(hero + busca + como funciona + prova social + cidades + FAQ + CTA final),
mesmo que exista uma página estática do Elementor definida como home.

Depois de ativar o tema:

1. **Configurações → Links permanentes → Salvar** (recarrega as rotas virtuais).
2. **Configurações → Leitura** — pode deixar como está; se preferir limpar,
   escolha "Seus posts mais recentes" ou crie uma página vazia chamada `Home`.
3. **Elementor → Theme Builder** — desative/exclua templates com a condição
   "Página inicial", "Cabeçalho" e "Rodapé" (o tema já traz os seus).
4. Limpe o cache (plugin de cache e Cloudflare).
5. A página antiga com o `<iframe>` pode ser excluída — ela não é mais usada.

Para voltar a usar a home do construtor, adicione em um plugin/child theme:

```php
add_filter( 'awr_force_front_page', '__return_false' );
```

## Fotos e mapas reais das lojas (Google Places)

O app usa a API do Google Places para exibir foto, nota, telefone e horários
reais de cada unidade. O tema faz o mesmo a partir da v3.8.0. Para ativar:

```php
// wp-config.php
define( 'AWR_GOOGLE_MAPS_KEY', 'sua-chave' ); // Places API (New) + Maps Embed API
```

- Sem a chave, o tema usa `assets/img/lojas/{slug}.jpg` (ou `cover.jpg`) e o mapa
  por endereço — nada quebra.
- As fotos são servidas pelo proxy `/(wp-json)/awr/v1/store-photo`, então a chave
  nunca aparece no HTML.
- Cache de 6h em transients (`awr_place_*`, `awr_photo_*`).

## Páginas de bairro (v3.8.0)

- `/baterias-bairro/{cidade}/` — hub com todos os bairros da cidade.
- `/baterias-bairro/{cidade}/{bairro}/` — página local com H1, busca, loja
  responsável, FAQ e JSON-LD (LocalBusiness + BreadcrumbList + FAQPage).
- Incluídas no `awr-sitemap-bairros.xml` e linkadas nas páginas de cidade.
