# 5.36.1 — abertura do site lenta
- CSS, JS e fontes do tema voltam a ser entregues pelo arquivo real (/wp-content/themes/awr-baterias/assets/...). As rotas /awr-asset/ e /awr-font/ faziam cada arquivo subir o WordPress inteiro (≈7 execuções de PHP por visita) e, sem extensão na URL, a Cloudflare não guardava em cache.
- As rotas antigas continuam respondendo, para páginas antigas ainda em cache. Para religar: add_filter( 'awr_assets_via_php', '__return_true' ).
- Limpeza automática de cache na troca de versão passa a rodar só no painel (admin), não na visita de um cliente.
- Depois de instalar: abra o painel uma vez, limpe o cache da Cloudflare e defina Browser Cache TTL de 1 ano (ou copie o htaccess-exemplo.txt).
