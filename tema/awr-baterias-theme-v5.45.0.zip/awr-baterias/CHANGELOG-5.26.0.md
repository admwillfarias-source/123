# AWR Baterias 5.26.0

Arquivos alterados e motivo:
- assets/css/awr-critical.css — inclui as regras finais do cabeçalho e do hero (extraídas do bundle com wordpress-theme/tools/extrair-css-critico.py) e fontes de reserva "Figtree Fallback"/"Outfit Fallback" com métricas ajustadas: o topo nasce com o tamanho final (CLS do hero).
- assets/css/awr.css, awr-final.css — transições genéricas ("transition: .2s", equivalente a all) trocadas por cor/fundo/borda/transform/opacity; removida a transição de altura do cabeçalho.
- assets/css/*.css — laranja #ea580c → #c2410c (contraste 5,2:1 com branco): botões com contorno, "Busque sua bateria aqui", "Buscar bateria".
- assets/css/awr-final.css — fundo sólido de reserva no rodapé; "Responde em 2 min" em branco pleno.
- assets/js/awr-core.js — awr-search.js não é mais baixado ao abrir a página; carrega no 1º foco/toque na busca, reaplicando o clique (abas/chips) e o texto digitado.
- functions.php, style.css — versão.

Origem do GTM-TDZQBM2P: opção "GTM ID" do tema (Personalizar → AWR — Integrações), que sobrescreve o padrão GTM-5JTRM2L. Nenhuma tag removida do código: GA4 e Ads seguem pelo gtag do tema; as tags duplicadas e a de Ads com 404 devem sair de dentro do contêiner no GTM.
