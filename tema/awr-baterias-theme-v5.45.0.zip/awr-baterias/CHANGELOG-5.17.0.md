# AWR Baterias, tema v5.17.0 (sobre a v5.16.1)

Não testado em WordPress ao vivo. Valide em homologação antes de publicar.

## O que mudou

1. **H1s da planilha "Metas por URL" aplicados (51 páginas)**
   - `inc/seo-lote.php`: nova função `awr_seo_lote_h1()` com o mapa path => H1 sugerido.
   - O H1 sugerido tem prioridade sobre o H1 padrão da rota em:
     - `template-parts/hero.php` (veículos, modelos, veículo×cidade, segmentos e demais rotas que usam o hero padrão);
     - `routes/cidade.php` (páginas /baterias-em/{cidade}/);
     - `routes/produto.php` (páginas de produto);
     - `routes/post.php` (artigos do blog).
   - A home foi mantida com o H1 atual ("Baterias para carros, motos e caminhões…"), escolhido anteriormente — a sugestão da planilha ("Baterias em Porto Alegre") não foi aplicada para não perder o texto de conversão.
2. Versão 5.17.0 em `style.css` e `functions.php`.

## Checklist de testes

- view-source de `/baterias-em/novo-hamburgo/`: H1 deve ser "Bateria em Novo Hamburgo: Entrega e Troca em 35 Min".
- `/baterias/jeep/renegade-com-start-stop/2019/`: H1 "Bateria Renegade Start-Stop 2019: Modelo Certo e Preço".
- `/produto/bateria-moura-60ah-m60ge/`: H1 "Bateria Moura 60Ah M60GE: Preço e Entrega".
- `/blog/carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser/`: H1 "Carro Não Liga e Faz Estalo: Causas e Como Resolver".
- Home: H1 inalterado.
- Páginas fora da lista: H1 padrão da rota inalterado.
