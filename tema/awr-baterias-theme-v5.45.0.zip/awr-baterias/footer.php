<?php
/**
 * Rodapé do tema.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_c     = awr_contact();
$awr_embed = 'widget' === awr_current_route() || '1' === (string) get_query_var( 'embed' );
$awr_product_offer = $GLOBALS['awr_product_mobile_offer'] ?? null;
?>
</main>

<?php if ( ! $awr_embed ) : ?>
<footer class="awr-footer">
	<div class="awr-container awr-footer__cta"><div><b>⚡ Bateria agora? Estamos de plantão.</b><span>Média de resposta no WhatsApp: menos de 2 minutos.</span></div><p><a class="awr-btn awr-btn--green" href="<?php echo esc_url( awr_wa( 'Olá! Preciso de uma bateria agora.' ) ); ?>">WhatsApp</a><a class="awr-btn awr-btn--gold" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>"><?php echo esc_html( $awr_c['phone'] ); ?></a></p></div>
	<div class="awr-container awr-footer__grid">
		<div>
			<h3 class="awr-fwidget__title awr-footer__brand">▣ <span>AWR</span>BATERIAS</h3>
			<p>Entrega e instalação de bateria em até 35 minutos em Porto Alegre e Grande Porto Alegre.</p>
			<p>
				<a href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>"><?php echo esc_html( $awr_c['phone'] ); ?></a><br>
				<a target="_top" href="<?php echo esc_url( awr_wa( 'Olá! Quero um orçamento de bateria.' ) ); ?>">WhatsApp <?php echo esc_html( $awr_c['whatsapp'] ); ?></a><br>
				<a href="mailto:<?php echo esc_attr( $awr_c['email'] ); ?>"><?php echo esc_html( $awr_c['email'] ); ?></a>
			</p>
		</div>

		<div>
			<h3 class="awr-fwidget__title">Cidades atendidas</h3>
			<ul class="awr-footer__list">
				<?php foreach ( array_slice( awr_cidades(), 0, 10 ) as $cid ) : ?>
					<li><a href="<?php echo esc_url( home_url( '/baterias-em/' . $cid['slug'] . '/' ) ); ?>">Bateria em <?php echo esc_html( $cid['nome'] ); ?></a></li>
				<?php endforeach; ?>
				<?php foreach ( awr_marca_cidades_envio() as $awr_fenv ) :
					$awr_fcv = function_exists( 'awr_cidade_venda_by_slug' ) ? awr_cidade_venda_by_slug( $awr_fenv ) : null;
					if ( ! $awr_fcv ) { continue; }
					?>
					<li><a href="<?php echo esc_url( home_url( '/baterias-em/' . $awr_fcv['slug'] . '/' ) ); ?>">Bateria em <?php echo esc_html( $awr_fcv['nome'] ); ?> (envio)</a></li>
				<?php endforeach; ?>
			</ul>
		</div>

		<div>
			<?php
			// v3.81.0 — widgets do rodapé sem listas vazias (ex.: "Nenhuma categoria" do blog).
			if ( is_active_sidebar( 'awr-footer' ) ) {
				ob_start();
				dynamic_sidebar( 'awr-footer' );
				$awr_fw = (string) ob_get_clean();
				if ( false === strpos( $awr_fw, 'cat-item-none' ) ) {
					echo $awr_fw; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
			}
			?>
			<h3 class="awr-fwidget__title">Marcas</h3>
			<ul class="awr-footer__list">
				<?php foreach ( awr_marcas() as $mk ) : ?>
					<li><a href="<?php echo esc_url( home_url( '/marca/' . $mk['slug'] . '/' ) ); ?>">Bateria <?php echo esc_html( $mk['nome'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>

		</div>
		<div>
			<h3 class="awr-fwidget__title">Categorias</h3>
			<ul class="awr-footer__list">
				<?php foreach ( awr_segmentos() as $sg ) : ?>
					<li><a href="<?php echo esc_url( awr_segmento_url( $sg ) ); ?>"><?php echo esc_html( $sg['nome'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>

		</div>
	</div>
	<div class="awr-container awr-footer__explore">
			<h3 class="awr-fwidget__title">Explore a AWR</h3>
			<ul class="awr-footer__list">
				<li><a href="<?php echo esc_url( home_url( '/baterias-em/' ) ); ?>">Todas as cidades atendidas</a></li>
				<li><a href="<?php echo esc_url( home_url( '/marca/' ) ); ?>">Todas as marcas</a></li>
				<li><a href="<?php echo esc_url( home_url( '/bateria-para/' ) ); ?>">Bateria por tipo de veículo</a></li>
				<li><a href="<?php echo esc_url( home_url( '/baterias/amperagem/' ) ); ?>">Baterias por amperagem</a></li>
				<li><a href="<?php echo esc_url( home_url( '/baterias/' ) ); ?>">Todos os modelos de bateria</a></li>
				<li><a href="<?php echo esc_url( home_url( '/categorias/' ) ); ?>">Tipos de bateria (AGM, EFB, náutica)</a></li>
				<li><a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>">Blog e guias</a></li>
				<li><a href="<?php echo esc_url( home_url( '/bateria-a-domicilio-porto-alegre/' ) ); ?>">Bateria a domicílio em Porto Alegre</a></li>
				<li><a href="<?php echo esc_url( home_url( '/bateria-perto-de-mim/' ) ); ?>">Bateria perto de mim</a></li>
				<li><a href="<?php echo esc_url( home_url( '/socorro-bateria/' ) ); ?>">Socorro de bateria (carro não liga)</a></li>
				<li><a href="<?php echo esc_url( home_url( '/parceiros/' ) ); ?>">Seja parceiro</a></li>
			</ul>
	</div>
	<div class="awr-container awr-footer__stores"><h3>Nossas lojas</h3><ul><?php foreach ( awr_stores() as $st ) : ?><li><b><a href="<?php echo esc_url( home_url( '/lojas/' . $st['slug'] . '/' ) ); ?>">AWR Baterias — <?php echo esc_html( $st['nome'] ); ?></a></b><span><?php echo esc_html( $st['enderecoCompleto'] ); ?></span><a href="<?php echo esc_attr( $st['telefoneHref'] ); ?>"><?php echo esc_html( $st['telefone'] ); ?></a><small><?php echo esc_html( $st['horarios']['semana'] ?? '' ); ?><?php echo ! empty( $st['horarios']['sabado'] ) ? ' · ' . esc_html( $st['horarios']['sabado'] ) : ''; ?></small></li><?php endforeach; ?></ul></div>


	<div class="awr-container awr-footer__legal">
		<p><strong>AWR Baterias — a bateria que chega até você. AWR Energia — a bateria certa para seu sistema.</strong></p>
		<p><a href="<?php echo esc_url( home_url( '/garantia/' ) ); ?>">Solicitar garantia</a> · <a href="<?php echo esc_url( home_url( '/rastrear-pedido/' ) ); ?>">Rastrear pedido</a> · <a href="<?php echo esc_url( home_url( '/comparar/' ) ); ?>">Comparar baterias</a> · <a href="<?php echo esc_url( home_url( '/central-tecnica/' ) ); ?>">Central Técnica</a></p>
		<p><?php echo esc_html( awr_company()['razao_social'] ); ?></p>
		<p>CNPJ: <?php echo esc_html( awr_company()['cnpj'] ); ?></p>
	</div>
	<div class="awr-container awr-footer__bottom">
		<span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> AWR Baterias — Porto Alegre / RS</span>
		<span><?php echo esc_html( $awr_c['rating'] ); ?>★ · <?php echo esc_html( $awr_c['reviews'] ); ?>+ avaliações no Google</span>
	</div>
</footer>

<!-- Barra fixa mobile (mesma do app) -->
<div class="awr-mobilebar" role="navigation" aria-label="Ações rápidas" data-awr-mobilebar>
	<?php if ( $awr_product_offer ) : ?>
	<div class="awr-mobilebar__price"><small>À vista</small><b><?php echo $awr_product_offer['price'] ? esc_html( awr_brl( $awr_product_offer['price'] ) ) : 'Consulte'; ?></b></div>
	<button type="button" class="awr-mobilebar__btn awr-mobilebar__btn--buy" data-awr-checkout data-sku="<?php echo esc_attr( $awr_product_offer['sku'] ); ?>" data-nome="<?php echo esc_attr( $awr_product_offer['nome'] ); ?>" data-preco="<?php echo esc_attr( $awr_product_offer['price'] ); ?>" data-pid="<?php echo esc_attr( $awr_product_offer['pid'] ); ?>" data-casco="<?php echo esc_attr( $awr_product_offer['casco'] ); ?>"><b>⚡ Comprar e instalar</b><small>Finalizar pedido</small></button>
	<a class="awr-mobilebar__btn awr-mobilebar__btn--wa awr-mobilebar__btn--mini" target="_top" rel="noopener" aria-label="Pedir esta bateria pelo WhatsApp"
	   href="<?php echo esc_url( awr_wa( 'Olá! Quero PEDIR esta bateria: ' . $awr_product_offer['nome'] . ' (SKU ' . $awr_product_offer['sku'] . ').' ) ); ?>">
		<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M12.04 2c-5.5 0-9.96 4.46-9.96 9.96 0 1.76.46 3.48 1.34 5L2 22l5.2-1.36a9.9 9.9 0 0 0 4.84 1.24h.01c5.5 0 9.96-4.46 9.96-9.96S17.54 2 12.04 2zm5.83 14.06c-.24.68-1.4 1.3-1.94 1.35-.5.05-1.13.07-1.82-.11-.42-.13-.96-.31-1.65-.61-2.9-1.25-4.8-4.17-4.95-4.37-.14-.2-1.18-1.57-1.18-3s.75-2.13 1.02-2.42c.27-.29.58-.36.78-.36h.56c.18 0 .42-.07.66.5.24.58.82 2 .89 2.15.07.14.12.31.02.5-.09.2-.14.31-.28.48-.14.16-.29.36-.42.49-.14.14-.28.29-.12.57.16.27.71 1.17 1.53 1.9 1.05.94 1.94 1.23 2.21 1.37.27.14.43.12.59-.07.16-.2.68-.79.86-1.07.18-.27.36-.22.6-.13.25.09 1.57.74 1.84.88.27.13.45.2.51.31.07.11.07.63-.17 1.24z"/></svg>
	</a>
	<?php else : ?>
	<a class="awr-mobilebar__btn awr-mobilebar__btn--call" data-awr-source="mobilebar" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">
		<b><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg> Ligar</b><small>Atende agora</small>
	</a>
	<a class="awr-mobilebar__btn awr-mobilebar__btn--wa awr-mobilebar__btn--wide" data-awr-source="mobilebar" data-awr-wa-ctx target="_top" rel="noopener"
	   href="<?php echo esc_url( awr_wa( 'Olá! Preciso de bateria agora.' ) ); ?>">
		<b><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12.04 2c-5.5 0-9.96 4.46-9.96 9.96 0 1.76.46 3.48 1.34 5L2 22l5.2-1.36a9.9 9.9 0 0 0 4.84 1.24h.01c5.5 0 9.96-4.46 9.96-9.96S17.54 2 12.04 2zm5.83 14.06c-.24.68-1.4 1.3-1.94 1.35-.5.05-1.13.07-1.82-.11-.42-.13-.96-.31-1.65-.61-2.9-1.25-4.8-4.17-4.95-4.37-.14-.2-1.18-1.57-1.18-3s.75-2.13 1.02-2.42c.27-.29.58-.36.78-.36h.56c.18 0 .42-.07.66.5.24.58.82 2 .89 2.15.07.14.12.31.02.5-.09.2-.14.31-.28.48-.14.16-.29.36-.42.49-.14.14-.28.29-.12.57.16.27.71 1.17 1.53 1.9 1.05.94 1.94 1.23 2.21 1.37.27.14.43.12.59-.07.16-.2.68-.79.86-1.07.18-.27.36-.22.6-.13.25.09 1.57.74 1.84.88.27.13.45.2.51.31.07.11.07.63-.17 1.24z"/></svg> WhatsApp agora</b><small>Responde em 2 min</small>
	</a>
	<?php endif; ?>
</div>

<!-- 5.43.0 — paridade com o MobileBar do app: enquanto a pessoa digita na busca a barra
     some e fica só o botão redondo de WhatsApp; com o resultado na tela vira "Socorro Rápido". -->
<a class="awr-fab" data-awr-fab data-awr-wa-ctx target="_top" rel="noopener" data-awr-source="mobile_fab" aria-label="Socorro rápido pelo WhatsApp" href="<?php echo esc_url( awr_wa( 'Olá! Preciso de uma bateria.' ) ); ?>">
	<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/></svg><span>Socorro Rápido</span>
</a>

<!-- v5.0.0 — bloco fixo de contato no computador -->
<div class="awr-deskdock" aria-label="Fale com a AWR agora">
	<a class="awr-deskdock__btn awr-deskdock__btn--wa" data-awr-source="float" data-awr-wa-ctx target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Preciso de bateria agora.' ) ); ?>">
		<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"><path d="M12.04 2c-5.5 0-9.96 4.46-9.96 9.96 0 1.76.46 3.48 1.34 5L2 22l5.2-1.36a9.9 9.9 0 0 0 4.84 1.24h.01c5.5 0 9.96-4.46 9.96-9.96S17.54 2 12.04 2zm5.83 14.06c-.24.68-1.4 1.3-1.94 1.35-.5.05-1.13.07-1.82-.11-.42-.13-.96-.31-1.65-.61-2.9-1.25-4.8-4.17-4.95-4.37-.14-.2-1.18-1.57-1.18-3s.75-2.13 1.02-2.42c.27-.29.58-.36.78-.36h.56c.18 0 .42-.07.66.5.24.58.82 2 .89 2.15.07.14.12.31.02.5-.09.2-.14.31-.28.48-.14.16-.29.36-.42.49-.14.14-.28.29-.12.57.16.27.71 1.17 1.53 1.9 1.05.94 1.94 1.23 2.21 1.37.27.14.43.12.59-.07.16-.2.68-.79.86-1.07.18-.27.36-.22.6-.13.25.09 1.57.74 1.84.88.27.13.45.2.51.31.07.11.07.63-.17 1.24z"/></svg>
		<span><b>Pedir no WhatsApp</b><small>Resposta em ~2 min</small></span>
	</a>
	<a class="awr-deskdock__btn awr-deskdock__btn--call" data-awr-source="desktop_float" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">
		<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
		<span><b><?php echo esc_html( $awr_c['phone'] ); ?></b><small>Ligar para a central</small></span>
	</a>
</div>

<?php endif; ?>

</div><!-- #awr-app -->
<?php wp_footer(); ?>
</body>
</html>
