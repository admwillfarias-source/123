<?php
/**
 * 5.56.0 — Checkout novo (Bateria → Entrega → Pagamento): servidor.
 *
 * 1. awr_entrega_cotacao(): fonte única de região, prazo e taxa. Junta as
 *    regras que até a 5.55 viviam separadas:
 *      - navegador (awr-search.js: Ee/ke/_a/Ae) — região rápida pelas 12
 *        cidades, horário (POA 06:30–22:00 todos os dias; demais 09:00–18:00
 *        em dia útil), plantão POA R$ 60, mais de 12 km da loja R$ 20;
 *      - servidor (inc/frete-cep.php) — faixas de CEP mesmo dia R$ 20 e
 *        transportadora R$ 50/75, que já sobrescreviam a taxa no pedido;
 *      - cidades (inc/city-delivery.php) — "mesmo dia" / "dia seguinte".
 *    A ordem é a mesma que o pedido já cobrava: taxa do navegador, depois a
 *    faixa de CEP por cima. A diferença é que agora a tela mostra esse valor.
 * 2. Endpoints awr/v1/cotacao e awr/v1/lead (+ ações no canal /awr-busca/).
 * 3. Leads de abandono (só com aceite): post privado awr_lead, tela
 *    WooCommerce → Checkouts abandonados, exclusão em 30 dias.
 * 4. Idempotência do pedido (pedido_token) — usada por awr_create_order().
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Checkout novo ligado? (Configurações → AWR Busca; padrão: sim). */
function awr_checkout_v2_ativo() {
	return (bool) apply_filters( 'awr_checkout_v2', '0' !== (string) get_option( 'awr_checkout_v2', '1' ) );
}

/* ---------------------------------------------------------------------
   Regras de entrega (mesmos números do awr-search.js)
   --------------------------------------------------------------------- */

/** Cidades com entrega rápida (lista `ya` do navegador). */
function awr_co_cidades_rapidas() {
	return array(
		'Porto Alegre'    => array( -30.0346, -51.2177 ),
		'Viamão'          => array( -30.0811, -51.0233 ),
		'Alvorada'        => array( -29.9914, -51.0809 ),
		'Canoas'          => array( -29.9177, -51.1836 ),
		'Gravataí'        => array( -29.9444, -50.9919 ),
		'Cachoeirinha'    => array( -29.9511, -51.0939 ),
		'São Leopoldo'    => array( -29.7603, -51.1472 ),
		'Sapucaia do Sul' => array( -29.8277, -51.145 ),
		'Esteio'          => array( -29.8608, -51.1789 ),
		'Novo Hamburgo'   => array( -29.6883, -51.1306 ),
		'Estância Velha'  => array( -29.6483, -51.1739 ),
		'Ivoti'           => array( -29.5919, -51.1608 ),
	);
}

/** Lojas (lista `Da` do navegador), para a taxa de distância. */
function awr_co_lojas_coords() {
	return array( array( -30.0532, -51.223 ), array( -30.0359, -51.1786 ), array( -29.9237, -51.181 ), array( -29.9498, -51.0207 ), array( -29.7755, -51.1393 ), array( -29.6768, -51.1278 ) );
}

/** Feriados (lista `we` do navegador). */
function awr_co_feriados() {
	return array( '2026-01-01', '2026-02-02', '2026-02-16', '2026-02-17', '2026-04-03', '2026-04-21', '2026-05-01', '2026-06-04', '2026-09-07', '2026-09-20', '2026-10-12', '2026-11-02', '2026-11-15', '2026-11-20', '2026-12-25', '2027-01-01', '2027-02-02', '2027-02-08', '2027-02-09', '2027-03-26', '2027-04-21', '2027-05-01', '2027-05-27', '2027-09-07', '2027-09-20', '2027-10-12', '2027-11-02', '2027-11-15', '2027-11-20', '2027-12-25', '2028-01-01', '2028-02-02', '2028-02-28', '2028-02-29', '2028-04-14', '2028-04-21', '2028-05-01', '2028-06-15', '2028-09-07', '2028-09-20', '2028-10-12', '2028-11-02', '2028-11-15', '2028-11-20', '2028-12-25' );
}

function awr_co_norm( $s ) {
	$s = remove_accents( (string) $s );
	return trim( preg_replace( '/\s+/', ' ', str_replace( '-', ' ', strtolower( $s ) ) ) );
}

/** Cidade rápida correspondente (mesma comparação do navegador: igual ou prefixo). */
function awr_co_cidade_rapida( $cidade ) {
	$e = awr_co_norm( $cidade );
	if ( '' === $e ) { return null; }
	foreach ( awr_co_cidades_rapidas() as $nome => $ll ) {
		$n = awr_co_norm( $nome );
		if ( $n === $e || 0 === strpos( $n, $e ) || 0 === strpos( $e, $n ) ) { return array( 'nome' => $nome, 'll' => $ll ); }
	}
	return null;
}

function awr_co_eh_poa( $cidade ) {
	$e = awr_co_norm( $cidade );
	return '' === $e || 'porto alegre' === $e || 'poa' === $e;
}

function awr_co_km( $a, $b ) {
	$r  = M_PI / 180;
	$la = ( $b[0] - $a[0] ) * $r;
	$lo = ( $b[1] - $a[1] ) * $r;
	$h  = pow( sin( $la / 2 ), 2 ) + cos( $a[0] * $r ) * cos( $b[0] * $r ) * pow( sin( $lo / 2 ), 2 );
	return 2 * 6371 * asin( sqrt( $h ) );
}

/** Distância da cidade até a loja mais próxima (null se a cidade não é da lista). */
function awr_co_km_loja( $cidade ) {
	$c = awr_co_cidade_rapida( $cidade );
	if ( ! $c ) { return null; }
	$min = null;
	foreach ( awr_co_lojas_coords() as $l ) {
		$d = awr_co_km( $c['ll'], $l );
		if ( null === $min || $d < $min ) { $min = $d; }
	}
	return $min;
}

/** Janela de atendimento em minutos do dia (null = fechado o dia todo). */
function awr_co_janela( $cidade, DateTimeInterface $dt ) {
	if ( awr_co_eh_poa( $cidade ) ) { return array( 390, 1320 ); }
	$dow = (int) $dt->format( 'w' );
	if ( 0 === $dow || 6 === $dow || in_array( $dt->format( 'Y-m-d' ), awr_co_feriados(), true ) ) { return null; }
	return array( 540, 1080 );
}

/** Taxa por horário/distância (função `ke` do navegador). */
function awr_co_taxa_horario( $cidade, DateTimeInterface $dt ) {
	$j   = awr_co_janela( $cidade, $dt );
	$min = (int) $dt->format( 'G' ) * 60 + (int) $dt->format( 'i' );
	if ( ! $j || $min < $j[0] || $min > $j[1] ) { return 0.0; }
	if ( ! awr_co_eh_poa( $cidade ) ) {
		$km = awr_co_km_loja( $cidade );
		return null !== $km && $km > 12 ? (float) ( defined( 'AWR_TAXA_DISTANCIA' ) ? AWR_TAXA_DISTANCIA : 20 ) : 0.0;
	}
	return ( $min >= 390 && $min <= 510 ) || ( $min >= 1081 && $min <= 1320 ) ? (float) ( defined( 'AWR_TAXA_PLANTAO' ) ? AWR_TAXA_PLANTAO : 60 ) : 0.0;
}

function awr_co_aberto( $cidade, DateTimeInterface $dt ) {
	$j   = awr_co_janela( $cidade, $dt );
	$min = (int) $dt->format( 'G' ) * 60 + (int) $dt->format( 'i' );
	return $j && $min >= $j[0] && $min <= $j[1];
}

/** Endereço do CEP (ViaCEP), com cache de 30 dias (falha: 10 min). */
function awr_co_endereco_cep( $cep ) {
	$cep = preg_replace( '/\D/', '', (string) $cep );
	if ( 8 !== strlen( $cep ) ) { return null; }
	$key = 'awr_cep_' . $cep;
	$c   = get_transient( $key );
	if ( is_array( $c ) ) { return $c['ok'] ? $c : null; }
	$out = array( 'ok' => false );
	$res = wp_remote_get( 'https://viacep.com.br/ws/' . $cep . '/json/', array( 'timeout' => 4 ) );
	if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
		$j = json_decode( (string) wp_remote_retrieve_body( $res ), true );
		if ( is_array( $j ) && empty( $j['erro'] ) && ! empty( $j['localidade'] ) ) {
			$out = array( 'ok' => true, 'rua' => (string) ( $j['logradouro'] ?? '' ), 'bairro' => (string) ( $j['bairro'] ?? '' ), 'cidade' => (string) $j['localidade'], 'uf' => strtoupper( (string) ( $j['uf'] ?? '' ) ) );
		}
	}
	set_transient( $key, $out, $out['ok'] ? 30 * DAY_IN_SECONDS : 10 * MINUTE_IN_SECONDS );
	return $out['ok'] ? $out : null;
}

/** Dados da cidade (assets/data/cidades.json) pelo nome. */
function awr_co_cidade_dados( $cidade ) {
	$e = awr_co_norm( $cidade );
	foreach ( (array) ( function_exists( 'awr_cidades' ) ? awr_cidades() : array() ) as $c ) {
		if ( isset( $c['nome'] ) && awr_co_norm( $c['nome'] ) === $e ) { return $c; }
	}
	return null;
}

/**
 * Cotação de entrega — o que a tela mostra é o que o pedido cobra.
 *
 * @param string $cep    CEP (8 dígitos).
 * @param array  $o      quando (timestamp), tipo (rapida|agendada|retirada),
 *                       peso (kg), cidade/uf/rua/bairro (se o ViaCEP falhar).
 * @return array
 */
function awr_entrega_cotacao( $cep, $o = array() ) {
	$o    = wp_parse_args( $o, array( 'quando' => 0, 'tipo' => 'rapida', 'peso' => 0, 'cidade' => '', 'uf' => '', 'rua' => '', 'bairro' => '' ) );
	$cep  = preg_replace( '/\D/', '', (string) $cep );
	$tz   = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'America/Sao_Paulo' );
	$agora = (int) apply_filters( 'awr_co_agora', time() );
	$dt   = ( new DateTimeImmutable( '@' . ( $o['quando'] ? (int) $o['quando'] : $agora ) ) )->setTimezone( $tz );
	$end  = 8 === strlen( $cep ) ? awr_co_endereco_cep( $cep ) : null;
	$cid  = $end ? $end['cidade'] : sanitize_text_field( $o['cidade'] );
	$uf   = $end ? $end['uf'] : strtoupper( sanitize_text_field( $o['uf'] ) );
	$fr   = function_exists( 'awr_frete_por_cep' ) ? awr_frete_por_cep( $cep, (float) $o['peso'] ) : array( 'tipo' => 'sem-cobertura', 'valor' => null, 'prazo' => '' );

	$r = array(
		'ok'        => 8 === strlen( $cep ),
		'cep'       => $cep,
		'endereco'  => array(
			'rua'    => $end ? $end['rua'] : sanitize_text_field( $o['rua'] ),
			'bairro' => $end ? $end['bairro'] : sanitize_text_field( $o['bairro'] ),
			'cidade' => $cid,
			'uf'     => $uf ? $uf : ( $cid ? 'RS' : '' ),
		),
		'endereco_auto' => (bool) $end,
		'faixa'     => $fr['tipo'],
		'tipo'      => in_array( $o['tipo'], array( 'rapida', 'agendada', 'retirada' ), true ) ? $o['tipo'] : 'rapida',
	);
	if ( 'retirada' === $r['tipo'] ) {
		return array_merge( $r, array(
			'ok' => true, 'regiao' => 'retirada', 'modo' => 'retirada', 'aberto' => true,
			'prazo' => array( 'titulo' => 'Retirada na loja', 'texto' => 'Instalação grátis na loja escolhida.', 'min' => 0 ),
			'taxa' => 0.0, 'taxa_rotulo' => 'Grátis', 'so_pix' => false, 'casco_obrig' => false, 'cpf_obrig' => false,
			'acrescimo_pct' => 0, 'agendar' => false, 'quando' => $dt->format( 'c' ),
		) );
	}
	if ( ! $r['ok'] ) {
		return array_merge( $r, array( 'regiao' => 'invalido', 'modo' => 'invalido', 'taxa' => null, 'mensagem' => 'Informe um CEP válido com 8 números.' ) );
	}

	// Região (função `Ee`): fora do RS > cidade da lista > consultar.
	if ( $uf && 'RS' !== $uf ) {
		$regiao = 'fora-rs';
	} elseif ( '' === $cid ) {
		$regiao = 'gratis-35' === $fr['tipo'] ? 'rapida' : 'consultar';
	} else {
		$regiao = awr_co_cidade_rapida( $cid ) ? 'rapida' : 'consultar';
	}
	$rapida_regiao = 'rapida' === $regiao;
	$aberto        = $rapida_regiao && awr_co_aberto( $cid, $dt );
	if ( 'agendada' === $o['tipo'] && ( ! $o['quando'] || (int) $o['quando'] < $agora - 300 ) ) { $aberto = false; }

	// Taxa: regra do navegador, com a faixa de CEP por cima (como o pedido já fazia).
	$taxa = 'retirada' === $r['tipo'] || 'fora-rs' === $regiao ? 0.0 : awr_co_taxa_horario( $cid, $dt );
	if ( 'retirada' !== $r['tipo'] && 'fora-rs' !== $regiao && in_array( $fr['tipo'], array( 'mesmo-dia', 'transportadora' ), true ) ) {
		$taxa = (float) $fr['valor'];
	}
	$taxa_cotar = 'fora-rs' === $regiao && 'retirada' !== $r['tipo'];

	// Prazo — só promete o que foi calculado.
	$cdados = $cid ? awr_co_cidade_dados( $cid ) : null;
	$modo_c = $cdados && function_exists( 'awr_city_delivery_mode' ) ? awr_city_delivery_mode( $cdados ) : '';
	if ( 'retirada' === $r['tipo'] ) {
		$modo = 'retirada'; $titulo = 'Retirada na loja'; $texto = 'Instalação grátis na loja escolhida.';
	} elseif ( 'fora-rs' === $regiao ) {
		$modo = 'fora-rs'; $titulo = 'Envio por transportadora'; $texto = 'Sem instalação no local. Frete e prazo (1 a 5 dias úteis) confirmados no WhatsApp.';
	} elseif ( 'transportadora' === $fr['tipo'] ) {
		$modo = 'transportadora'; $titulo = 'Envio por transportadora'; $texto = 'Entrega em 2 a 3 dias úteis, sem instalação no local.';
	} elseif ( 'mesmo-dia' === $fr['tipo'] ) {
		$modo = 'mesmo-dia'; $titulo = 'Entrega e instalação no mesmo dia'; $texto = 'Confirmamos o horário pelo WhatsApp.';
	} elseif ( 'agendada' === $r['tipo'] && $rapida_regiao && $aberto ) {
		$modo = 'agendada'; $titulo = 'Entrega e instalação agendadas'; $texto = 'Em ' . $dt->format( 'd/m' ) . ' às ' . $dt->format( 'H:i' ) . '.';
	} elseif ( $rapida_regiao && $aberto ) {
		$modo = 'rapida'; $titulo = 'Entrega e instalação em até 35 minutos'; $texto = 'Estimativa a partir da confirmação do pedido; pode variar com o trânsito.';
	} elseif ( $rapida_regiao ) {
		$modo = 'fechado'; $titulo = 'Atendimento no próximo horário';
		$texto = awr_co_eh_poa( $cid ) ? 'Plantão em Porto Alegre das 06:30 às 22h. Agende o melhor horário.' : 'Fora de Porto Alegre atendemos das 9h às 18h em dias úteis. Agende o melhor horário.';
	} elseif ( in_array( $modo_c, array( 'ate-17h', 'dia-seguinte' ), true ) ) {
		$modo = $modo_c; $p = awr_city_prazo( $cdados );
		$titulo = 'Entrega e instalação ' . $p['curto']; $texto = 'Confirmamos o horário pelo WhatsApp.';
	} else {
		$modo = 'consultar'; $titulo = 'Prazo confirmado no WhatsApp'; $texto = 'Ainda não temos entrega em 35 minutos na sua região. Confirmamos disponibilidade e prazo com você.';
	}

	// Restrições do checkout atual (função `q`): fora da região rápida.
	$restrito = 'retirada' !== $r['tipo'] && ! $rapida_regiao;

	return array_merge( $r, array(
		'regiao'        => $regiao,
		'modo'          => $modo,
		'aberto'        => $aberto,
		'prazo'         => array( 'titulo' => $titulo, 'texto' => $texto, 'min' => 'rapida' === $modo ? 35 : 0 ),
		'taxa'          => $taxa_cotar ? null : round( $taxa, 2 ),
		'taxa_rotulo'   => $taxa_cotar ? 'Frete cotado no WhatsApp' : ( $taxa > 0 ? 'R$ ' . number_format( $taxa, 2, ',', '.' ) : 'Grátis' ),
		'so_pix'        => $restrito,
		'casco_obrig'   => $restrito,
		'cpf_obrig'     => $restrito,
		'acrescimo_pct' => 'fora-rs' === $regiao && 'retirada' !== $r['tipo'] ? 4 : 0,
		'agendar'       => $rapida_regiao && 'retirada' !== $r['tipo'],
		'quando'        => $dt->format( 'c' ),
	) );
}

/** Resposta pública da cotação (REST e /awr-busca/). */
function awr_cotacao_response( $p ) {
	$quando = 0;
	if ( ! empty( $p['data'] ) && ! empty( $p['hora'] ) ) {
		try {
			$tz     = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'America/Sao_Paulo' );
			$quando = ( new DateTimeImmutable( sanitize_text_field( $p['data'] ) . ' ' . sanitize_text_field( $p['hora'] ), $tz ) )->getTimestamp();
		} catch ( Exception $e ) { $quando = 0; }
	}
	$peso = 0;
	if ( ! empty( $p['product_id'] ) && function_exists( 'wc_get_product' ) ) {
		$w    = wc_get_product( (int) $p['product_id'] );
		$peso = $w ? (float) $w->get_weight() : 0;
	}
	return awr_entrega_cotacao( $p['cep'] ?? '', array(
		'quando' => $quando,
		'tipo'   => sanitize_key( (string) ( $p['tipo'] ?? 'rapida' ) ),
		'peso'   => $peso,
		'cidade' => (string) ( $p['cidade'] ?? '' ),
		'uf'     => (string) ( $p['uf'] ?? '' ),
		'rua'    => (string) ( $p['rua'] ?? '' ),
		'bairro' => (string) ( $p['bairro'] ?? '' ),
	) );
}

/* ---------------------------------------------------------------------
   Limite por IP (mesma chave composta do /pedido)
   --------------------------------------------------------------------- */
function awr_co_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
	foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR' ) as $h ) {
		if ( ! empty( $_SERVER[ $h ] ) ) {
			$ip .= '|' . sanitize_text_field( trim( explode( ',', wp_unslash( $_SERVER[ $h ] ) )[0] ) );
			break;
		}
	}
	return $ip;
}

/** true se ainda está dentro do limite (e conta a tentativa). */
function awr_co_limite( $escopo, $max, $janela = 600 ) {
	$key  = 'awr_rl_' . $escopo . '_' . md5( awr_co_ip() );
	$ext  = function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache();
	$hits = (int) ( $ext ? wp_cache_get( $key, 'awr' ) : get_transient( $key ) );
	if ( $hits >= $max ) { return false; }
	if ( $ext ) { wp_cache_set( $key, $hits + 1, 'awr', $janela ); } else { set_transient( $key, $hits + 1, $janela ); }
	return true;
}

/* ---------------------------------------------------------------------
   Idempotência do pedido
   --------------------------------------------------------------------- */
function awr_pedido_token( $payload ) {
	$t = strtolower( (string) ( $payload['pedido_token'] ?? '' ) );
	return preg_match( '/^[a-z0-9-]{16,64}$/', $t ) ? $t : '';
}

/** Pedido já criado com este token (30 min) ou null. */
function awr_pedido_por_token( $token ) {
	if ( ! $token ) { return null; }
	$r = get_transient( 'awr_ptk_' . md5( $token ) );
	return is_array( $r ) ? $r : null;
}

/** Trava curta contra dois envios simultâneos. true = travou agora. */
function awr_pedido_trava( $token ) {
	if ( ! $token ) { return true; }
	$k = 'awr_ptk_lock_' . md5( $token );
	$v = get_option( $k );
	if ( $v && (int) $v > time() - 60 ) { return false; }
	if ( $v ) { delete_option( $k ); }
	return add_option( $k, time(), '', 'no' );
}

function awr_pedido_solta( $token, $resultado = null ) {
	if ( ! $token ) { return; }
	if ( is_array( $resultado ) && ! empty( $resultado['ok'] ) ) {
		set_transient( 'awr_ptk_' . md5( $token ), $resultado, 30 * MINUTE_IN_SECONDS );
	}
	delete_option( 'awr_ptk_lock_' . md5( $token ) );
}

/* ---------------------------------------------------------------------
   Leads de abandono (somente com aceite do cliente)
   --------------------------------------------------------------------- */
add_action( 'init', function () {
	register_post_type( 'awr_lead', array(
		'label'               => 'Checkouts abandonados',
		'public'              => false,
		'show_ui'             => false,
		'exclude_from_search' => true,
		'publicly_queryable'  => false,
		'rewrite'             => false,
		'query_var'           => false,
		'supports'            => array( 'title' ),
	) );
} );

function awr_lead_wa( $tel ) {
	$d = preg_replace( '/\D/', '', (string) $tel );
	if ( strlen( $d ) >= 10 && strlen( $d ) <= 11 ) { $d = '55' . $d; }
	return $d;
}

/** Grava/atualiza o lead do WhatsApp informado. */
function awr_lead_salvar( $p ) {
	$wa = awr_lead_wa( $p['telefone'] ?? '' );
	if ( strlen( $wa ) < 12 || empty( $p['aceite'] ) ) {
		return new WP_Error( 'invalid', 'Lead sem aceite ou WhatsApp inválido.', array( 'status' => 400 ) );
	}
	$campos = array(
		'nome'    => sanitize_text_field( $p['nome'] ?? '' ),
		'cep'     => preg_replace( '/\D/', '', (string) ( $p['cep'] ?? '' ) ),
		'bateria' => sanitize_text_field( $p['bateria'] ?? '' ),
		'sku'     => sanitize_text_field( $p['sku'] ?? '' ),
		'preco'   => (float) ( $p['preco'] ?? 0 ),
		'veiculo' => sanitize_text_field( $p['veiculo'] ?? '' ),
		'etapa'   => sanitize_key( (string) ( $p['etapa'] ?? '' ) ),
		'origem'  => esc_url_raw( (string) ( $p['origem'] ?? '' ) ),
	);
	$ids = get_posts( array( 'post_type' => 'awr_lead', 'post_status' => 'private', 'meta_key' => '_awr_wa', 'meta_value' => $wa, 'fields' => 'ids', 'posts_per_page' => 1, 'no_found_rows' => true ) );
	$id  = $ids ? (int) $ids[0] : 0;
	$arr = array( 'post_type' => 'awr_lead', 'post_status' => 'private', 'post_title' => trim( $campos['nome'] . ' — ' . $campos['bateria'] ) );
	if ( $id ) {
		$arr['ID'] = $id;
		wp_update_post( $arr );
	} else {
		$id = (int) wp_insert_post( $arr );
	}
	if ( ! $id ) { return new WP_Error( 'erro', 'Não foi possível salvar.', array( 'status' => 500 ) ); }
	update_post_meta( $id, '_awr_wa', $wa );
	update_post_meta( $id, '_awr_lead', $campos );
	update_post_meta( $id, '_awr_lead_em', time() );
	return array( 'ok' => true );
}

/** Pedido concluído com o mesmo WhatsApp: apaga o lead. */
function awr_lead_apagar_por_tel( $tel ) {
	$wa = awr_lead_wa( $tel );
	if ( strlen( $wa ) < 12 ) { return 0; }
	$ids = get_posts( array( 'post_type' => 'awr_lead', 'post_status' => 'any', 'meta_key' => '_awr_wa', 'meta_value' => $wa, 'fields' => 'ids', 'posts_per_page' => 20, 'no_found_rows' => true ) );
	foreach ( $ids as $id ) { wp_delete_post( (int) $id, true ); }
	return count( $ids );
}

/** Limpeza diária: leads com mais de 30 dias. */
add_action( 'awr_leads_limpeza', function () {
	$ids = get_posts( array(
		'post_type'      => 'awr_lead',
		'post_status'    => 'any',
		'fields'         => 'ids',
		'posts_per_page' => 200,
		'no_found_rows'  => true,
		'date_query'     => array( array( 'column' => 'post_modified_gmt', 'before' => '30 days ago' ) ),
	) );
	foreach ( $ids as $id ) { wp_delete_post( (int) $id, true ); }
} );
add_action( 'init', function () {
	if ( function_exists( 'wp_next_scheduled' ) && ! wp_next_scheduled( 'awr_leads_limpeza' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'awr_leads_limpeza' );
	}
} );

/** WooCommerce → Checkouts abandonados. */
add_action( 'admin_menu', function () {
	$pai = class_exists( 'WooCommerce' ) ? 'woocommerce' : 'options-general.php';
	add_submenu_page( $pai, 'Checkouts abandonados', 'Checkouts abandonados', 'manage_woocommerce', 'awr-leads', 'awr_leads_admin_page' );
}, 60 );

function awr_leads_admin_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
	if ( isset( $_GET['apagar'] ) && check_admin_referer( 'awr_lead_apagar' ) ) {
		$id = (int) $_GET['apagar'];
		if ( 'awr_lead' === get_post_type( $id ) ) { wp_delete_post( $id, true ); }
	}
	$ids = get_posts( array( 'post_type' => 'awr_lead', 'post_status' => 'any', 'fields' => 'ids', 'posts_per_page' => 200, 'orderby' => 'modified', 'order' => 'DESC', 'no_found_rows' => true ) );
	echo '<div class="wrap"><h1>Checkouts abandonados</h1>';
	echo '<p>Somente clientes que marcaram "Pode me chamar no WhatsApp se eu não concluir". Cada registro é apagado após 30 dias ou quando o cliente conclui um pedido com o mesmo WhatsApp.</p>';
	if ( ! $ids ) { echo '<p><em>Nenhum checkout abandonado no momento.</em></p></div>'; return; }
	echo '<table class="widefat striped"><thead><tr><th>Quando</th><th>Nome</th><th>Bateria</th><th>Veículo</th><th>CEP</th><th>Parou em</th><th></th></tr></thead><tbody>';
	foreach ( $ids as $id ) {
		$l  = (array) get_post_meta( $id, '_awr_lead', true );
		$wa = (string) get_post_meta( $id, '_awr_wa', true );
		$msg = 'Olá' . ( ! empty( $l['nome'] ) ? ' ' . strtok( $l['nome'], ' ' ) : '' ) . '! Aqui é da AWR Baterias. Vimos que você começou o pedido da bateria ' . ( $l['bateria'] ?? '' ) . ( ! empty( $l['veiculo'] ) ? ' para o ' . $l['veiculo'] : '' ) . '. Posso ajudar a concluir?';
		echo '<tr><td>' . esc_html( get_the_modified_date( 'd/m H:i', $id ) ) . '</td><td>' . esc_html( $l['nome'] ?? '' ) . '</td><td>' . esc_html( $l['bateria'] ?? '' ) . ( ! empty( $l['preco'] ) ? ' — R$ ' . esc_html( number_format( (float) $l['preco'], 2, ',', '.' ) ) : '' ) . '</td><td>' . esc_html( $l['veiculo'] ?? '' ) . '</td><td>' . esc_html( $l['cep'] ?? '' ) . '</td><td>' . esc_html( $l['etapa'] ?? '' ) . '</td><td>'
			. '<a class="button button-primary" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/' . $wa . '?text=' . rawurlencode( $msg ) ) . '">Chamar no WhatsApp</a> '
			. '<a class="button" href="' . esc_url( wp_nonce_url( add_query_arg( 'apagar', $id ), 'awr_lead_apagar' ) ) . '">Apagar</a></td></tr>';
	}
	echo '</tbody></table></div>';
}

/* ---------------------------------------------------------------------
   Endpoints
   --------------------------------------------------------------------- */
function awr_lead_response( $p ) {
	if ( '' !== trim( (string) ( $p['awr_hp'] ?? '' ) ) ) {
		return new WP_Error( 'spam', 'Requisição inválida.', array( 'status' => 400 ) );
	}
	if ( ! awr_co_limite( 'lead', 10 ) ) {
		return new WP_Error( 'rate_limited', 'Muitas tentativas.', array( 'status' => 429 ) );
	}
	return awr_lead_salvar( $p );
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'awr/v1', '/cotacao', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			if ( ! headers_sent() ) { nocache_headers(); }
			return rest_ensure_response( awr_cotacao_response( $req->get_params() ) );
		},
	) );
	register_rest_route( 'awr/v1', '/lead', array(
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$p = $req->get_json_params();
			return awr_lead_response( is_array( $p ) ? $p : $req->get_params() );
		},
	) );
} );

/** Mesmas ações no canal /awr-busca/ (imune a cache e a bloqueio do REST). */
add_action( 'template_redirect', function () {
	$path = trim( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' );
	if ( 'awr-busca' !== substr( $path, -9 ) || ! function_exists( 'awr_search_api_payload' ) ) { return; }
	$p = awr_search_api_payload();
	$a = sanitize_key( (string) ( $p['action'] ?? '' ) );
	if ( 'cotacao' !== $a && 'lead' !== $a ) { return; }
	header( 'X-Robots-Tag: noindex, nofollow', true );
	header( 'Cache-Control: no-store, max-age=0', true );
	if ( 'cotacao' === $a ) { wp_send_json( awr_cotacao_response( $p ), 200 ); }
	$r = awr_lead_response( $p );
	if ( is_wp_error( $r ) ) { wp_send_json( array( 'ok' => false, 'message' => $r->get_error_message() ), (int) ( $r->get_error_data()['status'] ?? 400 ) ); }
	wp_send_json( $r, 200 );
}, -101 );
