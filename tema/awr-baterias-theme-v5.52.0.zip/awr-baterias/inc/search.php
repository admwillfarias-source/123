<?php
/**
 * Busca de veículos / SKU / amperagem — porte de src/data/vehicles.ts.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

const AWR_SYNONYMS = array(
	'vw'       => array( 'volkswagen' ),
	'volks'    => array( 'volkswagen' ),
	'mb'       => array( 'mercedes', 'benz' ),
	'merc'     => array( 'mercedes' ),
	'mercedes' => array( 'mercedes', 'benz' ),
	'benz'     => array( 'mercedes', 'benz' ),
	'gm'       => array( 'chevrolet' ),
	'chevy'    => array( 'chevrolet' ),
	'hatch'    => array( 'hatch', 'hacth' ),
	'hacth'    => array( 'hatch', 'hacth' ),
	'sedan'    => array( 'sedan', 'sedam' ),
	'sedam'    => array( 'sedan', 'sedam' ),
	'plus'     => array( 'plus', 'sedan' ),
	'triton'   => array( 'triton', 'l200' ),
	'l200'     => array( 'l200', 'triton' ),
);

const AWR_STOPWORDS = array( 'novo', 'nova', 'new', 'carro', 'bateria', 'para', 'do', 'da', 'de' );

function awr_normalize( $s ) {
	$s = mb_strtolower( (string) $s, 'UTF-8' );
	$s = remove_accents( $s );
	$s = preg_replace( '/[^a-z0-9\s]/', ' ', $s );
	return trim( preg_replace( '/\s+/', ' ', $s ) );
}

/** Normalização sem espaços/hífens: "hr v" => "hrv", "rav 4" => "rav4". */
function awr_compact( $s ) {
	return preg_replace( '/\s+/', '', awr_normalize( $s ) );
}


function awr_slugify( $s ) {
	return sanitize_title( remove_accents( (string) $s ) );
}

/** Distância de edição ≤ 1 (substituição, inserção, remoção ou transposição)? */
function awr_edit_distance_max1( $a, $b ) {
	$la = strlen( $a ); $lb = strlen( $b );
	if ( abs( $la - $lb ) > 1 ) { return false; }
	if ( $a === $b ) { return true; }
	if ( $la === $lb ) {
		$diffs = 0; $idx = array();
		for ( $i = 0; $i < $la; $i++ ) {
			if ( $a[ $i ] !== $b[ $i ] ) { $diffs++; $idx[] = $i; if ( $diffs > 2 ) { return false; } }
		}
		if ( 1 === $diffs ) { return true; }
		return 2 === $diffs && $idx[1] === $idx[0] + 1 && $a[ $idx[0] ] === $b[ $idx[1] ] && $a[ $idx[1] ] === $b[ $idx[0] ];
	}
	$s = $la < $lb ? $a : $b;
	$l = $la < $lb ? $b : $a;
	$i = 0; $j = 0; $skipped = false;
	$ls = strlen( $s ); $ll = strlen( $l );
	while ( $i < $ls && $j < $ll ) {
		if ( $s[ $i ] === $l[ $j ] ) { $i++; $j++; continue; }
		if ( $skipped ) { return false; }
		$skipped = true;
		$j++;
	}
	return true;
}

/**
 * Pontua o casamento de um token (e sinônimos) com um item do catálogo.
 * Prioridade: palavra inteira do MODELO > início do modelo > marca exata
 * > erro de digitação no modelo > substring compacta. Substring solta na
 * marca NÃO pontua — era o que fazia "ka" casar com KAWASAKI e esconder
 * o Ford Ka. Espelho de scoreTokenInItem em src/data/vehicles.ts.
 */
function awr_score_token_in_item( $alts, $brand, $model, $brand_c, $model_c ) {
	$model_words = array_filter( explode( ' ', $model ) );
	$brand_words = array_filter( explode( ' ', $brand ) );
	$best = -1;
	foreach ( $alts as $a ) {
		$ac = preg_replace( '/\s+/', '', $a );
		if ( '' === $a ) { continue; }
		$al = strlen( $a ); $acl = strlen( $ac );
		// 1) Palavra inteira do modelo ("ka" === "KA" do Ford Ka)
		if ( in_array( $a, $model_words, true ) ) { $best = max( $best, 100 + $al ); continue; }
		// 2) Modelo começa com o token
		if ( 0 === strpos( $model, $a ) ) { $best = max( $best, 70 + $al ); continue; }
		// 3) Marca exata ou palavra inteira da marca ("nissan", "volkswagen")
		if ( $brand === $a || in_array( $a, $brand_words, true ) ) { $best = max( $best, 40 + $al ); continue; }
		// 4) Erro de digitação no modelo: 1 letra de diferença, tokens de 4+ letras
		if ( $al >= 4 ) {
			foreach ( $model_words as $w ) {
				if ( strlen( $w ) >= 4 && $w[0] === $a[0] && awr_edit_distance_max1( $a, $w ) ) {
					$best = max( $best, 25 + $al );
					break;
				}
			}
			if ( $best >= 25 ) { continue; }
		}
		// 5) Substring do modelo ("icks" => KICKS)
		if ( $al >= 3 && false !== strpos( $model, $a ) ) { $best = max( $best, 12 + $al ); continue; }
		// 6) Forma compacta sem espaços/hífens ("hrv" => "hr v")
		if ( $acl >= 3 && false !== strpos( $model_c, $ac ) ) { $best = max( $best, 8 + $acl ); continue; }
		// 7) Por último: substring da marca ("kawa" => KAWASAKI) — nunca acima de modelo
		if ( $al >= 3 && ( false !== strpos( $brand, $a ) || false !== strpos( $brand_c, $ac ) ) ) { $best = max( $best, 2 + $al ); }
	}
	return $best;
}

/** Sugestões agrupadas por marca|modelo|período. */
function awr_search_suggestions( $query, $limit = 12 ) {
	$q = awr_normalize( $query );
	if ( mb_strlen( $q ) < 2 ) { return array(); }
	$tokens     = array_filter( explode( ' ', $q ) );
	$year       = null;
	$text_tokens = array();
	foreach ( $tokens as $t ) {
		if ( null === $year && preg_match( '/^(19|20)\d{2}$/', $t ) ) { $year = (int) $t; continue; }
		if ( in_array( $t, AWR_STOPWORDS, true ) ) { continue; }
		$text_tokens[] = $t;
	}
	$alts = array();
	foreach ( $text_tokens as $t ) {
		$alts[] = isset( AWR_SYNONYMS[ $t ] ) ? array_unique( array_merge( array( $t ), AWR_SYNONYMS[ $t ] ) ) : array( $t );
	}
	if ( empty( $alts ) && ! $year ) { return array(); }

	$items   = awr_batteries()['items'];
	$scored  = array();
	$partial = array();
	$total   = count( $alts );
	foreach ( $items as $it ) {
		if ( $year && ( $year < $it['d'] || $year > $it['a'] ) ) { continue; }
		$brand   = awr_normalize( $it['ma'] );
		$model   = awr_normalize( $it['mo'] );
		$brand_c = preg_replace( '/\s+/', '', $brand );
		$model_c = preg_replace( '/\s+/', '', $model );
		$hits  = 0;
		$score = 0;
		foreach ( $alts as $group ) {
			$best = awr_score_token_in_item( $group, $brand, $model, $brand_c, $model_c );
			if ( $best < 0 ) { continue; }
			$hits++;
			$score += $best;
		}
		if ( $year ) { $score += 5; }
		$row = array( 'it' => $it, 'score' => $score, 'hits' => $hits );
		if ( $hits === $total ) { $scored[] = $row; } elseif ( $hits > 0 ) { $partial[] = $row; }
	}
	// Fallback: nenhuma linha casa com todas as palavras => melhor correspondência parcial.
	$pool = ! empty( $scored ) ? $scored : $partial;
	usort( $pool, function ( $x, $y ) {
		return ( $y['hits'] <=> $x['hits'] ) ?: ( ( $y['score'] <=> $x['score'] ) ?: ( $y['it']['a'] <=> $x['it']['a'] ) );
	} );

	$groups = array();
	foreach ( $pool as $row ) {
		$it  = $row['it'];
		$key = $it['ma'] . '|' . $it['mo'] . '|' . $it['d'] . '-' . $it['a'];

		if ( ! isset( $groups[ $key ] ) ) {
			if ( count( $groups ) >= $limit ) { break; }
			$ylabel          = $it['d'] === $it['a'] ? (string) $it['d'] : $it['d'] . '-' . $it['a'];
			$groups[ $key ] = array(
				'brand'     => $it['ma'],
				'model'     => $it['mo'],
				'yearStart' => $it['d'],
				'yearEnd'   => $it['a'],
				'year'      => $year ? $year : $it['a'],
				'label'     => $it['ma'] . ' ' . $it['mo'] . ' (' . $ylabel . ')',
				'slug'      => awr_slugify( $it['ma'] . '-' . $it['mo'] ),
				'items'     => array( $it ),
			);
		} else {
			$groups[ $key ]['items'][] = $it;
		}
	}
	return array_values( $groups );
}

/** Variantes compatíveis com marca+modelo+ano. */
function awr_vehicle_items( $brand, $model, $year ) {
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		if ( $it['ma'] === $brand && $it['mo'] === $model && $year >= $it['d'] && $year <= $it['a'] ) {
			$out[] = $it;
		}
	}
	return $out;
}

/** Resolve slug "chevrolet-onix" + ano nas variantes. */
function awr_vehicle_by_slug( $slug, $year = 0 ) {
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		if ( awr_slugify( $it['ma'] . '-' . $it['mo'] ) !== $slug ) { continue; }
		if ( $year && ( $year < $it['d'] || $year > $it['a'] ) ) { continue; }
		$out[] = $it;
	}
	return $out;
}

// 5.52.0: 'mb' = Motobatt (catálogo de motos AGM).
const AWR_BRAND_KEYS = array( 'm' => 'Moura', 'z' => 'Zetta', 'h' => 'Heliar', 'e' => 'Excell', 'h65' => 'Heliar', 'el' => 'Eletran', 'mb' => 'Motobatt' );

/** Cache de objeto simples (grupo awr), com fallback silencioso. */
function awr_cache_remember( $key, $callback ) {
	$ext = function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache();
	$ck  = $key . '_' . AWR_VERSION;
	if ( $ext ) {
		$hit = wp_cache_get( $ck, 'awr' );
		if ( is_array( $hit ) ) { return $hit; }
	}
	$val = call_user_func( $callback );
	if ( $ext ) { wp_cache_set( $ck, $val, 'awr', DAY_IN_SECONDS ); }
	return $val;
}

/**
 * 5.46.0 — Slug público do SKU em /bateria/{slug}/. Para SKUs comuns é o
 * próprio SKU em minúsculas (URL inalterada). SKUs com espaço, vírgula ou
 * barra ("HTX14 12", "MA8,6E", "HE60HD / H65HD") geravam URLs inválidas no
 * sitemap, com canonical diferente e página "SKU não encontrado".
 */
function awr_sku_slug( $sku ) {
	return sanitize_title( strtolower( (string) $sku ) );
}

/** SKU do catálogo a partir do slug da URL (inverso de awr_sku_slug). */
function awr_sku_from_slug( $slug ) {
	static $mapa = null;
	if ( null === $mapa ) {
		$mapa = array();
		foreach ( awr_sku_index() as $e ) {
			$k = awr_sku_slug( $e['sku'] );
			if ( ! isset( $mapa[ $k ] ) ) { $mapa[ $k ] = $e['sku']; }
		}
	}
	$slug = sanitize_title( (string) $slug );
	return $mapa[ $slug ] ?? strtoupper( $slug );
}

function awr_sku_index() {
	static $idx = null;
	if ( null !== $idx ) { return $idx; }
	$idx = awr_cache_remember( 'skuidx', function () {
		$out  = array();
		$seen = array();
		foreach ( awr_batteries()['items'] as $it ) {
			foreach ( AWR_BRAND_KEYS as $k => $brand ) {
				$raw = isset( $it[ $k ] ) ? trim( (string) $it[ $k ] ) : '';
				if ( '' === $raw ) { continue; }
				$sku = strtoupper( $raw );
				$key = $brand . '|' . $sku;
				if ( isset( $seen[ $key ] ) ) { continue; }
				$seen[ $key ] = true;
				$out[]        = array( 'sku' => $sku, 'brand' => $brand );
			}
		}
		return $out;
	} );
	return $idx;
}


/** Marca real associada ao SKU no catálogo de compatibilidade. */
function awr_brand_by_sku( $sku ) {
	$sku = strtoupper( trim( (string) $sku ) );
	foreach ( awr_sku_index() as $entry ) {
		if ( $entry['sku'] === $sku ) { return $entry['brand']; }
	}
	return '';
}

/** Amperagem provável a partir do SKU/nome. */
function awr_extract_amperage( ...$parts ) {
	$hay = strtoupper( implode( ' ', array_filter( $parts ) ) );
	if ( preg_match( '/(\d{2,3})\s*AH/', $hay, $m ) ) {
		$n = (int) $m[1];
		if ( $n >= 20 && $n <= 260 ) { return $n; }
	}
	if ( preg_match( '/(?<![A-Z0-9])(\d{2,3})(?=[A-Z]|$)/', $hay, $m ) ) {
		$n = (int) $m[1];
		if ( $n >= 20 && $n <= 260 ) { return $n; }
	}
	return 0;
}

function awr_search_by_sku( $query, $limit = 5 ) {
	$q = strtoupper( preg_replace( '/\s+/', '', (string) $query ) );
	if ( strlen( $q ) < 2 ) { return array(); }
	$exact = null; $starts = array(); $contains = array();
	foreach ( awr_sku_index() as $e ) {
		if ( $e['sku'] === $q ) { $exact = $e; continue; }
		if ( 0 === strpos( $e['sku'], $q ) ) { $starts[] = $e; }
		elseif ( false !== strpos( $e['sku'], $q ) ) { $contains[] = $e; }
	}
	$out = $exact ? array_merge( array( $exact ), $starts, $contains ) : array_merge( $starts, $contains );
	return array_slice( $out, 0, $limit );
}

function awr_search_by_amperage( $ah, $limit = 60 ) {
	$ah = (int) $ah;
	if ( $ah <= 0 ) { return array(); }
	$out = array();
	foreach ( awr_sku_index() as $e ) {
		if ( awr_extract_amperage( $e['sku'] ) === $ah ) { $out[] = $e; }
		if ( count( $out ) >= $limit ) { break; }
	}
	return $out;
}

/**
 * Amperagens realmente disponíveis (compatibilidade + catálogo WooCommerce).
 * Só entram valores que geram pelo menos um modelo na página.
 */
function awr_amperagens_disponiveis() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$out = awr_cache_remember( 'amperagens_v2', function () {
		$set = array();

		foreach ( awr_sku_index() as $e ) {
			$ah = awr_extract_amperage( $e['sku'] );
			if ( $ah >= 30 && $ah <= 260 ) { $set[ $ah ] = true; }
		}

		// Catálogo WooCommerce: traz 72Ah, 180Ah, 220Ah e demais itens fora da tabela.
		if ( function_exists( 'awr_shop_amperage_index' ) ) {
			foreach ( array_keys( awr_shop_amperage_index() ) as $ah ) {
				$ah = (int) $ah;
				if ( $ah >= 30 && $ah <= 260 ) { $set[ $ah ] = true; }
			}
		}

		$list = array_keys( $set );
		sort( $list );
		return $list;
	} );
	return $out;
}

/** Existe pelo menos um modelo para a amperagem? */
function awr_amperagem_tem_modelos( $ah ) {
	$ah = (int) $ah;
	if ( $ah <= 0 ) { return false; }
	if ( awr_search_by_amperage( $ah, 1 ) ) { return true; }
	$idx = function_exists( 'awr_shop_amperage_index' ) ? awr_shop_amperage_index() : array();
	return ! empty( $idx[ $ah ] );
}




/** Desconto de casco por amperagem (porte de priceFloor.ts). */
function awr_desconto_casco( $ah ) {
	$ah = (int) $ah;
	if ( $ah <= 0 ) { return 40; }
	if ( $ah <= 50 ) { return 40; }
	if ( $ah <= 70 ) { return 60; }
	if ( $ah <= 90 ) { return 80; }
	return 100;
}

/** Lista de SKUs de um conjunto de variantes, com a marca. */
function awr_skus_from_items( $items ) {
	$out = array();
	foreach ( $items as $it ) {
		foreach ( AWR_BRAND_KEYS as $k => $brand ) {
			$raw = isset( $it[ $k ] ) ? trim( (string) $it[ $k ] ) : '';
			if ( '' === $raw ) { continue; }
			$out[ strtoupper( $raw ) ] = array( 'sku' => strtoupper( $raw ), 'brand' => $brand );
		}
	}
	return array_values( $out );
}

/* ======================================================================
   v3.5.0 — índice de veículos para as rotas de SEO
   /baterias/{marca}/ /baterias/{marca}/{modelo}/ /baterias/{marca}/{modelo}/{ano}/
   ====================================================================== */

/** Marcas de veículo do catálogo: slug => nome. */
function awr_vehicle_brands() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$out = awr_cache_remember( 'vbrands', function () {
		$list = array();
		foreach ( awr_batteries()['items'] as $it ) {
			$list[ awr_slugify( $it['ma'] ) ] = $it['ma'];
		}
		ksort( $list );
		return $list;
	} );
	return $out;
}


/** O slug é uma marca de veículo? */
function awr_is_vehicle_brand( $slug ) {
	$b = awr_vehicle_brands();
	return isset( $b[ $slug ] ) ? $b[ $slug ] : '';
}

/**
 * 5.49.0 — Índice marca → modelo → posições em awr_batteries()['items'].
 * Antes awr_vehicle_models()/awr_vehicle_variants() varriam a base inteira
 * (com awr_slugify em cada item) a cada chamada; o sitemap de veículos fazia
 * isso ~16 mil vezes e levava 65 s. Uma varredura por requisição basta.
 */
function awr_vehicle_index() {
	static $idx = null;
	if ( null !== $idx ) { return $idx; }
	$idx = array();
	foreach ( awr_batteries()['items'] as $i => $it ) {
		$idx[ awr_slugify( $it['ma'] ) ][ awr_slugify( $it['mo'] ) ][] = $i;
	}
	return $idx;
}

/** Modelos de uma marca: slug => array(nome, ano_min, ano_max). */
function awr_vehicle_models( $brand_slug ) {
	$idx = awr_vehicle_index();
	if ( empty( $idx[ $brand_slug ] ) ) { return array(); }
	$items = awr_batteries()['items'];
	$out   = array();
	foreach ( $idx[ $brand_slug ] as $k => $pos ) {
		foreach ( $pos as $i ) {
			$it = $items[ $i ];
			if ( ! isset( $out[ $k ] ) ) {
				$out[ $k ] = array( 'nome' => $it['mo'], 'de' => (int) $it['d'], 'ate' => (int) $it['a'] );
			} else {
				$out[ $k ]['de']  = min( $out[ $k ]['de'], (int) $it['d'] );
				$out[ $k ]['ate'] = max( $out[ $k ]['ate'], (int) $it['a'] );
			}
		}
	}
	ksort( $out );
	return $out;
}

/** Variantes de um modelo (marca+modelo em slug), opcionalmente filtradas por ano. */
function awr_vehicle_variants( $brand_slug, $model_slug, $year = 0 ) {
	$idx = awr_vehicle_index();
	if ( empty( $idx[ $brand_slug ][ $model_slug ] ) ) { return array(); }
	$items = awr_batteries()['items'];
	$out   = array();
	foreach ( $idx[ $brand_slug ][ $model_slug ] as $i ) {
		$it = $items[ $i ];
		if ( $year && ( $year < $it['d'] || $year > $it['a'] ) ) { continue; }
		$out[] = $it;
	}
	return $out;
}

/**
 * 5.51.0 — Famílias de modelo: "Creta" reúne "Creta 1.0 e 1.6" e "Creta 2.0".
 * Buscas sem versão ("bateria creta", "bateria hb20 1.0", "bateria kwid")
 * caíam em páginas de uma versão + ano; a família lista todas as versões.
 *
 * Chave = primeiro termo do slug do modelo; dois termos quando o primeiro é
 * curto ou genérico (t-cross, hr-v, grand-vitara, range-rover…).
 * Só famílias com 2+ versões. Retorna slug => array(nome, modelos[], existe),
 * onde "existe" indica que o slug já é uma página de versão (ex.: kwid).
 */
function awr_vehicle_families( $brand_slug ) {
	static $memo = array();
	if ( isset( $memo[ $brand_slug ] ) ) { return $memo[ $brand_slug ]; }
	$genericos = (array) apply_filters( 'awr_familia_termos_genericos', array(
		'grand', 'gran', 'new', 'novo', 'nova', 'santa', 'land', 'range', 'serie', 'series', 'classe', 'class',
		'benz', 'super', 'mega', 'linha', 'modelo', 'all', 'up', 'e', 'id', 'ix', 'model',
	) );
	$modelos = awr_vehicle_models( $brand_slug );
	$grupos  = array();
	foreach ( $modelos as $mslug => $m ) {
		$t = explode( '-', (string) $mslug );
		$k = $t[0];
		if ( isset( $t[1] ) && ( strlen( $t[0] ) <= 2 || in_array( $t[0], $genericos, true ) ) ) { $k = $t[0] . '-' . $t[1]; }
		if ( strlen( $k ) < 2 ) { continue; }
		$grupos[ $k ][] = (string) $mslug;
	}
	$out = array();
	foreach ( $grupos as $k => $lista ) {
		if ( count( $lista ) < 2 ) { continue; }
		// Nome: menor prefixo de palavras do nome do modelo cujo slug = chave.
		$nome  = '';
		$words = preg_split( '/\s+/', trim( (string) $modelos[ $lista[0] ]['nome'] ) );
		$acc   = '';
		foreach ( $words as $w ) {
			$acc = trim( $acc . ' ' . $w );
			if ( awr_slugify( $acc ) === $k ) { $nome = $acc; break; }
		}
		if ( '' === $nome ) { $nome = strtoupper( str_replace( '-', ' ', $k ) ); }
		$out[ $k ] = array(
			'slug'    => $k,
			'nome'    => $nome,
			'modelos' => $lista,
			'existe'  => isset( $modelos[ $k ] ),
		);
	}
	$memo[ $brand_slug ] = $out;
	return $out;
}

/** Família (com URL própria) de um slug, ou null. */
function awr_vehicle_family( $brand_slug, $family_slug ) {
	$f = awr_vehicle_families( $brand_slug );
	if ( ! isset( $f[ $family_slug ] ) || $f[ $family_slug ]['existe'] ) { return null; }
	// Só vira página quando a tabela tem 2+ linhas distintas (conteúdo próprio).
	if ( count( awr_vehicle_family_rows( $brand_slug, $f[ $family_slug ] ) ) < 2 ) { return null; }
	return $f[ $family_slug ];
}

/** Família a que pertence uma versão (inclusive quando o slug da família é a própria versão). */
function awr_vehicle_family_of( $brand_slug, $model_slug ) {
	foreach ( awr_vehicle_families( $brand_slug ) as $f ) {
		if ( in_array( (string) $model_slug, $f['modelos'], true ) ) { return $f; }
	}
	return null;
}

/** URL da página da família (ou da versão homônima, quando ela já existe). */
function awr_vehicle_family_url( $brand_slug, $family_slug ) {
	return home_url( '/baterias/' . $brand_slug . '/' . $family_slug . '/' );
}

/**
 * Linhas da tabela da família: uma por variante do catálogo.
 * Cada linha: versao, slug, de, ate, ah, tec, codigos (marca => código).
 */
function awr_vehicle_family_rows( $brand_slug, $familia ) {
	$modelos = awr_vehicle_models( $brand_slug );
	$teto    = (int) gmdate( 'Y' ) + 1;
	$rows    = array();
	$vistos  = array();
	foreach ( $familia['modelos'] as $ms ) {
		foreach ( awr_vehicle_variants( $brand_slug, $ms ) as $it ) {
			$cod = array();
			foreach ( AWR_BRAND_KEYS as $k => $marca ) {
				$v = isset( $it[ $k ] ) ? trim( (string) $it[ $k ] ) : '';
				if ( '' !== $v && ! isset( $cod[ $marca ] ) ) { $cod[ $marca ] = strtoupper( $v ); }
			}
			if ( ! $cod ) { continue; }
			$hay = strtoupper( $it['mo'] . ' ' . implode( ' ', $cod ) );
			$tec = false !== strpos( $hay, 'AGM' ) ? 'AGM' : ( false !== strpos( $hay, 'EFB' ) ? 'EFB' : ( preg_match( '/(?<!SEM )START.?STOP/', $hay ) ? 'Start-stop' : 'Convencional' ) );
			$ah  = 0;
			foreach ( $cod as $c ) {
				if ( preg_match( '/(\d{2,3})/', $c, $mm ) && (int) $mm[1] >= 20 && (int) $mm[1] <= 260 ) { $ah = (int) $mm[1]; break; }
			}
			// Dados com a mesma versão grafada de dois jeitos (ex.: "sedam/hacth") repetem a linha.
			$chave = implode( '|', $cod ) . '|' . (int) $it['d'] . '|' . (int) $it['a'];
			if ( isset( $vistos[ $chave ] ) ) { continue; }
			$vistos[ $chave ] = true;
			$rows[] = array(
				'versao'  => $modelos[ $ms ]['nome'] ?? $it['mo'],
				'slug'    => (string) $ms,
				'de'      => (int) $it['d'],
				'ate'     => min( (int) $it['a'], $teto ),
				'ah'      => $ah,
				'tec'     => $tec,
				'codigos' => $cod,
			);
		}
	}
	usort( $rows, function ( $x, $y ) {
		return array( $x['versao'], $y['de'] ) <=> array( $y['versao'], $x['de'] );
	} );
	return $rows;
}

/**
 * 5.51.0 — Elétricos e híbridos do catálogo (bateria auxiliar 12V), uma linha
 * por variante: marca, modelo, url, de, ate, ah, tec, codigos.
 */
function awr_eletricos_modelos() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$out = array();
	$rx  = '/EL[EÉ]TRIC|H[IÍ]BRID|HYBRID|PHEV|\b4XE\b|E-TECH|\bEV\b/u';
	foreach ( awr_vehicle_brands() as $bslug => $bnome ) {
		foreach ( awr_vehicle_models( $bslug ) as $mslug => $m ) {
			if ( ! preg_match( $rx, strtoupper( (string) $m['nome'] ) ) ) { continue; }
			foreach ( awr_vehicle_family_rows( $bslug, array( 'modelos' => array( (string) $mslug ) ) ) as $r ) {
				$out[] = array_merge( $r, array(
					'marca'  => $bnome,
					'modelo' => $r['versao'],
					'url'    => awr_vehicle_url( $bnome, $m['nome'] ),
				) );
			}
		}
	}
	return $out;
}

/**
 * 5.52.0 — Tipo do veículo para textos e H1: carro, moto, quadriciclo,
 * aquatico ou pesado (caminhão, ônibus, trator, máquina).
 */
function awr_vehicle_tipo( $brand_slug, $model_slug ) {
	static $memo = array();
	$k = $brand_slug . '/' . $model_slug;
	if ( isset( $memo[ $k ] ) ) { return $memo[ $k ]; }
	$vars = awr_vehicle_variants( $brand_slug, $model_slug );
	$nome = strtoupper( (string) ( $vars[0]['mo'] ?? $model_slug ) );
	$moto = false;
	foreach ( $vars as $it ) { if ( function_exists( 'awr_is_moto_item' ) && awr_is_moto_item( $it ) ) { $moto = true; break; } }
	if ( $moto ) {
		if ( 'sea-doo' === $brand_slug || preg_match( '/WAVE ?RUNNER|WAVE ?RAIDER|WAVE ?VENTURE|WAVE ?BLASTER|JET ?SKI|JETSKI|SUPER ?JET|\bSTX\b|\bULTRA \d|\bGTX\b|\bRXP\b|\bRXT\b|\bGTI \d|\bFX ?(HO|SHO|CRUISER)/', $nome ) ) {
			$t = 'aquatico';
		} elseif ( in_array( $brand_slug, array( 'can-am', 'arctic-cat', 'marshin-kazuma' ), true ) || preg_match( '/\bATV\b|\bUTV\b|4X4|2X4|\bQUAD|RANGER|\bRZR|SPORTSMAN|PRAIRIE|BRUTE FORCE|GRIZZLY|KODIAK|RHINO|FOREMAN|RANCHER|\bRECON|RUBICON|\bTRX|\bMULE|TERYX|COMMANDER|MAVERICK|OUTLANDER|RENEGADE|DEFENDER|KINGQUAD|PROWLER|WILDCAT|SNOWMOBILE|\bRMK\b|\bINDY\b|SKI-DOO|\bLT-[AFRZ]/', $nome ) ) {
			$t = 'quadriciclo';
		} else {
			$t = 'moto';
		}
	} else {
		$pesadas = array( 'agco', 'case', 'caterpillar', 'clark', 'daf', 'huber', 'iveco', 'john-deere', 'komatsu', 'new-holland', 'poclain', 'randon', 'scania', 'svedala', 'tema', 'tema-terra', 'terex', 'valmet', 'wabco', 'yale', 'zector', 'cbt', 'muller' );
		$rx      = '/TRATOR|COLHEITADEIRA|RETROESCAVADEIRA|ESCAVADEIRA|MOTONIVELADORA|CARREGADEIRA|EMPILHADEIRA|ROLO COMPACTADOR|PULVERIZADOR|GUINDASTE|[OÔ]NIBUS|CAMINH[AÃ]O|\bCARGO\b|CONSTELLATION|WORKER|\bATEGO|\bACCELO|\bAXOR|\bACTROS|\bATRON|\bAROCS|DELIVERY|VOLKSBUS|MICRO-?[OÔ]NIBUS|\bCABINE\b|^MA \d{1,2}\.\d/';
		$num     = in_array( $brand_slug, array( 'mercedes-benz', 'ford', 'volkswagen', 'agrale', 'volvo' ), true ) && preg_match( '/^(L|LK|LS|LP|O|OF|OH|VM|FH|FM|NL|NH|EDC|A|MA)?[ \-]?(\d{1,2}[\.\-]\d{3}|\d{3,5})([\.\-\/ ]|$)/', $nome );
		$t       = ( in_array( $brand_slug, $pesadas, true ) || preg_match( $rx, $nome ) || $num ) ? 'pesado' : 'carro';
	}
	$memo[ $k ] = $t;
	return $t;
}

/** Rótulo do tipo para o H1 ("moto", "caminhão"…); vazio para carro. */
function awr_vehicle_tipo_rotulo( $tipo ) {
	$r = array( 'moto' => 'moto', 'quadriciclo' => 'quadriciclo', 'aquatico' => 'jet ski', 'pesado' => 'caminhão e máquina' );
	return $r[ $tipo ] ?? '';
}

/**
 * Nome de marca/modelo em caixa normal para H1 e textos ("HYUNDAI CRETA 2.0"
 * → "Hyundai Creta 2.0"). Palavras com número e siglas de até 3 letras ficam
 * em maiúsculas (HB20, CG 160, XRE, GTI); conectivos ficam minúsculos.
 */
function awr_nome_veiculo( $s ) {
	$minus = array( 'E', 'DE', 'DA', 'DO', 'DAS', 'DOS', 'COM', 'SEM', 'PARA', 'ATE', 'ATÉ', 'A', 'EXCETO' );
	$tit3  = array( 'GOL', 'UNO', 'FOX', 'KIA', 'ONE', 'NEW', 'VAN', 'BUG', 'FAN', 'POP', 'BIZ' );
	$out   = array();
	foreach ( preg_split( '/(\s+)/u', trim( (string) $s ), -1, PREG_SPLIT_DELIM_CAPTURE ) as $i => $w ) {
		if ( '' === trim( $w ) ) { $out[] = $w; continue; }
		$up = function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $w, 'UTF-8' ) : strtoupper( $w );
		if ( $i > 0 && in_array( trim( $up, '()' ), $minus, true ) ) { $out[] = function_exists( 'mb_strtolower' ) ? mb_strtolower( $w, 'UTF-8' ) : strtolower( $w ); continue; }
		$partes = preg_split( '/([\-\/\(\)])/u', $w, -1, PREG_SPLIT_DELIM_CAPTURE );
		foreach ( $partes as &$p ) {
			$pu = function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $p, 'UTF-8' ) : strtoupper( $p );
			$len = function_exists( 'mb_strlen' ) ? mb_strlen( $p, 'UTF-8' ) : strlen( $p );
			if ( preg_match( '/\d/', $p ) || ( $len <= 3 && ! in_array( $pu, $tit3, true ) ) || ! preg_match( '/^\p{L}+$/u', $p ) ) { $p = $pu; continue; }
			$lo = function_exists( 'mb_strtolower' ) ? mb_strtolower( $p, 'UTF-8' ) : strtolower( $p );
			$p  = ( function_exists( 'mb_strtoupper' ) ? mb_strtoupper( mb_substr( $lo, 0, 1, 'UTF-8' ), 'UTF-8' ) . mb_substr( $lo, 1, null, 'UTF-8' ) : ucfirst( $lo ) );
		}
		unset( $p );
		$out[] = implode( '', $partes );
	}
	return implode( '', $out );
}

/** Anos indexáveis de um modelo (últimos ~22 anos até o ano corrente + 1). */
function awr_vehicle_years( $brand_slug, $model_slug ) {
	$min = 9999; $max = 0;
	foreach ( awr_vehicle_variants( $brand_slug, $model_slug ) as $it ) {
		$min = min( $min, (int) $it['d'] );
		$max = max( $max, (int) $it['a'] );
	}
	if ( ! $max ) { return array(); }
	// Teto: ano corrente + 1. Sem isso, dados corrompidos (ex.: "a":9170)
	// geram milhares de URLs de ano que o rewrite (19|20)xx não aceita → 404.
	$max   = min( $max, (int) gmdate( 'Y' ) + 1 );
	$floor = max( $min, (int) gmdate( 'Y' ) - 22 );
	if ( $floor > $max ) { return array(); }
	$out   = array();
	for ( $y = $floor; $y <= $max; $y++ ) { $out[] = $y; }
	return $out;
}

/** URL canônica de um veículo. */
function awr_vehicle_url( $marca, $modelo, $ano = 0 ) {
	$u = '/baterias/' . awr_slugify( $marca ) . '/' . awr_slugify( $modelo ) . '/';
	if ( $ano ) { $u .= (int) $ano . '/'; }
	return home_url( $u );
}
