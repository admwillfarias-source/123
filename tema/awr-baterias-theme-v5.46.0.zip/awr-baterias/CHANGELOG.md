## 5.46.0
- Auditoria de SEO: prazo correto nas 7 cidades sem entrega rápida (12,3 mil páginas diziam "0 min"), títulos sem corte, sitemap limpo, JSON-LD corrigido, og:image, páginas estacionárias comerciais e evento purchase no GA4 (detalhes em CHANGELOG-5.46.0.md).

## 5.45.0
- Foto do hero sem fundo e coluna direita alinhada com o texto (detalhes em CHANGELOG-5.45.0.md).

## 5.44.0
- Foto nova no hero (técnico AWR com Moura AGM), hospedada no tema e à prova de quebra (detalhes em CHANGELOG-5.44.0.md).

## 5.43.0
- Frase nova do hero, checkout automático após a busca, barra inferior e WhatsApp contextual iguais ao app, ajustes de velocidade no celular (detalhes em CHANGELOG-5.43.0.md).

## 5.42.0
- Home em paridade com o app: arte 35 min, diagnóstico grátis, prova social em linha e ordem das seções (detalhes em CHANGELOG-5.42.0.md).


## 5.33.0
- Menu completo: Carro, Moto, Caminhão, AWR Energia, Loja, Comparar, Central Técnica e Lojas.
- Identificação por foto IA oculta no tema; envio de foto pelo WhatsApp preservado.
- Topo mobile da home com busca limpa e sem botão verde duplicado.
- Hub estacionário nativo assume URLs do plugin legado, com canonical único e redirecionamentos locais validados.

## 5.32.0
- Paridade mobile com o app: topo navy nas páginas de segmento, botões WhatsApp verde-escuro e Ligar com contorno, campos e cards das páginas novas com margens e estilo do app, tabelas com rolagem lateral.
