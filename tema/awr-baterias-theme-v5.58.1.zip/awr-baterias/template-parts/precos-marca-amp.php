<?php
/**
 * 5.51.0 — Tabela de preço por amperagem × marca (menor preço à vista da
 * tabela oficial), cada célula ligada a /marca/{marca}/{n}ah/.
 *
 * Uso: awr_part( 'precos-marca-amp', array( 'titulo' => '...', 'local' => 'em Porto Alegre' ) );
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! function_exists( 'awr_marca_amp_lista' ) ) { return; }

$args   = wp_parse_args( $args ?? array(), array( 'titulo' => 'Preço de bateria por amperagem e marca', 'local' => '' ) );
$marcas = array( 'moura', 'heliar', 'zetta', 'excell' );
$ahs    = array( 40, 45, 50, 60, 70, 75, 80, 90, 95, 100 );
$lista  = awr_marca_amp_lista();
$nomes  = awr_marca_amp_marcas();
$linhas = array();
foreach ( $ahs as $ah ) {
	$l = array();
	foreach ( $marcas as $m ) {
		$l[ $m ] = ! empty( $lista[ $m ][ $ah ] ) ? min( array_column( $lista[ $m ][ $ah ], 'vista' ) ) : 0;
	}
	if ( array_filter( $l ) ) { $linhas[ $ah ] = $l; }
}
if ( ! $linhas ) { return; }
?>
<section class="awr-block awr-precos-amp">
	<h2 class="awr-section-title"><?php echo esc_html( $args['titulo'] ); ?></h2>
	<div class="awr-fam-tabela-wrap">
		<table class="awr-fam-tabela awr-fam-tabela--matriz">
			<thead><tr><th>Ah</th><?php foreach ( $marcas as $m ) : ?><th><?php echo esc_html( $nomes[ $m ]['nome'] ); ?></th><?php endforeach; ?></tr></thead>
			<tbody>
				<?php foreach ( $linhas as $ah => $l ) : ?>
					<tr>
						<td class="awr-fam-tabela__versao"><a href="<?php echo esc_url( home_url( '/baterias/amperagem/' . $ah . '/' ) ); ?>"><?php echo esc_html( $ah . 'Ah' ); ?></a></td>
						<?php foreach ( $l as $m => $p ) : ?>
							<td><?php if ( $p ) : ?><a href="<?php echo esc_url( awr_marca_amp_url( $m, $ah ) ); ?>"><?php echo esc_html( 'R$ ' . number_format( (float) $p, 0, ',', '.' ) ); ?></a><?php else : ?>—<?php endif; ?></td>
						<?php endforeach; ?>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<p class="awr-fam-nota">Menor preço à vista (Pix ou dinheiro) com a troca da bateria usada<?php echo $args['local'] ? esc_html( ', entrega e instalação ' . $args['local'] ) : ''; ?>. Em até 10x sem juros no cartão. Toque no preço para ver os modelos e os carros compatíveis.</p>
</section>
