<?php
/**
 * 5.57.0 — Avaliações reais do WooCommerce na página de produto.
 * Sem avaliações aprovadas não há nota nem estrelas: só o convite para avaliar.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$args  = wp_parse_args( $args ?? array(), array( 'itens' => array(), 'media' => 0, 'total' => 0, 'url' => '' ) );
$itens = (array) $args['itens'];
?>
<section class="awr-block awr-pp-aval" id="avaliacoes">
	<h2 class="awr-section-title">Avaliações de clientes</h2>
	<?php if ( $itens && (int) $args['total'] > 0 ) : ?>
		<p class="awr-pp-aval__resumo"><b><?php echo esc_html( number_format( (float) $args['media'], 1, ',', '' ) ); ?></b> de 5 · <?php echo (int) $args['total']; ?> avaliaç<?php echo 1 === (int) $args['total'] ? 'ão' : 'ões'; ?> de compradores</p>
		<ul class="awr-pp-aval__lista">
			<?php foreach ( $itens as $a ) : ?>
				<li>
					<p class="awr-pp-aval__top"><span aria-label="<?php echo (int) $a['nota']; ?> de 5"><?php echo esc_html( str_repeat( '★', max( 0, min( 5, (int) $a['nota'] ) ) ) ); ?></span> <b><?php echo esc_html( $a['nome'] ); ?></b> <small><?php echo esc_html( $a['data'] ); ?></small></p>
					<p><?php echo esc_html( wp_strip_all_tags( $a['texto'] ) ); ?></p>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php else : ?>
		<p>Esta bateria ainda não tem avaliações publicadas. Comprou com a AWR? Conte como foi.</p>
	<?php endif; ?>
	<?php if ( $args['url'] ) : ?>
		<p><a class="awr-btn awr-btn--outline" rel="nofollow" href="<?php echo esc_url( $args['url'] ); ?>">Avaliar esta bateria</a></p>
	<?php endif; ?>
</section>
