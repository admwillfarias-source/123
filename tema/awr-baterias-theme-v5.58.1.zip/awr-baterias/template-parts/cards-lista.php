<?php
/**
 * 5.54.0 — Lista de cards de bateria no modelo escolhido (inc/cards.php).
 * Uso: awr_part( 'cards-lista', array( 'produtos' => $p, 'veiculo' => 'Hyundai Creta 2.0 2020' ) );
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$args = wp_parse_args( $args ?? array(), array( 'produtos' => array(), 'veiculo' => '', 'modelo' => null ) );
if ( ! $args['produtos'] ) { return; }
$awr_l = awr_cards_preparar( $args['produtos'], $args['veiculo'], $args['modelo'] );
?>
<div class="awr-cards awr-cards--busca awr-cards--m-<?php echo esc_attr( $awr_l['modelo'] ); ?>" data-card-modelo="<?php echo esc_attr( $awr_l['modelo'] ); ?>">
	<?php foreach ( $awr_l['visiveis'] as $p ) { awr_part( 'card-bateria', array( 'produto' => $p, 'veiculo' => $args['veiculo'] ) ); } ?>
</div>
<?php if ( count( $awr_l['visiveis'] ) > 1 ) : ?>
	<p class="awr-cards__arraste">Arraste para o lado para ver mais opções →</p>
<?php endif; ?>
<?php if ( $awr_l['mais'] ) : ?>
	<details class="awr-cards-mais">
		<summary>Ver todas as compatíveis (<?php echo (int) count( $awr_l['mais'] ); ?>)</summary>
		<div class="awr-cards awr-cards--busca">
			<?php foreach ( $awr_l['mais'] as $p ) { awr_part( 'card-bateria', array( 'produto' => $p, 'veiculo' => $args['veiculo'] ) ); } ?>
		</div>
	</details>
<?php endif; ?>
