<?php
/**
 * /awr-previa-cards/ — 5.54.0. Os 3 modelos de card lado a lado, com um
 * veículo real (?veiculo=onix 2018). Só para administrador; noindex.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! current_user_can( 'manage_options' ) ) {
	status_header( 404 );
	get_template_part( '404' );
	return;
}
$awr_q   = isset( $_GET['veiculo'] ) ? sanitize_text_field( wp_unslash( $_GET['veiculo'] ) ) : 'Onix 2018'; // phpcs:ignore WordPress.Security.NonceVerification
$awr_sug = awr_search_suggestions( $awr_q, 1 );
$awr_ano = preg_match( '/\b((?:19|20)\d{2})\b/', $awr_q, $m ) ? (int) $m[1] : 0;
$awr_it  = $awr_sug ? awr_vehicle_by_slug( $awr_sug[0]['slug'], $awr_ano ) : array();
$awr_vei = $awr_it ? awr_nome_veiculo( $awr_it[0]['ma'] . ' ' . $awr_it[0]['mo'] ) . ( $awr_ano ? ' ' . $awr_ano : '' ) : $awr_q;
$awr_pr  = $awr_it ? awr_products_by_skus( awr_skus_from_items( $awr_it ) ) : array();
get_header();
?>
<div class="awr-container awr-veiculo">
	<h1>Prévia dos modelos de card — <?php echo esc_html( $awr_vei ); ?></h1>
	<form method="get"><input type="text" name="veiculo" value="<?php echo esc_attr( $awr_q ); ?>"> <button class="awr-btn awr-btn--sec" type="submit">Trocar veículo</button>
	<a href="<?php echo esc_url( admin_url( 'options-general.php?page=awr-busca-admin' ) ); ?>">Escolher o modelo no painel</a></form>
	<?php if ( ! $awr_pr ) : ?><p>Nenhuma bateria para esse veículo.</p><?php endif; ?>
	<?php foreach ( awr_card_modelos() as $awr_k => $awr_rot ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title"><?php echo esc_html( $awr_rot ); ?></h2>
			<?php if ( 'app' !== $awr_k && ! awr_cards_menor_preco( $awr_pr ) ) : ?><p>Sem preço na loja para esse veículo: este modelo mostra o mesmo que o A.</p><?php endif; ?>
			<?php awr_part( 'cards-lista', array( 'produtos' => $awr_pr, 'veiculo' => $awr_vei, 'modelo' => $awr_k ) ); ?>
		</section>
	<?php endforeach; ?>
</div>
<?php
get_footer();
