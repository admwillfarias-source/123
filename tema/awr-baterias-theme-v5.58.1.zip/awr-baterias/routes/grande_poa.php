<?php
/**
 * /baterias-grande-porto-alegre/ — 5.51.0.
 * Hub das cidades com entrega e instalação local (assets/data/cidades.json),
 * com o prazo real de cada uma (awr_city_prazo) e a loja que atende.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$awr_cids = (array) awr_cidades();
usort( $awr_cids, function ( $x, $y ) {
	return ( (int) ( $x['prioridade'] ?? 99 ) <=> (int) ( $y['prioridade'] ?? 99 ) ) ?: strcmp( $x['nome'], $y['nome'] );
} );
$awr_zonas = (array) awr_data( 'zonas-poa' );

$awr_faq = array(
	array( 'q' => 'Quais cidades da Grande Porto Alegre a AWR atende com instalação no local?', 'r' => implode( ', ', array_column( $awr_cids, 'nome' ) ) . '. Em todas elas a equipe leva a bateria e instala no seu endereço.' ),
	array( 'q' => 'Em quanto tempo a bateria chega?', 'r' => 'Depende da cidade: veja o prazo de cada uma na lista desta página. Nas cidades com entrega rápida, a bateria chega e é instalada em até 35 minutos.' ),
	array( 'q' => 'A instalação é cobrada à parte?', 'r' => 'Não. A instalação e o teste do alternador estão incluídos no preço, e recolhemos a bateria usada.' ),
	array( 'q' => 'E se eu estiver fora da Grande Porto Alegre?', 'r' => 'Enviamos por transportadora para cidades do RS, SC, PR e SP, com frete cotado pelo CEP.' ),
);

get_header();
?>
<div class="awr-container awr-veiculo awr-familia awr-grande-poa">
	<?php
	awr_part( 'hero', array(
		'eyebrow'  => 'Porto Alegre e região metropolitana',
		'h1'       => 'Baterias na Grande Porto Alegre com entrega e instalação no local',
		'lead'     => 'A AWR leva a bateria e instala no seu endereço em ' . count( $awr_cids ) . ' cidades da região metropolitana, com teste do alternador e garantia de fábrica. Veja o prazo da sua cidade.',
		'wa'       => 'Olá! Preciso de uma bateria. Vocês atendem minha cidade na Grande Porto Alegre?',
		'wa_label' => 'Falar com um atendente',
		'trilha'   => array( array( 'nome' => 'Cidades', 'url' => home_url( '/baterias-em/' ) ) ),
		'atual'    => 'Grande Porto Alegre',
		'badges'   => array( '🚗 Instalação no local', '🛡 Garantia de fábrica', '💳 10x sem juros' ),
	) );
	?>

	<section class="awr-block">
		<h2 class="awr-section-title">Cidades atendidas e prazo de entrega</h2>
		<div class="awr-fam-tabela-wrap">
			<table class="awr-fam-tabela">
				<thead><tr><th>Cidade</th><th>Prazo</th><th>Loja que atende</th><th></th></tr></thead>
				<tbody>
					<?php foreach ( $awr_cids as $awr_c ) : ?>
						<?php
						$awr_pz   = awr_city_prazo( $awr_c );
						$awr_loja = function_exists( 'awr_loja_do_bairro' ) ? awr_loja_do_bairro( $awr_c['slug'] ) : null;
						?>
						<tr>
							<td class="awr-fam-tabela__versao"><a href="<?php echo esc_url( home_url( '/baterias-em/' . $awr_c['slug'] . '/' ) ); ?>"><?php echo esc_html( $awr_c['nome'] ); ?></a></td>
							<td><?php echo esc_html( ucfirst( $awr_pz['curto'] ) ); ?></td>
							<td><?php echo $awr_loja ? '<a href="' . esc_url( home_url( '/lojas/' . $awr_loja['slug'] . '/' ) ) . '">' . esc_html( $awr_loja['nome'] ?? $awr_loja['slug'] ) . '</a>' : '—'; ?></td>
							<td><a class="awr-fam-tabela__cta" target="_top" rel="noopener" data-awr-source="grande_poa" href="<?php echo esc_url( awr_wa( 'Olá! Preciso de uma bateria em ' . $awr_c['nome'] . '. Qual o preço e o prazo?' ) ); ?>">Pedir</a></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</section>

	<?php if ( $awr_zonas ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title">Porto Alegre por zona</h2>
			<ul class="awr-chips">
				<?php foreach ( $awr_zonas as $awr_z ) : ?>
					<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-porto-alegre/' . $awr_z['slug'] . '/' ) ); ?>"><?php echo esc_html( 'Baterias ' . ( $awr_z['nome'] ?? $awr_z['slug'] ) ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>

	<section class="awr-block">
		<h2 class="awr-section-title">Fora da região metropolitana?</h2>
		<p>Enviamos para cidades do RS, SC, PR e SP por transportadora, com rastreio e frete cotado pelo CEP. <a href="<?php echo esc_url( home_url( '/entrega-por-transportadora/' ) ); ?>">Veja como funciona o envio por transportadora</a>.</p>
	</section>

	<?php awr_part( 'search', array( 'titulo' => 'Busque a bateria do seu carro' ) ); ?>

	<?php awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes', 'itens' => $awr_faq ) ); ?>
</div>
<?php
awr_faq_jsonld( $awr_faq, home_url( '/baterias-grande-porto-alegre/#faq' ) );
get_footer();
