<?php
/**
 * /baterias-carros-eletricos-e-hibridos/ — 5.51.0.
 * Bateria auxiliar de 12V dos elétricos e híbridos do catálogo. No Search
 * Console é o nicho em que o site já ganha (Peugeot e-Expert, Kwid E-Tech,
 * Fusion Hybrid, Tiggo 8 híbrido, Compass 4xe, BYD Dolphin Mini).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$awr_lista = awr_eletricos_modelos();
$awr_marcas = array();
foreach ( $awr_lista as $awr_r ) { $awr_marcas[ $awr_r['marca'] ][] = $awr_r; }
ksort( $awr_marcas );

$awr_faq = array(
	array( 'q' => 'Carro elétrico tem bateria de 12V?', 'r' => 'Sim. Além da bateria de tração (alta tensão), elétricos e híbridos usam uma bateria auxiliar de 12V que liga a central eletrônica, as travas, a multimídia e o sistema que ativa a bateria principal. Se ela descarrega, o carro não "liga", mesmo com a bateria de tração carregada.' ),
	array( 'q' => 'Quais os sinais de que a bateria 12V do elétrico ou híbrido está fraca?', 'r' => 'Painel que não acende ou pisca, carro que não entra em "ready", travas e chave presencial falhando, alertas de sistema elétrico e multimídia reiniciando. O teste no local confirma em poucos minutos.' ),
	array( 'q' => 'Qual o tipo de bateria 12V dos elétricos e híbridos?', 'r' => 'Depende do modelo: muitos usam AGM, outros EFB ou convencional, em tamanhos específicos. A tabela desta página mostra a bateria de cada modelo do catálogo.' ),
	array( 'q' => 'Vocês instalam a bateria 12V no local?', 'r' => 'Sim. Em Porto Alegre e Grande Porto Alegre a AWR leva a bateria e instala no seu endereço em até 35 minutos, com cuidado com a memória dos módulos. Para outras cidades enviamos por transportadora.' ),
);

get_header();
?>
<div class="awr-container awr-veiculo awr-familia awr-eletricos">
	<?php
	awr_part( 'hero', array(
		'eyebrow'  => 'Elétricos e híbridos',
		'h1'       => 'Bateria 12V para carros elétricos e híbridos',
		'lead'     => 'Seu elétrico ou híbrido não entra em "ready"? Na maioria das vezes a culpada é a bateria auxiliar de 12V. Veja a bateria certa de ' . count( $awr_lista ) . ' modelos e receba com instalação no local em até 35 minutos em Porto Alegre e Grande Porto Alegre.',
		'wa'       => 'Olá! Preciso da bateria 12V do meu carro elétrico/híbrido. Podem me passar o preço e a entrega?',
		'wa_label' => 'Falar com um atendente',
		'trilha'   => array( array( 'nome' => 'Baterias', 'url' => home_url( '/baterias/' ) ) ),
		'atual'    => 'Bateria para elétricos e híbridos',
		'badges'   => array( '⏱ Instalação em até 35 min', '🔌 Bateria auxiliar 12V', '🛡 Garantia de fábrica' ),
	) );
	?>

	<section class="awr-block">
		<h2 class="awr-section-title">Por que o elétrico ou híbrido para por causa da bateria 12V</h2>
		<p>A bateria de tração move o carro, mas quem acorda os sistemas é a bateria de 12V. Ela alimenta módulos, travas, chave presencial e o relé que conecta a bateria de alta tensão. Como fica muito tempo em uso leve e sem a carga de um alternador convencional, ela costuma durar menos do que se espera e dá pouco aviso antes de falhar.</p>
		<p>Na troca, o importante é usar a especificação certa (AGM, EFB ou convencional, no tamanho e na polaridade do original) e fazer a instalação sem perder a memória dos módulos. É isso que a equipe da AWR faz no local.</p>
	</section>

	<section class="awr-block">
		<h2 class="awr-section-title">Bateria 12V por modelo</h2>
		<?php foreach ( $awr_marcas as $awr_mn => $awr_rs ) : ?>
			<h3 class="awr-eletricos__marca"><?php echo esc_html( $awr_mn ); ?></h3>
			<div class="awr-fam-tabela-wrap">
				<table class="awr-fam-tabela">
					<thead><tr><th>Modelo</th><th>Anos</th><th>Bateria 12V</th><th>Tipo</th><th></th></tr></thead>
					<tbody>
						<?php foreach ( $awr_rs as $awr_r ) : ?>
							<tr>
								<td class="awr-fam-tabela__versao"><a href="<?php echo esc_url( $awr_r['url'] ); ?>"><?php echo esc_html( $awr_r['modelo'] ); ?></a></td>
								<td><?php echo esc_html( $awr_r['de'] . '–' . $awr_r['ate'] ); ?></td>
								<td><?php echo esc_html( ( $awr_r['ah'] ? $awr_r['ah'] . 'Ah · ' : '' ) . implode( ' · ', $awr_r['codigos'] ) ); ?></td>
								<td><?php echo esc_html( $awr_r['tec'] ); ?></td>
								<td><a class="awr-fam-tabela__cta" target="_top" rel="noopener" data-awr-source="eletricos" href="<?php echo esc_url( awr_wa( 'Olá! Quero a bateria 12V do ' . $awr_mn . ' ' . $awr_r['modelo'] . '. Qual o preço e a entrega?' ) ); ?>">Pedir</a></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endforeach; ?>
		<p class="awr-fam-nota">Códigos das fabricantes Moura, Heliar, Zetta e Excell. O técnico confirma a aplicação no local antes de instalar, sem custo.</p>
	</section>

	<?php awr_part( 'search', array( 'titulo' => 'Não achou seu modelo? Busque pelo nome e ano' ) ); ?>

	<?php awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes', 'itens' => $awr_faq ) ); ?>
</div>
<?php
awr_faq_jsonld( $awr_faq, home_url( '/baterias-carros-eletricos-e-hibridos/#faq' ) );
get_footer();
