<?php
/**
 * Caminhos de SEO da busca por veículo.
 *
 * /baterias/{marca}/                  → hub do fabricante
 * /baterias/{marca}/{modelo}/         → todos os anos do modelo
 * /baterias/{marca}/{modelo}/{ano}/   → página final com SKUs compatíveis
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$marca_slug  = awr_param_a();
$modelo_slug = awr_param_b();
$ano         = (int) awr_param_c();
$marca_nome  = awr_is_vehicle_brand( $marca_slug );

if ( ! $marca_nome ) { get_template_part( '404' ); return; }

$modelos = awr_vehicle_models( $marca_slug );
$variantes = $modelo_slug ? awr_vehicle_variants( $marca_slug, $modelo_slug, $ano ) : array();
$modelo_nome = ( $modelo_slug && isset( $modelos[ $modelo_slug ] ) ) ? $modelos[ $modelo_slug ]['nome'] : '';

// 5.51.0 — /baterias/{marca}/{familia}/: todas as versões de um modelo.
if ( $modelo_slug && ! $modelo_nome && ! $ano && awr_vehicle_family( $marca_slug, $modelo_slug ) ) {
	require __DIR__ . '/veiculo_familia.php';
	return;
}

if ( $modelo_slug && ! $modelo_nome ) { get_template_part( '404' ); return; }

// Família da versão (para o bloco "todas as versões").
$awr_familia = $modelo_nome ? awr_vehicle_family_of( $marca_slug, $modelo_slug ) : null;

// 5.52.0 — tipo do veículo (carro, moto, caminhão…) e nomes em caixa normal
// para H1 e textos (o slug não muda: awr_slugify ignora maiúsculas).
$awr_tipo   = $modelo_slug ? awr_vehicle_tipo( $marca_slug, (string) $modelo_slug ) : 'carro';
$awr_rotulo = awr_vehicle_tipo_rotulo( $awr_tipo );
$marca_nome = awr_nome_veiculo( $marca_nome );
if ( $modelo_nome ) { $modelo_nome = awr_nome_veiculo( $modelo_nome ); }
$awr_seu    = array( 'moto' => 'da sua moto', 'quadriciclo' => 'do seu quadriciclo', 'aquatico' => 'do seu jet ski', 'pesado' => 'do seu caminhão ou máquina' )[ $awr_tipo ] ?? 'do seu carro';

$titulo = trim( $marca_nome . ' ' . $modelo_nome . ( $ano ? " {$ano}" : '' ) );
$awr_faq_entrega = array(
	'moto'        => 'Em Porto Alegre e Grande Porto Alegre levamos e instalamos a bateria da moto no local, em até 35 minutos nas cidades com entrega rápida. Para outras cidades, enviamos por transportadora.',
	'quadriciclo' => 'Entregamos em Porto Alegre e Grande Porto Alegre ou enviamos por transportadora. Confirme a disponibilidade e o prazo no WhatsApp.',
	'aquatico'    => 'Entregamos em Porto Alegre e Grande Porto Alegre ou enviamos por transportadora. Confirme a disponibilidade e o prazo no WhatsApp.',
	'pesado'      => 'Atendemos caminhões, ônibus e máquinas em Porto Alegre e Grande Porto Alegre, com instalação no local. Sistemas de 24V usam duas baterias de 12V; o técnico confere antes de instalar.',
)[ $awr_tipo ] ?? 'Em até 35 minutos em Porto Alegre e Grande Porto Alegre, com instalação grátis e teste do alternador.';
$produtos = $variantes ? awr_products_by_skus( awr_skus_from_items( $variantes ) ) : array();
$compat_checkout = array();
foreach ( array_slice( $produtos, 0, 3 ) as $produto ) {
	$compat_checkout[] = array(
		'sku'      => (string) ( $produto['sku'] ?? '' ),
		'nome'     => (string) ( $produto['nome'] ?? $produto['name'] ?? $produto['sku'] ?? '' ),
		'preco'    => (float) ( $produto['price'] ?? $produto['preco'] ?? 0 ),
		'casco'    => (float) ( $produto['casco'] ?? 0 ),
		'image'    => (string) ( $produto['image'] ?? $produto['imagem'] ?? '' ),
		'garantia' => (string) ( $produto['garantia'] ?? '' ),
		'veiculo'  => $titulo,
	);
}

get_header();
?>
<div class="awr-container awr-veiculo">
	<?php
	$trilha = array( array( 'nome' => 'Baterias', 'url' => home_url( '/baterias/' ) ) );
	if ( $modelo_nome ) {
		$trilha[] = array( 'nome' => $marca_nome, 'url' => home_url( '/baterias/' . $marca_slug . '/' ) );
	}
	if ( $ano ) {
		$trilha[] = array( 'nome' => $modelo_nome, 'url' => awr_vehicle_url( $marca_nome, $modelo_nome ) );
	}
	if ( in_array( $awr_tipo, array( 'quadriciclo', 'aquatico' ), true ) && ! $produtos ) {
		$awr_lead = "Veja a bateria compatível com o {$titulo} e peça o preço no WhatsApp. Entrega em Porto Alegre e Grande Porto Alegre ou envio por transportadora.";
	} elseif ( $ano ) {
		$awr_lead = "Veja as baterias compatíveis com " . ( 'moto' === $awr_tipo ? 'a moto ' : 'o ' ) . "{$titulo}, com preço à vista, 10x sem juros e instalação grátis no local em até 35 minutos em Porto Alegre e Grande Porto Alegre.";
	} elseif ( $modelo_nome ) {
		$awr_lead = "Escolha o ano " . ( 'moto' === $awr_tipo ? 'da sua' : 'do seu' ) . " {$marca_nome} {$modelo_nome} e confira a bateria certa, o preço atualizado e a entrega com instalação no local.";
	} else {
		$awr_lead = "Todos os modelos {$marca_nome} atendidos pela AWR Baterias, com entrega e instalação em até 35 minutos.";
	}
	awr_part( 'hero', array(
		'eyebrow' => 'Baterias ' . $marca_nome,
		'h1'      => $modelo_nome ? trim( "Bateria para {$awr_rotulo} {$titulo}" ) : "Bateria para {$marca_nome} — todos os modelos",
		'lead'    => $awr_lead,
		'wa'      => "Olá! Preciso da bateria {$awr_seu} {$titulo}. Podem me passar o preço e a entrega?",
		'wa_label'=> 'Falar com um atendente',
		'trilha'  => $trilha,
		'atual'   => $modelo_nome ? "Bateria {$titulo}" : "Bateria {$marca_nome}",
		'badges'  => $ano ? array( '⏱ Instalação em até 35 min', '🛡 Garantia de fábrica', '💳 10x sem juros' ) : null,
	) );
	?>

	<?php
	// 5.53.0 — Modelo sem páginas de ano (motos antigas do catálogo Motobatt):
	// os produtos e preços aparecem na própria página do modelo.
	$awr_sem_anos = $modelo_nome && ! $ano && ! awr_vehicle_years( $marca_slug, $modelo_slug );
	?>
	<?php if ( ( $ano || $awr_sem_anos ) && $produtos ) : ?>
		<script type="application/json" id="awr-static-compat"><?php echo wp_json_encode( $compat_checkout, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?></script>
		<section class="awr-results awr-results--static" aria-label="Baterias compatíveis">
			<div class="awr-results__head">
				<div class="awr-results__headtext">
					<span class="awr-results__badge"><i aria-hidden="true"></i>Compatíveis • em estoque</span>
					<h2 class="awr-results__title">Baterias recomendadas <small><?php $awr_min = awr_cards_menor_preco( $produtos ); echo esc_html( $titulo . ( $awr_min ? ' · a partir de ' . awr_brl( $awr_min ) : '' ) ); ?></small></h2>
				</div>
				<a class="awr-results__reset" href="<?php echo esc_url( home_url( '/buscar/' ) ); ?>">Trocar veículo</a>
			</div>
			<?php awr_part( 'cards-lista', array( 'produtos' => $produtos, 'veiculo' => $titulo ) ); ?>
		</section>
	<?php elseif ( $ano ) : ?>
		<div class="awr-results__empty">
			<p>Estamos atualizando os preços para o <b><?php echo esc_html( $titulo ); ?></b>. Fale com a gente — respondemos em 2 minutos com preço e entrega.</p>
			<a class="awr-btn awr-btn--green" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( "Olá! Preciso da bateria do meu {$titulo}. Podem me passar o preço e a entrega?" ) ); ?>">Falar no WhatsApp agora</a>
		</div>
	<?php endif; ?>

	<?php if ( $modelo_nome && ! $ano ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title">Escolha o ano <?php echo esc_html( ( 'moto' === $awr_tipo ? 'da sua ' : 'do seu ' ) . $modelo_nome ); ?></h2>
			<?php
			$awr_dec = array();
			foreach ( array_reverse( awr_vehicle_years( $marca_slug, $modelo_slug ) ) as $y ) { $awr_dec[ (int) floor( $y / 10 ) * 10 ][] = $y; }
			?>
			<?php foreach ( $awr_dec as $awr_d => $awr_ys ) : ?>
				<h3 class="awr-veiculo__decada"><?php echo esc_html( $modelo_nome . ' ' . ( 2000 <= $awr_d ? 'anos ' . $awr_d : 'anos ' . $awr_d ) ); ?></h3>
				<ul class="awr-chips">
					<?php foreach ( $awr_ys as $y ) : ?>
						<li><a class="awr-chip" href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $modelo_nome, $y ) ); ?>"><?php echo esc_html( $marca_nome . ' ' . $modelo_nome . ' ' . $y ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endforeach; ?>
		</section>
	<?php endif; ?>

	<?php if ( $ano ) : ?>
		<details class="awr-block awr-link-disclosure">
			<summary>Outros anos do <?php echo esc_html( $modelo_nome ); ?></summary>
			<ul class="awr-chips">
				<?php foreach ( array_reverse( awr_vehicle_years( $marca_slug, $modelo_slug ) ) as $y ) : ?>
					<?php if ( $y === $ano ) { continue; } ?>
					<li><a class="awr-chip" href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $modelo_nome, $y ) ); ?>"><?php echo esc_html( $modelo_nome . ' ' . $y ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</details>
	<?php endif; ?>

	<?php if ( $awr_familia ) : ?>
		<section class="awr-block awr-familia-versoes">
			<h2 class="awr-section-title">Todas as versões do <?php echo esc_html( $marca_nome . ' ' . $awr_familia['nome'] ); ?></h2>
			<ul class="awr-chips">
				<?php if ( awr_vehicle_family( $marca_slug, $awr_familia['slug'] ) ) : ?>
					<li><a class="awr-chip awr-chip--destaque" href="<?php echo esc_url( awr_vehicle_family_url( $marca_slug, $awr_familia['slug'] ) ); ?>">Bateria de cada versão do <?php echo esc_html( $awr_familia['nome'] ); ?> (tabela)</a></li>
				<?php endif; ?>
				<?php foreach ( $awr_familia['modelos'] as $awr_ms ) : ?>
					<?php if ( $awr_ms === (string) $modelo_slug || empty( $modelos[ $awr_ms ] ) ) { continue; } ?>
					<li><a class="awr-chip" href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $modelos[ $awr_ms ]['nome'] ) ); ?>"><?php echo esc_html( $marca_nome . ' ' . $modelos[ $awr_ms ]['nome'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>

	<?php if ( ! $modelo_nome ) : ?>
		<?php
		// 5.52.0 — Página da marca: modelos visíveis, um H3 por família (ou letra).
		$awr_grupos = array();
		$awr_nafam  = array();
		foreach ( awr_vehicle_families( $marca_slug ) as $awr_f ) {
			foreach ( $awr_f['modelos'] as $awr_ms ) { $awr_nafam[ $awr_ms ] = true; }
			$awr_grupos[ awr_nome_veiculo( $awr_f['nome'] ) ] = array( 'url' => awr_vehicle_family( $marca_slug, $awr_f['slug'] ) ? awr_vehicle_family_url( $marca_slug, $awr_f['slug'] ) : '', 'modelos' => $awr_f['modelos'] );
		}
		foreach ( $modelos as $awr_ms => $awr_m ) {
			if ( isset( $awr_nafam[ (string) $awr_ms ] ) ) { continue; }
			$awr_l = strtoupper( substr( (string) $awr_ms, 0, 1 ) );
			$awr_l = ctype_digit( $awr_l ) ? '0–9' : $awr_l;
			$awr_grupos[ 'Modelos ' . $awr_l ]['url']       = '';
			$awr_grupos[ 'Modelos ' . $awr_l ]['modelos'][] = (string) $awr_ms;
		}
		ksort( $awr_grupos, SORT_NATURAL | SORT_FLAG_CASE );
		?>
		<section class="awr-block awr-marca-modelos">
			<h2 class="awr-section-title">Modelos <?php echo esc_html( $marca_nome ); ?> (<?php echo (int) count( $modelos ); ?>)</h2>
			<?php foreach ( $awr_grupos as $awr_g => $awr_d ) : ?>
				<h3 class="awr-veiculo__decada"><?php echo $awr_d['url'] ? '<a href="' . esc_url( $awr_d['url'] ) . '">' . esc_html( $marca_nome . ' ' . $awr_g ) . '</a>' : esc_html( 0 === strpos( $awr_g, 'Modelos ' ) ? $awr_g : $marca_nome . ' ' . $awr_g ); ?></h3>
				<ul class="awr-chips">
					<?php foreach ( $awr_d['modelos'] as $awr_ms ) : ?>
						<?php if ( empty( $modelos[ $awr_ms ] ) ) { continue; } ?>
						<li><a class="awr-chip" href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $modelos[ $awr_ms ]['nome'] ) ); ?>"><?php echo esc_html( awr_nome_veiculo( $modelos[ $awr_ms ]['nome'] ) ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endforeach; ?>
		</section>
	<?php else : ?>
	<details class="awr-block awr-link-disclosure">
		<summary>Modelos <?php echo esc_html( $marca_nome ); ?></summary>
		<ul class="awr-chips">
			<?php foreach ( $modelos as $ms => $m ) : ?>
				<?php if ( $ms === $modelo_slug ) { continue; } ?>
				<li><a class="awr-chip" href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $m['nome'] ) ); ?>"><?php echo esc_html( $marca_nome . ' ' . awr_nome_veiculo( $m['nome'] ) ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</details>
	<?php endif; ?>

	<?php awr_part( 'search', array( 'titulo' => 'Buscar a bateria de outro veículo' ) ); ?>

	<section class="awr-block awr-faq">
		<h2 class="awr-section-title">Perguntas frequentes</h2>
		<details><summary>Qual bateria usar no <?php echo esc_html( $titulo ?: $marca_nome ); ?>?</summary>
			<p>Indicamos os modelos compatíveis listados nesta página. Em caso de dúvida, o técnico confirma a aplicação no local antes da instalação, sem custo.</p></details>
		<details><summary>Em quanto tempo vocês entregam?</summary>
			<p><?php echo esc_html( $awr_faq_entrega ); ?></p></details>
		<details><summary>Qual a garantia?</summary>
			<p>Garantia de fábrica de 24 meses (18 meses na linha Zetta), com nota fiscal.</p></details>
	</section>

	<?php awr_part( 'links-internos', array( 'tipo' => 'conteudo', 'slug' => $marca_slug ) ); ?>
</div>

<?php
$faq = array(
	'@context'   => 'https://schema.org',
	'@type'      => 'FAQPage',
	'mainEntity' => array(
		array(
			'@type'          => 'Question',
			'name'           => 'Qual bateria usar no ' . ( $titulo ?: $marca_nome ) . '?',
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => 'Os modelos compatíveis estão listados nesta página. O técnico confirma a aplicação no local antes da instalação.' ),
		),
		array(
			'@type'          => 'Question',
			'name'           => 'Em quanto tempo a bateria é entregue?',
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $awr_faq_entrega ),
		),
	),
);
awr_jsonld( $faq );
if ( ( $ano || ! empty( $awr_sem_anos ) ) && $produtos ) { awr_product_item_list_schema( $produtos, 'Baterias recomendadas para ' . $titulo ); }

get_footer();
