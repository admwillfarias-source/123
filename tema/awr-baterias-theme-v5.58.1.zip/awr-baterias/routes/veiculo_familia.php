<?php
/**
 * /baterias/{marca}/{familia}/ — 5.51.0.
 * Todas as versões de um modelo (ex.: Creta 1.0 e 1.6 + Creta 2.0) com a
 * bateria de cada uma. Incluído por routes/veiculo.php; dados em
 * awr_vehicle_family_rows() (inc/search.php).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$awr_fam    = awr_vehicle_family( $marca_slug, $modelo_slug );
$awr_rows   = awr_vehicle_family_rows( $marca_slug, $awr_fam );
$awr_titulo = awr_nome_veiculo( $marca_nome . ' ' . $awr_fam['nome'] );
$awr_url    = awr_vehicle_family_url( $marca_slug, $awr_fam['slug'] );

$awr_items = array();
foreach ( $awr_fam['modelos'] as $awr_ms ) {
	$awr_items = array_merge( $awr_items, awr_vehicle_variants( $marca_slug, $awr_ms ) );
}
$awr_prod = array_slice( awr_products_by_skus( awr_skus_from_items( $awr_items ) ), 0, 6 );

$awr_ahs = array_filter( array_column( $awr_rows, 'ah' ) );
$awr_de  = $awr_rows ? min( array_column( $awr_rows, 'de' ) ) : 0;
$awr_ate = $awr_rows ? max( array_column( $awr_rows, 'ate' ) ) : 0;

// FAQ montada só com os dados da tabela.
$awr_faq = array();
foreach ( array_slice( $awr_rows, 0, 4 ) as $awr_r ) {
	$awr_faq[] = array(
		'q' => 'Qual a bateria do ' . $marca_nome . ' ' . $awr_r['versao'] . ' (' . $awr_r['de'] . ' a ' . $awr_r['ate'] . ')?',
		'r' => 'Usa bateria ' . ( $awr_r['ah'] ? $awr_r['ah'] . 'Ah ' : '' ) . ( 'Convencional' !== $awr_r['tec'] ? $awr_r['tec'] . ' ' : '' )
			. '— ' . implode( ', ', array_map( function ( $m, $c ) { return $m . ' ' . $c; }, array_keys( $awr_r['codigos'] ), $awr_r['codigos'] ) ) . '.',
	);
}
if ( $awr_ahs ) {
	$awr_faq[] = array(
		'q' => 'Qual a amperagem da bateria do ' . $awr_titulo . '?',
		'r' => min( $awr_ahs ) === max( $awr_ahs )
			? 'Todas as versões do ' . $awr_titulo . ' usam bateria de ' . min( $awr_ahs ) . 'Ah.'
			: 'Varia conforme a versão: de ' . min( $awr_ahs ) . 'Ah a ' . max( $awr_ahs ) . 'Ah. Confira a sua versão na tabela.',
	);
}
$awr_por_tec = array();
foreach ( $awr_rows as $awr_r ) { $awr_por_tec[ $awr_r['tec'] ][ $awr_r['versao'] ] = true; }
if ( array_intersect( array( 'AGM', 'EFB', 'Start-stop' ), array_keys( $awr_por_tec ) ) ) {
	$awr_partes = array();
	foreach ( $awr_por_tec as $awr_t => $awr_vs ) {
		$awr_partes[] = implode( ', ', array_keys( $awr_vs ) ) . ': ' . ( 'Convencional' === $awr_t ? 'bateria convencional' : ( 'Start-stop' === $awr_t ? 'bateria para start-stop' : 'bateria ' . $awr_t ) );
	}
	$awr_faq[] = array(
		'q' => 'O ' . $awr_titulo . ' usa bateria AGM ou EFB?',
		'r' => implode( '; ', $awr_partes ) . '. Nas versões AGM ou EFB, uma bateria comum dura pouco e pode acender alertas no painel.',
	);
}
$awr_faq[] = array(
	'q' => 'Vocês entregam e instalam a bateria do ' . $awr_titulo . '?',
	'r' => 'Sim. Em Porto Alegre e Grande Porto Alegre a bateria chega e é instalada no local em até 35 minutos, com teste do alternador. Para outras cidades enviamos por transportadora.',
);

get_header();
?>
<div class="awr-container awr-veiculo awr-familia">
	<?php
	awr_part( 'hero', array(
		'eyebrow'  => 'Baterias ' . $marca_nome,
		'h1'       => 'Bateria para ' . $awr_titulo . ': todas as versões',
		'lead'     => 'Veja a bateria certa para cada versão do ' . $awr_titulo . ( $awr_de ? " ({$awr_de} a {$awr_ate})" : '' ) . ', com preço à vista, 10x sem juros e instalação grátis em até 35 minutos em Porto Alegre e Grande Porto Alegre.',
		'wa'       => "Olá! Preciso da bateria do meu {$awr_titulo}. Podem me passar o preço e a entrega?",
		'wa_label' => 'Falar com um atendente',
		'trilha'   => array(
			array( 'nome' => 'Baterias', 'url' => home_url( '/baterias/' ) ),
			array( 'nome' => $marca_nome, 'url' => home_url( '/baterias/' . $marca_slug . '/' ) ),
		),
		'atual'    => 'Bateria ' . $awr_titulo,
		'badges'   => array( '⏱ Instalação em até 35 min', '🛡 Garantia de fábrica', '💳 10x sem juros' ),
	) );
	?>

	<section class="awr-block">
		<h2 class="awr-section-title">Qual bateria usa cada versão do <?php echo esc_html( $awr_titulo ); ?></h2>
		<div class="awr-fam-tabela-wrap">
			<table class="awr-fam-tabela">
				<thead><tr><th>Versão</th><th>Anos</th><th>Bateria</th><th>Tipo</th><th></th></tr></thead>
				<tbody>
					<?php foreach ( $awr_rows as $awr_r ) : ?>
						<tr>
							<td class="awr-fam-tabela__versao"><a href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $awr_r['versao'] ) ); ?>"><?php echo esc_html( awr_nome_veiculo( $awr_r['versao'] ) ); ?></a></td>
							<td><?php echo esc_html( $awr_r['de'] . '–' . $awr_r['ate'] ); ?></td>
							<td><?php echo esc_html( ( $awr_r['ah'] ? $awr_r['ah'] . 'Ah · ' : '' ) . implode( ' · ', $awr_r['codigos'] ) ); ?></td>
							<td><?php echo esc_html( $awr_r['tec'] ); ?></td>
							<td><a class="awr-fam-tabela__cta" target="_top" rel="noopener" data-awr-source="familia_<?php echo esc_attr( $awr_fam['slug'] ); ?>" href="<?php echo esc_url( awr_wa( sprintf( 'Olá! Quero a bateria do %1$s %2$s (%3$d a %4$d). Qual o preço e a entrega?', $marca_nome, $awr_r['versao'], $awr_r['de'], $awr_r['ate'] ) ) ); ?>">Pedir</a></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<p class="awr-fam-nota">Códigos das fabricantes Moura, Heliar, Zetta e Excell. O técnico confirma a aplicação no local antes de instalar, sem custo.</p>
	</section>

	<?php if ( $awr_prod ) : ?>
		<section class="awr-results awr-results--static" aria-label="Baterias para <?php echo esc_attr( $awr_titulo ); ?>">
			<div class="awr-results__head">
				<div class="awr-results__headtext">
					<span class="awr-results__badge"><i aria-hidden="true"></i>Compatíveis • em estoque</span>
					<h2 class="awr-results__title">Baterias para o <?php echo esc_html( $awr_titulo ); ?></h2>
				</div>
			</div>
			<?php awr_part( 'cards-lista', array( 'produtos' => $awr_prod, 'veiculo' => $awr_titulo ) ); ?>
		</section>
	<?php endif; ?>

	<section class="awr-block">
		<h2 class="awr-section-title">Escolha a versão e o ano</h2>
		<?php foreach ( $awr_fam['modelos'] as $awr_ms ) : ?>
			<?php $awr_mn = awr_vehicle_models( $marca_slug )[ $awr_ms ]['nome'] ?? ''; if ( ! $awr_mn ) { continue; } ?>
			<h3 class="awr-veiculo__decada"><?php echo esc_html( awr_nome_veiculo( $marca_nome . ' ' . $awr_mn ) ); ?></h3>
			<details class="awr-link-disclosure">
				<summary>Ver os anos</summary>
				<ul class="awr-chips">
					<li><a class="awr-chip" href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $awr_mn ) ); ?>">Todos os anos</a></li>
					<?php foreach ( array_reverse( awr_vehicle_years( $marca_slug, $awr_ms ) ) as $y ) : ?>
						<?php if ( ! awr_vehicle_variants( $marca_slug, $awr_ms, $y ) ) { continue; } ?>
						<li><a class="awr-chip" href="<?php echo esc_url( awr_vehicle_url( $marca_nome, $awr_mn, $y ) ); ?>"><?php echo esc_html( $awr_mn . ' ' . $y ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			</details>
		<?php endforeach; ?>
	</section>

	<?php awr_part( 'search', array( 'titulo' => 'Buscar a bateria de outro veículo' ) ); ?>

	<?php awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes', 'itens' => $awr_faq ) ); ?>

	<?php awr_part( 'links-internos', array( 'tipo' => 'conteudo', 'slug' => $marca_slug ) ); ?>
</div>
<?php
awr_faq_jsonld( $awr_faq, $awr_url . '#faq' );
$awr_lista = array();
foreach ( $awr_fam['modelos'] as $awr_i => $awr_ms ) {
	$awr_mn = awr_vehicle_models( $marca_slug )[ $awr_ms ]['nome'] ?? '';
	if ( $awr_mn ) {
		$awr_lista[] = array( '@type' => 'ListItem', 'position' => count( $awr_lista ) + 1, 'name' => 'Bateria para ' . $marca_nome . ' ' . $awr_mn, 'url' => awr_vehicle_url( $marca_nome, $awr_mn ) );
	}
}
awr_jsonld( array( '@context' => 'https://schema.org', '@type' => 'ItemList', 'name' => 'Versões do ' . $awr_titulo, 'itemListElement' => $awr_lista ) );
if ( $awr_prod ) { awr_product_item_list_schema( $awr_prod, 'Baterias para ' . $awr_titulo ); }
get_footer();
