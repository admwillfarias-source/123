<?php
/**
 * /marca/{marca}/{n}ah/ — 5.51.0. Dados em inc/marca-amperagem.php.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$awr_mslug = awr_param_a();
$awr_ah    = (int) awr_param_b();
$awr_m     = awr_marca_amp_marcas()[ $awr_mslug ] ?? null;
$awr_skus  = awr_marca_amp_skus( $awr_mslug, $awr_ah );
if ( ! $awr_m || ! $awr_skus ) { get_template_part( '404' ); return; }

$awr_nome   = 'Bateria ' . $awr_m['nome'] . ' ' . $awr_ah . 'Ah';
$awr_url    = awr_marca_amp_url( $awr_mslug, $awr_ah );
$awr_vistas = array_column( $awr_skus, 'vista' );
$awr_min    = min( $awr_vistas );
$awr_gar    = array_unique( array_column( $awr_skus, 'garantia' ) );
$awr_veic   = awr_marca_amp_veiculos( $awr_mslug, $awr_skus );
$awr_comp   = awr_marca_amp_comparativo( $awr_ah );
$awr_prod   = awr_products_by_skus( array_map( function ( $s ) use ( $awr_m ) { return array( 'sku' => $s, 'brand' => $awr_m['nome'] ); }, array_keys( $awr_skus ) ) );
$awr_preco  = function ( $v ) { return 'R$ ' . number_format( (float) $v, 2, ',', '.' ); };

$awr_faq = array(
	array(
		'q' => 'Quanto custa a ' . $awr_nome . '?',
		'r' => 'A partir de ' . $awr_preco( $awr_min ) . ' à vista (Pix ou dinheiro), com a troca da bateria usada, ou em até 10x sem juros. O preço inclui entrega e instalação em Porto Alegre e Grande Porto Alegre.',
	),
	array(
		'q' => 'Qual a garantia da ' . $awr_nome . '?',
		'r' => 'Garantia de fábrica de ' . implode( ' ou ', $awr_gar ) . ' meses, conforme o modelo, com nota fiscal.',
	),
);
if ( $awr_veic ) {
	$awr_faq[] = array(
		'q' => 'Quais carros usam a ' . $awr_nome . '?',
		'r' => 'Entre outros: ' . implode( ', ', array_map( function ( $v ) { return $v['marca'] . ' ' . $v['modelo']; }, array_slice( $awr_veic, 0, 8 ) ) ) . '. Confira a lista completa nesta página ou busque pelo seu veículo.',
	);
}
if ( count( $awr_comp ) > 1 ) {
	$awr_faq[] = array(
		'q' => 'Qual a diferença da ' . $awr_m['nome'] . ' ' . $awr_ah . 'Ah para outras marcas?',
		'r' => 'Na mesma amperagem a diferença está em CCA (partida no frio), garantia e preço. Compare na tabela desta página: ' . implode( '; ', array_map( function ( $mk, $p ) use ( $awr_preco ) { return ( awr_marca_amp_marcas()[ $mk ]['nome'] ?? $mk ) . ' a partir de ' . $awr_preco( $p ); }, array_keys( $awr_comp ), $awr_comp ) ) . '.',
	);
}

get_header();
?>
<div class="awr-container awr-veiculo awr-familia awr-marca-amp">
	<?php
	awr_part( 'hero', array(
		'eyebrow'  => 'Bateria ' . $awr_m['nome'],
		'h1'       => $awr_nome . ': preço, modelos e carros compatíveis',
		'lead'     => $awr_nome . ' a partir de ' . $awr_preco( $awr_min ) . ' à vista, com garantia de ' . implode( ' ou ', $awr_gar ) . ' meses. Entrega e instalação grátis em até 35 minutos em Porto Alegre e Grande Porto Alegre, ou envio por transportadora.',
		'wa'       => 'Olá! Quero a ' . $awr_nome . '. Qual o preço e a entrega?',
		'wa_label' => 'Pedir no WhatsApp',
		'trilha'   => array(
			array( 'nome' => 'Marcas', 'url' => home_url( '/marca/' ) ),
			array( 'nome' => $awr_m['nome'], 'url' => home_url( '/marca/' . $awr_mslug . '/' ) ),
		),
		'atual'    => $awr_nome,
		'badges'   => array( '⏱ Instalação em até 35 min', '🛡 Garantia de fábrica', '💳 10x sem juros' ),
	) );
	?>

	<section class="awr-block">
		<h2 class="awr-section-title">Modelos <?php echo esc_html( $awr_nome ); ?> e preços</h2>
		<div class="awr-fam-tabela-wrap">
			<table class="awr-fam-tabela">
				<thead><tr><th>Modelo</th><th>CCA</th><th>Garantia</th><th>À vista*</th><th></th></tr></thead>
				<tbody>
					<?php
					// Um modelo pode ter vários códigos (polaridade/caixa): uma linha por modelo.
					$awr_grupos = array();
					foreach ( $awr_skus as $awr_sku => $awr_t ) {
						$awr_k = $awr_t['modelo'] . '|' . $awr_t['vista'];
						if ( ! isset( $awr_grupos[ $awr_k ] ) ) { $awr_grupos[ $awr_k ] = array( 't' => $awr_t, 'skus' => array() ); }
						$awr_grupos[ $awr_k ]['skus'][] = $awr_sku;
					}
					uasort( $awr_grupos, function ( $x, $y ) { return $x['t']['vista'] <=> $y['t']['vista']; } );
					?>
					<?php foreach ( $awr_grupos as $awr_g ) : $awr_t = $awr_g['t']; $awr_sku = implode( ', ', $awr_g['skus'] ); ?>
						<tr>
							<td class="awr-fam-tabela__versao"><?php echo esc_html( $awr_t['modelo'] ); ?> <small>(<?php echo esc_html( $awr_sku ); ?>)</small></td>
							<td><?php echo esc_html( (int) $awr_t['cca'] . ' A' ); ?></td>
							<td><?php echo esc_html( (int) $awr_t['garantia'] . ' meses' ); ?></td>
							<td><b><?php echo esc_html( $awr_preco( $awr_t['vista'] ) ); ?></b></td>
							<td><a class="awr-fam-tabela__cta" target="_top" rel="noopener" data-awr-source="marca_amp_<?php echo esc_attr( $awr_mslug . '_' . $awr_ah ); ?>" href="<?php echo esc_url( awr_wa( 'Olá! Quero a bateria ' . $awr_t['modelo'] . ' (' . $awr_sku . '). Qual o prazo de entrega?' ) ); ?>">Pedir</a></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<p class="awr-fam-nota">*Preço à vista no Pix ou dinheiro, com a troca da bateria usada (casco). Sem a troca, o casco é cobrado à parte. Em até 10x sem juros no cartão.</p>
	</section>

	<?php if ( $awr_prod ) : ?>
		<section class="awr-results awr-results--static" aria-label="<?php echo esc_attr( $awr_nome ); ?> na loja">
			<div class="awr-cards">
				<?php foreach ( array_slice( $awr_prod, 0, 6 ) as $p ) { awr_part( 'card-bateria', array( 'produto' => $p ) ); } ?>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $awr_veic ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title">Carros que usam a <?php echo esc_html( $awr_nome ); ?></h2>
			<ul class="awr-chips">
				<?php foreach ( $awr_veic as $awr_v ) : ?>
					<li><a class="awr-chip" href="<?php echo esc_url( $awr_v['url'] ); ?>"><?php echo esc_html( $awr_v['marca'] . ' ' . $awr_v['modelo'] . ' (' . $awr_v['de'] . '–' . $awr_v['ate'] . ')' ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>

	<?php if ( count( $awr_comp ) > 1 ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title">Bateria <?php echo esc_html( $awr_ah ); ?>Ah: compare as marcas</h2>
			<ul class="awr-chips">
				<?php foreach ( $awr_comp as $awr_mk => $awr_p ) : ?>
					<li><?php if ( $awr_mk === $awr_mslug ) : ?><span class="awr-chip awr-chip--destaque"><?php else : ?><a class="awr-chip" href="<?php echo esc_url( awr_marca_amp_url( $awr_mk, $awr_ah ) ); ?>"><?php endif; ?><?php echo esc_html( ( awr_marca_amp_marcas()[ $awr_mk ]['nome'] ?? $awr_mk ) . ' ' . $awr_ah . 'Ah · a partir de ' . $awr_preco( $awr_p ) ); ?><?php echo $awr_mk === $awr_mslug ? '</span>' : '</a>'; ?></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>

	<section class="awr-block">
		<h2 class="awr-section-title">Outras amperagens <?php echo esc_html( $awr_m['nome'] ); ?></h2>
		<ul class="awr-chips">
			<?php foreach ( array_keys( awr_marca_amp_lista()[ $awr_mslug ] ?? array() ) as $awr_a ) : ?>
				<?php if ( $awr_a === $awr_ah ) { continue; } ?>
				<li><a class="awr-chip" href="<?php echo esc_url( awr_marca_amp_url( $awr_mslug, $awr_a ) ); ?>"><?php echo esc_html( $awr_m['nome'] . ' ' . $awr_a . 'Ah' ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</section>

	<?php awr_part( 'search', array( 'titulo' => 'Confirme a bateria do seu carro' ) ); ?>

	<?php awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes', 'itens' => $awr_faq ) ); ?>
</div>
<?php
awr_faq_jsonld( $awr_faq, $awr_url . '#faq' );
if ( $awr_prod ) { awr_product_item_list_schema( array_slice( $awr_prod, 0, 6 ), $awr_nome ); }
get_footer();
