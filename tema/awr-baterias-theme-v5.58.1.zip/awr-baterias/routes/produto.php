<?php
/**
 * Página de produto (WooCommerce) enxuta: apenas o produto e a descrição.
 * Sem paginação de páginas/posts, sem relacionados, upsell, abas ou avaliações.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$awr_pid = get_queried_object_id();
$awr_wc  = function_exists( 'wc_get_product' ) ? wc_get_product( $awr_pid ) : null;
if ( ! $awr_wc ) { get_template_part( '404' ); return; }

$sku = strtoupper( (string) $awr_wc->get_sku() );
$p   = $sku ? awr_product_by_sku( $sku ) : null;
if ( ! $p ) {
	$img = get_the_post_thumbnail_url( $awr_pid, 'medium_large' );
	$p   = array(
		'sku'       => $sku,
		'name'      => $awr_wc->get_name(),
		'price'     => (float) $awr_wc->get_price(),
		'image'     => $img ? $img : '',
		'permalink' => get_permalink( $awr_pid ),
		'amperagem' => awr_extract_amperage( $sku, $awr_wc->get_name() ),
		'brand'     => '',
	);
}
// v4.2.0 — resolve pela cadeia completa (índice, GTIN, taxonomia, nome, prefixo
// de fábrica), nunca só pelo catálogo automotivo, e nunca com a marca da loja.
$p['brand'] = trim( (string) ( $p['brand'] ?? '' ) );
if ( '' === $p['brand'] || 0 === stripos( $p['brand'], 'AWR' ) ) {
	$p['brand'] = awr_resolve_brand( $sku, $awr_wc->get_name(), $awr_wc );
}
$ah         = (int) ( $p['amperagem'] ?? 0 );

// Veículos compatíveis agrupados por marca (sem repetir faixas de ano item a item).
$compat = $sku ? awr_product_compat_grouped( $sku ) : array();
$faq    = $sku ? awr_product_faq( $sku, $p['name'], $p['brand'], $ah ) : array();

// Categoria WooCommerce para a trilha (mesma da trilha estruturada da loja).
$awr_cat_nome = '';
$awr_cat_url  = '';
$awr_terms    = get_the_terms( $awr_pid, 'product_cat' );
if ( $awr_terms && ! is_wp_error( $awr_terms ) ) {
	$awr_cat_nome = $awr_terms[0]->name;
	$awr_cat_url  = function_exists( 'awr_shop_url' ) ? awr_shop_url( $awr_terms[0]->slug, 1, '' ) : home_url( '/loja/' );
}

$descricao = apply_filters( 'the_content', $awr_wc->get_description() );
$resumo    = wp_strip_all_tags( (string) $awr_wc->get_short_description() );

get_header();
// Hooks do WooCommerce: extensões (Google for WooCommerce, pixels, etc.)
// injetam o código delas aqui.
if ( function_exists( 'awr_produto_hooks_woo' ) ) { awr_produto_hooks_woo( 'antes', $awr_wc ); }
$GLOBALS['awr_product_mobile_offer'] = array(
	'sku' => $p['sku'], 'nome' => $p['name'], 'price' => (float) $p['price'],
	'pid' => (int) ( $p['id'] ?? $awr_pid ), 'casco' => awr_valor_casco( $sku, $p['name'] ),
);
?>
<?php
// 5.57.0 — página de produto que vende (inc/produto-pagina.php).
$awr_moto   = awr_produto_eh_moto( $sku );
$awr_tipo   = $awr_moto ? 'moto' : 'carro';
$awr_meu    = $awr_moto ? 'minha moto' : 'meu carro';
$awr_seu    = $awr_moto ? 'na sua moto' : 'no seu carro';
$awr_da     = $awr_moto ? 'da moto' : 'do carro';
$awr_estq   = awr_produto_estoque( $awr_wc );
$awr_fotos  = awr_produto_galeria( $awr_wc, $p );
$awr_preco  = (float) $p['price'];
$awr_pix    = round( $awr_preco * 0.97, 2 );
$awr_cascov = (float) awr_valor_casco( $sku, $p['name'] );
$awr_gar    = function_exists( 'awr_garantia_label' ) ? (string) awr_garantia_label( $sku, $p['name'] ) : '';
$awr_nrev   = (int) $awr_wc->get_review_count();
$awr_media  = (float) $awr_wc->get_average_rating();
$awr_aval   = awr_produto_avaliacoes( $awr_wc );
$awr_h1     = function_exists( 'awr_seo_lote_h1' ) ? awr_seo_lote_h1() : '';
$awr_h1     = $awr_h1 ? $awr_h1 : awr_product_seo_name( $sku, $awr_wc->get_name(), $p['brand'], $ah );
$awr_pid_v  = (int) ( $p['id'] ?? $awr_pid );
$awr_wa_txt = 'Olá! Quero comprar a bateria ' . $awr_wc->get_name() . ' (' . $sku . ')' . ( $awr_preco ? ' por ' . awr_brl( $awr_preco ) : '' ) . ' com instalação.';
?>
<div class="awr-container awr-produto awr-pp-page" data-awr-pp data-sku="<?php echo esc_attr( $sku ); ?>" data-nome="<?php echo esc_attr( $p['name'] ); ?>" data-preco="<?php echo esc_attr( $awr_preco ); ?>" data-tipo="<?php echo esc_attr( $awr_tipo ); ?>">
	<?php
	$awr_trilha = array( array( 'nome' => 'Loja', 'url' => home_url( '/loja/' ) ) );
	if ( $awr_cat_nome ) { $awr_trilha[] = array( 'nome' => $awr_cat_nome, 'url' => $awr_cat_url ); }
	awr_part( 'breadcrumb', array( 'trilha' => $awr_trilha, 'atual' => $awr_wc->get_name() ) );
	?>
	<section class="awr-pp" aria-label="Comprar bateria">
		<div class="awr-pp__media" data-awr-gal>
			<?php if ( $awr_fotos ) : ?>
				<div class="awr-pp__track" tabindex="0" aria-label="Fotos da bateria">
					<?php foreach ( $awr_fotos as $awr_i => $awr_f ) : ?>
						<button type="button" class="awr-pp__slide" data-full="<?php echo esc_url( $awr_f[0] ); ?>" aria-label="Ampliar foto <?php echo (int) $awr_i + 1; ?>">
							<img src="<?php echo esc_url( $awr_f[0] ); ?>" alt="<?php echo esc_attr( $awr_f[2] ); ?>" width="<?php echo (int) ( $awr_f[3] ? $awr_f[3] : 600 ); ?>" height="<?php echo (int) ( $awr_f[4] ? $awr_f[4] : 600 ); ?>" <?php echo 0 === $awr_i ? 'fetchpriority="high"' : 'loading="lazy"'; ?> decoding="async">
						</button>
					<?php endforeach; ?>
				</div>
				<?php if ( count( $awr_fotos ) > 1 ) : ?>
					<button type="button" class="awr-pp__nav awr-pp__nav--prev" data-gal="-1" aria-label="Foto anterior">‹</button>
					<button type="button" class="awr-pp__nav awr-pp__nav--next" data-gal="1" aria-label="Próxima foto">›</button>
					<ul class="awr-pp__thumbs">
						<?php foreach ( $awr_fotos as $awr_i => $awr_f ) : ?>
							<li><button type="button" data-gal-i="<?php echo (int) $awr_i; ?>" aria-label="Ver foto <?php echo (int) $awr_i + 1; ?>"<?php echo 0 === $awr_i ? ' aria-current="true"' : ''; ?>><img src="<?php echo esc_url( $awr_f[1] ); ?>" alt="" width="64" height="64" loading="lazy"></button></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			<?php else : ?>
				<span class="awr-pp__noimg" aria-hidden="true">🔋</span>
			<?php endif; ?>
		</div>

		<div class="awr-pp__buy">
			<p class="awr-pp__eyebrow">
				<?php if ( $p['brand'] ) : ?><span class="awr-pp__brand"><?php echo esc_html( $p['brand'] ); ?></span><?php endif; ?>
				<span class="awr-pp__stock awr-pp__stock--<?php echo esc_attr( $awr_estq[0] ); ?>"><?php echo esc_html( $awr_estq[1] ); ?></span>
				<span class="awr-pp__fit" data-awr-pp-fit hidden></span>
			</p>
			<h1 class="awr-pp__title"><?php echo esc_html( $awr_h1 ); ?></h1>
			<p class="awr-pp__sub"><?php echo esc_html( awr_produto_subtitulo( $sku, $p['name'], $ah, $awr_moto ) ); ?></p>
			<?php if ( $awr_nrev > 0 && $awr_media > 0 ) : ?>
				<p class="awr-pp__stars"><span aria-hidden="true"><?php echo esc_html( str_repeat( '★', (int) round( $awr_media ) ) . str_repeat( '☆', 5 - (int) round( $awr_media ) ) ); ?></span> <b><?php echo esc_html( number_format( $awr_media, 1, ',', '' ) ); ?></b> <a href="#avaliacoes">(<?php echo (int) $awr_nrev; ?> avaliaç<?php echo 1 === $awr_nrev ? 'ão' : 'ões'; ?>)</a></p>
			<?php endif; ?>

			<?php if ( $awr_preco ) : ?>
				<p class="awr-pp__label">Preço à vista com a troca da bateria usada</p>
				<div class="awr-pp__prices">
					<p class="awr-pp__price"><?php echo esc_html( awr_brl( $awr_preco ) ); ?></p>
					<p class="awr-pp__pix"><b><?php echo esc_html( awr_brl( $awr_pix ) ); ?> no Pix</b><small>3% de desconto, pago na entrega</small></p>
				</div>
				<p class="awr-pp__parc">ou 10x de <b><?php echo esc_html( awr_brl( $awr_preco / 10 ) ); ?></b> sem juros no cartão</p>
				<?php if ( $awr_cascov > 0 ) : ?>
					<p class="awr-pp__troca">Sem a bateria usada na troca: <b><?php echo esc_html( awr_brl( $awr_preco + $awr_cascov ) ); ?></b> <span>(casco de <?php echo esc_html( awr_brl( $awr_cascov ) ); ?>)</span></p>
				<?php endif; ?>
			<?php else : ?>
				<p class="awr-pp__price awr-pp__price--sob">Preço sob consulta</p>
			<?php endif; ?>

			<p class="awr-pp__entrega"><?php echo awr_produto_icone( 'entrega' ); // phpcs:ignore ?> <span>Entrega e instalação em Porto Alegre e região. <a href="#entrega">Consulte o prazo pelo CEP</a></span></p>

			<div class="awr-pp__ctas">
				<?php if ( $awr_preco ) : ?>
					<button type="button" class="awr-pp__cta" data-awr-checkout data-sku="<?php echo esc_attr( $p['sku'] ); ?>" data-nome="<?php echo esc_attr( $p['name'] ); ?>" data-preco="<?php echo esc_attr( $awr_preco ); ?>" data-pid="<?php echo esc_attr( $awr_pid_v ); ?>" data-casco="<?php echo esc_attr( $awr_cascov ); ?>" data-imagem="<?php echo esc_url( $awr_fotos ? $awr_fotos[0][0] : '' ); ?>" data-garantia="<?php echo esc_attr( $awr_gar ); ?>">Comprar agora com instalação</button>
				<?php endif; ?>
				<a class="awr-pp__wa<?php echo $awr_preco ? '' : ' awr-pp__cta'; ?>" data-awr-pp-wa data-awr-source="produto_whatsapp" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( $awr_preco ? $awr_wa_txt : 'Olá! Quero o preço da bateria ' . $awr_wc->get_name() . ' (' . $sku . ').' ) ); ?>"><?php echo awr_wa_icon( 18 ); // phpcs:ignore ?> <?php echo $awr_preco ? 'Comprar pelo WhatsApp' : 'Pedir preço no WhatsApp'; ?></a>
			</div>
			<ul class="awr-pp__selos">
				<li><?php echo awr_produto_icone( 'seguro' ); // phpcs:ignore ?> Compra segura: paga na entrega</li>
				<li><?php echo awr_produto_icone( 'atende' ); // phpcs:ignore ?> Atendimento especializado</li>
				<li><?php echo awr_produto_icone( 'oficial' ); // phpcs:ignore ?> Site oficial AWR Baterias</li>
			</ul>
		</div>
	</section>

	<ul class="awr-pp__benef">
		<li><?php echo awr_produto_icone( 'entrega' ); // phpcs:ignore ?><span><b>Entrega e instalação</b> em até 35 min*</span></li>
		<li><?php echo awr_produto_icone( 'garantia' ); // phpcs:ignore ?><span><b><?php echo esc_html( $awr_gar ? $awr_gar : 'Garantia de fábrica' ); ?></b> com nota fiscal</span></li>
		<li><?php echo awr_produto_icone( 'aplica' ); // phpcs:ignore ?><span><b>Aplicação correta</b> conforme a montadora</span></li>
		<li><?php echo awr_produto_icone( 'troca' ); // phpcs:ignore ?><span><b>Preço com a troca</b> da bateria usada</span></li>
	</ul>
	<p class="awr-pp__nota">*Em Porto Alegre e região, conforme o CEP e o horário. Consulte abaixo.</p>

	<?php if ( $compat ) : ?>
		<section class="awr-pp-box awr-pp-compat" id="compatibilidade" aria-labelledby="awr-pp-compat-t">
			<div class="awr-pp-box__ico"><?php echo awr_produto_icone( $awr_tipo ); // phpcs:ignore ?></div>
			<div class="awr-pp-box__body">
				<h2 id="awr-pp-compat-t">Ver se essa bateria é compatível com <?php echo esc_html( $awr_meu ); ?></h2>
				<div class="awr-pp-compat__f">
					<label><span class="awr-sr">Marca</span><select data-c="marca"><option value="">Marca <?php echo esc_html( $awr_da ); ?></option></select></label>
					<label><span class="awr-sr">Modelo</span><select data-c="modelo" disabled><option value="">Modelo</option></select></label>
					<label><span class="awr-sr">Ano</span><select data-c="ano" disabled><option value="">Ano</option></select></label>
					<button type="button" class="awr-pp-box__btn" data-c="ok">Verificar compatibilidade</button>
				</div>
				<div class="awr-pp-compat__res" data-c="res" role="status" aria-live="polite"></div>
			</div>
			<script type="application/json" data-awr-pp-compat><?php echo wp_json_encode( awr_produto_compat_json( $compat ), JSON_UNESCAPED_UNICODE ); ?></script>
		</section>
	<?php endif; ?>

	<section class="awr-pp-box awr-pp-cep" id="entrega" aria-labelledby="awr-pp-cep-t">
		<div class="awr-pp-box__ico"><?php echo awr_produto_icone( 'entrega' ); // phpcs:ignore ?></div>
		<div class="awr-pp-box__body">
			<h2 id="awr-pp-cep-t">Consultar entrega e instalação</h2>
			<form class="awr-pp-cep__f" data-awr-pp-cep>
				<label><span class="awr-sr">CEP</span><input name="cep" inputmode="numeric" autocomplete="postal-code" maxlength="9" placeholder="Digite seu CEP"></label>
				<button type="submit" class="awr-pp-box__btn">Consultar</button>
				<a class="awr-pp-cep__mini" href="https://buscacepinter.correios.com.br/app/endereco/index.php" target="_blank" rel="noopener">Não sei meu CEP</a>
			</form>
			<div class="awr-pp-cep__res" data-c="cepres" role="status" aria-live="polite"></div>
		</div>
	</section>

	<nav class="awr-pp-ancoras" aria-label="Seções da página">
		<a href="#descricao">Descrição</a><a href="#especificacoes">Especificações</a><?php if ( $compat ) : ?><a href="#aplicacoes">Aplicações</a><?php endif; ?><a href="#perguntas">Perguntas</a><a href="#avaliacoes">Avaliações<?php echo $awr_nrev ? ' (' . (int) $awr_nrev . ')' : ''; ?></a>
	</nav>

	<div id="especificacoes" class="awr-pp-anc"></div>
	<?php awr_part( 'ficha-tecnica', array( 'sku' => $sku ) ); ?>
	<?php awr_part( 'produto-seo', array( 'sku' => $sku, 'marca' => $p['brand'], 'ah' => $ah ) ); ?>

	<?php awr_part( 'searchband', array( 'tag' => 'Buscar outra bateria', 'nota' => 'Confirme outro veículo ou modelo sem sair desta página.' ) ); ?>

	<section class="awr-block awr-produto__info">
		<h2 class="awr-section-title">Por que escolher esta bateria?</h2>
		<div class="awr-produto__infogrid">
			<div>
				<h3>Receba e instale no local</h3>
				<p>Em Porto Alegre e nas cidades da cobertura própria: entrega com instalação grátis conforme o prazo local. Em Caxias do Sul e demais cidades de envio: transportadora com rastreio, sem instalação local.</p>
			</div>
			<div>
				<h3>Formas de pagamento</h3>
				<p>Pague apenas na entrega: Pix, crédito em até 10x sem juros ou débito. Fora das cidades atendidas, o pagamento é por Pix antecipado.</p>
			</div>
			<div>
				<h3>Teste gratuito, garantia e nota fiscal</h3>
				<p>Bateria nova com garantia de fábrica e nota fiscal em todos os pedidos. Teste de alternador grátis no momento da instalação.</p>
			</div>
		</div>
	</section>

	<section class="awr-block awr-produto__desc" id="descricao">
		<h2 class="awr-section-title">Descrição</h2>
		<div class="awr-prose">
			<p><strong>Bateria entregue e instalada em até 35 minutos.</strong> Peça de onde estiver e pague na entrega.</p>
			<?php
			$awr_desc_html = awr_product_desc_html( $awr_wc->get_description() ?: $awr_wc->get_short_description() );
			echo $awr_desc_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</div>
	</section>

	<?php if ( $compat ) : ?>
		<section class="awr-block awr-compat" id="aplicacoes">
			<h2 class="awr-section-title">Descubra se a bateria <?php echo esc_html( $sku ); ?> serve <?php echo esc_html( $awr_seu ); ?></h2>
			<?php awr_part( 'compat-marcas', array( 'grupos' => $compat ) ); ?>
		</section>
	<?php endif; ?>
	<div id="perguntas" class="awr-pp-anc"></div>
	<?php awr_part( 'faq', array( 'titulo' => 'Perguntas sobre esta bateria', 'itens' => $faq ) ); ?>
	<?php awr_part( 'produto-avaliacoes', array( 'itens' => $awr_aval, 'media' => $awr_media, 'total' => $awr_nrev, 'url' => add_query_arg( 'review', '1', get_permalink( $awr_pid ) ) . '#reviews' ) ); ?>
	<?php $schema = awr_product_schema( $p, $awr_wc ); if ( $schema ) { awr_jsonld( $schema ); } ?>
	<?php awr_product_faq_schema( $faq ); ?>
</div>
<?php
if ( function_exists( 'awr_produto_hooks_woo' ) ) { awr_produto_hooks_woo( 'depois', $awr_wc ); }
get_footer();
?>
