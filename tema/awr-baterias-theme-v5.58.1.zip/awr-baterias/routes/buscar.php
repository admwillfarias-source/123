<?php
/**
 * /buscar/ — resultados de busca (server-side, com hidratação pelo JS).
 * Paridade 1:1 com o bloco de resultados do BatterySearch do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$veiculo  = sanitize_title( (string) get_query_var( 'veiculo' ) );
$ano      = (int) get_query_var( 'ano' );
$q        = sanitize_text_field( (string) get_query_var( 'q' ) );
$items    = $veiculo ? awr_vehicle_by_slug( $veiculo, $ano ) : array();
$produtos = $items ? awr_products_by_skus( awr_skus_from_items( $items ) ) : array();
$marca    = $items ? $items[0]['ma'] : '';
$modelo   = $items ? $items[0]['mo'] : '';
$titulo   = $items ? awr_nome_veiculo( trim( $marca . ' ' . $modelo ) ) . ( $ano ? " {$ano}" : '' ) : '';
$awr_min  = function_exists( 'awr_cards_menor_preco' ) ? awr_cards_menor_preco( $produtos ) : 0;
?>
<div class="awr-container awr-buscar">
	<?php
	awr_part( 'hero', array(
		'eyebrow' => $titulo ? 'Baterias compatíveis' : 'Busca de baterias',
		'h1'      => $titulo ? "Bateria para {$titulo}" : 'Busque a bateria certa para o seu veículo',
		'lead'    => $titulo
			? 'Preço final com instalação grátis no local, em até 35 minutos em Porto Alegre e Grande Porto Alegre.'
			: 'Digite modelo e ano — mostramos a amperagem correta e o preço na hora, sem cadastro. Entrega e instalação em até 35 minutos em Porto Alegre e Grande Porto Alegre.',
		'wa'      => $titulo ? "Olá! Preciso da bateria do meu {$titulo}. Podem me passar o preço?" : 'Olá! Preciso de ajuda para encontrar a bateria certa do meu veículo.',
		'wa_label'=> 'Falar com um atendente',
		'atual'   => $titulo ? "Baterias para {$titulo}" : 'Buscar bateria',
	) );
	?>

	<?php awr_part( 'search', array( 'autofocus' => ! $titulo ) ); ?>

	<?php if ( $titulo ) : ?>
		<section class="awr-results awr-results--static" aria-label="Baterias compatíveis">
			<div class="awr-results__head">
				<div class="awr-results__headtext">
					<span class="awr-results__badge"><i aria-hidden="true"></i>Compatíveis • em estoque</span>
					<h2 class="awr-results__title">Baterias recomendadas <small><?php echo esc_html( $titulo . ( $awr_min ? ' · a partir de ' . awr_brl( $awr_min ) : '' ) ); ?></small></h2>
				</div>
				<a class="awr-results__reset" href="<?php echo esc_url( home_url( '/buscar/' ) ); ?>">
					<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>
					Trocar veículo
				</a>
			</div>

			<?php if ( $produtos ) : ?>
				<?php awr_part( 'cards-lista', array( 'produtos' => $produtos, 'veiculo' => $titulo ) ); ?>
			<?php else : ?>
				<div class="awr-results__empty">
					<p>Não conseguimos carregar os preços agora para <b><?php echo esc_html( $titulo ); ?></b>. Fale com a gente — respondemos em 2 minutos com o preço e a entrega.</p>
					<a class="awr-btn awr-btn--green" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( "Olá! Preciso da bateria do meu {$titulo}. Podem me passar o preço e a entrega?" ) ); ?>">Falar no WhatsApp agora</a>
				</div>
			<?php endif; ?>
		</section>
	<?php endif; ?>
	<?php if ( $titulo ) { awr_product_item_list_schema( $produtos, 'Baterias recomendadas para ' . $titulo ); } ?>
</div>

<?php if ( ! $titulo ) : ?>
<section class="awr-container awr-block awr-buscar-como">
	<h2 class="awr-section-title">Como funciona a busca da bateria pelo seu veículo</h2>
	<div class="awr-buscar-como__grid">
		<div><h3>1. Informe o veículo</h3><p>Digite o modelo e o ano (ex.: Onix 2018). A busca confere a bateria homologada pela montadora.</p></div>
		<div><h3>2. Veja o preço com instalação</h3><p>Preço final na hora, com instalação e teste do alternador inclusos, 3% de desconto no Pix ou 10x sem juros.</p></div>
		<div><h3>3. Receba em até 35 minutos</h3><p>Em Porto Alegre e Grande Porto Alegre a AWR leva e instala no seu endereço. Pague só na entrega.</p></div>
	</div>
	<h2 class="awr-section-title">Não encontrou seu modelo?</h2>
	<p>Fale com a gente: atendemos carros, motos, caminhões e máquinas e respondemos em cerca de 2 minutos com o preço e o prazo. <a target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Não encontrei meu veículo na busca. Podem me ajudar com a bateria?' ) ); ?>">Chamar no WhatsApp</a></p>
</section>
<?php endif; ?>
<?php awr_part( 'como-funciona' ); ?>
<?php get_footer(); ?>
