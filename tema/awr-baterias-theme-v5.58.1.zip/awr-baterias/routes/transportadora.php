<?php
/**
 * /entrega-por-transportadora/ — 5.51.0.
 * Como funciona a venda com envio para as cidades fora da região
 * metropolitana (assets/data/cidades-venda.json), por estado.
 * Os textos seguem o que routes/cidade_venda.php já promete.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$awr_uf_nome = array( 'RS' => 'Rio Grande do Sul', 'SC' => 'Santa Catarina', 'PR' => 'Paraná', 'SP' => 'São Paulo' );
$awr_por_uf  = array();
foreach ( (array) awr_cidades_venda() as $awr_c ) {
	$awr_por_uf[ $awr_c['estado'] ?? '' ][] = $awr_c;
}
$awr_ordem = array_keys( $awr_uf_nome );
uksort( $awr_por_uf, function ( $x, $y ) use ( $awr_ordem ) {
	return ( array_search( $x, $awr_ordem, true ) ?? 99 ) <=> ( array_search( $y, $awr_ordem, true ) ?? 99 );
} );
foreach ( $awr_por_uf as &$awr_l ) { usort( $awr_l, function ( $x, $y ) { return strcmp( $x['nome'], $y['nome'] ); } ); }
unset( $awr_l );
$awr_total = array_sum( array_map( 'count', $awr_por_uf ) );

$awr_passos = array(
	array( '1. Informe o veículo e o CEP', 'Pelo buscador ou pelo WhatsApp: modelo, ano e CEP de entrega.' ),
	array( '2. Receba a cotação', 'Preço da bateria e frete fechado até a sua cidade, pelo WhatsApp.' ),
	array( '3. Pague com nota fiscal', 'Pix, cartão em 10x sem juros ou faturamento em CNPJ.' ),
	array( '4. Envio e rastreio', 'Despacho por transportadora com embalagem reforçada e código de rastreio.' ),
);
$awr_faq = array(
	array( 'q' => 'Para quais cidades vocês enviam bateria?', 'r' => 'Para ' . $awr_total . ' cidades do Rio Grande do Sul, Santa Catarina, Paraná e São Paulo listadas nesta página. Se a sua não estiver na lista, mande o CEP no WhatsApp que verificamos.' ),
	array( 'q' => 'Quanto custa o frete?', 'r' => 'O frete é cotado na hora conforme o peso da bateria e o CEP de entrega. Envie seu CEP no WhatsApp e respondemos com o valor fechado.' ),
	array( 'q' => 'Qual o prazo de entrega?', 'r' => 'No Rio Grande do Sul, de 1 a 2 dias úteis. Nos demais estados o prazo depende da transportadora e é informado junto com o frete.' ),
	array( 'q' => 'A instalação está incluída no envio?', 'r' => 'Não. A entrega com instalação no local é exclusiva da Grande Porto Alegre. No envio, a bateria vai pronta para instalar, com nota fiscal e garantia de fábrica.' ),
	array( 'q' => 'Como pago a bateria enviada?', 'r' => 'Pix com desconto, cartão em até 10x sem juros ou faturamento para empresas com CNPJ.' ),
);

get_header();
?>
<div class="awr-container awr-veiculo awr-familia awr-transportadora">
	<?php
	awr_part( 'hero', array(
		'eyebrow'  => 'Envio para RS, SC, PR e SP',
		'h1'       => 'Bateria com entrega por transportadora para ' . $awr_total . ' cidades',
		'lead'     => 'Fora da Grande Porto Alegre a AWR vende e envia a bateria certa para o seu carro por transportadora, com rastreio, nota fiscal e garantia de fábrica. Frete cotado pelo CEP.',
		'wa'       => 'Olá! Quero comprar uma bateria com envio para minha cidade. Podem cotar o frete?',
		'wa_label' => 'Cotar frete no WhatsApp',
		'trilha'   => array( array( 'nome' => 'Cidades', 'url' => home_url( '/baterias-em/' ) ) ),
		'atual'    => 'Entrega por transportadora',
		'badges'   => array( '📦 Envio com rastreio', '🧾 Nota fiscal', '🛡 Garantia de fábrica' ),
	) );
	?>

	<section class="awr-block">
		<h2 class="awr-section-title">Como funciona</h2>
		<ol class="awr-transportadora__passos">
			<?php foreach ( $awr_passos as $awr_p ) : ?>
				<li><b><?php echo esc_html( $awr_p[0] ); ?></b> <?php echo esc_html( $awr_p[1] ); ?></li>
			<?php endforeach; ?>
		</ol>
		<p>Está em Porto Alegre ou na região metropolitana? Lá a entrega é com instalação no local. <a href="<?php echo esc_url( home_url( '/baterias-grande-porto-alegre/' ) ); ?>">Veja as cidades e os prazos da Grande Porto Alegre</a>.</p>
	</section>

	<?php foreach ( $awr_por_uf as $awr_uf => $awr_l ) : ?>
		<section class="awr-block">
			<h2 class="awr-section-title"><?php echo esc_html( ( $awr_uf_nome[ $awr_uf ] ?? $awr_uf ) . ' (' . count( $awr_l ) . ' cidades)' ); ?></h2>
			<p class="awr-fam-nota"><?php echo esc_html( 'RS' === $awr_uf ? 'Entrega em 1 a 2 dias úteis.' : 'Envio por transportadora, prazo informado com o frete.' ); ?></p>
			<ul class="awr-chips">
				<?php foreach ( $awr_l as $awr_c ) : ?>
					<li><a class="awr-chip" href="<?php echo esc_url( home_url( '/baterias-em/' . $awr_c['slug'] . '/' ) ); ?>"><?php echo esc_html( 'Bateria em ' . $awr_c['nome'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endforeach; ?>

	<?php awr_part( 'search', array( 'titulo' => 'Busque a bateria do seu carro' ) ); ?>

	<?php awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes', 'itens' => $awr_faq ) ); ?>
</div>
<?php
awr_faq_jsonld( $awr_faq, home_url( '/entrega-por-transportadora/#faq' ) );
get_footer();
