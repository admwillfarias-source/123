/* AWR Baterias 5.56.0 — checkout em 3 etapas (Bateria → Entrega → Pagamento).
   Carregado só no clique (awr-core.js). Prazo, taxa e endereço vêm do servidor
   (awr/v1/cotacao); o pedido vai para awr/v1/pedido com pedido_token, então
   dois cliques ou um reenvio nunca geram dois pedidos. */
(function () {
	'use strict';
	var A = window.AWR || {}, KEY = 'awr_co_v2', DIAS7 = 6048e5, d = document;
	var brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
	var S = null, root = null, last = null, cotSeq = 0, leadEtapa = '', enviando = false;

	function $(s, c) { return (c || root).querySelector(s); }
	function esc(v) { return String(v == null ? '' : v).replace(/[&<>'"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]; }); }
	function dig(v) { return String(v || '').replace(/\D/g, ''); }
	function fmt(v) { return brl.format(Number(v) || 0); }
	function tok() { var a = new Uint8Array(12); (window.crypto || {}).getRandomValues ? crypto.getRandomValues(a) : a.forEach(function (_, i) { a[i] = Math.random() * 256; }); return 'co-' + Array.prototype.map.call(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
	function mascTel(v) { v = dig(v).slice(0, 11); return v.length > 10 ? '(' + v.slice(0, 2) + ') ' + v.slice(2, 7) + '-' + v.slice(7) : v.length > 6 ? '(' + v.slice(0, 2) + ') ' + v.slice(2, 6) + '-' + v.slice(6) : v.length > 2 ? '(' + v.slice(0, 2) + ') ' + v.slice(2) : v; }
	function mascCep(v) { v = dig(v).slice(0, 8); return v.length > 5 ? v.slice(0, 5) + '-' + v.slice(5) : v; }
	function docOk(v) {
		v = dig(v);
		if (v.length === 11) {
			if (/^(\d)\1+$/.test(v)) return false;
			for (var t = 9; t < 11; t++) { for (var s = 0, i = 0; i < t; i++) s += v[i] * (t + 1 - i); if (((s * 10) % 11) % 10 != v[t]) return false; }
			return true;
		}
		return v.length === 14;
	}

	/* ---------- eventos (GA4 / Ads) ---------- */
	function ev(n, p) {
		p = Object.assign({ card_modelo: A.cardModelo || 'app', checkout: 'v2', currency: 'BRL' }, p || {});
		if (window.AWRCore && window.AWRCore.track) { window.AWRCore.track(n, p); return; }
		window.dataLayer = window.dataLayer || []; window.dataLayer.push(Object.assign({ event: n }, p));
		if (typeof window.gtag === 'function') window.gtag('event', n, p);
	}
	function item() { return [{ item_id: S.prod.sku, item_name: S.prod.nome, price: S.prod.preco, quantity: 1 }]; }
	function evUma(k, n, p) { if (S.ev[k]) return; S.ev[k] = 1; salvar(); ev(n, Object.assign({ value: total().total, items: item() }, p)); }

	/* ---------- estado salvo no aparelho (7 dias) ---------- */
	function ler() { try { var s = JSON.parse(localStorage.getItem(KEY) || 'null'); return s && Date.now() - s.ts < DIAS7 ? s : null; } catch (e) { return null; } }
	function salvar() { if (!S) return; S.ts = Date.now(); try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
	function limpar() { try { localStorage.removeItem(KEY); } catch (e) {} }

	function prodDe(el) {
		var ds = el.dataset || el;
		return { sku: ds.sku || '', nome: ds.nome || ('Bateria ' + (ds.sku || '')), preco: Number(ds.preco || 0), pid: Number(ds.pid || 0), casco: Number(ds.casco || 0), imagem: ds.imagem || '', garantia: ds.garantia || '', veiculo: ds.veiculo || '' };
	}
	/* Outras compatíveis: os cards com preço da própria página. */
	function alternativas() {
		var vistos = {}, out = [];
		Array.prototype.forEach.call(d.querySelectorAll('[data-awr-checkout][data-sku]'), function (el) {
			var p = prodDe(el);
			if (!p.sku || !(p.preco > 0) || vistos[p.sku]) return;
			vistos[p.sku] = 1; if (!p.veiculo && S && S.prod) p.veiculo = S.prod.veiculo; out.push(p);
		});
		return out;
	}

	/* ---------- contas (mesmas regras do servidor) ---------- */
	function pixPag(p) { return p === 'Pix' || p === 'Dinheiro'; }
	function total() {
		var f = S.f, c = S.cot || {}, base = S.prod.preco;
		var desc = pixPag(f.pagamento) ? Math.round(base * 3) / 100 : 0;
		var taxa = f.tipo === 'retirada' ? 0 : Number(c.taxa) || 0;
		var casco = (c.casco_obrig && f.tipo !== 'retirada') || !f.troca ? S.prod.casco : 0;
		var acr = c.acrescimo_pct && f.tipo !== 'retirada' ? Math.round(base * 4) / 100 : 0;
		return { base: base, desc: desc, taxa: taxa, casco: casco, acr: acr, total: Math.round((base - desc + taxa + casco + acr) * 100) / 100 };
	}

	/* ---------- servidor ---------- */
	function qs(o) { return Object.keys(o).filter(function (k) { return o[k] !== '' && o[k] != null; }).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(o[k]); }).join('&'); }
	function getJSON(url) { return fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } }).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }); }
	function cotar() {
		var f = S.f, cep = dig(f.cep), seq = ++cotSeq;
		if (cep.length !== 8 && f.tipo !== 'retirada') return;
		var p = { cep: cep, tipo: f.tipo, product_id: S.prod.pid || '', data: f.tipo === 'agendada' ? f.data : '', hora: f.tipo === 'agendada' ? f.hora : '' };
		S.cotando = true; pintarEntrega();
		getJSON((A.restUrl || '/wp-json/awr/v1/') + 'cotacao?' + qs(p))
			.catch(function () { return getJSON((A.searchUrl || '/awr-busca/') + '?' + qs(Object.assign({ action: 'cotacao' }, p))); })
			.then(function (c) {
				if (seq !== cotSeq) return;
				S.cotando = false; S.cotErro = '';
				if (!c || !c.ok) { S.cot = null; S.cotErro = (c && c.mensagem) || 'CEP não encontrado. Confira os números.'; }
				else {
					var mudouCep = !S.cot || S.cot.cep !== c.cep;
					S.cot = c;
					if (c.modo !== 'retirada') {
						if (mudouCep || !f.rua) { f.rua = c.endereco.rua || ''; f.bairro = c.endereco.bairro || ''; }
						f.cidade = c.endereco.cidade || f.cidade; f.uf = c.endereco.uf || f.uf;
						S.editEnd = !c.endereco_auto || !c.endereco.rua;
					}
					if (c.so_pix && !pixPag(f.pagamento)) f.pagamento = 'Pix';
					if (c.so_pix && f.pagamento === 'Dinheiro') f.pagamento = 'Pix';
				}
				salvar(); pintarEntrega(); pintarResumo();
			})
			.catch(function () { if (seq !== cotSeq) return; S.cotando = false; S.cot = null; S.cotErro = 'Não conseguimos calcular a entrega agora. Tente de novo ou fale no WhatsApp.'; pintarEntrega(); });
	}
	function lead() {
		var f = S.f, et = 'etapa' + S.step;
		if (!f.aceite || dig(f.telefone).length < 10 || f.nome.trim().length < 3 || leadEtapa === et) return;
		leadEtapa = et;
		fetch((A.restUrl || '/wp-json/awr/v1/') + 'lead', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ aceite: 1, nome: f.nome, telefone: f.telefone, cep: f.cep, bateria: S.prod.nome, sku: S.prod.sku, preco: S.prod.preco, veiculo: S.prod.veiculo, etapa: et, origem: location.href.split('#')[0] }) }).catch(function () {});
	}

	/* ---------- HTML ---------- */
	var ICO = {
		ok: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>',
		lock: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>'
	};
	function waLink(txt) { return 'https://wa.me/' + (A.whatsapp || '') + '?text=' + encodeURIComponent(txt); }
	function garantiaTxt(g) { var m = parseInt(dig(g), 10); return m ? m + ' meses de garantia' : ''; }
	function prazoCurto() { var c = S.cot; return c && c.prazo ? c.prazo.titulo : ''; }

	function cabecalho() {
		var nomes = ['Bateria', 'Entrega', 'Pagamento'], h = '';
		nomes.forEach(function (n, i) {
			var k = i + 1, at = S.step === k, feito = S.step > k && S.step < 4;
			h += '<li class="' + (at ? 'is-on' : '') + (feito ? ' is-done' : '') + '"' + (at ? ' aria-current="step"' : '') + '>' + (feito ? '<button type="button" data-a="ir" data-k="' + k + '"><span>' + ICO.ok + '</span>' + n + '</button>' : '<span><b>' + k + '</b></span>' + n) + '</li>';
		});
		return '<header class="awrco__top"><button type="button" class="awrco__x awrco__back" data-a="voltar" aria-label="Voltar"' + (S.step > 1 && S.step < 4 ? '' : ' hidden') + '>‹</button><span class="awrco__logo">' + (A.logoHtml || '<b>AWR</b> BATERIAS') + '</span><span class="awrco__safe">' + ICO.lock + ' Compra 100% segura</span><button type="button" class="awrco__x" data-a="fechar" aria-label="Fechar">×</button></header>' +
			(S.step < 4 ? '<ol class="awrco__prog" aria-label="Etapas da compra">' + h + '</ol>' : '');
	}

	function etapaBateria() {
		var p = S.prod, alts = alternativas().filter(function (a) { return a.sku !== p.sku; }), g = garantiaTxt(p.garantia);
		var preco = p.preco > 0
			? '<p class="awrco__preco">' + fmt(p.preco) + '</p><p class="awrco__parc">ou 10x de ' + fmt(p.preco / 10) + ' sem juros</p><p class="awrco__pix">' + fmt(p.preco * 0.97) + ' no Pix <span>3% de desconto</span></p>'
			: '<p class="awrco__preco awrco__preco--sob">Preço sob consulta</p>';
		return '<h2 id="awrco-t" tabindex="-1">Bateria recomendada para seu veículo</h2>' +
			(p.veiculo ? '<p class="awrco__compat">' + ICO.ok + ' Compatível com o seu ' + esc(p.veiculo) + '</p>' : '') +
			'<div class="awrco__prod">' + (p.imagem ? '<img src="' + esc(p.imagem) + '" alt="" width="104" height="104" loading="eager" decoding="async">' : '<span class="awrco__noimg" aria-hidden="true">🔋</span>') +
			'<div>' + (g ? '<span class="awrco__selo">' + esc(g) + '</span>' : '') + '<h3>' + esc(p.nome) + '</h3><p class="awrco__sku">Modelo ' + esc(p.sku) + '</p>' + preco + '</div></div>' +
			'<ul class="awrco__benef">' +
			'<li>' + ICO.ok + ' Instalação e teste do alternador grátis</li>' +
			(g ? '<li>' + ICO.ok + ' ' + esc(g.charAt(0).toUpperCase() + g.slice(1)) + '</li>' : '') +
			'<li>' + ICO.ok + ' Bateria nova e original, com nota fiscal</li>' +
			'<li>' + ICO.ok + ' Preço na troca: entregue a bateria usada na instalação</li>' +
			'<li>' + ICO.ok + ' Entrega e instalação em até 35 min*</li></ul>' +
			'<p class="awrco__nota">*Em Porto Alegre e região, conforme o CEP e o horário. Confirmamos o prazo e eventuais taxas na próxima etapa, antes de você finalizar.</p>' +
			'<div class="awrco__acoes">' + (p.preco > 0
				? '<button type="button" class="awrco__cta" data-a="avancar">Quero esta bateria ›</button>'
				: '<a class="awrco__cta" target="_top" rel="noopener" data-awr-source="checkout_v2_sem_preco" href="' + esc(waLink('Olá! Quero o preço da bateria ' + p.nome + ' (' + p.sku + ')' + (p.veiculo ? ' para o ' + p.veiculo : '') + '.')) + '">Pedir preço no WhatsApp ›</a>') +
			(alts.length ? '<button type="button" class="awrco__link" data-a="alts" aria-haspopup="dialog">Ver outras baterias compatíveis (' + alts.length + ')</button>' : '') + '</div>';
	}

	function campo(nome, rot, v, extra, dica) {
		return '<label class="awrco__f"><span>' + rot + '</span><input name="' + nome + '" value="' + esc(v) + '" ' + (extra || '') + '>' + (dica || '') + '</label>';
	}
	function etapaEntrega() {
		var f = S.f;
		return '<h2 id="awrco-t" tabindex="-1">Para onde levamos sua bateria?</h2>' +
			'<div class="awrco__grid">' +
			campo('cep', 'CEP', f.cep, 'inputmode="numeric" autocomplete="postal-code" maxlength="9" aria-required="true" placeholder="00000-000"', '<a class="awrco__mini" href="https://buscacepinter.correios.com.br/app/endereco/index.php" target="_blank" rel="noopener">Não sei meu CEP</a>') +
			campo('nome', 'Seu nome', f.nome, 'autocomplete="name" aria-required="true" placeholder="Nome e sobrenome"') +
			campo('telefone', 'WhatsApp', f.telefone, 'type="tel" inputmode="tel" autocomplete="tel-national" aria-required="true" placeholder="(51) 99999-9999"') +
			'</div><label class="awrco__check"><input type="checkbox" name="aceite"' + (f.aceite ? ' checked' : '') + '> <span>Pode me chamar no WhatsApp se eu não concluir o pedido</span></label>' +
			'<div data-entrega></div>' +
			'<div class="awrco__acoes"><button type="button" class="awrco__cta" data-a="avancar">Continuar para pagamento ›</button></div>';
	}
	function blocoEntrega() {
		var f = S.f, c = S.cot, h = '';
		if (f.tipo === 'retirada') return blocoTipo() + blocoLoja();
		if (dig(f.cep).length !== 8) return '<p class="awrco__dica">Digite o CEP para ver o prazo e a taxa de entrega.</p>';
		if (S.cotando) return '<p class="awrco__dica" role="status">Calculando a entrega para o seu CEP…</p>';
		if (S.cotErro) return '<p class="awrco__aviso" role="alert">' + esc(S.cotErro) + '</p>';
		if (!c) return '';
		var end = f.rua ? esc(f.rua) + (f.bairro ? ' — ' + esc(f.bairro) : '') + '<br>' : '';
		h += S.editEnd
			? '<div class="awrco__grid">' + campo('rua', 'Rua', f.rua, 'autocomplete="address-line1" aria-required="true"') + campo('bairro', 'Bairro', f.bairro, 'aria-required="true"') + '</div><p class="awrco__dica">' + esc(f.cidade + (f.uf ? '/' + f.uf : '')) + '</p>'
			: '<div class="awrco__end"><p>' + end + esc(f.cidade + (f.uf ? '/' + f.uf : '')) + '</p><button type="button" class="awrco__link" data-a="editend">Editar endereço</button></div>';
		h += '<div class="awrco__grid awrco__grid--2">' + campo('numero', 'Número', f.numero, 'autocomplete="address-line2" aria-required="true" placeholder="Nº ou s/n"') + campo('complemento', 'Complemento (opcional)', f.complemento, 'placeholder="Apto, bloco, ponto de referência"') + '</div>';
		var rapida = c.modo === 'rapida';
		h += '<div class="awrco__prazo' + (rapida ? ' is-rapida' : '') + (c.modo === 'fechado' ? ' is-alerta' : '') + '"><strong>' + (rapida ? '⚡ ' : '') + esc(c.prazo.titulo) + '</strong><span>' + esc(c.prazo.texto) + '</span><em>Taxa de entrega: ' + esc(c.taxa_rotulo) + '</em></div>';
		if (c.so_pix) h += '<p class="awrco__aviso">' + (c.regiao === 'fora-rs' ? 'Sua região é atendida por transportadora, sem instalação no local, com acréscimo de 4%.' : 'Sua região é atendida por envio, sem instalação no local.') + ' Pagamento via Pix e CPF/CNPJ obrigatório para a nota.</p>';
		return h + blocoTipo();
	}
	function blocoTipo() {
		var f = S.f, c = S.cot || {};
		var aberto = f.tipo !== 'rapida' || c.modo === 'fechado' || S.verTipos;
		if (!aberto) return '<button type="button" class="awrco__link" data-a="tipos">Prefere agendar ou retirar na loja?</button>';
		var op = function (v, t) { return '<label class="awrco__chip"><input type="radio" name="tipo" value="' + v + '"' + (f.tipo === v ? ' checked' : '') + '> <span>' + t + '</span></label>'; };
		var h = '<fieldset class="awrco__tipos"><legend>Como prefere receber?</legend>' + op('rapida', 'O quanto antes') + (c.agendar || f.tipo === 'agendada' ? op('agendada', 'Agendar horário') : '') + op('retirada', 'Retirar na loja') + '</fieldset>';
		if (f.tipo === 'agendada') {
			var hoje = new Date(); hoje.setMinutes(hoje.getMinutes() - hoje.getTimezoneOffset());
			h += '<div class="awrco__grid awrco__grid--2">' + campo('data', 'Dia', f.data, 'type="date" min="' + hoje.toISOString().slice(0, 10) + '" aria-required="true"') + campo('hora', 'Horário', f.hora, 'type="time" min="06:30" max="22:00" step="900" aria-required="true"') + '</div>';
		}
		return h;
	}
	var lojas = null;
	function blocoLoja() {
		if (!lojas) {
			lojas = fetch((A.dataUrl || '') + 'stores.json').then(function (r) { return r.json(); }).catch(function () { return []; });
			lojas.then(function () { pintarEntrega(); });
			return '<p class="awrco__dica">Carregando as lojas…</p>';
		}
		var lista = lojas.v || [];
		if (!lojas.v) lojas.then(function (l) { lojas.v = l || []; pintarEntrega(); });
		var f = S.f, h = '<label class="awrco__f"><span>Loja para retirada e instalação</span><select name="loja" aria-required="true"><option value="">Selecione a loja</option>';
		lista.forEach(function (s) { var n = 'AWR ' + s.nome + ' — ' + s.cidade + '/' + s.estado; h += '<option' + (f.loja === n ? ' selected' : '') + '>' + esc(n) + '</option>'; });
		return h + '</select></label><p class="awrco__dica">Instalação grátis na loja. Leve o veículo no horário de funcionamento.</p>';
	}

	function linha(r, v, cls) { return '<div class="awrco__lin' + (cls ? ' ' + cls : '') + '"><dt>' + r + '</dt><dd>' + v + '</dd></div>'; }
	function resumo(compl) {
		var p = S.prod, f = S.f, t = total(), c = S.cot || {};
		var h = '<h3 class="awrco__rtit">Resumo do pedido</h3><dl class="awrco__res">' + linha(esc(p.nome) + (p.veiculo ? '<small>' + esc(p.veiculo) + '</small>' : ''), fmt(t.base));
		if (compl && f.tipo !== 'retirada' && f.rua) h += linha('Endereço<small>' + esc(f.rua + ', ' + f.numero + (f.complemento ? ' - ' + f.complemento : '') + ' — ' + f.cidade) + '</small>', '<button type="button" class="awrco__link" data-a="ir" data-k="2">Editar</button>');
		if (f.tipo === 'retirada') h += linha('Retirada na loja' + (f.loja ? '<small>' + esc(f.loja) + '</small>' : ''), 'Grátis');
		else if (c.prazo) h += linha('Entrega<small>' + esc(c.prazo.titulo) + '</small>', esc(c.taxa_rotulo));
		if (f.tipo === 'retirada' || (c.prazo && !c.so_pix)) h += linha('Instalação e teste', 'Grátis');
		if (t.casco) h += linha('Casco (sem a bateria usada)', fmt(t.casco));
		if (t.acr) h += linha('Acréscimo fora do RS (4%)', fmt(t.acr));
		if (t.desc) h += linha('Desconto ' + esc(f.pagamento) + ' (3%)', '− ' + fmt(t.desc), 'is-desc');
		h += linha('Total', fmt(t.total), 'is-total') + '</dl>';
		if (f.pagamento === 'Crédito' && f.parcelas > 1) h += '<p class="awrco__dica">' + f.parcelas + 'x de ' + fmt(t.total / f.parcelas) + ' sem juros</p>';
		return h + '<p class="awrco__dica">' + (c.so_pix && f.tipo !== 'retirada' ? '💳 Pagamento via Pix, combinado no WhatsApp ao confirmar o envio.' : '💳 Você paga só na entrega, ao técnico.') + '</p>';
	}

	function etapaPagamento() {
		var f = S.f, c = S.cot || {}, t = total(), so = c.so_pix && f.tipo !== 'retirada';
		var op = function (v, tit, sub) {
			return '<label class="awrco__pag' + (f.pagamento === v ? ' is-on' : '') + '"><input type="radio" name="pagamento" value="' + v + '"' + (f.pagamento === v ? ' checked' : '') + '><span><strong>' + tit + '</strong><small>' + sub + '</small></span></label>';
		};
		var parc = '';
		if (f.pagamento === 'Crédito') {
			parc = '<label class="awrco__f"><span>Parcelas</span><select name="parcelas">';
			for (var i = 1; i <= 10; i++) parc += '<option value="' + i + '"' + (Number(f.parcelas) === i ? ' selected' : '') + '>' + (i === 1 ? 'À vista · ' + fmt(t.total) : i + 'x de ' + fmt(t.total / i) + ' sem juros') + '</option>';
			parc += '</select></label>';
		}
		var cascoObrig = c.casco_obrig && f.tipo !== 'retirada';
		return '<h2 id="awrco-t" tabindex="-1">Como prefere pagar?</h2><p class="awrco__sub">' + (so ? 'Envio por transportadora: pagamento via Pix, combinado no WhatsApp.' : 'Pague só na entrega, direto ao técnico.') + '</p>' +
			'<fieldset class="awrco__pags"><legend class="awrco__sr">Forma de pagamento</legend>' +
			op('Pix', 'Pix', '3% de desconto · ' + fmt(S.prod.preco * 0.97)) +
			(so ? '' : op('Crédito', 'Cartão de crédito', 'Em até 10x sem juros') + op('Débito', 'Cartão de débito', 'À vista') + op('Dinheiro', 'Dinheiro', '3% de desconto')) +
			'</fieldset>' + parc +
			(cascoObrig
				? '<p class="awrco__aviso">Sem instalação no local não há troca da bateria usada: o casco (' + fmt(S.prod.casco) + ') entra no total.</p>'
				: '<label class="awrco__check"><input type="checkbox" name="troca"' + (f.troca ? ' checked' : '') + '> <span>Vou entregar a bateria usada na troca' + (f.troca ? '' : ' <small>(sem a troca: + ' + (S.prod.casco ? fmt(S.prod.casco) : 'valor a confirmar') + ' de casco)</small>') + '</span></label>') +
			'<details class="awrco__doc"' + (c.cpf_obrig || f.doc ? ' open' : '') + '><summary>Precisa de nota com CPF/CNPJ?' + (c.cpf_obrig && f.tipo !== 'retirada' ? ' (obrigatório)' : '') + '</summary>' + campo('doc', 'CPF ou CNPJ', f.doc, 'inputmode="numeric" autocomplete="off"') + '</details>' +
			'<div class="awrco__resumo-in">' + resumo(true) + '</div>' +
			'<input type="text" name="awr_hp" tabindex="-1" autocomplete="off" class="awrco__hp" aria-hidden="true">' +
			'<div class="awrco__acoes"><button type="button" class="awrco__cta" data-a="finalizar">Finalizar pedido ›</button>' +
			'<button type="button" class="awrco__link" data-a="wa" aria-haspopup="dialog">Prefiro finalizar pelo WhatsApp</button></div>';
	}

	function etapaOk() {
		var p = S.pedido, c = p.prazo || {}, numero = esc(p.numero);
		var prev = c.titulo && (c.min > 0 || /mesmo dia|agendad|dia seguinte/i.test(c.titulo)) ? esc(c.titulo) + (c.texto && /agendad/i.test(c.titulo) ? ' — ' + esc(c.texto) : '') : 'Confirmamos o horário pelo WhatsApp';
		return '<div class="awrco__ok"><span class="awrco__okico">' + ICO.ok + '</span><h2 id="awrco-t" tabindex="-1">Pedido confirmado!</h2><p class="awrco__num">Pedido #' + numero + '</p>' +
			'<p>' + esc(p.resumo) + '</p>' +
			'<ol class="awrco__linha"><li class="is-done"><strong>Pedido recebido</strong><span>Já está no nosso sistema.</span></li><li><strong>Em separação</strong><span>A loja mais próxima separa a bateria certa.</span></li><li><strong>' + (S.f.tipo === 'retirada' ? 'Pronto para retirada' : 'Sai para atendimento') + '</strong><span>Avisamos você no WhatsApp.</span></li><li><strong>' + (S.f.tipo === 'retirada' ? 'Retirada na loja' : 'Chegada prevista') + '</strong><span>' + prev + '</span></li></ol>' +
			'<div class="awrco__acoes"><a class="awrco__cta" target="_top" rel="noopener" data-awr-source="checkout_v2_acompanhar" href="' + esc(waLink('Olá! Fiz o pedido #' + p.numero + ' pelo site (' + S.prod.nome + '). Quero acompanhar.')) + '">Acompanhar no WhatsApp</a>' +
			'<a class="awrco__btn2" href="' + esc(p.redirect) + '">Ver detalhes do pedido</a></div></div>';
	}

	function pintar() {
		var corpo = S.step === 1 ? etapaBateria() : S.step === 2 ? etapaEntrega() : S.step === 3 ? etapaPagamento() : etapaOk();
		root.querySelector('.awrco__box').innerHTML = cabecalho() + '<div class="awrco__body"><div class="awrco__main" data-step="' + S.step + '">' + corpo + '</div>' + (S.step < 4 ? '<aside class="awrco__side" aria-label="Resumo"></aside>' : '') + '</div>';
		root.classList.toggle('is-ok', S.step === 4);
		if (S.step === 2) pintarEntrega();
		pintarResumo();
		var h = $('#awrco-t'); if (h) h.focus({ preventScroll: true });
		var m = $('.awrco__main'); if (m) m.scrollTop = 0;
		if (S.step > 1 && S.step < 4) lead();
	}
	function pintarEntrega() {
		var box = root && $('[data-entrega]'); if (!box) return;
		var ativo = d.activeElement && box.contains(d.activeElement) ? d.activeElement.name : '';
		box.innerHTML = blocoEntrega();
		if (ativo) { var el = box.querySelector('[name="' + ativo + '"]'); if (el) el.focus(); }
	}
	function pintarResumo() {
		var a = root && $('.awrco__side'); if (a) a.innerHTML = resumo(S.step === 3);
		var i = root && $('.awrco__resumo-in'); if (i) i.innerHTML = resumo(true);
	}

	/* ---------- validação por etapa ---------- */
	function erro(msg, nome) {
		var old = root.querySelector('.awrco__err'); if (old) old.remove();
		root.querySelectorAll('[aria-invalid]').forEach(function (e) { e.removeAttribute('aria-invalid'); });
		var p = d.createElement('p'); p.className = 'awrco__err'; p.setAttribute('role', 'alert'); p.textContent = msg;
		var ac = $('.awrco__main .awrco__acoes'); ac ? ac.parentNode.insertBefore(p, ac) : $('.awrco__main').appendChild(p);
		var el = nome && root.querySelector('[name="' + nome + '"]');
		if (el) { el.setAttribute('aria-invalid', 'true'); el.focus(); }
		ev('checkout_erro', { step: S.step, erro: nome || 'geral' });
		return false;
	}
	function valida(k) {
		var f = S.f, c = S.cot;
		if (k === 2) {
			if (f.tipo !== 'retirada' && dig(f.cep).length !== 8) return erro('Informe o CEP com 8 números.', 'cep');
			if (f.nome.trim().length < 3) return erro('Informe seu nome.', 'nome');
			if (dig(f.telefone).length < 10) return erro('Informe um WhatsApp válido com DDD.', 'telefone');
			if (f.tipo === 'retirada') return f.loja ? true : erro('Selecione a loja para retirada.', 'loja');
			if (S.cotando) return erro('Aguarde: estamos calculando a entrega.');
			if (!c) return erro(S.cotErro || 'Confira o CEP para calcularmos a entrega.', 'cep');
			if (!f.rua.trim()) { S.editEnd = true; pintarEntrega(); return erro('Informe a rua.', 'rua'); }
			if (!f.bairro.trim()) { S.editEnd = true; pintarEntrega(); return erro('Informe o bairro.', 'bairro'); }
			if (!f.numero.trim()) return erro('Informe o número (ou s/n).', 'numero');
			if (f.tipo === 'agendada' && (!f.data || !f.hora)) return erro('Escolha o dia e o horário.', f.data ? 'hora' : 'data');
			if (c.modo === 'fechado') return erro(c.prazo.texto, f.tipo === 'agendada' ? 'hora' : 'tipo');
		}
		if (k === 3) {
			if (!f.pagamento) return erro('Escolha a forma de pagamento.', 'pagamento');
			var precisa = c && c.cpf_obrig && f.tipo !== 'retirada';
			if (precisa && !f.doc.trim()) { var dt = $('.awrco__doc'); if (dt) dt.open = true; return erro('Informe o CPF ou CNPJ, obrigatório para envio por transportadora.', 'doc'); }
			if (f.doc.trim() && !docOk(f.doc)) { var dd = $('.awrco__doc'); if (dd) dd.open = true; return erro('CPF/CNPJ inválido. Confira os números.', 'doc'); }
		}
		return true;
	}

	function irPara(k) {
		if (k > S.step) {
			for (var i = S.step; i < k; i++) if (!valida(i)) return;
			if (S.step === 1) evUma('begin', 'checkout_etapa_bateria', { step: 1 });
			if (k >= 3 && S.step <= 2) evUma('ship', 'add_shipping_info', { shipping_tier: S.f.tipo === 'retirada' ? 'retirada' : (S.cot && S.cot.modo) || '' });
		}
		S.step = k; salvar(); pintar();
	}

	/* ---------- envio do pedido ---------- */
	function payload() {
		var f = S.f, t = total(), c = S.cot || {};
		return {
			checkout: 'v2', pedido_token: S.token, sku: S.prod.sku, product_id: S.prod.pid, nome_produto: S.prod.nome, preco: S.prod.preco,
			nome: f.nome.trim(), telefone: f.telefone, cep: dig(f.cep), endereco: f.rua, numero: f.numero, complemento: f.complemento, bairro: f.bairro, cidade: f.cidade, uf: f.uf,
			entrega_tipo: f.tipo, entrega_data: f.tipo === 'agendada' ? f.data : '', entrega_hora: f.tipo === 'agendada' ? f.hora : '', loja_retirada: f.tipo === 'retirada' ? f.loja : '',
			pagamento: f.pagamento, parcelas: f.pagamento === 'Crédito' ? Number(f.parcelas) || 1 : 1, desconto_pct: pixPag(f.pagamento) ? 3 : 0,
			casco: t.casco, sem_troca: t.casco ? 1 : 0, taxa_mostrada: c.taxa == null ? -1 : t.taxa, total: t.total, doc: f.doc, carro_ano: S.prod.veiculo,
			awr_hp: (root.querySelector('[name="awr_hp"]') || {}).value || '', origem: window.top !== window.self ? 'iframe' : 'site_v2'
		};
	}
	function finalizar(btn, tentativa) {
		if (enviando && !tentativa) return;
		if (!valida(2) || !valida(3)) return;
		enviando = true; btn.disabled = true; btn.setAttribute('aria-busy', 'true'); btn.textContent = 'Registrando seu pedido…';
		var body = payload();
		fetch((A.restUrl || '/wp-json/awr/v1/') + 'pedido', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body) })
			.then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { return { st: r.status, j: j }; }); })
			.then(function (r) {
				if (r.st === 409 && (tentativa || 0) < 4) { setTimeout(function () { finalizar(btn, (tentativa || 0) + 1); }, 1500); return; }
				enviando = false;
				if (!r.j || !r.j.ok) throw new Error((r.j && r.j.message) || 'Não foi possível registrar o pedido.');
				concluir(r.j, body);
			})
			.catch(function (e) {
				enviando = false; btn.disabled = false; btn.removeAttribute('aria-busy'); btn.textContent = 'Tentar de novo ›';
				erro(e.message + ' Se preferir, finalize pelo WhatsApp.');
			});
	}
	function concluir(r, body) {
		var t = Number(r.total) || body.total, n = String(r.pedido), ja = false;
		try { ja = !!localStorage.getItem('awr_tx_' + n); localStorage.setItem('awr_tx_' + n, '1'); } catch (e) {}
		if (!ja) {
			ev('purchase', { transaction_id: n, value: t, shipping: total().taxa, items: item(), payment_type: body.pagamento });
			if (window.awrConversion) window.awrConversion('pedido', { source: 'checkout_v2', sku: S.prod.sku, item_name: S.prod.nome, value: t, transaction_id: n, step: 'concluido' });
		}
		S.pedido = { numero: n, total: t, redirect: r.redirect || '/pedido-confirmado/?pedido=' + n, prazo: r.prazo || (S.cot && S.cot.prazo) || null, resumo: S.prod.nome + ' · ' + fmt(t) + ' · ' + body.pagamento + (S.cot && S.cot.so_pix && S.f.tipo !== 'retirada' ? '' : ' na entrega') };
		S.step = 4; limpar(); pintar();
	}

	/* ---------- folhas (outras baterias / WhatsApp) ---------- */
	var folhaAberta = null;
	function folha(html, nome) {
		fecharFolha();
		var s = d.createElement('div'); s.className = 'awrco__sheet'; s.setAttribute('role', 'dialog'); s.setAttribute('aria-modal', 'true'); s.setAttribute('aria-labelledby', 'awrco-st');
		s.innerHTML = '<div class="awrco__sheetbox"><button type="button" class="awrco__x awrco__sx" data-a="fecharfolha" aria-label="Fechar">×</button>' + html + '</div>';
		root.appendChild(s); folhaAberta = s; s.dataset.nome = nome;
		var h = s.querySelector('#awrco-st'); if (h) h.focus();
	}
	function fecharFolha() { if (folhaAberta) { folhaAberta.remove(); folhaAberta = null; } }
	function folhaAlts() {
		var alts = alternativas(), h = '<h2 id="awrco-st" tabindex="-1">Outras baterias compatíveis</h2><fieldset class="awrco__alts"><legend class="awrco__sr">Escolha uma bateria</legend>';
		alts.forEach(function (a) {
			var g = garantiaTxt(a.garantia);
			h += '<label class="awrco__alt' + (a.sku === S.prod.sku ? ' is-on' : '') + '"><input type="radio" name="alt" value="' + esc(a.sku) + '"' + (a.sku === S.prod.sku ? ' checked' : '') + '><span><strong>' + esc(a.nome) + '</strong><small>' + (g ? esc(g) + ' · ' : '') + 'Pix ' + fmt(a.preco * 0.97) + '</small></span><b>' + fmt(a.preco) + '</b></label>';
		});
		folha(h + '</fieldset><button type="button" class="awrco__cta" data-a="pick">Selecionar esta bateria</button>', 'alts');
		ev('checkout_ver_alternativas', { sku: S.prod.sku, opcoes: alts.length });
	}
	function textoWa() {
		var f = S.f, t = total(), c = S.cot || {};
		var l = ['Olá! Quero comprar a bateria ' + S.prod.nome + ' (' + S.prod.sku + ').'];
		if (S.prod.veiculo) l.push('🚗 Veículo: ' + S.prod.veiculo);
		if (f.nome) l.push('👤 Nome: ' + f.nome);
		if (f.tipo === 'retirada') l.push('📦 Retirada na loja: ' + (f.loja || 'a definir'));
		else if (f.rua) l.push('🏠 ' + f.rua + ', ' + (f.numero || 's/n') + (f.complemento ? ' - ' + f.complemento : '') + ' — ' + f.bairro + ', ' + f.cidade + ' (CEP ' + mascCep(f.cep) + ')');
		if (c.prazo && f.tipo !== 'retirada') l.push('🚚 ' + c.prazo.titulo + ' · taxa: ' + c.taxa_rotulo);
		if (f.pagamento) l.push('💳 ' + f.pagamento + (f.pagamento === 'Crédito' && f.parcelas > 1 ? ' em ' + f.parcelas + 'x' : '') + ' na entrega');
		l.push('🧾 Total: ' + fmt(t.total));
		return l.join('\n');
	}
	function folhaWa() {
		var f = S.f;
		folha('<h2 id="awrco-st" tabindex="-1">Prefere comprar pelo WhatsApp?</h2><p>Enviamos os dados abaixo para um atendente, que confirma tudo com você.</p><dl class="awrco__res">' +
			linha('Bateria', esc(S.prod.nome)) + (S.prod.veiculo ? linha('Veículo', esc(S.prod.veiculo)) : '') +
			(f.tipo === 'retirada' ? linha('Retirada', esc(f.loja || 'a definir')) : f.rua ? linha('Endereço', esc(f.rua + ', ' + (f.numero || 's/n') + ' — ' + f.cidade)) : '') + linha('Total', fmt(total().total), 'is-total') + '</dl>' +
			'<a class="awrco__cta awrco__cta--wa" target="_top" rel="noopener" data-awr-source="checkout_v2_whatsapp" data-a="waenviar" href="' + esc(waLink(textoWa())) + '">Comprar pelo WhatsApp</a><button type="button" class="awrco__btn2" data-a="fecharfolha">Continuar pelo site</button>', 'wa');
	}

	/* ---------- interação ---------- */
	function onClick(e) {
		var b = e.target.closest('[data-a]'); if (!b || !root.contains(b)) { if (e.target === root) fechar(); return; }
		var a = b.getAttribute('data-a');
		if (a === 'fechar') return fechar();
		if (a === 'voltar') return irPara(Math.max(1, S.step - 1));
		if (a === 'ir') return irPara(Number(b.getAttribute('data-k')));
		if (a === 'avancar') return irPara(S.step + 1);
		if (a === 'alts') return folhaAlts();
		if (a === 'wa') { ev('checkout_whatsapp_aberto', { step: S.step }); return folhaWa(); }
		if (a === 'waenviar') { ev('checkout_whatsapp_enviado', { step: S.step, value: total().total }); return; }
		if (a === 'fecharfolha') { fecharFolha(); var cta = $('.awrco__main .awrco__cta'); if (cta) cta.focus(); return; }
		if (a === 'editend') { S.editEnd = true; pintarEntrega(); var r = $('[name="rua"]'); if (r) r.focus(); return; }
		if (a === 'tipos') { S.verTipos = true; pintarEntrega(); var t = $('[name="tipo"]:checked'); if (t) t.focus(); return; }
		if (a === 'finalizar') return finalizar(b);
		if (a === 'pick') {
			var sel = folhaAberta && folhaAberta.querySelector('[name="alt"]:checked'), p = sel && alternativas().filter(function (x) { return x.sku === sel.value; })[0];
			fecharFolha();
			if (p && p.sku !== S.prod.sku) { S.prod = p; S.ev = { open: 1 }; ev('checkout_troca_bateria', { sku: p.sku, value: p.preco }); salvar(); if (dig(S.f.cep).length === 8) cotar(); }
			S.step = 1; pintar();
		}
	}
	function onInput(e) {
		var el = e.target, n = el.name; if (!n || !(n in S.f) && n !== 'alt') return;
		if (n === 'alt') { folhaAberta.querySelectorAll('.awrco__alt').forEach(function (l) { l.classList.toggle('is-on', l.contains(el) && el.checked); }); return; }
		if (n === 'telefone') el.value = mascTel(el.value);
		if (n === 'cep') el.value = mascCep(el.value);
		var v = el.type === 'checkbox' ? el.checked : el.value;
		el.removeAttribute('aria-invalid');
		var mudou = S.f[n] !== v; S.f[n] = v; salvar();
		if (!mudou) return;
		if (n === 'cep') { if (dig(v).length === 8) cotar(); else { S.cot = null; S.cotErro = ''; if (e.type === 'change') pintarEntrega(); } }
		if (n === 'tipo') { S.verTipos = true; if (v !== 'retirada' || dig(S.f.cep).length === 8) cotar(); pintarEntrega(); pintarResumo(); }
		if ((n === 'data' || n === 'hora') && S.f.data && S.f.hora) cotar();
		if (n === 'loja') pintarResumo();
		if (n === 'aceite' && v) { leadEtapa = ''; lead(); }
		if (n === 'pagamento') { evUma('pay', 'add_payment_info', { payment_type: v }); pintar(); var r = $('[name="pagamento"]:checked'); if (r) r.focus(); }
		if (n === 'troca' || n === 'parcelas') { if (n === 'troca') { pintar(); var tr = $('[name="troca"]'); if (tr) tr.focus(); } else pintarResumo(); }
	}
	function onKey(e) {
		if (e.key === 'Escape') { e.preventDefault(); if (folhaAberta) { fecharFolha(); return; } fechar(); return; }
		if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type !== 'checkbox' && e.target.type !== 'radio') { e.preventDefault(); var c = $('.awrco__main .awrco__cta'); if (c && S.step === 2) c.click(); return; }
		if (e.key !== 'Tab') return;
		var box = folhaAberta || root.querySelector('.awrco__box');
		var f = Array.prototype.filter.call(box.querySelectorAll('a[href],button:not([disabled]),input:not([type=hidden]):not(.awrco__hp),select,textarea,summary,[tabindex="0"]'), function (x) { return x.offsetParent !== null; });
		if (!f.length) return;
		var ini = f[0], fim = f[f.length - 1];
		if (e.shiftKey && (d.activeElement === ini || !box.contains(d.activeElement))) { e.preventDefault(); fim.focus(); }
		else if (!e.shiftKey && (d.activeElement === fim || !box.contains(d.activeElement))) { e.preventDefault(); ini.focus(); }
	}

	function fechar() {
		if (!root) return;
		if (S && S.step < 4) { ev('checkout_fechado', { step: S.step }); lead(); }
		fecharFolha(); root.remove(); root = null;
		d.documentElement.classList.remove('awrco-aberto');
		d.removeEventListener('keydown', onKey, true);
		if (last && last.focus) try { last.focus(); } catch (e) {}
	}

	function abrir(el) {
		if (root) fechar();
		var novo = prodDe(el), s = ler();
		var ae = d.activeElement;
		last = ae && ae !== d.body && !(root && root.contains(ae)) ? ae : el && el.nodeType === 1 ? el.querySelector('button,a[href]') || el : null;
		var f0 = { cep: '', nome: '', telefone: '', rua: '', bairro: '', cidade: '', uf: '', numero: '', complemento: '', tipo: 'rapida', data: '', hora: '', loja: '', pagamento: 'Pix', parcelas: 1, troca: true, doc: '', aceite: false };
		if (s && s.f) {
			S = s; S.f = Object.assign(f0, s.f);
			if (S.prod.sku !== novo.sku) { S.prod = novo; S.step = 1; S.ev = { open: S.ev && S.ev.open }; }
			if (S.step > 3) S.step = 1;
		} else {
			S = { v: 1, token: tok(), prod: novo, step: 1, f: f0, cot: null, ev: {} };
		}
		// 5.57.0 — a página de produto manda o veículo confirmado e o CEP consultado.
		var dsx = (el && (el.dataset || el)) || {};
		if (novo.veiculo) S.prod.veiculo = novo.veiculo;
		if (dsx.cep && dig(dsx.cep).length === 8 && dig(S.f.cep) !== dig(dsx.cep)) { S.f.cep = mascCep(dsx.cep); S.cot = null; S.f.rua = ''; S.f.bairro = ''; S.f.numero = ''; }
		S.cotando = false; S.verTipos = false; enviando = false; leadEtapa = '';
		root = d.createElement('div'); root.className = 'awrco'; root.setAttribute('role', 'dialog'); root.setAttribute('aria-modal', 'true'); root.setAttribute('aria-labelledby', 'awrco-t');
		root.innerHTML = '<div class="awrco__box"></div>';
		d.body.appendChild(root); d.documentElement.classList.add('awrco-aberto');
		root.addEventListener('click', onClick); root.addEventListener('input', onInput); root.addEventListener('change', onInput);
		d.addEventListener('keydown', onKey, true);
		pintar();
		if (!S.ev.open) { S.ev.open = 1; salvar(); ev('begin_checkout', { value: S.prod.preco, items: item(), retomado: s ? 1 : 0 }); }
		if (S.step >= 2 && dig(S.f.cep).length === 8) cotar();
	}

	window.AWRCheckout = { open: abrir, close: fechar, _estado: function () { return S; } };
})();
