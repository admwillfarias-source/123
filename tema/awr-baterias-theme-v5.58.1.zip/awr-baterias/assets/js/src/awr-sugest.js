/* AWR 5.58.0 — Sugestões da busca no navegador.
   Espelho de awr_search_suggestions / awr_score_token_in_item / awr_search_by_sku
   (inc/search.php) sobre o índice assets/js/awr-sugest.json. Sem servidor a cada letra.
   window.AWRSugest.carregar() → Promise; .sugerir(q) → {veiculos, skus} ou null se o índice não chegou. */
(function () {
	'use strict';
	var A = window.AWR || {}, IDX = null, P = null, NM = null;
	function strip(s) { return String(s).normalize('NFD').replace(/[̀-ͯ]/g, ''); }
	function norm(s) { return strip(String(s == null ? '' : s).toLowerCase()).replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim(); }
	function slug(s) { return strip(String(s).toLowerCase()).replace(/\./g, '-').replace(/[^a-z0-9\s_-]/g, '').replace(/[\s_]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, ''); }

	function preparar(d) {
		NM = d.m.map(function (m, i) {
			var b = norm(d.b[m[0]]), mo = norm(m[1]);
			return { ma: d.b[m[0]], mo: m[1], b: b, m: mo, bc: b.replace(/\s+/g, ''), mc: mo.replace(/\s+/g, ''), mw: mo.split(' ').filter(Boolean), bw: b.split(' ').filter(Boolean), slug: (d.x && d.x[i]) || slug(d.b[m[0]] + '-' + m[1]) };
		});
		IDX = d;
	}
	function carregar() {
		if (P) return P;
		var u = A.sugestUrl || ((A.dataUrl || '').replace(/data\/?$/, 'js/') + 'awr-sugest.json');
		P = fetch(u, { credentials: 'same-origin' }).then(function (r) { if (!r.ok) throw new Error('idx'); return r.json(); }).then(function (d) { if (!d || d.v !== 2) throw new Error('idx'); preparar(d); return true; });
		P.catch(function () { P = null; });
		return P;
	}

	function ed1(a, b) {
		var la = a.length, lb = b.length;
		if (Math.abs(la - lb) > 1) return false;
		if (a === b) return true;
		if (la === lb) {
			var d = 0, ix = [];
			for (var i = 0; i < la; i++) if (a[i] !== b[i]) { d++; ix.push(i); if (d > 2) return false; }
			if (d === 1) return true;
			return d === 2 && ix[1] === ix[0] + 1 && a[ix[0]] === b[ix[1]] && a[ix[1]] === b[ix[0]];
		}
		var s = la < lb ? a : b, l = la < lb ? b : a, p = 0, q = 0, sk = false;
		while (p < s.length && q < l.length) {
			if (s[p] === l[q]) { p++; q++; continue; }
			if (sk) return false;
			sk = true; q++;
		}
		return true;
	}
	function pont(alts, it) {
		var best = -1;
		for (var k = 0; k < alts.length; k++) {
			var a = alts[k];
			if (a === '') continue;
			var ac = a.replace(/\s+/g, ''), al = a.length, acl = ac.length;
			if (it.mw.indexOf(a) !== -1) { best = Math.max(best, 100 + al); continue; }
			if (it.m.indexOf(a) === 0) { best = Math.max(best, 70 + al); continue; }
			if (it.b === a || it.bw.indexOf(a) !== -1) { best = Math.max(best, 40 + al); continue; }
			if (al >= 4) {
				for (var w = 0; w < it.mw.length; w++) {
					var mw = it.mw[w];
					if (mw.length >= 4 && mw[0] === a[0] && ed1(a, mw)) { best = Math.max(best, 25 + al); break; }
				}
				if (best >= 25) continue;
			}
			if (al >= 3 && it.m.indexOf(a) !== -1) { best = Math.max(best, 12 + al); continue; }
			if (acl >= 3 && it.mc.indexOf(ac) !== -1) { best = Math.max(best, 8 + acl); continue; }
			if (al >= 3 && (it.b.indexOf(a) !== -1 || it.bc.indexOf(ac) !== -1)) best = Math.max(best, 2 + al);
		}
		return best;
	}

	function veiculos(query, limit) {
		var q = norm(query);
		if (q.length < 2) return [];
		var toks = q.split(' ').filter(Boolean), year = null, tt = [];
		toks.forEach(function (t) {
			if (year === null && /^(19|20)\d{2}$/.test(t)) { year = +t; return; }
			if (IDX.w.indexOf(t) !== -1) return;
			tt.push(t);
		});
		var alts = tt.map(function (t) {
			var s = IDX.y[t]; if (!s) return [t];
			var o = [t]; s.forEach(function (x) { if (o.indexOf(x) === -1) o.push(x); }); return o;
		});
		if (!alts.length && !year) return [];
		var R = IDX.r, sc = [], pa = [], tot = alts.length, n = 0;
		for (var i = 0; i < R.length; i += 3) {
			var d = R[i + 1], a = R[i + 2];
			if (year && (year < d || year > a)) continue;
			var it = NM[R[i]], hits = 0, score = 0;
			for (var g = 0; g < alts.length; g++) { var b = pont(alts[g], it); if (b < 0) continue; hits++; score += b; }
			if (year) score += 5;
			var row = { i: R[i], d: d, a: a, s: score, h: hits, o: n++ };
			if (hits === tot) sc.push(row); else if (hits > 0) pa.push(row);
		}
		var pool = sc.length ? sc : pa;
		pool.sort(function (x, y) { return (y.h - x.h) || (y.s - x.s) || (y.a - x.a) || (x.o - y.o); });
		var out = [], seen = {};
		for (var j = 0; j < pool.length && out.length < limit; j++) {
			var r = pool[j], m = NM[r.i], key = r.i + '|' + r.d + '-' + r.a;
			if (seen[key]) continue;
			seen[key] = 1;
			out.push({ brand: m.ma, model: m.mo, yearStart: r.d, yearEnd: r.a, year: year || r.a, label: m.ma + ' ' + m.mo + ' (' + (r.d === r.a ? String(r.d) : r.d + '-' + r.a) + ')', slug: m.slug });
		}
		return out;
	}
	function skus(query, limit) {
		var q = String(query || '').replace(/\s+/g, '').toUpperCase();
		if (q.length < 2) return [];
		var ex = null, st = [], co = [];
		IDX.s.forEach(function (e) {
			var s = e[0], o = { sku: s, brand: e[1] };
			if (s === q) { ex = o; return; }
			if (s.indexOf(q) === 0) st.push(o); else if (s.indexOf(q) !== -1) co.push(o);
		});
		return (ex ? [ex] : []).concat(st, co).slice(0, limit);
	}
	function sugerir(q) {
		if (!IDX) return null;
		q = String(q || '').slice(0, 100);
		return { veiculos: veiculos(q, 8), skus: skus(q, 5), local: true };
	}
	window.AWRSugest = { carregar: carregar, sugerir: sugerir, pronto: function () { return !!IDX; } };
})();
