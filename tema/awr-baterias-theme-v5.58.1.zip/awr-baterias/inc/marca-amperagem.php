<?php
/**
 * 5.51.0 — Páginas marca × amperagem: /marca/{marca}/{n}ah/.
 *
 * Search Console (3 meses): "bateria heliar 60 amperes" 563 impressões,
 * "zetta 50ah" 471, "zetta 70 amperes" 452, "moura 180 amperes" 419,
 * "zetta 180 amperes" 414, "eletran 60ah" 933, "heliar 150" 249…
 * Só existe página quando a tabela oficial (inc/tabela-baterias.php) tem
 * modelo daquela marca naquela amperagem: preço, CCA e garantia reais.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Marca do site => prefixo do modelo na tabela oficial e chave em batteries.json. */
function awr_marca_amp_marcas() {
	return apply_filters( 'awr_marca_amp_marcas', array(
		'moura'   => array( 'nome' => 'Moura', 'tabela' => 'MOURA', 'chave' => 'm' ),
		'heliar'  => array( 'nome' => 'Heliar', 'tabela' => 'HELIAR', 'chave' => 'h' ),
		'zetta'   => array( 'nome' => 'Zetta', 'tabela' => 'ZETTA', 'chave' => 'z' ),
		'excell'  => array( 'nome' => 'Excell', 'tabela' => 'EXCELL', 'chave' => 'e' ),
		'eletran' => array( 'nome' => 'Eletran', 'tabela' => 'ELETRA', 'chave' => 'el' ),
	) );
}

/** marca => ah => array( sku => linha da tabela ), ordenado. */
function awr_marca_amp_lista() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$out    = array();
	$marcas = awr_marca_amp_marcas();
	foreach ( awr_tabela_baterias() as $sku => $t ) {
		$w = strtoupper( strtok( (string) $t['modelo'], ' ' ) );
		foreach ( $marcas as $slug => $m ) {
			if ( $w === $m['tabela'] && (int) $t['ah'] > 0 ) {
				// O nome do modelo manda quando contradiz o campo ah
				// (ex.: "HELIAR EFB72PD" cadastrado com ah 60).
				$ah = (int) $t['ah'];
				if ( preg_match( '/(?<!\d)(\d{2,3})(?!\d)/', substr( (string) $t['modelo'], strlen( $w ) ), $mm ) && (int) $mm[1] >= 20 && (int) $mm[1] <= 260 ) {
					$ah = (int) $mm[1];
				}
				$out[ $slug ][ $ah ][ $sku ] = $t;
			}
		}
	}
	foreach ( $out as &$a ) { ksort( $a ); }
	return $out;
}

/** Modelos (sku => linha) de uma marca numa amperagem; vazio se não houver. */
function awr_marca_amp_skus( $marca, $ah ) {
	$l = awr_marca_amp_lista();
	return $l[ $marca ][ (int) $ah ] ?? array();
}

function awr_marca_amp_url( $marca, $ah ) {
	return home_url( '/marca/' . $marca . '/' . (int) $ah . 'ah/' );
}

/**
 * Veículos que usam um destes códigos da marca (batteries.json).
 * Uma linha por modelo: marca, modelo, de, ate, url.
 */
function awr_marca_amp_veiculos( $marca, $skus, $lim = 40 ) {
	$chave = awr_marca_amp_marcas()[ $marca ]['chave'] ?? '';
	if ( ! $chave ) { return array(); }
	$set = array_flip( array_map( 'strtoupper', array_keys( $skus ) ) );
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		$c = strtoupper( trim( (string) ( $it[ $chave ] ?? '' ) ) );
		if ( '' === $c || ! isset( $set[ $c ] ) ) { continue; }
		$k = $it['ma'] . '|' . $it['mo'];
		if ( isset( $out[ $k ] ) ) {
			$out[ $k ]['de']  = min( $out[ $k ]['de'], (int) $it['d'] );
			$out[ $k ]['ate'] = max( $out[ $k ]['ate'], (int) $it['a'] );
			continue;
		}
		$out[ $k ] = array( 'marca' => $it['ma'], 'modelo' => $it['mo'], 'de' => (int) $it['d'], 'ate' => (int) $it['a'], 'url' => awr_vehicle_url( $it['ma'], $it['mo'] ) );
	}
	$teto = (int) gmdate( 'Y' ) + 1;
	foreach ( $out as &$v ) { $v['ate'] = min( $v['ate'], $teto ); }
	unset( $v );
	// Mais recentes primeiro: são os que mais procuram bateria hoje.
	uasort( $out, function ( $x, $y ) { return $y['ate'] <=> $x['ate'] ?: strcmp( $x['marca'] . $x['modelo'], $y['marca'] . $y['modelo'] ); } );
	return array_slice( array_values( $out ), 0, $lim );
}

/** Outras marcas na mesma amperagem (para comparação): marca => menor preço à vista. */
function awr_marca_amp_comparativo( $ah ) {
	$out = array();
	foreach ( awr_marca_amp_lista() as $marca => $porah ) {
		if ( empty( $porah[ (int) $ah ] ) ) { continue; }
		$out[ $marca ] = min( array_column( $porah[ (int) $ah ], 'vista' ) );
	}
	asort( $out );
	return $out;
}
