<?php
/**
 * v5.11.0 — corta scripts de medição de plugins fora da loja/checkout.
 * O tema já envia GA4, Google Ads e GTM; as cópias do Jetpack/Site Kit/Woo
 * Analytics só disputavam a linha de execução do celular (tarefas longas).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function awr_perf_plugin_handles() {
	return apply_filters( 'awr_perf_plugin_handles', array(
		// 5.55.0: 'jetpack-stats' saiu da lista — volta a contar, com carregamento adiado (abaixo).
		'woocommerce-analytics-client', 'woocommerce-analytics', 'wc-analytics',
		'googlesitekit-events-provider-content-events', 'googlesitekit-events-provider-woocommerce',
		'googlesitekit-consent-mode',
	) );
}

function awr_perf_light_screen() {
	if ( is_admin() ) { return false; }
	return function_exists( 'awr_screen_needs_woo' ) ? ! awr_screen_needs_woo() : true;
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! awr_perf_light_screen() ) { return; }
	foreach ( awr_perf_plugin_handles() as $h ) {
		wp_dequeue_script( $h );
		wp_deregister_script( $h );
	}
}, 9999 );

add_action( 'wp_print_footer_scripts', function () {
	if ( ! awr_perf_light_screen() ) { return; }
	foreach ( awr_perf_plugin_handles() as $h ) { wp_dequeue_script( $h ); }
}, 1 );

/**
 * 5.55.0 — Jetpack Stats com carregamento adiado.
 *
 * Desde a 5.11.0 o script era removido fora da loja e o painel do Jetpack
 * ficava sem as visitas. Agora o bloco inline do Jetpack (_stq.push "view")
 * continua igual e só o arquivo externo (stats.wp.com/e-AAAASS.js) é pedido
 * depois do load, com o navegador ocioso, ou na primeira interação.
 *
 * Vale em todas as telas do site. O adiamento antigo (awr_delayed_script_handles,
 * inc/assets.php) trocava a tag inteira e apagava o bloco inline: nem na loja
 * a visita era registrada.
 *
 * Filtro awr_jetpack_stats_modo: 'adiado' (padrão) | 'normal' | 'desligado'.
 */
function awr_jetpack_stats_modo() {
	$m = (string) apply_filters( 'awr_jetpack_stats_modo', 'adiado' );
	return in_array( $m, array( 'adiado', 'normal', 'desligado' ), true ) ? $m : 'adiado';
}

add_action( 'wp_enqueue_scripts', function () {
	if ( 'desligado' === awr_jetpack_stats_modo() && awr_perf_light_screen() ) {
		wp_dequeue_script( 'jetpack-stats' );
	}
}, 9999 );

/** Troca a tag externa do Jetpack Stats pelo carregador adiado (o inline fica igual). */
function awr_jetpack_stats_tag_adiada( $tag ) {
	return preg_replace_callback(
		'#<script\b[^>]*\bsrc=(["\'])(https?://stats\.wp\.com/[^"\']+)\1[^>]*>\s*</script>#i',
		function ( $m ) {
			$src = esc_url( $m[2] );
			return '<script id="awr-jetpack-stats-loader">(function(){var d=0,s=' . wp_json_encode( $src ) . ';'
				. 'function go(){if(d)return;d=1;var e=document.createElement("script");e.src=s;e.defer=true;e.id="jetpack-stats-js";document.head.appendChild(e);'
				. '["touchstart","pointerdown","scroll","keydown"].forEach(function(t){removeEventListener(t,go,{passive:true})})}'
				. '["touchstart","pointerdown","scroll","keydown"].forEach(function(t){addEventListener(t,go,{once:true,passive:true})});'
				. 'function idle(){("requestIdleCallback" in window)?requestIdleCallback(go,{timeout:1500}):setTimeout(go,1200)}'
				. 'if(document.readyState==="complete")idle();else addEventListener("load",idle,{once:true})})();</script>';
		},
		$tag,
		1
	);
}

add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( is_admin() || 'jetpack-stats' !== $handle || 'adiado' !== awr_jetpack_stats_modo() ) { return $tag; }
	return awr_jetpack_stats_tag_adiada( $tag );
}, 20, 2 );

/* Troca woocommerce-no-js → woocommerce-js reescreve a classe do <body> e
   invalida todo o layout no carregamento (reflow forçado). Fora da loja não
   há nada que dependa dessa classe. */
add_action( 'wp', function () {
	if ( awr_perf_light_screen() ) {
		remove_action( 'wp_footer', 'wc_no_js' );
	}
} );

/* Bloco inline do WooCommerce Analytics (window.wcAnalytics) fora da loja. */
add_action( 'template_redirect', function () {
	if ( ! awr_perf_light_screen() ) { return; }
	ob_start( function ( $html ) {
		return preg_replace( '#<script type="text/javascript">\s*\(function\(\) \{\s*window\.wcAnalytics.*?</script>\s*#s', '', $html, 1 );
	} );
}, 99 );
