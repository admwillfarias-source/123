<?php
/**
 * 5.57.0 — Página de produto que vende: dados auxiliares de routes/produto.php.
 *
 * Tudo vem do WooCommerce e da tabela oficial (inc/tabela-baterias.php,
 * inc/garantia.php, inc/merchant-gtin.php). Nada é inventado: sem avaliação,
 * sem estrelas; sem foto extra, sem galeria.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Bateria de moto? (Motobatt e códigos de moto das outras marcas.) */
function awr_produto_eh_moto( $sku ) {
	$sku = strtoupper( trim( (string) $sku ) );
	if ( function_exists( 'awr_sku_is_motobatt' ) && awr_sku_is_motobatt( $sku ) ) { return true; }
	return (bool) preg_match( '/^(HTZ|HTX|HT12A|MTX|MTZ|MBTX|MBTZ|YTX|YTZ|YB)/', $sku );
}

/** Linha abaixo do H1: tecnologia · Ah · CCA · para motos/carros. */
function awr_produto_subtitulo( $sku, $nome, $ah, $moto ) {
	$p   = array();
	$tec = function_exists( 'awr_bateria_tecnologia' ) ? (string) awr_bateria_tecnologia( $sku, $nome ) : '';
	if ( $tec && 'Convencional' !== $tec ) { $p[] = $tec; }
	$p[] = '12V';
	if ( $ah ) { $p[] = $ah . 'Ah'; }
	$e = function_exists( 'awr_espec_bateria' ) ? awr_espec_bateria( $sku, $nome ) : null;
	if ( $e && ! empty( $e['cca'] ) ) { $p[] = (int) $e['cca'] . ' A de partida'; }
	return implode( ' · ', $p ) . ' — para ' . ( $moto ? 'motos' : 'carros' );
}

/** Situação do estoque no WooCommerce: array( classe, texto ). */
function awr_produto_estoque( $wc ) {
	$st = $wc && method_exists( $wc, 'get_stock_status' ) ? (string) $wc->get_stock_status() : 'instock';
	if ( 'outofstock' === $st ) { return array( 'off', 'Consulte a disponibilidade' ); }
	if ( 'onbackorder' === $st ) { return array( 'enc', 'Sob encomenda' ); }
	return array( 'in', 'Em estoque · pronta para entrega' );
}

/**
 * Fotos do produto: imagem principal + galeria do WooCommerce.
 *
 * @return array lista de array( grande, mini, alt, w, h )
 */
function awr_produto_galeria( $wc, $p ) {
	$out = array();
	$ids = array();
	if ( $wc && method_exists( $wc, 'get_image_id' ) && $wc->get_image_id() ) { $ids[] = (int) $wc->get_image_id(); }
	if ( $wc && method_exists( $wc, 'get_gallery_image_ids' ) ) { $ids = array_merge( $ids, array_map( 'intval', (array) $wc->get_gallery_image_ids() ) ); }
	foreach ( array_unique( array_filter( $ids ) ) as $id ) {
		$g = wp_get_attachment_image_src( $id, 'large' );
		$m = wp_get_attachment_image_src( $id, 'thumbnail' );
		if ( ! $g ) { continue; }
		$alt = trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) );
		$out[] = array( $g[0], $m ? $m[0] : $g[0], $alt ? $alt : (string) ( $p['name'] ?? '' ), (int) $g[1], (int) $g[2] );
	}
	if ( ! $out && ! empty( $p['image'] ) ) {
		$out[] = array( $p['image'], $p['image'], (string) ( $p['name'] ?? '' ), 600, 600 );
	}
	return $out;
}

/** Compatibilidade compacta para o seletor: { marca: [[modelo, de, ate], …] }. */
function awr_produto_compat_json( $grupos ) {
	$out = array();
	foreach ( (array) $grupos as $marca => $modelos ) {
		foreach ( $modelos as $m ) {
			$out[ function_exists( 'awr_nome_veiculo' ) ? awr_nome_veiculo( $marca ) : $marca ][] = array( function_exists( 'awr_nome_veiculo' ) ? awr_nome_veiculo( $m['modelo'] ) : $m['modelo'], (int) $m['de'], (int) $m['ate'] );
		}
	}
	return $out;
}

/** Avaliações aprovadas do WooCommerce (somente reais). */
function awr_produto_avaliacoes( $wc, $max = 10 ) {
	if ( ! $wc || ! function_exists( 'get_comments' ) ) { return array(); }
	$out = array();
	foreach ( (array) get_comments( array( 'post_id' => $wc->get_id(), 'status' => 'approve', 'type' => 'review', 'number' => $max ) ) as $c ) {
		$out[] = array(
			'nome'  => (string) $c->comment_author,
			'nota'  => (int) get_comment_meta( $c->comment_ID, 'rating', true ),
			'texto' => (string) $c->comment_content,
			'data'  => mysql2date( 'd/m/Y', $c->comment_date ),
		);
	}
	return $out;
}

/** Ícones dos benefícios (SVG inline, sem emoji). */
function awr_produto_icone( $nome ) {
	$p = array(
		'entrega'  => '<path d="M3 7h11v9H3z"/><path d="M14 10h4l3 3v3h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
		'garantia' => '<path d="M12 3 5 6v5c0 4.5 3 8.4 7 10 4-1.6 7-5.5 7-10V6z"/><path d="m9 12 2 2 4-4"/>',
		'aplica'   => '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/>',
		'troca'    => '<path d="M4 9h13l-3-3"/><path d="M20 15H7l3 3"/>',
		'seguro'   => '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
		'atende'   => '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/>',
		'oficial'  => '<circle cx="12" cy="9" r="6"/><path d="m8.5 14.5-1.5 7 5-3 5 3-1.5-7"/>',
		'moto'     => '<circle cx="5.5" cy="16.5" r="3.5"/><circle cx="18.5" cy="16.5" r="3.5"/><path d="M5.5 16.5 9 9h4l2 4h-6M15 13l3.5 3.5M13 9l1-3h3"/>',
		'carro'    => '<path d="M5 16V11l2-5h10l2 5v5"/><path d="M3 16h18v3H3z"/><circle cx="7.5" cy="16" r="1"/><circle cx="16.5" cy="16" r="1"/>',
	);
	return '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( $p[ $nome ] ?? '' ) . '</svg>';
}

/** CSS e JS só na página de produto (depois do awr-final, para vencer o legado). */
add_action( 'wp_enqueue_scripts', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
	wp_enqueue_style( 'awr-produto', AWR_URI . '/assets/css/awr-produto.css', array( 'awr-final' ), awr_asset_ver( 'assets/css/awr-produto.css' ) );
	wp_enqueue_script( 'awr-produto', AWR_URI . '/assets/js/awr-produto.js', array( 'awr-core' ), awr_asset_ver( 'assets/js/awr-produto.js' ), true );
	wp_script_add_data( 'awr-produto', 'defer', true );
}, 1000 );
