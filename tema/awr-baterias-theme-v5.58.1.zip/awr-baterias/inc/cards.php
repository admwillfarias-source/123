<?php
/**
 * 5.54.0 — Modelos de card de bateria (Configurações → AWR Busca).
 *
 *  app          A — igual ao app (BatterySearch.tsx), na ordem do catálogo.
 *  destaque     B — com preço primeiro; a 1ª ganha a fita "Recomendada".
 *  comparativo  C — Econômica / Recomendada / Premium (até 3 com preço) e
 *               "Ver todas as compatíveis" para o resto.
 *
 * A mesma regra roda no navegador (awrCards em assets/js/awr-search.js).
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Modelos disponíveis: slug => rótulo. */
function awr_card_modelos() {
	return array(
		'app'         => 'A — Igual ao app (padrão)',
		'destaque'    => 'B — Recomendada em destaque',
		'comparativo' => 'C — Econômica / Recomendada / Premium',
	);
}

/** Modelo ativo (opção awr_card_modelo; ?awr_card=… só para administrador). */
function awr_card_modelo() {
	$m = (string) get_option( 'awr_card_modelo', 'app' );
	if ( isset( $_GET['awr_card'] ) && function_exists( 'current_user_can' ) && current_user_can( 'manage_options' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$m = sanitize_key( wp_unslash( $_GET['awr_card'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	}
	$m = (string) apply_filters( 'awr_card_modelo', $m );
	return isset( awr_card_modelos()[ $m ] ) ? $m : 'app';
}

/**
 * Ordena e marca os produtos conforme o modelo.
 *
 * @return array( 'visiveis' => array, 'mais' => array, 'modelo' => string )
 */
function awr_cards_preparar( $produtos, $veiculo = '', $modelo = null ) {
	$modelo   = $modelo ? $modelo : awr_card_modelo();
	$produtos = array_values( (array) $produtos );
	$com      = array_values( array_filter( $produtos, function ( $p ) { return (float) ( $p['price'] ?? 0 ) > 0; } ) );
	$sem      = array_values( array_filter( $produtos, function ( $p ) { return (float) ( $p['price'] ?? 0 ) <= 0; } ) );

	if ( 'destaque' === $modelo && $com ) {
		$com[0]['destaque'] = $veiculo ? 'Recomendada para o seu ' . $veiculo : 'Recomendada pela AWR';
		$com[0]['rec']      = true;
		return array( 'visiveis' => array_merge( $com, $sem ), 'mais' => array(), 'modelo' => $modelo );
	}

	if ( 'comparativo' === $modelo && $com ) {
		usort( $com, function ( $a, $b ) { return (float) $a['price'] <=> (float) $b['price']; } );
		$gar  = function ( $p ) { return (int) preg_replace( '/\D/', '', (string) ( $p['garantia'] ?? '' ) ); };
		$n    = count( $com );
		$tier = array();
		if ( 1 === $n ) {
			$tier = array( 0 => 'rec' );
		} elseif ( 2 === $n ) {
			$tier = array( 0 => 'eco', 1 => 'rec' );
		} else {
			// Econômica: a mais barata. Premium: a mais cara. Recomendada: a de maior
			// garantia entre as do meio (empate: a mais barata delas).
			$prem = $n - 1;
			$rec  = 1;
			$best = -1;
			for ( $i = 1; $i < $n; $i++ ) {
				if ( $i === $prem ) { continue; }
				if ( $gar( $com[ $i ] ) > $best ) { $best = $gar( $com[ $i ] ); $rec = $i; }
			}
			$tier = array( 0 => 'eco', $rec => 'rec', $prem => 'prem' );
		}
		$rot  = array( 'eco' => 'Econômica', 'rec' => 'Recomendada', 'prem' => 'Premium' );
		$para = array(
			'eco'  => 'Menor preço para quem roda pouco',
			'rec'  => 'Melhor custo-benefício para o dia a dia',
			'prem' => 'Mais durabilidade, partida forte e garantia maior',
		);
		$vis = array();
		$mais = array();
		foreach ( array( 'eco', 'rec', 'prem' ) as $t ) {
			$i = array_search( $t, $tier, true );
			if ( false === $i ) { continue; }
			$p             = $com[ $i ];
			$p['tier']     = $t;
			$p['destaque'] = $rot[ $t ];
			$p['para']     = $para[ $t ];
			$p['rec']      = 'rec' === $t;
			$vis[]         = $p;
		}
		foreach ( $com as $i => $p ) { if ( ! isset( $tier[ $i ] ) ) { $mais[] = $p; } }
		return array( 'visiveis' => $vis, 'mais' => array_merge( $mais, $sem ), 'modelo' => $modelo );
	}

	return array( 'visiveis' => $produtos, 'mais' => array(), 'modelo' => 'app' );
}

/** Menor preço à vista entre os produtos (0 se nenhum tiver preço). */
function awr_cards_menor_preco( $produtos ) {
	$min = 0;
	foreach ( (array) $produtos as $p ) {
		$v = (float) ( $p['price'] ?? 0 );
		if ( $v > 0 && ( ! $min || $v < $min ) ) { $min = $v; }
	}
	return $min;
}
