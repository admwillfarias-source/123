<?php
/**
 * 5.59.0 — Bloqueio opcional de robôs no .htaccess (antes do PHP rodar).
 *
 * O robots.txt já pede a esses robôs para não rastrear o site, mas alguns
 * ignoram. Cada visita deles carrega WordPress + WooCommerce (60–120 MB) e
 * conta no limite de memória da conta na hospedagem. Este bloco responde 403
 * direto pelo Apache, sem PHP. Desligado de fábrica: liga e desliga pelo
 * painel (Configurações → AWR Busca). Google, Bing, Apple e as buscas de IA
 * nunca entram na lista.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

const AWR_ROBOS_MARCA = 'AWR Robos';

function awr_robos_htaccess_arq() {
	return ( function_exists( 'get_home_path' ) ? get_home_path() : ABSPATH ) . '.htaccess';
}

function awr_robos_bloco() {
	$bots = array_map( function ( $b ) { return preg_quote( $b, '/' ); }, awr_robos_bloqueados() );
	return array(
		'<IfModule mod_rewrite.c>',
		'RewriteEngine On',
		'RewriteCond %{HTTP_USER_AGENT} (' . implode( '|', $bots ) . ') [NC]',
		'RewriteRule .* - [F,L]',
		'</IfModule>',
	);
}

/** O bloco está no .htaccess? */
function awr_robos_ativo() {
	$arq = awr_robos_htaccess_arq();
	return is_readable( $arq ) && false !== strpos( (string) file_get_contents( $arq ), '# BEGIN ' . AWR_ROBOS_MARCA ); // phpcs:ignore WordPress.WP.AlternativeFunctions
}

/**
 * Liga/desliga. O bloco vai para o INÍCIO do arquivo (antes das regras do
 * WordPress, senão o Apache nunca chega nele). Guarda cópia em .htaccess-awr-backup.
 *
 * @return true|string Mensagem de erro.
 */
function awr_robos_aplicar( $ligar ) {
	$arq = awr_robos_htaccess_arq();
	$txt = file_exists( $arq ) ? (string) file_get_contents( $arq ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( ( file_exists( $arq ) && ! is_writable( $arq ) ) || ( ! file_exists( $arq ) && ! is_writable( dirname( $arq ) ) ) ) {
		return 'O arquivo .htaccess não tem permissão de escrita.';
	}
	$limpo = preg_replace( '/# BEGIN ' . preg_quote( AWR_ROBOS_MARCA, '/' ) . '.*?# END ' . preg_quote( AWR_ROBOS_MARCA, '/' ) . "\\R*/s", '', $txt );
	$novo  = $ligar ? '# BEGIN ' . AWR_ROBOS_MARCA . "\n" . implode( "\n", awr_robos_bloco() ) . "\n# END " . AWR_ROBOS_MARCA . "\n\n" . $limpo : $limpo;
	if ( $novo === $txt ) { return true; }
	if ( '' !== $txt ) { @file_put_contents( $arq . '-awr-backup', $txt ); } // phpcs:ignore
	return false !== file_put_contents( $arq, $novo ) ? true : 'Falha ao gravar o .htaccess.'; // phpcs:ignore WordPress.WP.AlternativeFunctions
}

add_action( 'admin_init', function () {
	if ( ! isset( $_GET['awr_robos'] ) || ! current_user_can( 'manage_options' ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification
	check_admin_referer( 'awr_robos' );
	if ( ! function_exists( 'get_home_path' ) ) { require_once ABSPATH . 'wp-admin/includes/file.php'; }
	$r = awr_robos_aplicar( '1' === $_GET['awr_robos'] ); // phpcs:ignore WordPress.Security.NonceVerification
	set_transient( 'awr_robos_msg', true === $r ? 'ok' : $r, 5 * MINUTE_IN_SECONDS );
	wp_safe_redirect( admin_url( 'options-general.php?page=awr-busca-admin' ) );
	exit;
} );

function awr_robos_painel_html() {
	if ( ! current_user_can( 'manage_options' ) ) { return ''; }
	if ( ! function_exists( 'get_home_path' ) ) { require_once ABSPATH . 'wp-admin/includes/file.php'; }
	$on  = awr_robos_ativo();
	$msg = get_transient( 'awr_robos_msg' );
	$h   = '<h2>Robôs que não trazem vendas</h2>';
	if ( $msg ) {
		delete_transient( 'awr_robos_msg' );
		$h .= '<div class="notice ' . ( 'ok' === $msg ? 'notice-success' : 'notice-error' ) . ' inline"><p>' . esc_html( 'ok' === $msg ? 'Pronto.' : $msg ) . '</p></div>';
	}
	$h .= '<p>O robots.txt já pede para estes robôs não rastrearem o site: <code>' . esc_html( implode( ', ', awr_robos_bloqueados() ) ) . '</code>. Google, Bing, Apple e as buscas de IA continuam liberados.</p>';
	$h .= '<p>Para os que ignoram o robots.txt, o bloqueio pode ir também no .htaccess (resposta 403 sem carregar o WordPress). Situação: <strong>' . ( $on ? 'ligado' : 'desligado' ) . '</strong>.</p>';
	$url = wp_nonce_url( admin_url( 'options-general.php?page=awr-busca-admin&awr_robos=' . ( $on ? '0' : '1' ) ), 'awr_robos' );
	return $h . '<p><a class="button" href="' . esc_url( $url ) . '">' . ( $on ? 'Desligar bloqueio no .htaccess' : 'Ligar bloqueio no .htaccess' ) . '</a> <span class="description">Uma cópia do arquivo fica em .htaccess-awr-backup.</span></p>';
}
