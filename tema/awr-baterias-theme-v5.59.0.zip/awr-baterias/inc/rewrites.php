<?php
/**
 * Rotas virtuais (mesmas URLs do app TanStack).
 *
 * /buscar/                       → resultados de busca
 * /baterias-em/{cidade}/         → LP de cidade
 * /bateria/{sku}/                → página de SKU
 * /baterias/amperagem/{ah}/      → listagem por amperagem
 * /bateria-para/{aplicacao}/     → LP de aplicação
 * /marca/{marca}/                → LP de marca
 * /bateria/{marca}/{cidade}/     → marca + cidade
 * /lojas/ e /lojas/{slug}/       → lojas
 * /blog/ e /blog/{slug}/         → conteúdo
 * /widget-busca/                 → widget isolado para iframe
 * /pedido-confirmado/            → confirmação de pedido (GTM)
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

function awr_routes() {
	return array(
		'search_api'        => '^awr-busca/?$',
		'buscar'            => '^buscar/?$',
		'baterias_de_carro' => '^baterias-de-carro/?$',
		'cidade'            => '^baterias-em/([^/]+)/?$',
		'amperagem'         => '^baterias/amperagem/([0-9]+)/?$',
		'marca_cidade'      => '^bateria/([^/]+)/([^/]+)/?$',
		'sku'               => '^bateria/([^/]+)/?$',
		'aplicacao'         => '^bateria-para/([^/]+)/?$',
		'veiculo_cidade'    => '^baterias-para/([^/]+)/([^/]+)/?$',
		'veiculo_modelo'    => '^baterias-para/([^/]+)/?$',
		'b2b'               => '^solucoes-b2b/?$',
		'ramo'              => '^aplicacoes/([^/]+)/?$',
		'hub_ramos'         => '^aplicacoes/?$',
		'bairro'            => '^baterias-bairro/([^/]+)/([^/]+)/?$',
		'hub_bairros'       => '^baterias-bairro/([^/]+)/?$',
		'zona_poa'          => '^baterias-porto-alegre/([^/]+)/?$',

		'categoria'         => '^categorias/([^/]+)/?$',
		'hub_categorias'    => '^categorias/?$',

		'shop_cat_page'     => '^loja/c/([^/]+)/page/([0-9]+)/?$',
		'shop_cat'          => '^loja/c/([^/]+)/?$',
		'shop_page'         => '^loja/page/([0-9]+)/?$',
		'shop'              => '^loja/?$',

		'marca_amp'         => '^marca/([^/]+)/([0-9]{2,3})ah/?$',
		'marca'             => '^marca/([^/]+)/?$',
		'loja'              => '^lojas/([^/]+)/?$',
		'lojas'             => '^lojas/?$',
		'post'              => '^blog/([^/]+)/?$',
		'blog'              => '^blog/?$',
		'widget'            => '^widget-busca/?$',
		'pedido'            => '^pedido-confirmado/?$',
		'parceiros'         => '^parceiros/?$',
		'comparar'          => '^comparar/?$',
		'garantia'          => '^garantia/?$',
		'rastrear_pedido'   => '^rastrear-pedido/?$',
		'central_tecnica'   => '^central-tecnica/?$',

		// Páginas de serviço/urgência com URL própria (espelham o app).
		'domicilio'         => '^bateria-a-domicilio-porto-alegre/?$',
		'perto_de_mim'      => '^bateria-perto-de-mim/?$',
		'eletricos'         => '^baterias-carros-eletricos-e-hibridos/?$',
		'previa_cards'      => '^awr-previa-cards/?$',
		'grande_poa'        => '^baterias-grande-porto-alegre/?$',
		'transportadora'    => '^entrega-por-transportadora/?$',
		'socorro'           => '^socorro-bateria/?$',
		'lp'                => '^lp/([^/]+)/?$',
		// Hub de amperagem precisa vir ANTES do legado /baterias/{slug}/,
		// senão "amperagem" é tratado como cidade e cai em 301 → 404.
		'hub_amperagens'    => '^baterias/amperagem/?$',
		'cidade_legacy'     => '^baterias/([^/]+)/?$',

		// LP de marca de moto — declarada ANTES dos segmentos: o primeiro
		// regex que casa vence, e /baterias-para-moto/marca/{x}/ também casa
		// com segmento_bairro (marca como "cidade", {x} como "bairro").
		'moto_marca'        => '^baterias-para-moto/marca/([^/]+)/?$',
		'moto_marcas'       => '^baterias-para-moto/marca/?$',

		// 5.46.0 — Estacionárias por aplicação e por amperagem (antes de segmento_cidade,
		// que trataria o slug como cidade e responderia 404).
		'estac_sub'         => '^(baterias-estacionarias)/(nobreak-e-ups|alarme-e-seguranca|energia-solar|condominios-e-empresas|[0-9]{2,3}ah)/?$',

		// Categorias/segmentos (espelham o app): estacionária, caminhão e moto.
		'segmento_bairro'   => '^(baterias-estacionarias|bateria-estacionaria|baterias-para-caminhao|baterias-para-moto)/([^/]+)/([^/]+)/?$',
		'segmento_cidade'   => '^(baterias-estacionarias|bateria-estacionaria|baterias-para-caminhao|baterias-para-moto)/([^/]+)/?$',
		'segmento'          => '^(baterias-estacionarias|bateria-estacionaria(?:-rs)?|baterias-para-caminhao|baterias-para-moto)/?$',


		// LPs de SEO com URL própria (aliases de /lp/{slug}/).
		'lp_alias'          => '^(baterias-gravatai|bateria-24h-porto-alegre)/?$',

		// Caminhos de SEO da busca por veículo.
		// O primeiro segmento não pode ser "amperagem" nem "page" — essas rotas
		// são reservadas ao hub de amperagem e à paginação do hub de SKUs.
		'veiculo_ano'       => '^baterias/(?!amperagem/|page/)([^/]+)/([^/]+)/((?:19|20)[0-9]{2})/?$',
		'veiculo'           => '^baterias/(?!amperagem/|page/)([^/]+)/([^/]+)/?$',


		// Hubs de indexação — declarados por último para terem prioridade (add_rewrite_rule 'top').
		'hub_cidades'       => '^baterias-em/?$',
		'hub_veiculos'      => '^baterias-para/?$',
		'hub_marcas'        => '^marca/?$',
		'hub_aplicacoes'    => '^bateria-para/?$',
		'hub_skus'          => '^baterias/?$',
		'hub_skus_page'     => '^baterias/page/([0-9]+)/?$',
		'bateria_hub'       => '^bateria/?$',
	);
}


add_action( 'init', function () {
	add_rewrite_tag( '%awr_route%', '([^&]+)' );
	add_rewrite_tag( '%awr_a%', '([^&]+)' );
	add_rewrite_tag( '%awr_b%', '([^&]+)' );
	add_rewrite_tag( '%awr_c%', '([^&]+)' );

	foreach ( awr_routes() as $name => $regex ) {
		$target = 'index.php?awr_route=' . $name;
		// Conta apenas grupos de captura reais (ignora "(?:", "(?!", "(?=").
		$n      = preg_match_all( '/\((?!\?)/', $regex );

		if ( $n >= 1 ) { $target .= '&awr_a=$matches[1]'; }
		if ( $n >= 2 ) { $target .= '&awr_b=$matches[2]'; }
		if ( $n >= 3 ) { $target .= '&awr_c=$matches[3]'; }
		add_rewrite_rule( $regex, $target, 'top' );
	}
} );

add_filter( 'query_vars', function ( $vars ) {
	$vars[] = 'awr_route';
	$vars[] = 'awr_a';
	$vars[] = 'awr_b';
	$vars[] = 'awr_c';
	$vars[] = 'veiculo';
	$vars[] = 'ano';
	$vars[] = 'q';
	$vars[] = 'pedido';
	$vars[] = 'embed';
	return $vars;
} );

/**
 * Versão do cache do tema — usada nas chaves de transient (sitemaps etc.).
 * Trocar a versão do tema invalida o cache sem apagar nada no banco.
 */
function awr_cache_ver() {
	// 5.58.2 — sem AWR_VERSION: trocar de versão não invalida mais sitemaps e
	// listas da loja de uma vez. Muda quando o catálogo ou a indexação mudam.
	$cat = AWR_DIR . '/assets/data-php/batteries.php';
	return substr( md5( ( file_exists( $cat ) ? filemtime( $cat ) . filesize( $cat ) : '0' ) . '|' . get_option( 'awr_idx_modo', 'envio' ) . '|' . get_option( 'awr_idx_cobertura_top', 400 ) ), 0, 8 );
}

/**
 * Flush das rotas apenas em contexto administrativo/WP-CLI.
 * Nunca durante uma visita comum — gravar rewrite_rules é caro.
 */
add_action( 'admin_init', function () {
	if ( get_option( 'awr_rewrite_version' ) === AWR_VERSION ) { return; }
	flush_rewrite_rules( false );
	update_option( 'awr_rewrite_version', AWR_VERSION, false );
}, 99 );


function awr_current_route() {
	$r = get_query_var( 'awr_route' );
	if ( $r ) { return sanitize_key( $r ); }

	// Fallback resiliente: reconhece as rotas pelo REQUEST_URI mesmo quando
	// cache/plugin reteve regras antigas após a atualização do tema.
	$path = trim( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' );
	$home_path = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $home_path && 0 === strpos( $path, $home_path . '/' ) ) {
		$path = substr( $path, strlen( $home_path ) + 1 );
	}
	foreach ( awr_routes() as $name => $regex ) {
		if ( preg_match( '#^' . trim( $regex, '^$' ) . '$#', $path, $m ) ) {
			$GLOBALS['awr_route_fallback'] = array( 'route' => $name, 'a' => $m[1] ?? '', 'b' => $m[2] ?? '', 'c' => $m[3] ?? '' );
			return sanitize_key( $name );
		}
	}
	return '';
}
function awr_param_a() {
	$v = get_query_var( 'awr_a' );
	if ( ! $v && ! empty( $GLOBALS['awr_route_fallback']['a'] ) ) { $v = $GLOBALS['awr_route_fallback']['a']; }
	if ( in_array( $v, array( 'bateria-estacionaria', 'bateria-estacionaria-rs' ), true ) ) { return 'baterias-estacionarias'; }
	return sanitize_title( $v );
}
function awr_param_b() {
	$v = get_query_var( 'awr_b' );
	if ( ! $v && ! empty( $GLOBALS['awr_route_fallback']['b'] ) ) { $v = $GLOBALS['awr_route_fallback']['b']; }
	return sanitize_title( $v );
}

function awr_param_c() {
	$v = get_query_var( 'awr_c' );
	if ( ! $v && ! empty( $GLOBALS['awr_route_fallback']['c'] ) ) { $v = $GLOBALS['awr_route_fallback']['c']; }
	return sanitize_title( $v );
}

/** Confirma que os parâmetros de uma rota virtual apontam para conteúdo real. */
function awr_virtual_route_valid( $route ) {
	$a = awr_param_a();
	$b = awr_param_b();

	switch ( $route ) {
		case 'cidade':
			return (bool) ( awr_cidade_by_slug( $a ) || awr_cidade_venda_by_slug( $a ) );
		case 'bairro':
			return (bool) ( awr_cidade_by_slug( $a ) && awr_bairro_by_slug( $a, $b ) );
		case 'hub_bairros':
			return (bool) awr_cidade_by_slug( $a );
		case 'marca':
			return (bool) awr_marca_by_slug( $a );
		case 'marca_cidade':
			$mc = awr_marca_by_slug( $a );
			if ( ! $mc || empty( $mc['cidadePages'] ) ) { return false; }
			if ( awr_cidade_by_slug( $b ) ) { return true; }
			// Cidades estratégicas fora da cobertura própria (atendidas por envio).
			return in_array( $b, awr_marca_cidades_envio(), true ) && (bool) awr_cidade_venda_by_slug( $b );

		case 'loja':
			return (bool) awr_store_by_slug( $a );
		case 'post':
			return (bool) awr_post_by_slug( $a );
		case 'aplicacao':
			return (bool) awr_aplicacao_by_slug( $a );
		case 'veiculo_modelo':
			return (bool) awr_vc_model( $a );
		case 'veiculo_cidade':
			return (bool) ( awr_vc_model( $a ) && awr_vc_cidade( $b ) );
		case 'ramo':
			return (bool) awr_ramo_by_slug( $a );
		case 'categoria':
			return (bool) awr_categoria_seo_by_slug( $a );
		case 'shop_cat':
		case 'shop_cat_page':
			return (bool) awr_shop_categoria_by_slug( $a );
		case 'estac_sub':
			return function_exists( 'awr_est_pagina' ) && (bool) awr_est_pagina( $b );
		case 'segmento':
			return (bool) awr_segmento_by_base( $a );
		case 'moto_marca':
			return (bool) awr_moto_brand( $a );
		case 'segmento_cidade':
			$sg = awr_segmento_by_base( $a );
			return (bool) ( $sg && awr_segmento_cidade_by_slug( $b, $sg ) );
		case 'segmento_bairro':
			$sg = awr_segmento_by_base( $a );
			if ( ! $sg || ! awr_segmento_cidade_by_slug( $b, $sg ) ) { return false; }
			return (bool) awr_bairro_by_slug( $b, awr_param_c() );
		case 'lp':
		case 'lp_alias':
			$lps = awr_lps();
			return isset( $lps[ $a ] );
		case 'marca_amp':
			return (bool) awr_marca_amp_skus( $a, (int) $b );
		case 'veiculo':
		case 'veiculo_ano':
			if ( ! awr_is_vehicle_brand( $a ) ) { return false; }
			$modelos = awr_vehicle_models( $a );
			if ( isset( $modelos[ $b ] ) ) { return true; }
			// 5.51.0 — página da família (/baterias/{marca}/{familia}/), sem ano.
			return 'veiculo' === $route && (bool) awr_vehicle_family( $a, $b );
	}

	return true;
}

/** Assume apenas as páginas estacionárias antes de plugins que encerram a resposta. */
add_action( 'template_redirect', function () {
	if ( is_admin() || wp_doing_ajax() || is_feed() || is_robots() || is_customize_preview() ) { return; }
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) { return; }
	if ( isset( $_GET['elementor-preview'] ) || isset( $_GET['preview'] ) ) { return; }
	$path = trim( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' );
	$base = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $base && 0 === strpos( $path, $base . '/' ) ) { $path = substr( $path, strlen( $base ) + 1 ); }
	// Legado com cidade no slug: somente destinos locais realmente existentes.
	if ( preg_match( '#^bateria-estacionaria-(?!rs$)([a-z0-9-]+)$#', $path, $m ) ) {
		$sg = awr_segmento_by_base( 'baterias-estacionarias' );
		if ( ! $sg || ! awr_segmento_cidade_by_slug( $m[1], $sg ) ) { return; }
		wp_safe_redirect( home_url( '/baterias-estacionarias/' . $m[1] . '/' ), 301 );
		exit;
	}
	$route = '';
	foreach ( array( 'estac_sub', 'segmento_bairro', 'segmento_cidade', 'segmento' ) as $name ) {
		$regex = awr_routes()[ $name ];
		if ( ! preg_match( '#' . $regex . '#', $path, $m ) || ! in_array( $m[1], array( 'baterias-estacionarias', 'bateria-estacionaria', 'bateria-estacionaria-rs' ), true ) ) { continue; }
		$route = $name;
		set_query_var( 'awr_route', $name );
		set_query_var( 'awr_a', 'baterias-estacionarias' );
		set_query_var( 'awr_b', $m[2] ?? '' );
		set_query_var( 'awr_c', $m[3] ?? '' );
		break;
	}
	if ( ! $route ) { return; }
	global $wp_query;
	$valid = awr_virtual_route_valid( $route );
	$wp_query->is_404 = ! $valid;
	$wp_query->is_home = false;
	$wp_query->is_page = false;
	$wp_query->is_singular = false;
	status_header( $valid ? 200 : 404 );
	add_filter( 'elementor/theme/need_override_location', '__return_false', 99 );
	add_filter( 'elementor/theme/get_location_templates/template_id', '__return_false', 99 );
	include $valid ? AWR_DIR . '/routes/' . $route . '.php' : AWR_DIR . '/404.php';
	exit;
}, -PHP_INT_MAX );

/** Carrega o template da rota virtual. */
/**
 * 5.52.0 — Destino 301 de uma URL antiga do catálogo de veículos ou de SKU
 * (marcas unificadas, modelos duplicados e códigos corrigidos), ou ''.
 * Mapa gerado no build do catálogo: assets/data/veiculos-redirects.json.
 */
function awr_catalogo_redirect( $route ) {
	static $map = null;
	if ( null === $map ) {
		$f   = AWR_DIR . '/assets/data/veiculos-redirects.json';
		$map = is_readable( $f ) ? (array) json_decode( (string) file_get_contents( $f ), true ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	$a = awr_param_a();
	$b = awr_param_b();
	if ( 'sku' === $route ) {
		return $map['skus'][ '/bateria/' . $a . '/' ] ?? '';
	}
	$v = (array) ( $map['veiculos'] ?? array() );
	if ( 'cidade_legacy' === $route ) {
		return $v[ '/baterias/' . $a . '/' ] ?? '';
	}
	// /baterias-para/{marca-modelo}/(cidade/) de modelo removido ou renomeado.
	if ( 'moto_marca' === $route ) {
		$m = $v[ '/baterias/' . $a . '/' ] ?? '';
		return $m ? '/baterias-para-moto/marca/' . trim( substr( $m, strlen( '/baterias/' ) ), '/' ) . '/' : '';
	}
	if ( 'veiculo_cidade' === $route || 'veiculo_modelo' === $route ) {
		foreach ( $v as $de => $para ) {
			$pd = explode( '/', trim( $de, '/' ) );
			$pp = explode( '/', trim( $para, '/' ) );
			if ( 3 === count( $pd ) && 3 === count( $pp ) && $pd[1] . '-' . $pd[2] === $a && $pd[1] . '-' . $pd[2] !== $pp[1] . '-' . $pp[2] ) {
				return '/baterias-para/' . $pp[1] . '-' . $pp[2] . '/' . ( 'veiculo_cidade' === $route ? $b . '/' : '' );
			}
		}
		return '';
	}
	if ( 'veiculo' === $route || 'veiculo_ano' === $route ) {
		$dest = $v[ '/baterias/' . $a . '/' . $b . '/' ] ?? '';
		if ( $dest && 'veiculo_ano' === $route ) { $dest .= (int) awr_param_c() . '/'; }
		// Família ou modelo de marca unificada sem par exato → página da marca nova.
		if ( ! $dest ) { $dest = $v[ '/baterias/' . $a . '/' ] ?? ''; }
		return $dest;
	}
	return '';
}

add_filter( 'template_include', function ( $template ) {
	$route = awr_current_route();
	if ( ! $route ) { return $template; }

	$awr_invalida = 'sku' === $route
		? ( function_exists( 'awr_sku_existe' ) && function_exists( 'awr_sku_from_slug' ) && ! awr_sku_existe( awr_sku_from_slug( awr_param_a() ) ) )
		: ( in_array( $route, array( 'cidade_legacy', 'veiculo', 'veiculo_ano', 'veiculo_cidade', 'veiculo_modelo', 'moto_marca' ), true ) && ! awr_virtual_route_valid( $route ) );
	if ( $awr_invalida ) {
		$awr_dest = awr_catalogo_redirect( $route );
		if ( $awr_dest ) {
			wp_safe_redirect( home_url( $awr_dest ), 301 );
			exit;
		}
	}

	// /baterias/{slug}: marca de veículo → hub do fabricante; senão, cidade legada (301).
	if ( 'cidade_legacy' === $route ) {
		if ( awr_is_vehicle_brand( awr_param_a() ) ) {
			status_header( 200 );
			global $wp_query;
			$wp_query->is_404 = false;
			return AWR_DIR . '/routes/veiculo.php';
		}
		// 5.52.0 — marca unificada (ex.: /baterias/john/ → /baterias/john-deere/).
		$awr_dest = awr_catalogo_redirect( 'cidade_legacy' );
		wp_safe_redirect( home_url( $awr_dest ? $awr_dest : '/baterias-em/' . awr_param_a() . '/' ), 301 );
		exit;
	}

	// /buscar/?veiculo=&ano= → URL canônica do veículo (evita duplicação).
	if ( 'buscar' === $route ) {
		$v = sanitize_title( (string) get_query_var( 'veiculo' ) );
		$y = (int) get_query_var( 'ano' );
		if ( $v ) {
			$hit = awr_vehicle_by_slug( $v, $y );
			if ( $hit ) {
				wp_safe_redirect( awr_vehicle_url( $hit[0]['ma'], $hit[0]['mo'], $y ), 301 );
				exit;
			}
		}
	}
	// LP antiga de estacionárias → hub da categoria.
	if ( ( 'lp' === $route || 'lp_alias' === $route ) && 'baterias-estacionarias' === awr_param_a() ) {
		wp_safe_redirect( home_url( '/baterias-estacionarias/' ), 301 );
		exit;
	}
	// LP "24h" prometia horário que a AWR não atende → página oficial de socorro.
	if ( ( 'lp' === $route || 'lp_alias' === $route ) && 'bateria-24h-porto-alegre' === awr_param_a() ) {
		wp_safe_redirect( home_url( '/socorro-bateria/' ), 301 );
		exit;
	}

	if ( 'moto_marcas' === $route ) {
		wp_safe_redirect( home_url( '/baterias-para-moto/' ), 301 );
		exit;
	}

	if ( 'bateria_hub' === $route ) {
		wp_safe_redirect( home_url( '/baterias/' ), 301 );
		exit;
	}

	// /baterias/{marca}/{modelo}/{ano}/ sem variantes compatíveis → 301 para o
	// modelo (evita página vazia indexável e concentra a autoridade da URL).
	if ( 'veiculo_ano' === $route ) {
		$vm = awr_param_a();
		$vo = awr_param_b();
		$vy = (int) awr_param_c();
		if ( awr_is_vehicle_brand( $vm ) && ! awr_vehicle_variants( $vm, $vo, $vy ) && awr_vehicle_variants( $vm, $vo ) ) {
			wp_safe_redirect( home_url( '/baterias/' . $vm . '/' . $vo . '/' ), 301 );
			exit;
		}
	}

	// Parâmetro inexistente em rota virtual deve ser 404 real, nunca soft-404.
	if ( ! awr_virtual_route_valid( $route ) ) {
		status_header( 404 );
		global $wp_query;
		$wp_query->is_404 = true;
		return get_404_template() ?: AWR_DIR . '/404.php';
	}

	status_header( 200 );
	global $wp_query;
	$wp_query->is_404 = false;

	// Cidade fora da cobertura própria → template de venda com envio.
	if ( 'cidade' === $route && ! awr_cidade_by_slug( awr_param_a() ) && awr_cidade_venda_by_slug( awr_param_a() ) ) {
		return AWR_DIR . '/routes/cidade_venda.php';
	}

	// As duas rotas do hub paginado usam o mesmo template.
	$map        = array( 'baterias_de_carro' => 'baterias-de-carro', 'shop_page' => 'shop', 'shop_cat' => 'shop', 'shop_cat_page' => 'shop', 'hub_skus_page' => 'hub_skus', 'veiculo' => 'veiculo', 'veiculo_ano' => 'veiculo', 'lp_alias' => 'lp' );
	$file_route = $map[ $route ] ?? $route;
	$file       = AWR_DIR . '/routes/' . $file_route . '.php';
	return file_exists( $file ) ? $file : $template;
}, 99 );

