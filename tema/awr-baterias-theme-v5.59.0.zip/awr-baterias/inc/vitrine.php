<?php
/**
 * 5.59.0 — Vitrine estática dos produtos da busca.
 *
 * O catálogo de aplicação tem só ~182 códigos de bateria. Em vez de cada busca
 * (e cada página de veículo visitada por robô) carregar o WooCommerce, o tema
 * grava UMA vez um arquivo uploads/awr-busca/vitrine.json com o produto de cada
 * código (nome, foto, preço, estoque). O navegador monta o resultado da busca
 * com esse arquivo, sem PHP, e o servidor também o usa antes de ir ao banco.
 *
 * O arquivo é regerado 60 s depois de qualquer alteração de produto/estoque,
 * duas vezes ao dia e pelo botão em Configurações → AWR Busca. O valor cobrado
 * no pedido continua vindo do WooCommerce (awr_create_order_inner).
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

const AWR_VITRINE_ARQ    = 'vitrine.json';
const AWR_VITRINE_VALIDA = 26 * 3600; // Mais velha que isso não é usada.

/** Pasta e URL da vitrine em uploads/. @return array{dir:string,url:string} */
function awr_vitrine_local() {
	if ( ! function_exists( 'wp_upload_dir' ) ) { return array( 'dir' => '', 'url' => '' ); }
	$up = wp_upload_dir( null, false );
	if ( empty( $up['basedir'] ) ) { return array( 'dir' => '', 'url' => '' ); }
	return array(
		'dir' => $up['basedir'] . '/awr-busca',
		'url' => set_url_scheme( $up['baseurl'] . '/awr-busca/' . AWR_VITRINE_ARQ ),
	);
}

/** Pares [código, marca] do catálogo, na ordem de AWR_BRAND_KEYS. */
function awr_vitrine_pares() {
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		foreach ( AWR_BRAND_KEYS as $k => $brand ) {
			$raw = isset( $it[ $k ] ) ? strtoupper( trim( (string) $it[ $k ] ) ) : '';
			if ( '' !== $raw ) { $out[ $raw . '|' . $brand ] = array( $raw, $brand ); }
		}
	}
	return array_values( $out );
}

/**
 * Monta a vitrine. 'p' = código => produto (já com garantia, casco e cca, como
 * awr_products_by_skus); 'f' = "código|marca" => card "sob consulta" dos códigos
 * sem produto na loja.
 */
function awr_vitrine_montar() {
	$p = array(); $f = array(); $faltam = array(); $n = 0;
	foreach ( awr_vitrine_pares() as $i => $par ) {
		list( $sku, $brand ) = $par;
		if ( ! array_key_exists( $sku, $p ) ) {
			$prod = awr_build_product( $sku );
			if ( is_array( $prod ) ) {
				// Texto longo não vai para o navegador (nenhum card usa).
				$prod['description'] = '';
				$prod['short_description'] = '';
				$prod['garantia'] = awr_garantia_label( $prod['sku'] ?? $sku, $prod['name'] ?? '' );
				$prod['casco']    = awr_valor_casco( $prod['sku'] ?? $sku, $prod['name'] ?? '' );
				$prod['cca']      = awr_cca( $prod['sku'] ?? $sku, $prod['name'] ?? '' );
				$n++;
			} else {
				$faltam[] = $sku;
			}
			$p[ $sku ] = is_array( $prod ) ? $prod : null;
			// Libera os objetos do WooCommerce a cada 30 códigos (memória baixa).
			if ( 0 === ( count( $p ) % 30 ) && function_exists( 'wp_cache_flush_runtime' ) ) { wp_cache_flush_runtime(); }
		}
		if ( null === $p[ $sku ] ) {
			$nome = trim( $brand . ' ' . $sku );
			$f[ $sku . '|' . $brand ] = array(
				'sku'          => $sku,
				'brand'        => $brand,
				'name'         => $nome,
				'price'        => 0,
				'price_html'   => '',
				'image'        => '',
				'permalink'    => '',
				'amperagem'    => awr_extract_amperage( $sku ),
				'cca'          => awr_cca( $sku, $nome ),
				'garantia'     => awr_garantia_label( $sku, $nome ),
				'casco'        => awr_valor_casco( $sku, $nome ),
				'sob_consulta' => true,
			);
		}
	}
	return array(
		'v'      => 1,
		'gerado' => time(),
		'n_loja' => $n,
		'n'      => count( $p ),
		'faltam' => array_values( array_unique( $faltam ) ),
		'p'      => array_filter( $p ),
		'f'      => (object) $f,
	);
}

/**
 * Grava a vitrine. Nunca troca um arquivo bom por um vazio: se nenhum código
 * achou produto (banco sobrecarregado, WooCommerce desligado), mantém o anterior.
 *
 * @return array{ok:bool,n_loja:int,n:int,msg:string}
 */
function awr_vitrine_gravar() {
	global $wpdb;
	if ( ! function_exists( 'wc_get_product' ) ) { return array( 'ok' => false, 'n_loja' => 0, 'n' => 0, 'msg' => 'WooCommerce inativo' ); }
	$loc = awr_vitrine_local();
	if ( ! $loc['dir'] || ( ! is_dir( $loc['dir'] ) && ! wp_mkdir_p( $loc['dir'] ) ) || ! is_writable( $loc['dir'] ) ) {
		return array( 'ok' => false, 'n_loja' => 0, 'n' => 0, 'msg' => 'Pasta uploads/awr-busca sem permissão de escrita' );
	}
	if ( isset( $wpdb ) ) { $wpdb->last_error = ''; }
	$v = awr_vitrine_montar();
	if ( $v['n_loja'] < 1 || ( isset( $wpdb ) && '' !== (string) $wpdb->last_error ) ) {
		update_option( 'awr_vitrine_status', array( 'ok' => false, 'em' => time(), 'n_loja' => $v['n_loja'], 'n' => $v['n'], 'faltam' => array() ), false );
		return array( 'ok' => false, 'n_loja' => $v['n_loja'], 'n' => $v['n'], 'msg' => 'Nenhum produto encontrado — a vitrine anterior foi mantida' );
	}
	$json = wp_json_encode( $v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	$tmp  = $loc['dir'] . '/' . AWR_VITRINE_ARQ . '.tmp';
	if ( ! $json || ! file_put_contents( $tmp, $json ) || ! @rename( $tmp, $loc['dir'] . '/' . AWR_VITRINE_ARQ ) ) { // phpcs:ignore
		return array( 'ok' => false, 'n_loja' => $v['n_loja'], 'n' => $v['n'], 'msg' => 'Falha ao gravar o arquivo' );
	}
	update_option( 'awr_vitrine_status', array( 'ok' => true, 'em' => $v['gerado'], 'n_loja' => $v['n_loja'], 'n' => $v['n'], 'faltam' => $v['faltam'] ), false );
	return array( 'ok' => true, 'n_loja' => $v['n_loja'], 'n' => $v['n'], 'msg' => '' );
}

/** Vitrine para o servidor (lida uma vez por requisição). null se ausente ou velha. */
function awr_vitrine() {
	static $v = false;
	if ( false !== $v ) { return $v; }
	$v   = null;
	$loc = awr_vitrine_local();
	$arq = $loc['dir'] ? $loc['dir'] . '/' . AWR_VITRINE_ARQ : '';
	if ( ! $arq || ! is_readable( $arq ) || ( time() - (int) filemtime( $arq ) ) > AWR_VITRINE_VALIDA ) { return $v; }
	$d = json_decode( (string) file_get_contents( $arq ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( is_array( $d ) && 1 === (int) ( $d['v'] ?? 0 ) && ! empty( $d['p'] ) ) { $v = $d; }
	return $v;
}

/** URL pública da vitrine (vazia se ainda não existe). */
function awr_vitrine_url() {
	$st = get_option( 'awr_vitrine_status' );
	if ( ! is_array( $st ) || empty( $st['em'] ) ) { return ''; }
	return awr_vitrine_local()['url'];
}

/** Agenda a regeração para daqui a 60 s (um só evento, por mais alterações que haja). */
function awr_vitrine_agendar() {
	if ( ! wp_next_scheduled( 'awr_vitrine_build' ) ) { wp_schedule_single_event( time() + 60, 'awr_vitrine_build' ); }
}
add_action( 'awr_vitrine_build', 'awr_vitrine_gravar' );
add_action( 'awr_vitrine_cron', 'awr_vitrine_gravar' );

foreach ( array( 'woocommerce_update_product', 'woocommerce_new_product', 'woocommerce_delete_product', 'woocommerce_trash_product',
	'woocommerce_product_set_stock', 'woocommerce_variation_set_stock', 'woocommerce_product_set_stock_status', 'woocommerce_variation_set_stock_status' ) as $awr_h ) {
	add_action( $awr_h, 'awr_vitrine_agendar' );
}
unset( $awr_h );
// Promoções agendadas do WooCommerce começam/terminam pelo cron diário dele.
add_action( 'woocommerce_scheduled_sales', 'awr_vitrine_agendar', 99 );

// Cron de segurança duas vezes ao dia (agendado só no painel, nunca em visita).
add_action( 'admin_init', function () {
	if ( wp_doing_ajax() ) { return; }
	if ( ! wp_next_scheduled( 'awr_vitrine_cron' ) ) { wp_schedule_event( time() + 600, 'twicedaily', 'awr_vitrine_cron' ); }
} );

// Botão do painel: Configurações → AWR Busca → "Regerar vitrine".
add_action( 'admin_init', function () {
	if ( empty( $_GET['awr_vitrine'] ) || ! current_user_can( 'manage_woocommerce' ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification
	check_admin_referer( 'awr_vitrine' );
	$r = awr_vitrine_gravar();
	set_transient( 'awr_vitrine_msg', $r, 5 * MINUTE_IN_SECONDS );
	wp_safe_redirect( admin_url( 'options-general.php?page=awr-busca-admin' ) );
	exit;
} );

/** Resumo para o painel. */
function awr_vitrine_painel_html() {
	$st  = get_option( 'awr_vitrine_status' );
	$url = wp_nonce_url( admin_url( 'options-general.php?page=awr-busca-admin&awr_vitrine=1' ), 'awr_vitrine' );
	$h   = '<h2>Vitrine da busca (5.59.0)</h2><p>A busca mostra os produtos a partir de um arquivo estático, sem carregar o WooCommerce a cada pesquisa.</p>';
	$msg = get_transient( 'awr_vitrine_msg' );
	if ( is_array( $msg ) ) {
		delete_transient( 'awr_vitrine_msg' );
		$h .= '<div class="notice ' . ( $msg['ok'] ? 'notice-success' : 'notice-error' ) . ' inline"><p>' . esc_html( $msg['ok'] ? 'Vitrine regerada.' : $msg['msg'] ) . '</p></div>';
	}
	if ( is_array( $st ) && ! empty( $st['em'] ) ) {
		$h .= '<p><strong>Vitrine: ' . (int) $st['n_loja'] . ' de ' . (int) $st['n'] . ' códigos com produto na loja</strong>, '
			. ( $st['ok'] ? 'gerada em ' . esc_html( wp_date( 'd/m/Y H:i', (int) $st['em'] ) ) : '<span style="color:#b32d2e">última tentativa falhou em ' . esc_html( wp_date( 'd/m/Y H:i', (int) $st['em'] ) ) . '</span>' ) . '.</p>';
		if ( ! empty( $st['faltam'] ) ) {
			$h .= '<details><summary>Códigos do catálogo sem produto na loja (' . count( $st['faltam'] ) . ') — aparecem como "sob consulta"</summary><p><code>' . esc_html( implode( ', ', $st['faltam'] ) ) . '</code></p></details>';
		}
	} else {
		$h .= '<p>A vitrine ainda não foi gerada. Enquanto isso a busca usa o servidor, como antes.</p>';
	}
	return $h . '<p><a class="button button-primary" href="' . esc_url( $url ) . '">Regerar vitrine agora</a></p>';
}
