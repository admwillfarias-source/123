<?php
/**
 * 5.54.0 — Configurações → AWR Busca (substitui o painel AWR Motobatt da 5.53.0).
 *
 * 1. Modelo de card dos resultados (inc/cards.php) e link para a pré-via.
 * 2. Teste de busca: veículo → códigos do catálogo → produto da loja e preço.
 * 3. Relatório de todos os códigos do catálogo contra o WooCommerce.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'admin_menu', function () {
	add_options_page( 'AWR Busca', 'AWR Busca', 'manage_woocommerce', 'awr-busca-admin', 'awr_busca_admin_page' );
} );

/** Códigos do catálogo: código => array( marca, veiculos, ex ). */
function awr_busca_codigos() {
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		foreach ( AWR_BRAND_KEYS as $k => $marca ) {
			$c = strtoupper( trim( (string) ( $it[ $k ] ?? '' ) ) );
			if ( '' === $c ) { continue; }
			if ( ! isset( $out[ $c ] ) ) { $out[ $c ] = array( 'marca' => $marca, 'veiculos' => 0, 'ex' => array() ); }
			$out[ $c ]['veiculos']++;
			if ( count( $out[ $c ]['ex'] ) < 2 ) { $out[ $c ]['ex'][] = awr_nome_veiculo( $it['ma'] . ' ' . $it['mo'] ); }
		}
	}
	uasort( $out, function ( $a, $b ) { return $b['veiculos'] <=> $a['veiculos']; } );
	return $out;
}

function awr_busca_admin_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }

	// Salvar o modelo de card.
	if ( isset( $_POST['awr_card_modelo'] ) && check_admin_referer( 'awr_busca_admin' ) ) {
		$m = sanitize_key( wp_unslash( $_POST['awr_card_modelo'] ) );
		if ( isset( awr_card_modelos()[ $m ] ) ) {
			update_option( 'awr_card_modelo', $m, false );
			echo '<div class="notice notice-success"><p>Modelo de card salvo. Limpe o cache do site para os visitantes verem.</p></div>';
		}
	}
	// 5.56.0 — chave do checkout novo (desligar volta ao checkout anterior na hora).
	if ( isset( $_POST['awr_checkout_v2_form'] ) && check_admin_referer( 'awr_busca_admin' ) ) {
		update_option( 'awr_checkout_v2', empty( $_POST['awr_checkout_v2'] ) ? '0' : '1', false );
		echo '<div class="notice notice-success"><p>Checkout salvo. Limpe o cache do site para os visitantes verem.</p></div>';
	}
	// 5.58.1 — regerar os índices da busca e do seletor de motos (manual).
	if ( isset( $_POST['awr_indices_regerar'] ) && check_admin_referer( 'awr_busca_admin' ) ) {
		do_action( 'awr_indices_build' );
		$awr_o = get_option( 'awr_indices_arquivos' );
		echo '<div class="notice ' . ( is_array( $awr_o ) && ! empty( $awr_o['url'] ) ? 'notice-success"><p>Índices regerados.' : 'notice-error"><p>Não foi possível gravar em uploads/awr-busca/. O site segue usando os índices do tema.' ) . '</p></div>';
	}
	$atual = (string) get_option( 'awr_card_modelo', 'app' );
	$teste = isset( $_GET['veiculo'] ) ? sanitize_text_field( wp_unslash( $_GET['veiculo'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$rel   = ! empty( $_GET['relatorio'] ); // phpcs:ignore WordPress.Security.NonceVerification
	$base  = admin_url( 'options-general.php?page=awr-busca-admin' );
	?>
	<div class="wrap">
		<h1>AWR Busca — preço das baterias e modelo de card</h1>

		<h2>1. Modelo de card nos resultados</h2>
		<form method="post">
			<?php wp_nonce_field( 'awr_busca_admin' ); ?>
			<?php foreach ( awr_card_modelos() as $k => $rot ) : ?>
				<p><label><input type="radio" name="awr_card_modelo" value="<?php echo esc_attr( $k ); ?>" <?php checked( $atual, $k ); ?>> <?php echo esc_html( $rot ); ?></label></p>
			<?php endforeach; ?>
			<p><button class="button button-primary">Salvar modelo</button>
			<a class="button" target="_blank" href="<?php echo esc_url( home_url( '/awr-previa-cards/' ) ); ?>">Ver os 3 modelos lado a lado</a></p>
			<p class="description">Os eventos do GA4 levam o parâmetro <code>card_modelo</code>, para comparar a conversão de cada modelo.</p>
		</form>

		<h2>Checkout</h2>
		<form method="post">
			<?php wp_nonce_field( 'awr_busca_admin' ); ?>
			<input type="hidden" name="awr_checkout_v2_form" value="1">
			<p><label><input type="checkbox" name="awr_checkout_v2" value="1" <?php checked( function_exists( 'awr_checkout_v2_ativo' ) && awr_checkout_v2_ativo() ); ?>> Usar o checkout novo em 3 etapas (Bateria → Entrega → Pagamento)</label></p>
			<p class="description">Desmarcado, o site volta ao checkout anterior. Os pedidos dos dois entram no WooCommerce como "Processando". Leads de abandono: WooCommerce → Checkouts abandonados.</p>
			<p><button class="button">Salvar checkout</button></p>
		</form>

		<?php echo function_exists( 'awr_vitrine_painel_html' ) ? awr_vitrine_painel_html() : ''; // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<?php echo function_exists( 'awr_robos_painel_html' ) ? awr_robos_painel_html() : ''; // phpcs:ignore WordPress.Security.EscapeOutput ?>

		<h2>Índices da busca</h2>
		<form method="post">
			<?php wp_nonce_field( 'awr_busca_admin' ); ?>
			<p class="description">As sugestões da busca e o seletor de motos usam índices em arquivo. O tema já vem com eles; regere só se o catálogo mudar sem atualizar o tema.</p>
			<p><button class="button" name="awr_indices_regerar" value="1">Regerar índices agora</button>
			<a class="button" href="<?php echo esc_url( home_url( '/?awr_flush_produtos=1' ) ); ?>">Limpar cache de produtos</a></p>
			<p class="description">"Limpar cache de produtos" refaz na hora a ligação entre os códigos do catálogo e os produtos da loja (preço, foto e nome) e agenda a vitrine para daqui a 1 minuto.</p>
		</form>

		<h2>2. Testar a busca de um veículo</h2>
		<form method="get">
			<input type="hidden" name="page" value="awr-busca-admin">
			<input type="text" name="veiculo" value="<?php echo esc_attr( $teste ); ?>" placeholder="Ex.: Onix 2018" class="regular-text">
			<button class="button">Testar</button>
		</form>
		<?php
		if ( $teste ) {
			$sug = awr_search_suggestions( $teste, 1 );
			if ( ! $sug ) {
				echo '<p>Nenhum veículo encontrado para "' . esc_html( $teste ) . '".</p>';
			} else {
				$v     = $sug[0];
				$ano   = preg_match( '/\b((?:19|20)\d{2})\b/', $teste, $m ) ? (int) $m[1] : 0;
				$items = awr_vehicle_by_slug( $v['slug'], $ano );
				$prods = awr_products_by_skus( awr_skus_from_items( $items ) );
				echo '<p><strong>' . esc_html( $v['label'] ?? $v['slug'] ) . ( $ano ? ' ' . (int) $ano : '' ) . '</strong> — ' . (int) count( $prods ) . ' códigos no catálogo.</p>';
				echo '<table class="widefat striped"><thead><tr><th>Código do catálogo</th><th>Marca</th><th>Produto na loja</th><th>SKU na loja</th><th>Preço</th></tr></thead><tbody>';
				foreach ( $prods as $p ) {
					$ok = empty( $p['sob_consulta'] ) && ! empty( $p['id'] );
					echo '<tr><td><code>' . esc_html( $p['sku_catalogo'] ?? $p['sku'] ) . '</code></td><td>' . esc_html( $p['brand'] ?? '' ) . '</td><td>'
						. ( $ok ? '<a href="' . esc_url( get_edit_post_link( (int) $p['id'] ) ) . '">' . esc_html( $p['name'] ) . '</a>' : '<span style="color:#b32d2e">não encontrado na loja</span>' )
						. '</td><td>' . ( $ok ? esc_html( $p['sku'] ) : '—' ) . '</td><td>' . ( (float) ( $p['price'] ?? 0 ) > 0 ? esc_html( 'R$ ' . number_format( (float) $p['price'], 2, ',', '.' ) ) : '<span style="color:#b32d2e">sem preço</span>' ) . '</td></tr>';
				}
				echo '</tbody></table>';
			}
		}
		?>

		<h2>3. Todos os códigos do catálogo contra a loja</h2>
		<?php if ( ! $rel ) : ?>
			<p>Confere os códigos de todas as marcas (Moura, Heliar, Zetta, Excell, Eletran, Motobatt) e mostra o que tem produto com preço, o que tem produto sem preço e o que não existe na loja. Pode levar alguns segundos.</p>
			<p><a class="button" href="<?php echo esc_url( add_query_arg( 'relatorio', '1', $base ) ); ?>">Gerar relatório</a></p>
		<?php else : ?>
			<?php
			$cods = awr_busca_codigos();
			if ( function_exists( 'set_time_limit' ) ) { @set_time_limit( 120 ); } // phpcs:ignore
			awr_prime_products( array_keys( $cods ) );
			$grupos = array( 'sem' => array(), 'zero' => array(), 'ok' => array() );
			foreach ( $cods as $c => $d ) {
				$p = awr_product_by_sku( $c );
				$k = ! $p ? 'sem' : ( (float) $p['price'] > 0 ? 'ok' : 'zero' );
				$grupos[ $k ][] = array( $c, $d, $p );
			}
			$tit = array( 'sem' => 'Não encontrados na loja', 'zero' => 'Encontrados, mas sem preço', 'ok' => 'Com preço' );
			echo '<p><strong>' . (int) count( $grupos['ok'] ) . '</strong> com preço · <strong>' . (int) count( $grupos['zero'] ) . '</strong> sem preço · <strong>' . (int) count( $grupos['sem'] ) . '</strong> não encontrados (de ' . (int) count( $cods ) . ' códigos). Os primeiros de cada lista são os que atendem mais veículos.</p>';
			foreach ( $grupos as $k => $lista ) :
				?>
				<h3><?php echo esc_html( $tit[ $k ] . ' (' . count( $lista ) . ')' ); ?></h3>
				<table class="widefat striped"><thead><tr><th>Código</th><th>Marca</th><th>Veículos</th><th>Exemplos</th><th>Produto</th><th>SKU na loja</th><th>Preço</th></tr></thead><tbody>
				<?php foreach ( array_slice( $lista, 0, 300 ) as $l ) : list( $c, $d, $p ) = $l; ?>
					<tr>
						<td><code><?php echo esc_html( $c ); ?></code></td>
						<td><?php echo esc_html( $d['marca'] ); ?></td>
						<td><?php echo (int) $d['veiculos']; ?></td>
						<td><?php echo esc_html( implode( ', ', $d['ex'] ) ); ?></td>
						<td><?php echo $p ? '<a href="' . esc_url( get_edit_post_link( (int) $p['id'] ) ) . '">' . esc_html( $p['name'] ) . '</a>' : '—'; ?></td>
						<td><?php echo $p ? esc_html( $p['sku'] ) : '—'; ?></td>
						<td><?php echo $p && (float) $p['price'] > 0 ? esc_html( 'R$ ' . number_format( (float) $p['price'], 2, ',', '.' ) ) : '—'; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody></table>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
	<?php
}
