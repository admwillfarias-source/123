/* AWR 5.57.0 — página de produto: galeria, "serve na minha moto/carro?", entrega por CEP
   e passagem do veículo e do CEP para o checkout e o WhatsApp. Carregado só em produto. */
(function () {
	'use strict';
	var d = document, A = window.AWR || {}, pg = d.querySelector('[data-awr-pp]');
	if (!pg) return;
	var sku = pg.dataset.sku, nome = pg.dataset.nome, preco = Number(pg.dataset.preco || 0), tipo = pg.dataset.tipo || 'carro';
	var brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
	var st = { veiculo: '', cep: '' };
	function $(s, c) { return (c || d).querySelector(s); }
	function $$(s, c) { return Array.prototype.slice.call((c || d).querySelectorAll(s)); }
	function esc(v) { return String(v == null ? '' : v).replace(/[&<>'"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]; }); }
	function dig(v) { return String(v || '').replace(/\D/g, ''); }
	function ev(n, p) { p = Object.assign({ card_modelo: A.cardModelo || 'app', sku: sku, origem: 'produto' }, p || {}); if (window.AWRCore && window.AWRCore.track) window.AWRCore.track(n, p); else { (window.dataLayer = window.dataLayer || []).push(Object.assign({ event: n }, p)); } }
	try { var mem = JSON.parse(localStorage.getItem('awr_pp') || '{}'); st.cep = mem.cep || ''; if (mem.sku === sku) st.veiculo = mem.veiculo || ''; } catch (e) {}
	function guardar() { try { localStorage.setItem('awr_pp', JSON.stringify({ cep: st.cep, veiculo: st.veiculo, sku: sku })); } catch (e) {} }

	/* Veículo e CEP vão para todos os botões de compra (topo e barra do celular) e para o WhatsApp. */
	function aplicar() {
		$$('[data-awr-checkout][data-sku="' + sku + '"]').forEach(function (b) {
			if (st.veiculo) b.dataset.veiculo = st.veiculo; else delete b.dataset.veiculo;
			if (st.cep) b.dataset.cep = st.cep; else delete b.dataset.cep;
		});
		var t = 'Olá! Quero comprar a bateria ' + nome + ' (' + sku + ')' + (preco ? ' por ' + brl.format(preco) : '') + ' com instalação.';
		if (st.veiculo) t += ' ' + (tipo === 'moto' ? 'Moto' : 'Carro') + ': ' + st.veiculo + '.';
		if (st.cep) t += ' CEP: ' + st.cep + '.';
		$$('[data-awr-pp-wa]').forEach(function (a) { a.href = 'https://wa.me/' + (A.whatsapp || '') + '?text=' + encodeURIComponent(t); });
		var fit = $('[data-awr-pp-fit]');
		if (fit) { fit.hidden = !st.veiculo; fit.textContent = st.veiculo ? '✓ Compatível com ' + st.veiculo : ''; }
	}

	/* ---------- galeria ---------- */
	var gal = $('[data-awr-gal]'), track = gal && $('.awr-pp__track', gal);
	if (track) {
		var slides = $$('.awr-pp__slide', track), thumbs = $$('[data-gal-i]', gal), atual = 0;
		var ir = function (i) { atual = (i + slides.length) % slides.length; track.scrollTo({ left: slides[atual].offsetLeft - track.offsetLeft, behavior: 'smooth' }); marcar(); };
		var marcar = function () { thumbs.forEach(function (t, i) { if (i === atual) t.setAttribute('aria-current', 'true'); else t.removeAttribute('aria-current'); }); };
		gal.addEventListener('click', function (e) {
			var n = e.target.closest('[data-gal]'), t = e.target.closest('[data-gal-i]'), sl = e.target.closest('.awr-pp__slide');
			if (n) return ir(atual + Number(n.dataset.gal));
			if (t) return ir(Number(t.dataset.galI));
			if (sl && window.HTMLDialogElement) zoom(sl.dataset.full, $('img', sl).alt);
		});
		track.addEventListener('scroll', function () { var w = track.clientWidth || 1, i = Math.round(track.scrollLeft / w); if (i !== atual && slides[i]) { atual = i; marcar(); } }, { passive: true });
		track.addEventListener('keydown', function (e) { if (e.key === 'ArrowRight') { e.preventDefault(); ir(atual + 1); } if (e.key === 'ArrowLeft') { e.preventDefault(); ir(atual - 1); } });
	}
	function zoom(src, alt) {
		var dl = d.createElement('dialog'); dl.className = 'awr-pp__zoom';
		dl.innerHTML = '<button type="button" aria-label="Fechar">×</button><img src="' + esc(src) + '" alt="' + esc(alt) + '">';
		d.body.appendChild(dl); dl.addEventListener('close', function () { dl.remove(); });
		dl.addEventListener('click', function (e) { if (e.target === dl || e.target.tagName === 'BUTTON') dl.close(); });
		dl.showModal();
	}

	/* ---------- compatibilidade ---------- */
	var cbox = $('.awr-pp-compat'), dados = {};
	if (cbox) {
		try { dados = JSON.parse($('[data-awr-pp-compat]', cbox).textContent || '{}'); } catch (e) {}
		var sMa = $('[data-c=marca]', cbox), sMo = $('[data-c=modelo]', cbox), sAn = $('[data-c=ano]', cbox), res = $('[data-c=res]', cbox);
		var opt = function (v, t) { var o = d.createElement('option'); o.value = v; o.textContent = t; return o; };
		var outro = '__outro';
		Object.keys(dados).sort(function (a, b) { return a.localeCompare(b, 'pt-BR'); }).forEach(function (m) { sMa.appendChild(opt(m, m)); });
		sMa.appendChild(opt(outro, 'Outra marca'));
		var limpar = function (s, t) { s.innerHTML = ''; s.appendChild(opt('', t)); s.disabled = true; };
		sMa.addEventListener('change', function () {
			limpar(sMo, 'Modelo'); limpar(sAn, 'Ano'); res.innerHTML = '';
			if (!sMa.value) return;
			if (sMa.value === outro) return naoServe();
			(dados[sMa.value] || []).forEach(function (m, i) { sMo.appendChild(opt(String(i), m[0])); });
			sMo.appendChild(opt(outro, 'Outro modelo')); sMo.disabled = false; sMo.focus();
		});
		sMo.addEventListener('change', function () {
			limpar(sAn, 'Ano'); res.innerHTML = '';
			if (!sMo.value) return;
			if (sMo.value === outro) return naoServe();
			var m = dados[sMa.value][Number(sMo.value)], de = m[1], ate = m[2] || new Date().getFullYear();
			if (!de) { sAn.appendChild(opt('*', 'Todos os anos')); }
			else for (var y = ate; y >= de; y--) sAn.appendChild(opt(String(y), String(y)));
			sAn.disabled = false; sAn.focus();
		});
		sAn.addEventListener('change', function () { if (sAn.value) verificar(); });
		$('[data-c=ok]', cbox).addEventListener('click', verificar);
	}
	function verificar() {
		if (!sMa.value) { res.innerHTML = '<p class="awr-pp-compat__msg">Escolha a marca ' + (tipo === 'moto' ? 'da moto' : 'do carro') + '.</p>'; sMa.focus(); return; }
		if (sMa.value === outro || sMo.value === outro) return naoServe();
		if (!sMo.value) { res.innerHTML = '<p class="awr-pp-compat__msg">Escolha o modelo.</p>'; sMo.focus(); return; }
		if (!sAn.value) { res.innerHTML = '<p class="awr-pp-compat__msg">Escolha o ano.</p>'; sAn.focus(); return; }
		var m = dados[sMa.value][Number(sMo.value)];
		st.veiculo = (sMa.value + ' ' + m[0] + (sAn.value !== '*' ? ' ' + sAn.value : '')).replace(/\s+/g, ' ').trim();
		guardar(); aplicar();
		res.innerHTML = '<p class="awr-pp-compat__ok">✓ Serve ' + (tipo === 'moto' ? 'na sua ' : 'no seu ') + esc(st.veiculo) + '</p>';
		ev('compat_check', { resultado: 'serve', veiculo: st.veiculo });
	}
	function naoServe() {
		st.veiculo = ''; guardar(); aplicar();
		var q = (A.buscarUrl || '/buscar/');
		res.innerHTML = '<div class="awr-pp-compat__no"><p>Não encontramos o seu ' + (tipo === 'moto' ? 'modelo de moto' : 'modelo de carro') + ' na lista desta bateria.</p>' +
			'<p><a href="' + esc(q) + '">Ver a bateria certa para ' + (tipo === 'moto' ? 'a minha moto' : 'o meu carro') + '</a> · <a data-awr-source="produto_compat_whatsapp" target="_top" rel="noopener" href="https://wa.me/' + esc(A.whatsapp || '') + '?text=' + encodeURIComponent('Olá! A bateria ' + nome + ' (' + sku + ') serve no meu veículo? Modelo: ') + '">Confirmar no WhatsApp</a></p></div>';
		ev('compat_check', { resultado: 'nao_encontrado' });
	}

	/* ---------- entrega por CEP (mesma cotação do checkout) ---------- */
	var fcep = $('[data-awr-pp-cep]'), cres = $('[data-c=cepres]');
	function masc(v) { v = dig(v).slice(0, 8); return v.length > 5 ? v.slice(0, 5) + '-' + v.slice(5) : v; }
	/* 5.59.0 — a mesma cotação fica guardada 10 min (a página não pergunta de
	   novo a cada visita) e, se o servidor responder 429/5xx, nada de segundo canal. */
	function cotacao(q) {
		var k = 'awr_cot:' + q;
		try { var v = JSON.parse(localStorage.getItem(k) || 'null'); if (v && Date.now() - v.t < 6e5) return Promise.resolve(v.c); } catch (x) {}
		return fetch((A.restUrl || '/wp-json/awr/v1/') + 'cotacao?' + q, { credentials: 'same-origin' })
			.then(function (r) { if (!r.ok) throw r.status; return r.json(); })
			.catch(function (st) { if (st === 429 || st >= 500) throw st; return fetch((A.searchUrl || '/awr-busca/') + '?action=cotacao&' + q).then(function (r) { return r.json(); }); })
			.then(function (c) { if (c && c.ok) { try { localStorage.setItem(k, JSON.stringify({ t: Date.now(), c: c })); } catch (x) {} } return c; });
	}
	function cotar(cep) {
		cres.innerHTML = '<p class="awr-pp-cep__msg">Calculando a entrega…</p>';
		var pid = ($('[data-awr-checkout][data-pid]') || { dataset: {} }).dataset.pid, q = 'cep=' + dig(cep) + (pid ? '&product_id=' + pid : '');
		cotacao(q)
			.then(function (c) {
				if (!c || !c.ok || !c.prazo) { cres.innerHTML = '<p class="awr-pp-cep__msg is-erro">' + esc((c && c.mensagem) || 'CEP não encontrado. Confira os números.') + '</p>'; return; }
				st.cep = masc(cep); guardar(); aplicar();
				var e = c.endereco || {};
				cres.innerHTML = '<div class="awr-pp-cep__card' + (c.modo === 'rapida' ? ' is-rapida' : '') + '"><strong>' + esc(c.prazo.titulo) + '</strong>' +
					'<span>' + esc([e.bairro, e.cidade && e.cidade + (e.uf ? '/' + e.uf : '')].filter(Boolean).join(', ')) + '</span>' +
					'<span>' + esc(c.prazo.texto) + '</span><em>Taxa de entrega: ' + esc(c.taxa_rotulo) + (c.acrescimo_pct ? ' · acréscimo de ' + c.acrescimo_pct + '%' : '') + '</em>' +
					(c.so_pix ? '<em>Envio sem instalação no local · pagamento via Pix.</em>' : '') + '</div>';
				ev('delivery_quote', { modo: c.modo, regiao: c.regiao, taxa: c.taxa });
			})
			.catch(function () { cres.innerHTML = '<p class="awr-pp-cep__msg is-erro">Não conseguimos consultar agora. Tente de novo ou fale no WhatsApp.</p>'; });
	}
	if (fcep) {
		var inp = fcep.cep;
		if (st.cep) { inp.value = st.cep; var auto = function () { cotar(st.cep); }; 'requestIdleCallback' in window ? requestIdleCallback(auto, { timeout: 3000 }) : setTimeout(auto, 1500); }
		inp.addEventListener('input', function () { inp.value = masc(inp.value); if (dig(inp.value).length === 8) cotar(inp.value); });
		fcep.addEventListener('submit', function (e) { e.preventDefault(); if (dig(inp.value).length === 8) cotar(inp.value); else { cres.innerHTML = '<p class="awr-pp-cep__msg is-erro">Digite o CEP com 8 números.</p>'; inp.focus(); } });
	}

	/* Veículo já confirmado neste aparelho para esta bateria. */
	aplicar();
	if (st.veiculo && cbox) $('[data-c=res]', cbox).innerHTML = '<p class="awr-pp-compat__ok">✓ Você confirmou: ' + esc(st.veiculo) + ' · <button type="button" class="awr-pp-link" data-c="trocar">trocar</button></p>';
	d.addEventListener('click', function (e) { if (e.target.closest('[data-c=trocar]')) { st.veiculo = ''; guardar(); aplicar(); $('[data-c=res]', cbox).innerHTML = ''; $('[data-c=marca]', cbox).focus(); } });
})();
