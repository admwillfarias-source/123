/* AWR 5.59.0 — Busca no navegador, sem PHP a cada pesquisa.
   - Sugestões: índice local (AWRSugest); espera o índice chegar em vez de perguntar ao servidor.
   - Produtos: veículo → códigos (awr-vskus.json) + produto de cada código (vitrine.json,
     gerada pelo tema em uploads/ sempre que um produto muda). Mesmo resultado do PHP
     (awr_vehicle_by_slug + awr_skus_from_items + awr_products_by_skus).
   - Servidor só quando a vitrine não existe/está velha ou para busca por Ah; nunca em
     cascata: 429/5xx/tempo esgotado não tentam outro canal e pausam a aba por 60 s.
   Ligado ao awr-search.js por window.awrY / awrPre / awrStatus / awrSemRepetir / awrOcupado. */
(function () {
	'use strict';
	var A = window.AWR || {}, voando = {}, base = null, TTL = 6e5, janela = [], LIMITE = 20;
	var VALIDA = 26 * 3600, PAUSA = 6e4, CHAVE_PAUSA = 'awr_busy';

	function chave(e) { var o = {}; Object.keys(e || {}).sort().forEach(function (k) { if (e[k] !== '' && e[k] != null) o[k] = e[k]; }); return 'awr_pc2:' + JSON.stringify(o); }
	function ler(k) { try { var v = JSON.parse(sessionStorage.getItem(k) || 'null'); return v && Date.now() - v.t < TTL ? v.d : null; } catch (x) { return null; } }
	function gravar(k, d) { try { sessionStorage.setItem(k, JSON.stringify({ t: Date.now(), d: d })); } catch (x) {} }
	function vez() {
		var agora = Date.now();
		janela = janela.filter(function (t) { return agora - t < 6e4; });
		if (janela.length < LIMITE) { janela.push(agora); return Promise.resolve(); }
		return new Promise(function (r) { setTimeout(r, 6e4 - (agora - janela[0]) + 50); }).then(vez);
	}

	/* ---- Pausa depois de 429/503 (o servidor pediu para esperar) ---- */
	var pausaAte = 0;
	try { pausaAte = Number(sessionStorage.getItem(CHAVE_PAUSA)) || 0; } catch (x) {}
	window.awrStatus = function (st, ra) {
		if (st !== 429 && st !== 503) return;
		var s = Number(ra), ms = s > 0 && s < 600 ? s * 1e3 : PAUSA;
		pausaAte = Date.now() + ms;
		try { sessionStorage.setItem(CHAVE_PAUSA, String(pausaAte)); } catch (x) {}
	};
	window.awrOcupado = function () { return Date.now() < pausaAte; };
	/* Erros em que tentar outro canal ou repetir só cria mais processos PHP. */
	window.awrSemRepetir = function (er) {
		if (!er) return false;
		if (er.name === 'AbortError') return true;
		var st = Number(er.awrStatus) || 0;
		return st === 429 || st >= 500 || window.awrOcupado();
	};

	/* ---- Arquivos estáticos ---- */
	var cache = {};
	function json(nome, url) {
		if (cache[nome]) return cache[nome];
		var p = url ? fetch(url, { credentials: 'same-origin' }).then(function (r) { if (!r.ok) throw new Error(nome); return r.json(); }) : Promise.reject(new Error(nome));
		cache[nome] = p;
		p.catch(function () { setTimeout(function () { if (cache[nome] === p) delete cache[nome]; }, 3e4); });
		return p;
	}
	function vskus() {
		return json('vskus', A.vskusUrl).then(function (d) { if (!d || d.v !== 1 || !d.i) throw new Error('vskus'); return d; });
	}
	function vitrine() {
		if (!A.vitrineUrl) return Promise.reject(new Error('vitrine'));
		var u = A.vitrineUrl + (A.vitrineUrl.indexOf('?') === -1 ? '?' : '&') + 't=' + Math.floor(Date.now() / 6e5);
		return json('vitrine', u).then(function (d) {
			if (!d || d.v !== 1 || !d.p || Date.now() / 1e3 - Number(d.gerado || 0) > VALIDA) throw new Error('vitrine velha');
			return d;
		});
	}
	function preparar() { if (A.vitrineUrl) { vskus().catch(function () {}); vitrine().catch(function () {}); } }

	function copia(o) { var r = {}; for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) r[k] = o[k]; return r; }
	/* Mesmo card de awr_products_by_skus. null = código fora da vitrine (vai ao servidor). */
	function card(V, sku, brand) {
		var p = V.p[sku];
		if (p) { p = copia(p); p.brand = brand; p.sku_catalogo = sku; return p; }
		var f = V.f && V.f[sku + '|' + brand];
		return f ? copia(f) : null;
	}
	function nomeVeiculo(slug, idx) {
		var S = window.AWRSugest;
		return (S && S.rotulo ? Promise.resolve(S.carregar()).then(function () { return S.rotulo(slug); }, function () { return ''; }) : Promise.resolve(''))
			.then(function (n) { return n || ''; });
	}

	/* Resultado local; rejeita quando não dá para responder igual ao servidor. */
	function local(e) {
		if (e.ah || !A.vitrineUrl) return Promise.reject(new Error('sem local'));
		var sku = String(e.sku || '').trim(), skus = String(e.skus || '').trim(), slug = String(e.veiculo || '');
		if (skus || sku) {
			var lista = skus ? skus.split(',').map(function (s) { return s.trim(); }).filter(Boolean).slice(0, 12) : [sku];
			return vitrine().then(function (V) {
				var out = lista.map(function (s) { var p = V.p[s.toUpperCase()]; if (!p) return null; p = copia(p); p.brand = ''; p.sku_catalogo = s.toUpperCase(); return p; });
				if (out.some(function (x) { return !x; })) throw new Error('fora da vitrine');
				return { produtos: out };
			});
		}
		if (!slug) return Promise.reject(new Error('sem local'));
		var ano = parseInt(e.ano, 10) || 0, maxAno = new Date().getFullYear() + 2;
		if (ano && (ano < 1950 || ano > maxAno)) ano = 0;
		return Promise.all([vskus(), vitrine()]).then(function (r) {
			var X = r[0], V = r[1], it = X.i[slug] || [], ordem = [], marca = {}, primeiro = -1;
			for (var i = 0; i < it.length; i += 3) {
				if (ano && (ano < it[i] || ano > it[i + 1])) continue;
				if (primeiro < 0) primeiro = i / 3;
				X.l[it[i + 2]].forEach(function (k) {
					var par = X.s[k];
					if (!Object.prototype.hasOwnProperty.call(marca, par[0])) ordem.push(par[0]);
					marca[par[0]] = par[1];
				});
			}
			var produtos = [];
			for (var j = 0; j < ordem.length; j++) {
				var c = card(V, ordem[j], marca[ordem[j]]);
				if (!c) throw new Error('fora da vitrine');
				produtos.push(c);
			}
			var nomes = X.n && X.n[slug];
			var nome = primeiro < 0 ? Promise.resolve('') : nomes ? Promise.resolve(nomes[primeiro] || '') : nomeVeiculo(slug);
			return nome.then(function (n) { return { veiculo: n, ano: ano, produtos: produtos, local: true }; });
		});
	}

	function servidor(e) {
		return vez().then(function () { return base('produtos', e); });
	}
	function produtos(e) {
		var k = chave(e), c = ler(k);
		if (c) return Promise.resolve(c);
		if (voando[k]) return voando[k];
		var p = local(e).catch(function () { return servidor(e); }).then(function (d) {
			delete voando[k];
			if (d && !d.offline && d.produtos && d.produtos.some(function (x) { return Number(x.price) > 0; })) gravar(k, d);
			return d;
		}, function (er) { delete voando[k]; throw er; });
		voando[k] = p;
		return p;
	}

	window.awrY = function (a, e, b) {
		base = base || b;
		var S = window.AWRSugest;
		if (a === 'sugestoes' && S) {
			var r = S.sugerir(e && e.q);
			if (r) return Promise.resolve(r);
			/* Índice ainda chegando: espera até 2,5 s em vez de mandar cada letra ao servidor. */
			return Promise.race([S.carregar(), new Promise(function (ok) { setTimeout(ok, 2500); })]).then(function () {
				var r2 = S.sugerir(e && e.q);
				return r2 || vez().then(function () { return b(a, e); });
			}, function () { return vez().then(function () { return b(a, e); }); });
		}
		if (a === 'produtos') return produtos(e || {});
		return vez().then(function () { return b(a, e); });
	};

	/* Ano do clique (mesma regra da função f do awr-search.js). */
	function anoDe(v, digitado) {
		var m = String(digitado || '').match(/\b(19[89]\d|20\d{2})\b/), h = m ? Number(m[0]) : null;
		return h && h >= v.yearStart && h <= v.yearEnd ? h : v.yearEnd;
	}
	/* Sugestões na tela: baixa os arquivos estáticos; no toque, já monta o resultado. */
	window.awrPre = function (lista, digitado, ul) {
		if (!ul) return;
		preparar();
		ul.__awrLista = lista; ul.__awrDig = digitado;
		if (ul.__awrPre) return;
		ul.__awrPre = 1;
		ul.addEventListener('pointerdown', function (x) {
			var li = x.target.closest && x.target.closest('li[data-i]'), v = li && ul.__awrLista && ul.__awrLista[Number(li.dataset.i)];
			if (!base || !v || v.tipo !== 'veiculo' || !v.slug) return;
			produtos({ veiculo: v.slug, ano: anoDe(v, ul.__awrDig) }).catch(function () {});
		}, { passive: true });
	};
	if (window.AWRSugest) window.AWRSugest.carregar();
})();
