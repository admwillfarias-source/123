<?php
/**
 * Cabeçalho do tema — paridade visual com o Header.tsx do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$awr_c     = awr_contact();
$awr_local = awr_local_store();
$awr_embed = 'widget' === awr_current_route() || '1' === (string) get_query_var( 'embed' );
$awr_nav   = array(
	array( 'url' => home_url( '/baterias-de-carro/' ), 'label' => 'Carro' ),
	array( 'url' => home_url( '/baterias-para-moto/' ), 'label' => 'Moto' ),
	array( 'url' => home_url( '/baterias-para-caminhao/' ), 'label' => 'Caminhão' ),
	array( 'url' => home_url( '/baterias-estacionarias/' ), 'label' => 'Estacionária' ),
	array( 'url' => home_url( '/loja/' ), 'label' => 'Loja' ),
	array( 'url' => home_url( '/lojas/' ), 'label' => 'Lojas' ),
);
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php $awr_ga_debug = function_exists( 'awr_ga_debug_active' ) ? awr_ga_debug_active() : false; ?>
	<link rel="preconnect" href="https://www.googletagmanager.com" crossorigin>
	<link rel="preconnect" href="https://www.google-analytics.com" crossorigin>
	<link rel="preconnect" href="https://stats.g.doubleclick.net" crossorigin>
	<link rel="dns-prefetch" href="https://www.googletagmanager.com">
	<!-- Google tag (gtag.js) — fila local + carregamento na 1ª interação/idle (v3.73.0).
	     data-cfasync="false" mantém o Rocket Loader/otimizadores fora deste bloco. -->
	<script data-cfasync="false">
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  // Consent Mode (v5.6.0): medição e publicidade liberadas por padrão — com
	  // 'denied' o Google Ads deixava de registrar boa parte das conversões e o
	  // lance inteligente otimizava às cegas. Um plugin de cookies pode enviar
	  // um 'consent update' depois e sobrescrever estes valores.
	  gtag('consent', 'default', {
	    'analytics_storage': 'granted',
	    'ad_storage': 'granted',
	    'ad_user_data': 'granted',
	    'ad_personalization': 'granted',
	    'functionality_storage': 'granted',
	    'security_storage': 'granted'
	  });
	  gtag('js', new Date());
	  gtag('config', 'G-85HXPD5121'<?php echo $awr_ga_debug ? ", { debug_mode: true }" : ''; ?>);
	  gtag('config', 'AW-994517528'<?php echo $awr_ga_debug ? ", { debug_mode: true }" : ''; ?>);

	  // O gtag.js sai do caminho crítico: os comandos acima (e os cliques do
	  // visitante) ficam na fila do dataLayer e são enviados assim que o
	  // script chega — nenhum evento é perdido.
	  (function(){
	    var loaded = false;
	    function load(){
	      if (loaded) return; loaded = true;
	      var s = document.createElement('script');
	      s.async = true;
	      s.setAttribute('data-cfasync', 'false');
	      s.src = 'https://www.googletagmanager.com/gtag/js?id=G-85HXPD5121<?php echo $awr_ga_debug ? '&debug_mode=true' : ''; ?>';
	      document.head.appendChild(s);
	    }
	    var ev = ['pointerdown','keydown','scroll','touchstart','mousemove'];
	    function on(){ ev.forEach(function(e){ window.removeEventListener(e, on); }); load(); }
	    ev.forEach(function(e){ window.addEventListener(e, on, {passive:true, once:true}); });
	    if ('requestIdleCallback' in window) requestIdleCallback(function(){ setTimeout(load, 1500); }, {timeout:4000}); else setTimeout(load, 4000);
	    setTimeout(load, 5000);
	    // Rede de segurança: visita curtíssima ainda dispara a medição ao sair.
	    window.addEventListener('pagehide', load);
	    document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') load(); });
	  })();
	</script>


	<?php wp_head(); ?>
</head>
<body <?php body_class( $awr_embed ? array( 'awr-body', 'awr-embed' ) : array( 'awr-body' ) ); ?>>
<?php wp_body_open(); ?>
<div id="awr-app" class="awr-app">


<?php if ( ! $awr_embed ) : ?>
<a class="awr-skip" href="#awr-main">Ir para o conteúdo</a>

<header class="awr-header" data-awr-header>
	<div class="awr-container awr-header__inner">
		<a class="awr-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="AWR Baterias — início">
			<?php echo awr_logo_inner( true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</a>

		<nav class="awr-nav" aria-label="Menu principal">
			<ul class="awr-nav__list">
				<?php foreach ( $awr_nav as $item ) : ?>
					<li><a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['label'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</nav>

		<div class="awr-header__cta">
			<button type="button" class="awr-nearest-pill" data-awr-nearest>
				<span class="awr-btn__ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 1 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></span><span data-awr-nearest-label><?php echo $awr_local ? esc_html( 'AWR ' . $awr_local['nome'] ) : 'Loja perto de mim'; ?></span>
			</button>
			<a class="awr-btn awr-btn--navy awr-btn--shine" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>" aria-label="Ligar para <?php echo esc_attr( $awr_c['phone'] ); ?>">
				<span class="awr-btn__ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg></span><span><?php echo esc_html( $awr_c['phone'] ); ?></span>
			</a>
			<a class="awr-btn awr-btn--green awr-btn--shine" target="_top" rel="noopener"
			   href="<?php echo esc_url( awr_wa( 'Olá! Preciso de uma bateria com entrega hoje.' ) ); ?>">
				<span class="awr-btn__ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12.04 2c-5.5 0-9.96 4.46-9.96 9.96 0 1.76.46 3.48 1.34 5L2 22l5.2-1.36a9.9 9.9 0 0 0 4.84 1.24h.01c5.5 0 9.96-4.46 9.96-9.96S17.54 2 12.04 2zm5.83 14.06c-.24.68-1.4 1.3-1.94 1.35-.5.05-1.13.07-1.82-.11-.42-.13-.96-.31-1.65-.61-2.9-1.25-4.8-4.17-4.95-4.37-.14-.2-1.18-1.57-1.18-3s.75-2.13 1.02-2.42c.27-.29.58-.36.78-.36h.56c.18 0 .42-.07.66.5.24.58.82 2 .89 2.15.07.14.12.31.02.5-.09.2-.14.31-.28.48-.14.16-.29.36-.42.49-.14.14-.28.29-.12.57.16.27.71 1.17 1.53 1.9 1.05.94 1.94 1.23 2.21 1.37.27.14.43.12.59-.07.16-.2.68-.79.86-1.07.18-.27.36-.22.6-.13.25.09 1.57.74 1.84.88.27.13.45.2.51.31.07.11.07.63-.17 1.24z"/></svg></span><span>WhatsApp</span>
			</a>
		</div>

		<div class="awr-header__mobile">
			<a class="awr-mbtn awr-mbtn--call" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>" aria-label="Ligar agora"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg><span>Ligar</span></a>
			<a class="awr-mbtn awr-mbtn--wa" target="_top" rel="noopener" aria-label="Falar no WhatsApp"
			   href="<?php echo esc_url( awr_wa( 'Olá! Preciso de uma bateria.' ) ); ?>"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12.04 2c-5.5 0-9.96 4.46-9.96 9.96 0 1.76.46 3.48 1.34 5L2 22l5.2-1.36a9.9 9.9 0 0 0 4.84 1.24h.01c5.5 0 9.96-4.46 9.96-9.96S17.54 2 12.04 2zm5.83 14.06c-.24.68-1.4 1.3-1.94 1.35-.5.05-1.13.07-1.82-.11-.42-.13-.96-.31-1.65-.61-2.9-1.25-4.8-4.17-4.95-4.37-.14-.2-1.18-1.57-1.18-3s.75-2.13 1.02-2.42c.27-.29.58-.36.78-.36h.56c.18 0 .42-.07.66.5.24.58.82 2 .89 2.15.07.14.12.31.02.5-.09.2-.14.31-.28.48-.14.16-.29.36-.42.49-.14.14-.28.29-.12.57.16.27.71 1.17 1.53 1.9 1.05.94 1.94 1.23 2.21 1.37.27.14.43.12.59-.07.16-.2.68-.79.86-1.07.18-.27.36-.22.6-.13.25.09 1.57.74 1.84.88.27.13.45.2.51.31.07.11.07.63-.17 1.24z"/></svg></a>
			<button class="awr-mbtn awr-mbtn--menu" type="button" data-awr-menu-toggle aria-expanded="false" aria-controls="awr-sheet" aria-label="Abrir menu"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>
		</div>
	</div>
</header>
<?php /* Fora do <header> (blur): no celular vira aviso flutuante acima da barra inferior, como no app. */ ?>
<div class="awr-geo-banner" data-awr-geo-banner hidden></div>

<div class="awr-sheet" id="awr-sheet" data-awr-sheet hidden>
	<div class="awr-sheet__overlay" data-awr-sheet-close></div>
	<aside class="awr-sheet__panel" role="dialog" aria-modal="true" aria-label="Menu">
		<div class="awr-sheet__head">
			<span class="awr-logo"><?php echo awr_logo_inner( false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<button type="button" class="awr-sheet__close" data-awr-sheet-close aria-label="Fechar menu">×</button>
		</div>

		<nav class="awr-sheet__nav" aria-label="Menu mobile">
			<?php foreach ( $awr_nav as $item ) : ?>
				<a href="<?php echo esc_url( $item['url'] ); ?>"><?php echo esc_html( $item['label'] ); ?></a>
			<?php endforeach; ?>
		</nav>

		<div class="awr-sheet__store" data-awr-sheet-store>
			<button type="button" class="awr-btn awr-btn--location awr-sheet__geo" data-awr-nearest><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 1 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg> Usar minha localização</button>
		</div>

		<div class="awr-sheet__cta">
			<a class="awr-btn awr-btn--navy awr-btn--xl" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg> Ligar <?php echo esc_html( $awr_c['phone'] ); ?></a>
			<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Preciso de uma bateria.' ) ); ?>"><svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M12.04 2c-5.5 0-9.96 4.46-9.96 9.96 0 1.76.46 3.48 1.34 5L2 22l5.2-1.36a9.9 9.9 0 0 0 4.84 1.24h.01c5.5 0 9.96-4.46 9.96-9.96S17.54 2 12.04 2zm5.83 14.06c-.24.68-1.4 1.3-1.94 1.35-.5.05-1.13.07-1.82-.11-.42-.13-.96-.31-1.65-.61-2.9-1.25-4.8-4.17-4.95-4.37-.14-.2-1.18-1.57-1.18-3s.75-2.13 1.02-2.42c.27-.29.58-.36.78-.36h.56c.18 0 .42-.07.66.5.24.58.82 2 .89 2.15.07.14.12.31.02.5-.09.2-.14.31-.28.48-.14.16-.29.36-.42.49-.14.14-.28.29-.12.57.16.27.71 1.17 1.53 1.9 1.05.94 1.94 1.23 2.21 1.37.27.14.43.12.59-.07.16-.2.68-.79.86-1.07.18-.27.36-.22.6-.13.25.09 1.57.74 1.84.88.27.13.45.2.51.31.07.11.07.63-.17 1.24z"/></svg> WhatsApp</a>
		</div>
	</aside>
</div>
<?php endif; ?>

<main id="awr-main" class="awr-main">
