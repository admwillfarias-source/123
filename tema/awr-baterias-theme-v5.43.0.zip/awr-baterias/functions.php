<?php
/**
 * AWR Baterias — tema WordPress (porte do app Speedy Battery Connect).
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'AWR_VERSION', '5.43.0' );
define( 'AWR_DIR', get_stylesheet_directory() );

// Precisa vir antes de AWR_URI: normaliza o esquema quando o site está atrás
// de proxy/CDN e o WordPress ainda gera URLs em http:// (Mixed Content).
require_once AWR_DIR . '/inc/https.php';

define( 'AWR_URI', awr_force_https( get_stylesheet_directory_uri() ) );

require_once AWR_DIR . '/inc/precos.php';
require_once AWR_DIR . '/inc/data.php';
require_once AWR_DIR . '/inc/editorial.php';
require_once AWR_DIR . '/inc/comercial.php';
require_once AWR_DIR . '/inc/cidades-conteudo.php';
require_once AWR_DIR . '/inc/cidades-servicos.php';
require_once AWR_DIR . '/inc/estacionaria-regiao.php';
require_once AWR_DIR . '/inc/city-delivery.php';

require_once AWR_DIR . '/inc/delivery.php';
require_once AWR_DIR . '/inc/tabela-baterias.php';
require_once AWR_DIR . '/inc/garantia-oficial.php';
require_once AWR_DIR . '/inc/garantia.php';
require_once AWR_DIR . '/inc/search.php';
require_once AWR_DIR . '/inc/vehicle-city.php';
require_once AWR_DIR . '/inc/moto.php';
require_once AWR_DIR . '/inc/woo.php';
require_once AWR_DIR . '/inc/merchant.php';
require_once AWR_DIR . '/inc/merchant-gtin.php';
require_once AWR_DIR . '/inc/merchant-produtos.php';
if ( file_exists( AWR_DIR . '/inc/merchant-inventario.php' ) ) { require_once AWR_DIR . '/inc/merchant-inventario.php'; }
if ( file_exists( AWR_DIR . '/inc/perf-plugins.php' ) ) { require_once AWR_DIR . '/inc/perf-plugins.php'; }
if ( file_exists( AWR_DIR . '/inc/merchant-feed-filtro.php' ) ) { require_once AWR_DIR . '/inc/merchant-feed-filtro.php'; }
if ( file_exists( AWR_DIR . '/inc/merchant-titulo.php' ) ) { require_once AWR_DIR . '/inc/merchant-titulo.php'; }
require_once AWR_DIR . '/inc/shop.php';
require_once AWR_DIR . '/inc/search-api.php';
require_once AWR_DIR . '/inc/rewrites.php';
require_once AWR_DIR . '/inc/frontpage.php';
require_once AWR_DIR . '/inc/rest.php';
require_once AWR_DIR . '/inc/places.php';
require_once AWR_DIR . '/inc/isolation.php';

require_once AWR_DIR . '/inc/redirects.php';
require_once AWR_DIR . '/inc/produtos-perdidos.php';
require_once AWR_DIR . '/inc/seo.php';
require_once AWR_DIR . '/inc/seo-native.php';
require_once AWR_DIR . '/inc/seo-lote.php';
require_once AWR_DIR . '/inc/seo-indexacao.php';
require_once AWR_DIR . '/inc/schema-shop.php';
require_once AWR_DIR . '/inc/analytics.php';
require_once AWR_DIR . '/inc/desempenho.php';
require_once AWR_DIR . '/inc/perf.php';
require_once AWR_DIR . '/inc/assets.php';
require_once AWR_DIR . '/inc/queries.php';
require_once AWR_DIR . '/inc/health.php';
require_once AWR_DIR . '/inc/validacao.php';
require_once AWR_DIR . '/inc/debug-early.php';
if ( file_exists( AWR_DIR . '/inc/frete-cep.php' ) ) { require_once AWR_DIR . '/inc/frete-cep.php'; }

/** Empresa — espelha src/lib/contact.ts do app. */
function awr_company() {
	$comercial = awr_data( 'comercial' );
	return array(
		'cnpj' => $comercial['empresa']['cnpj'] ?? '',
		'razao_social' => $comercial['empresa']['razaoSocial'] ?? '',
		'name'            => 'AWR Baterias',
		'phone'           => '(51) 3516-5472',
		'phone_href'      => 'tel:+555135165472',
		'whatsapp'        => '(51) 99319-9486',
		'whatsapp_number' => '5551993199486',
		'city'            => 'Porto Alegre',
		'region'          => 'RS',
		'country'         => 'BR',
		'email'           => 'vendas@awrbaterias.com.br',
		'lat'             => -30.0346,
		'lng'             => -51.2177,
		'rating'          => '4.9',
		'reviews'         => '1935',
		'reviews_url'     => 'https://www.google.com/maps/search/?api=1&query=AWR+Baterias+Porto+Alegre',
	);
}

/**
 * Link de WhatsApp com mensagem pré-preenchida.
 *
 * v5.6.0 — a mensagem leva cidade e página de origem, para o atendente já
 * saber de onde o cliente veio e a AWR conseguir atribuir a venda ao canal.
 */
function awr_wa( $msg, $contexto = true ) {
	$c = function_exists( 'awr_contact' ) ? awr_contact() : awr_company();
	if ( $contexto && ! is_admin() ) {
		$partes = array();
		$loja   = function_exists( 'awr_local_store' ) ? awr_local_store() : null;
		if ( $loja && ! empty( $loja['cidade'] ) ) { $partes[] = $loja['cidade']; }
		$rota = function_exists( 'awr_current_route' ) ? (string) awr_current_route() : '';
		if ( $rota ) { $partes[] = $rota; }
		if ( $partes ) { $msg .= "\n(origem: " . implode( ' · ', $partes ) . ')'; }
	}
	return 'https://wa.me/' . $c['whatsapp_number'] . '?text=' . rawurlencode( $msg );
}

/**
 * Mensagem curta de pedido em 1 clique (v3.86.0).
 *
 * Só o essencial para o atendente identificar o pedido: bateria e veículo.
 * Preço, Pix, parcelamento, prazo e link saíram — a conversa continua no chat.
 *
 * @param array  $p       Produto (sku, name, brand, price, amperagem).
 * @param string $veiculo Veículo/ano da busca, quando houver.
 * @param string $url     Mantido por compatibilidade; não entra na mensagem.
 */
function awr_wa_pedido_msg( $p, $veiculo = '', $url = '' ) {
	unset( $url );
	$nome   = (string) ( ( $p['name'] ?? '' ) ?: trim( ( $p['brand'] ?? '' ) . ' ' . ( $p['sku'] ?? '' ) ) );
	$amp    = (string) ( $p['amperagem'] ?? '' );
	$linhas = array( 'Olá! Quero PEDIR esta bateria:' );
	$linhas[] = '• ' . $nome . ( $amp ? ' (' . $amp . ' Ah)' : '' ) . ' — SKU ' . ( $p['sku'] ?? '' );
	if ( $veiculo ) { $linhas[] = '• Veículo: ' . $veiculo; }

	return implode( "\n", $linhas );
}

/** URL da página atual, usada nas mensagens de pedido. */
function awr_current_url() {
	$host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
	return $host ? 'https://' . $host . $uri : home_url( '/' );
}


add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'awr', AWR_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'custom-logo', array(
		'height'      => 80,
		'width'       => 320,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	register_nav_menus( array(
		'primary' => __( 'Menu principal', 'awr' ),
		'footer'  => __( 'Rodapé', 'awr' ),
	) );
} );

/**
 * Logo do cabeçalho: usa a imagem enviada em Personalizar > Identidade do site
 * quando existir; caso contrário mantém o selo + texto padrão do tema.
 *
 * @param bool $with_mark Exibe o selo quando não há imagem.
 */
function awr_logo_inner( $with_mark = true ) {
	$id  = (int) get_theme_mod( 'custom_logo' );
	$img = $id ? wp_get_attachment_image( $id, 'full', false, array(
		'class'         => 'awr-logo__img',
		'alt'           => esc_attr( get_bloginfo( 'name' ) . ' — logo' ),
		'fetchpriority' => 'high',
		'decoding'      => 'async',
	) ) : '';

	if ( $img ) {
		return $img;
	}

	$mark = $with_mark ? '<span class="awr-logo__mark" aria-hidden="true"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 7h1a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2h-1"/><path d="M6 7H5a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h1"/><path d="M22 11v2"/><path d="m11 7-3 5h4l-3 5"/></svg></span>' : '';

	return $mark . '<span class="awr-logo__text"><b>AWR</b>BATERIAS</span>';
}

/** Ícone SVG do WhatsApp usado nos botões verdes. */
function awr_wa_icon( $size = 17 ) {
	$s = (int) $size;
	return '<svg viewBox="0 0 24 24" width="' . $s . '" height="' . $s . '" fill="currentColor" aria-hidden="true"><path d="M12.04 2C6.6 2 2.2 6.4 2.2 11.84c0 1.94.52 3.76 1.42 5.32L2 22l4.98-1.58a9.8 9.8 0 0 0 5.06 1.4h.01c5.43 0 9.83-4.4 9.83-9.84C21.88 6.4 17.47 2 12.04 2Zm5.72 13.9c-.24.68-1.4 1.3-1.93 1.34-.5.05-.96.23-3.23-.67-2.72-1.07-4.44-3.84-4.57-4.02-.13-.18-1.09-1.45-1.09-2.77 0-1.32.69-1.96.94-2.23.24-.27.53-.34.7-.34h.5c.16 0 .38-.06.59.45.24.57.8 1.98.87 2.12.07.14.11.3.02.48-.09.18-.13.3-.27.46l-.4.47c-.13.13-.27.28-.12.55.15.27.66 1.1 1.42 1.77.98.87 1.8 1.14 2.06 1.27.26.14.41.11.56-.07.15-.18.64-.75.81-1.01.18-.27.35-.22.59-.13.24.09 1.5.71 1.76.84.26.13.43.2.5.32.06.11.06.65-.18 1.33Z"/></svg>';
}

/**
 * Versão do asset baseada no mtime do arquivo — evita que CDN/cache de plugin
 * continue servindo o CSS antigo depois de atualizar o tema.
 */
function awr_asset_ver( $rel ) {
	$path = AWR_DIR . '/' . ltrim( $rel, '/' );
	return file_exists( $path ) ? AWR_VERSION . '.' . filemtime( $path ) : AWR_VERSION;
}

/** Existe bundle único de CSS gerado no empacotamento? */
function awr_css_bundle() {
	static $rel = null;
	if ( null !== $rel ) { return $rel; }
	$rel = file_exists( AWR_DIR . '/assets/css/awr-bundle.css' ) ? 'assets/css/awr-bundle.css' : '';
	return $rel;
}

add_action( 'wp_enqueue_scripts', function () {
	// Fontes hospedadas no tema (inline em inc/assets.php) — sem Google Fonts.


	$bundle = awr_css_bundle();
	if ( $bundle ) {
		// 1 requisição no lugar de 5 (style + awr + v3 + overrides + parity).
		wp_enqueue_style( 'awr-parity', AWR_URI . '/' . $bundle, array(), awr_asset_ver( $bundle ) );
	} else {
		wp_enqueue_style( 'awr-style', AWR_URI . '/style.css', array(), awr_asset_ver( 'style.css' ) );
		wp_enqueue_style( 'awr-main', AWR_URI . '/assets/css/awr.css', array( 'awr-style' ), awr_asset_ver( 'assets/css/awr.css' ) );
		wp_enqueue_style( 'awr-v3', AWR_URI . '/assets/css/awr-v3.css', array( 'awr-main' ), awr_asset_ver( 'assets/css/awr-v3.css' ) );
	}

	// Núcleo leve em todas as páginas; busca/checkout (awr-search.js) sobem
	// sob demanda no 1º foco/clique, ou pré-carregados no idle.
	wp_enqueue_script( 'awr-core', AWR_URI . '/assets/js/awr-core.js', array(), awr_asset_ver( 'assets/js/awr-core.js' ), true );
	wp_script_add_data( 'awr-core', 'defer', true );


	$c = awr_company();
	// O nonce do REST só é necessário nas telas que gravam algo (busca/checkout).
	$route       = awr_current_route();
	$needs_nonce = is_user_logged_in() || in_array( $route, array( 'pedido', 'buscar', 'produto', 'sku', 'widget' ), true )
		|| ( function_exists( 'is_checkout' ) && ( is_checkout() || is_cart() ) );
	wp_localize_script( 'awr-core', 'AWR', array(
		'restUrl'   => esc_url_raw( rest_url( 'awr/v1/' ) ),
		'searchUrl' => esc_url_raw( awr_search_api_url() ),
		'searchJs'  => awr_asset_cached_url( AWR_URI . '/assets/js/awr-search.js?ver=' . awr_asset_ver( 'assets/js/awr-search.js' ) ),
		'checkoutCss' => awr_asset_cached_url( AWR_URI . '/assets/css/awr-checkout-app.css?ver=' . awr_asset_ver( 'assets/css/awr-checkout-app.css' ) ),
		'nonce'     => $needs_nonce ? wp_create_nonce( 'wp_rest' ) : '',
		'home'      => home_url( '/' ),
		'buscarUrl' => home_url( '/buscar/' ),
		'dataUrl'   => AWR_URI . '/assets/data/',
		'whatsapp'  => $c['whatsapp_number'],
		'phoneHref' => $c['phone_href'],
		'hasWoo'    => class_exists( 'WooCommerce' ),
		// 5.43.0 — ao resolver a busca, abre o checkout da 1ª bateria recomendada.
		// Desligar: add_filter( 'awr_auto_checkout', '__return_false' );
		'autoCheckout' => (bool) apply_filters( 'awr_auto_checkout', true ),
	) );
} );


/**
 * Camada de blindagem visual — enfileirada por último (prioridade 999) para
 * vencer CSS de Elementor/plugins que sobrescreve fonte e cor dos botões.
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( ! awr_css_bundle() ) {
		wp_enqueue_style(
			'awr-overrides',
			AWR_URI . '/assets/css/awr-overrides.css',
			array( 'awr-v3' ),
			awr_asset_ver( 'assets/css/awr-overrides.css' )
		);
		// Camada final de paridade com o app (vence qualquer CSS de terceiros).
		wp_enqueue_style(
			'awr-parity',
			AWR_URI . '/assets/css/awr-parity.css',
			array( 'awr-overrides' ),
			awr_asset_ver( 'assets/css/awr-parity.css' )
		);
	}
	// awr-checkout-app.css NÃO entra aqui: carrega sob demanda junto com o
	// awr-search.js (1ª interação com busca/checkout) — ~10 KB fora do crítico.

	// Carrega somente a camada específica exigida pela rota atual.
	$dep = 'awr-parity';

	$route = awr_current_route();
	// Cada grupo corresponde a um arquivo assets/css/pages-{grupo}.css.
	// Uma rota precisa constar em TODOS os grupos cujas classes ela usa
	// (ex.: marca_cidade monta o hero com classes awrm-* de pages-marca.css).
	$groups_by_route = array(
		'lojas' => array( 'lojas', 'loja', 'hub_bairros' ),
		'cidade' => array( 'cidade', 'cidade_venda', 'bairro', 'hub_bairros', 'veiculo_cidade', 'marca_cidade', 'segmento_cidade', 'segmento_bairro' ),
		'marca' => array( 'marca', 'hub_marcas', 'marca_cidade' ),
		'conteudo' => array( 'blog', 'post', 'parceiros', 'comparar', 'garantia', 'rastrear_pedido', 'central_tecnica', 'b2b', 'domicilio', 'perto_de_mim', 'socorro' ),
		'hubs' => array( 'baterias_de_carro', 'segmento', 'segmento_cidade', 'segmento_bairro', 'hub_cidades', 'hub_aplicacoes', 'hub_amperagens', 'hub_skus', 'hub_skus_page', 'hub_categorias', 'hub_ramos', 'amperagem', 'aplicacao', 'ramo', 'categoria', 'cidade_venda', 'b2b', 'shop' ),
		'estacionaria' => array( 'segmento', 'segmento_cidade', 'segmento_bairro' ),
	);
	$grupos = array();
	foreach ( $groups_by_route as $group => $routes ) {
		if ( in_array( $route, $routes, true ) ) { $grupos[] = $group; }
	}
	foreach ( $grupos as $grupo ) {
		$rel = 'assets/css/pages-' . $grupo . '.css';
		if ( ! file_exists( AWR_DIR . '/' . $rel ) ) { continue; }
		$handle = 'awr-page-' . $grupo;
		wp_enqueue_style( $handle, AWR_URI . '/' . $rel, array( $dep ), awr_asset_ver( $rel ) );
		$dep = $handle;
	}
	// Correção visual definitiva: precisa vir depois de todos os CSS específicos
	// de rota, que ainda contêm as antigas regras azuis.
	wp_enqueue_style(
		'awr-final',
		AWR_URI . '/assets/css/awr-final.css',
		array( $dep ),
		awr_asset_ver( 'assets/css/awr-final.css' )
	);
}, 999 );


/** Body classes úteis para o CSS das rotas virtuais. */
add_filter( 'body_class', function ( $classes ) {
	$classes[] = 'awr-body';
	$route = awr_current_route();
	if ( $route ) { $classes[] = 'awr-route-' . sanitize_html_class( $route ); }
	return $classes;
} );

/** Widgets do rodapé. */
add_action( 'widgets_init', function () {
	register_sidebar( array(
		'name'          => __( 'Rodapé', 'awr' ),
		'id'            => 'awr-footer',
		'before_widget' => '<div class="awr-fwidget">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="awr-fwidget__title">',
		'after_title'   => '</h3>',
	) );
} );

/**
 * Fallback de tradução: alguns plugins carregam texto antes da hora e o
 * WordPress 6.8 passa a avisar. Recarregar em `init` mantém as strings
 * disponíveis sem depender do momento em que o plugin dispara.
 */
add_action( 'init', function () {
	load_theme_textdomain( 'awr', AWR_DIR . '/languages' );
}, 0 );

/** Helper de template. */
function awr_part( $slug, $args = array() ) {
	static $stack = array();
	// Apenas "nome-do-arquivo" — bloqueia ../, barras e caminhos absolutos.
	if ( ! is_string( $slug ) || ! preg_match( '/^[a-z0-9][a-z0-9-]*$/', $slug ) ) { return; }
	if ( in_array( $slug, $stack, true ) ) { return; } // trava contra recursão de includes.

	$stack[] = $slug;
	try {
		get_template_part( 'template-parts/' . $slug, null, $args );
	} catch ( Throwable $awr_tpl_err ) {
		// ParseError/Error dentro de um template não pode derrubar a página inteira
		// (HTTP 500 = página some do índice do Google). Registra no log e segue.
		error_log( sprintf( '[AWR] Falha no template-parts/%s.php: %s', $slug, $awr_tpl_err->getMessage() ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions
	} finally {
		array_pop( $stack );
	}
}

/**
 * A busca (widget único da página) já foi renderizada?
 * Evita IDs duplicados quando o hero traz a faixa de busca e a rota
 * também chamava o bloco de busca mais abaixo.
 *
 * @param bool $mark Marca como renderizada.
 */
function awr_search_rendered( $mark = false ) {
	static $done = false;
	if ( $mark ) { $done = true; }
	return $done;
}

/** A rota atual é de baterias estacionárias? */
function awr_is_estacionaria_route() {
	$route = function_exists( 'awr_current_route' ) ? awr_current_route() : '';
	if ( ! in_array( $route, array( 'segmento', 'segmento_cidade', 'segmento_bairro' ), true ) ) { return false; }
	$path = (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ); // phpcs:ignore WordPress.Security.NonceVerification
	return false !== strpos( $path, 'estacionaria' );
}

/**
 * A página atual deve exibir a faixa de busca do padrão da home?
 * Regra: sim nas páginas automotivas, de carro, moto e caminhão;
 * não nas estacionárias, na home e nas telas transacionais.
 */
function awr_show_searchband() {
	$route = function_exists( 'awr_current_route' ) ? awr_current_route() : '';
	// As rotas virtuais (cidade, lojas, blog, hubs...) mantêm a query principal
	// do WordPress como "início do blog": is_home() é true e escondia a busca
	// em todas as páginas internas. Com rota AWR ativa, quem decide é a rota.
	if ( ! $route && ( is_front_page() || is_home() ) ) { return false; }
	if ( in_array( $route, array( 'home', 'front', 'frontpage' ), true ) ) { return false; }
	if ( in_array( $route, array( 'widget', 'pedido', 'buscar' ), true ) ) { return false; }
	if ( function_exists( 'is_checkout' ) && ( is_checkout() || is_cart() ) ) { return false; }
	if ( awr_is_estacionaria_route() ) { return false; }
	return (bool) apply_filters( 'awr_show_searchband', true, $route );
}

/** Formata preço em BRL. */
function awr_brl( $value ) {
	return 'R$ ' . number_format( (float) $value, 2, ',', '.' );
}

/* ---------------------------------------------------------------------
   v3.53.0 — checagem diária automática de headers (cache/compressão)
   --------------------------------------------------------------------- */

/** Agenda ao ativar o tema. */
add_action( 'after_switch_theme', function () {
	if ( ! wp_next_scheduled( 'awr_header_check_cron' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'awr_header_check_cron' );
	}
} );

/** Cobre instalações onde o tema já estava ativo antes da v3.53.0. */
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'awr_header_check_cron' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'awr_header_check_cron' );
	}
}, 20 );

/** Limpa o agendamento ao trocar de tema. */
add_action( 'switch_theme', function () {
	wp_clear_scheduled_hook( 'awr_header_check_cron' );
} );
