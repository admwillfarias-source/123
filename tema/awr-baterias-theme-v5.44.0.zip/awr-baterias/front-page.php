<?php
/**
 * Home nativa v3 — paridade 1:1 com src/routes/index.tsx do app.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$awr_c = awr_company();
?>

<section class="awr-hero">
	<div class="awr-container awr-hero__grid">
		<div class="awr-hero__copy">
			<p class="awr-hero__kicker awr-hide-mobile">⚡ PEÇA AGORA A SUA BATERIA</p>
			<h1 class="awr-hero__title">
				Bateria arriou? Não fique parado! <strong>A AWR leva e instala sua bateria em até 35 minutos!</strong>
			</h1>
			<p class="awr-hero__rating">★ <?php echo esc_html( $awr_c['rating'] ); ?>/5 no Google · <?php echo esc_html( $awr_c['reviews'] ); ?>+ avaliações</p>

			<p class="awr-hero__socorro awr-only-mobile">Baterias para carros, motos e caminhões, entregues e instaladas onde você estiver. <a target="_top" rel="noopener" data-awr-source="hero_subtitulo" href="<?php echo esc_url( awr_wa( 'Olá! Minha bateria arriou. Quero pedir uma bateria com entrega e instalação agora.' ) ); ?>">Peça agora</a> e volte a rodar!</p>

			<p class="awr-hero__lead awr-hide-mobile">Baterias para carros, motos e caminhões, entregues e instaladas onde você estiver. <a target="_top" rel="noopener" data-awr-source="hero_subtitulo" href="<?php echo esc_url( awr_wa( 'Olá! Minha bateria arriou. Quero pedir uma bateria com entrega e instalação agora.' ) ); ?>">Peça agora</a> e volte a rodar!</p>
			<div class="awr-hero__ctas">
				<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Quero pedir uma bateria com entrega hoje.' ) ); ?>"><svg aria-hidden="true" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/></svg>Pedir Bateria Agora <span aria-hidden="true">→</span></a>
				<a class="awr-btn awr-btn--outline awr-btn--xl" href="<?php echo esc_url( home_url( '/buscar/' ) ); ?>"><svg aria-hidden="true" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>Ver Preços</a>
			</div>

			<?php // Avisos de prazo/horário ocultos na home (mantidos no checkout e nas páginas internas). ?>

			<p class="awr-hero__phone"><a href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>" aria-label="Ligar para a central <?php echo esc_attr( $awr_c['phone'] ); ?>"><svg aria-hidden="true" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>Ou ligue para nossa central</a></p>

			<?php // Diagnóstico gratuito — o tema não tem a rota /diagnostico do app, então leva ao WhatsApp. ?>
			<p class="awr-hero__diag"><a target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Não sei se o problema é a bateria. Quero fazer o diagnóstico grátis.' ) ); ?>"><svg aria-hidden="true" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/></svg>Não sabe se é a bateria? Faça o diagnóstico grátis</a></p>

			<ul class="awr-hero__badges awr-hero__stats">
				<li><a href="<?php echo esc_url( $awr_c['reviews_url'] ); ?>" target="_blank" rel="noopener" aria-label="Ver avaliações no Google"><span class="awr-hero__star" aria-hidden="true">★</span><strong><?php echo esc_html( str_replace( '.', ',', $awr_c['rating'] ) ); ?>/5</strong> Google <span class="awr-hero__muted">(<?php echo esc_html( number_format_i18n( (int) $awr_c['reviews'] ) ); ?>+ clientes)</span></a></li>
				<li><svg aria-hidden="true" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg><strong>17 anos</strong> de mercado</li>
				<li><svg aria-hidden="true" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg><strong>100%</strong> garantia</li>
			</ul>
		</div>

		<div class="awr-hero__searchslot">
			<?php
			// Foto do hero (técnico AWR com a Moura AGM) — arquivos do próprio tema, sem
			// depender de outro domínio. Só o computador baixa a foto: no celular o <img>
			// fica com um pixel vazio e nada é baixado (o topo carrega mais rápido).
			// Se o arquivo faltar ou não carregar, o bloco some e a busca sobe — nunca
			// aparece imagem quebrada.
			$awr_hero_dir = '/assets/img/hero-awr-moura-';
			$awr_hero_ok  = file_exists( AWR_DIR . $awr_hero_dir . '960.webp' );
			?>
			<?php if ( $awr_hero_ok ) : ?>
			<picture class="awr-hero__art">
				<source media="(min-width: 1024px)" type="image/webp" srcset="<?php echo esc_url( AWR_URI . $awr_hero_dir . '640.webp' ); ?> 640w, <?php echo esc_url( AWR_URI . $awr_hero_dir . '960.webp' ); ?> 960w" sizes="(min-width: 1280px) 525px, 42vw">
				<source media="(min-width: 1024px)" type="image/jpeg" srcset="<?php echo esc_url( AWR_URI . $awr_hero_dir . '960.jpg' ); ?>">
				<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="Técnico da AWR Baterias segurando uma bateria Moura AGM — entrega e instalação em até 35 minutos" width="960" height="960" fetchpriority="high" decoding="async" onerror="this.parentNode.style.display='none'">
			</picture>
			<?php endif; ?>
			<div class="awr-hero__search">
				<span class="awr-hero__search-tag">Busque sua bateria aqui</span>
				<?php awr_part( 'search', array( 'autofocus' => false, 'titulo' => '', 'compact' => true ) ); ?>
				<p class="awr-hero__search-note">Sem cadastro. Preço final com instalação inclusa.</p>
			</div>
		</div>

	</div>
</section>




<?php
// Ordem igual à do app: tríade → Automotiva/Energia + emergência → segmentos.
awr_part( 'trustbar' );
awr_part( 'emergencia' );
?>

<section class="awr-sec awr-segmentos-home">
	<div class="awr-container">
		<div class="awr-sec__head"><h2 class="awr-section-title">Encontre a bateria pela sua necessidade</h2><p>Cada linha tem seleção, produtos e atendimento próprios.</p></div>
		<div class="awr-segmentos-home__grid">
			<a href="<?php echo esc_url( home_url( '/baterias-de-carro/' ) ); ?>"><span aria-hidden="true">🚗</span><h3>Bateria de carro</h3><p>Busque pelo modelo e ano. Convencional, EFB e AGM.</p><b>Preço e instalação no local</b></a>
			<a href="<?php echo esc_url( home_url( '/baterias-estacionarias/' ) ); ?>"><span aria-hidden="true">🔋</span><h3>Bateria estacionária</h3><p>Nobreak, solar, telecom, segurança e empresas.</p><b>Dimensionamento e entrega</b></a>
			<a href="<?php echo esc_url( home_url( '/baterias-para-moto/' ) ); ?>"><span aria-hidden="true">🏍️</span><h3>Bateria de moto</h3><p>Seleção própria por marca, modelo e ano da moto.</p><b>5Ah a 12Ah</b></a>
			<a href="<?php echo esc_url( home_url( '/baterias-para-caminhao/' ) ); ?>"><span aria-hidden="true">🚚</span><h3>Bateria de caminhão</h3><p>Caminhão, carreta, ônibus, máquinas e frotas.</p><b>100Ah a 225Ah · 12V/24V</b></a>
		</div>
	</div>
</section>

<?php
awr_part( 'como-funciona-grid' );
awr_part( 'use-cases' );
awr_part( 'google-reviews' );
awr_part( 'stats-strip' );
?>

<section class="awr-brands">
	<div class="awr-container">
		<div class="awr-sec__head">
			<p class="awr-eyebrow">REVENDEDOR AUTORIZADO</p>
			<h2 class="awr-section-title">Baterias Moura, Heliar, Zetta e Excell em Porto Alegre</h2>
			<p>Baterias originais, com nota fiscal e garantia registrada de fábrica.</p>
		</div>
		<div class="awr-brands__grid">
			<?php foreach ( awr_marcas() as $mk ) : ?>
				<a href="<?php echo esc_url( home_url( '/marca/' . $mk['slug'] . '/' ) ); ?>">
					<b><?php echo esc_html( $mk['nome'] ); ?></b>
					<span><?php echo esc_html( $mk['tagline'] ?? 'Garantia de fábrica' ); ?></span>
				</a>
			<?php endforeach; ?>
			<a href="<?php echo esc_url( home_url( '/buscar/' ) ); ?>">
				<b>Ver todas</b><span>Compare modelos e preços</span>
			</a>
		</div>
	</div>
</section>

<section class="awr-sec awr-services">
	<div class="awr-container">
		<div class="awr-sec__head">
			<h2 class="awr-section-title">Tudo o que fazemos no local</h2>
			<p>Serviço completo, sem guincho e sem levar o carro até a loja.</p>
		</div>
		<div class="awr-services__grid">
			<?php
			$awr_servicos = array(
				array( '🔋', 'Troca de bateria', 'ENTREGA EM 35 MIN', 'Bateria nova instalada e testada onde o carro estiver.' ),
				array( '🧪', 'Teste de bateria e alternador', 'GRÁTIS', 'Diagnóstico completo antes de trocar qualquer peça.' ),
				array( '⚡', 'Baterias start-stop', 'AGM E EFB', 'Instalação com codificação correta para o sistema.' ),
				array( '🚚', 'Socorro no local', 'CASA, TRABALHO OU RUA', 'Atendimento em toda Porto Alegre e Grande POA.' ),
				array( '♻️', 'Compra do casco velho', 'DESCONTO NA HORA', 'Abatemos o valor do casco conforme a amperagem.' ),
				array( '🧾', 'Nota fiscal e garantia', 'ATÉ 24 MESES', 'Garantia de fábrica registrada em seu nome.' ),
			);
			foreach ( $awr_servicos as $s ) :
				?>
				<article>
					<span class="awr-services__ico" aria-hidden="true"><?php echo esc_html( $s[0] ); ?></span>
					<div>
						<p class="awr-services__eyebrow"><?php echo esc_html( $s[2] ); ?></p>
						<h3><?php echo esc_html( $s[1] ); ?></h3>
						<p><?php echo esc_html( $s[3] ); ?></p>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="awr-benefits">
	<div class="awr-container">
		<div class="awr-sec__head">
			<h2 class="awr-section-title">Por que escolher a AWR Baterias</h2>
			<p>Mais de 10 mil motoristas atendidos em Porto Alegre e região.</p>
		</div>
		<ul>
			<?php
			$awr_benef = array(
				array( '⏱️', 'Entrega em 35 minutos', 'Do pedido ao carro ligando' ),
				array( '🛠️', 'Instalação grátis', 'Equipe própria e certificada' ),
				array( '🛡️', 'Garantia de até 24 meses', 'Marcas originais e nota fiscal' ),
				array( '💳', 'Pague na entrega', 'Pix, débito e 10x sem juros' ),
			);
			foreach ( $awr_benef as $b ) :
				?>
				<li>
					<span class="awr-benefits__ico" aria-hidden="true"><?php echo esc_html( $b[0] ); ?></span>
					<b><?php echo esc_html( $b[1] ); ?></b>
					<span><?php echo esc_html( $b[2] ); ?></span>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<section class="awr-sec awr-sec--soft">
	<div class="awr-container">
		<div class="awr-sec__head"><h2 class="awr-section-title">Nossas lojas físicas</h2><p>Seis unidades para atender Porto Alegre e a Região Metropolitana.</p></div>
		<div class="awr-cities__grid">
			<?php foreach ( awr_stores() as $awr_store ) : ?>
				<a href="<?php echo esc_url( home_url( '/lojas/' . $awr_store['slug'] . '/' ) ); ?>">
					<h3 class="awr-cities__nome">AWR Baterias em <?php echo esc_html( $awr_store['cidade'] . ' — ' . $awr_store['bairro'] ); ?></h3>
					<span><?php echo esc_html( $awr_store['endereco'] ); ?></span><small>Ver unidade e telefone</small>
				</a>
			<?php endforeach; ?>
		</div>
		<p class="awr-cities__more"><a href="<?php echo esc_url( home_url( '/lojas/' ) ); ?>">Ver todas as lojas →</a></p>
	</div>
</section>

<?php // Depoimentos manuais removidos (bloco já estava desligado) — o app mostra só avaliações reais do Google. ?>

<section class="awr-sec awr-cities">
	<div class="awr-container">
		<div class="awr-sec__head">
			<h2 class="awr-section-title">Entrega de bateria em Porto Alegre e Região Metropolitana</h2>
			<p>Cobertura em Porto Alegre e toda a Região Metropolitana.</p>
		</div>
		<div class="awr-cities__grid">
			<?php foreach ( awr_cidades() as $cid ) : ?>
				<a href="<?php echo esc_url( home_url( '/baterias-em/' . $cid['slug'] . '/' ) ); ?>">
					<h3 class="awr-cities__nome"><?php echo esc_html( $cid['nome'] ); ?></h3>
					<span><?php echo esc_html( function_exists( 'awr_city_delivery_badge' ) ? awr_city_delivery_badge( $cid ) : 'Prazo confirmado no WhatsApp' ); ?></span>
					<small>Bateria a domicílio</small>
				</a>
			<?php endforeach; ?>
			<?php foreach ( awr_marca_cidades_envio() as $awr_env ) :
				$awr_cv = function_exists( 'awr_cidade_venda_by_slug' ) ? awr_cidade_venda_by_slug( $awr_env ) : null;
				if ( ! $awr_cv ) { continue; }
				?>
				<a href="<?php echo esc_url( home_url( '/baterias-em/' . $awr_cv['slug'] . '/' ) ); ?>">
					<h3 class="awr-cities__nome"><?php echo esc_html( $awr_cv['nome'] ); ?></h3>
					<span>Envio com rastreio</span>
					<small>Nota fiscal e garantia de fábrica</small>
				</a>
			<?php endforeach; ?>
		</div>
		<p class="awr-cities__more">Não achou sua cidade? <a href="<?php echo esc_url( awr_wa( 'Olá! Vocês atendem na minha cidade?' ) ); ?>" target="_top" rel="noopener">Confirme a cobertura no WhatsApp</a>.</p>
	</div>
</section>

<?php $awr_posts_home = array_slice( awr_posts_data(), 0, 3 ); ?>
<?php if ( $awr_posts_home ) : ?>
<section class="awr-sec awr-blog awr-sec--soft">
	<div class="awr-container">
		<div class="awr-blog__head">
			<div>
				<h2 class="awr-section-title">Guias da oficina</h2>
				<p class="awr-lead">Conteúdo prático de quem troca bateria todo dia.</p>
			</div>
			<a class="awr-btn awr-btn--outline" href="<?php echo esc_url( home_url( '/blog/' ) ); ?>">Ver todos os guias</a>
		</div>
		<div class="awr-blog__grid">
			<?php foreach ( $awr_posts_home as $p ) : ?>
				<a href="<?php echo esc_url( home_url( '/blog/' . $p['slug'] . '/' ) ); ?>">
					<div class="awr-blog__body">
						<span class="awr-blog__cat"><?php echo esc_html( $p['categoria'] ?? 'Guia' ); ?></span>
						<h3><?php echo esc_html( $p['h1'] ?? $p['titulo'] ); ?></h3>
						<p class="awr-lead"><?php echo esc_html( wp_trim_words( $p['descricao'] ?? '', 20 ) ); ?></p>
					</div>
				</a>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<section class="awr-sec">
	<div class="awr-container awr-mix">
		<div class="awr-mix__marcas">
			<h2 class="awr-section-title">Baterias por marca</h2>
			<ul>
				<?php foreach ( awr_marcas() as $mk ) : ?>
					<li><a href="<?php echo esc_url( home_url( '/marca/' . $mk['slug'] . '/' ) ); ?>">
						<h3><?php echo esc_html( $mk['nome'] ); ?></h3>
						<small><?php echo esc_html( $mk['tagline'] ?? 'Garantia de fábrica' ); ?></small>
					</a></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<div class="awr-mix__aplic">
			<h2 class="awr-section-title">Baterias por perfil de uso</h2>
			<ul>
				<?php foreach ( awr_aplicacoes() as $ap ) : ?>
					<li><a href="<?php echo esc_url( home_url( '/bateria-para/' . $ap['slug'] . '/' ) ); ?>">
						<h3><?php echo esc_html( $ap['nome'] ); ?></h3>
						<small><?php echo esc_html( $ap['tagline'] ?? '' ); ?></small>
					</a></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
</section>

<section class="awr-faq">
	<div class="awr-container">
		<div class="awr-sec__head">
			<h2 class="awr-section-title">Perguntas frequentes</h2>
			<p>As dúvidas que mais recebemos no WhatsApp.</p>
		</div>
		<?php
		$faqs = array(
			array( 'Vocês instalam no local?', 'Sim. A instalação é feita no local (casa, trabalho ou rua) sem custo adicional dentro da área de cobertura.' ),
			array( 'Qual o prazo de entrega?', 'Até 35 minutos em Porto Alegre e Grande Porto Alegre. ' . awr_aviso_35min() ),
			array( 'Qual o horário de atendimento?', awr_texto_horarios() ),
			array( 'Qual a garantia?', 'As baterias têm 24 meses de garantia de fábrica, com registro em nota fiscal.' ),
			array( 'Formas de pagamento?', 'Pix com desconto, dinheiro, débito e crédito em até 10x sem juros na maquininha, na entrega.' ),
			array( 'Vocês compram a bateria velha?', 'Sim. O desconto do casco é aplicado no ato da troca conforme a amperagem.' ),
			array( 'Atendem carros start-stop?', 'Sim. Trabalhamos com baterias AGM e EFB e fazemos a codificação necessária na instalação.' ),
		);
		?>
		<div class="awr-accordion">
			<?php foreach ( $faqs as $f ) : ?>
				<details class="awr-accordion__item">
					<summary><?php echo esc_html( $f[0] ); ?></summary>
					<p><?php echo esc_html( $f[1] ); ?></p>
				</details>
			<?php endforeach; ?>
		</div>
		<?php
		awr_jsonld( array(
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => array_map( function ( $f ) {
				return array(
					'@type'          => 'Question',
					'name'           => $f[0],
					'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f[1] ),
				);
			}, $faqs ),
		) );
		?>
	</div>
</section>

<section class="awr-finalcta">
	<div class="awr-container">
		<h2 class="awr-section-title">Bateria arriada agora? A gente resolve em 35 minutos.</h2>
		<p class="awr-lead">Atendimento imediato em Porto Alegre e Grande Porto Alegre, com instalação no local e 24 meses de garantia.</p>
		<p class="awr-hero__ctas">
			<a class="awr-btn awr-btn--green awr-btn--xl" target="_top" rel="noopener" href="<?php echo esc_url( awr_wa( 'Olá! Preciso de uma bateria com entrega hoje.' ) ); ?>">Chamar no WhatsApp</a>
			<a class="awr-btn awr-btn--outline awr-btn--xl" href="<?php echo esc_attr( $awr_c['phone_href'] ); ?>">Ligar <?php echo esc_html( $awr_c['phone'] ); ?></a>
		</p>
	</div>
</section>

<section class="awr-coverage">
	<div class="awr-container">
		<h2 class="awr-section-title">Cobertura em Porto Alegre e Região Metropolitana</h2>
		<p>A AWR Baterias entrega e instala baterias automotivas em Porto Alegre, Alvorada, Viamão, Canoas, Gravataí, Cachoeirinha, Esteio, São Leopoldo e demais cidades da RMPA. Atendemos carros de passeio, SUVs, picapes, utilitários e veículos start-stop, com teste de alternador gratuito e desconto na compra do casco velho.</p>
		<?php awr_part( 'links-internos', array( 'tipo' => 'home' ) ); ?>
	</div>
</section>

<?php get_footer(); ?>
