<?php
/**
 * SEO — títulos, meta description, canonical, JSON-LD e sitemap das rotas virtuais.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Contextos cujo SEO é controlado pelo tema, incluindo a página inicial. */
function awr_seo_managed_context() {
	if ( awr_current_route() || is_front_page() || is_home() ) { return true; }
	if ( function_exists( 'awr_seo_lote_managed' ) && awr_seo_lote_managed() ) { return true; }
	return function_exists( 'awr_seo_native_context' ) && (bool) awr_seo_native_context();
}


/** Limita texto sem cortar palavras no meio. */
function awr_seo_trim( $text, $limit ) {
	$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $text ) ) );
	if ( mb_strlen( $text ) <= $limit ) { return $text; }
	// 5.46.0 — títulos "Principal | Complemento": quando não cabe, descarta o
	// complemento inteiro em vez de cortá-lo no meio ("| Troca no", "| Entrega e").
	if ( false !== strpos( $text, ' | ' ) ) {
		$partes = explode( ' | ', $text );
		$cabe   = array();
		foreach ( $partes as $parte ) {
			$teste = implode( ' | ', array_merge( $cabe, array( $parte ) ) );
			if ( mb_strlen( $teste ) > $limit ) { break; }
			$cabe[] = $parte;
		}
		if ( $cabe ) { return awr_seo_trim_fim( implode( ' | ', $cabe ) ); }
		$text = $partes[0];
		if ( mb_strlen( $text ) <= $limit ) { return $text; }
	}
	$cut = rtrim( mb_substr( $text, 0, $limit + 1 ) );
	if ( mb_strlen( $cut ) > $limit || preg_match( '/\S$/u', mb_substr( $text, $limit, 1 ) ) ) {
		$cut = preg_replace( '/\s+\S*$/u', '', $cut );
	}
	return awr_seo_trim_fim( $cut );
}

/** Remove pontuação e preposições/conectivos soltos no fim de um texto cortado. */
function awr_seo_trim_fim( $txt ) {
	$txt = rtrim( (string) $txt, " \t\n\r\0\x0B,;:—-/|" );
	$ant = null;
	while ( $ant !== $txt ) {
		$ant = $txt;
		$txt = preg_replace( '/\s+(em|para|de|do|da|dos|das|e|no|na|nos|nas|com|a|o|ao|à|por|sem|até|ou)$/iu', '', $txt );
		$txt = rtrim( $txt, " \t\n\r\0\x0B,;:—-/|" );
	}
	return $txt;
}

/** Variação determinística de título/descrição (mesma URL → mesmo texto). */
function awr_seo_variant( $seed, $opcoes ) {
	$opcoes = array_values( (array) $opcoes );
	if ( ! $opcoes ) { return ''; }
	$h = 0;
	foreach ( str_split( (string) $seed ) as $ch ) { $h = ( $h * 31 + ord( $ch ) ) % 2147483647; }
	return $opcoes[ $h % count( $opcoes ) ];
}

/**
 * Ângulo comercial próprio de cada marca (público, gancho e prova).
 * Evita que todas as páginas de marca compartilhem a mesma description.
 */
function awr_marca_angulo( $slug ) {
	$mapa = array(
		'moura'         => array(
			'gancho'  => 'a mais vendida do Brasil',
			'publico' => 'quem não quer risco na partida',
			'prova'   => 'fornecedora oficial de VW, Fiat, GM e Ford',
		),
		'heliar'        => array(
			'gancho'  => 'tecnologia Clarios para carros modernos',
			'publico' => 'carro com Start-Stop e muita eletrônica',
			'prova'   => 'linha AGM Free com olho mágico de carga',
		),
		'zetta'         => array(
			'gancho'  => 'o melhor custo-benefício',
			'publico' => 'motorista de Uber, 99 e quem roda muito',
			'prova'   => 'fabricada pelo Grupo Moura',
		),
		'excell'        => array(
			'gancho'  => 'reposição nacional para carro e caminhão',
			'publico' => 'frota, utilitário e veículo de trabalho',
			'prova'   => 'linha robusta para uso pesado',
		),
		'optima'        => array(
			'gancho'  => 'AGM SpiralCell de alta performance',
			'publico' => 'som automotivo, 4x4 e carro preparado',
			'prova'   => 'referência mundial em ciclo profundo',
		),
		'motobatt'      => array(
			'gancho'  => 'AGM selada pronta para instalar',
			'publico' => 'moto de rua, big trail e scooter',
			'prova'   => 'quatro terminais, encaixe universal',
		),
		'freedom'       => array(
			'gancho'  => 'VRLA selada para flutuação e ciclo',
			'publico' => 'nobreak, energia solar, CFTV e telecom',
			'prova'   => 'dimensionamento do banco sem custo',
		),
		'global'        => array(
			'gancho'  => 'bancos de 12V para backup profissional',
			'publico' => 'condomínio, comércio e sala de TI',
			'prova'   => 'troca do banco com logística reversa',
		),
		'moura-nobreak' => array(
			'gancho'  => 'linha 12MVA de 7Ah a 18Ah',
			'publico' => 'nobreak apitando em casa ou no escritório',
			'prova'   => 'garantia Moura e recolhimento da usada',
		),
	);
	return isset( $mapa[ $slug ] ) ? $mapa[ $slug ] : null;
}



/** Preço "a partir de" do SKU, formatado em reais (vazio quando não há preço). */
function awr_seo_preco_sku( $sku ) {
	if ( ! function_exists( 'awr_product_by_sku' ) ) { return ''; }
	$p = awr_product_by_sku( strtoupper( (string) $sku ) );
	$v = $p ? (float) ( $p['price'] ?? 0 ) : 0;
	if ( $v <= 0 ) { return ''; }
	return 'R$ ' . ( fmod( $v, 1 ) === 0.0 ? number_format( $v, 0, ',', '.' ) : number_format( $v, 2, ',', '.' ) );
}

/** Preserva o sufixo da marca em títulos editoriais. */
function awr_seo_title_with_suffix( $title, $suffix = ' | AWR Baterias', $limit = 60 ) {
	$available = max( 1, $limit - mb_strlen( $suffix ) );
	return awr_seo_trim( $title, $available ) . $suffix;
}

/** Domínio canônico configurado (consolidação entre domínios — satélites). */
function awr_canonical_base() {
	$opt = trim( (string) get_option( 'awr_canonical_domain', '' ) );
	if ( $opt && preg_match( '#^https?://#i', $opt ) ) {
		return untrailingslashit( $opt );
	}
	return untrailingslashit( home_url( '/' ) );
}

/**
 * Aponta uma URL local para o domínio canônico, quando configurado, e limpa
 * parâmetros de rastreio (gclid, utm_*) e âncoras — o canonical é sempre
 * absoluto e autorreferenciado, sem query.
 */
function awr_canonical_url( $url ) {
	if ( ! $url ) { return $url; }
	$url  = strtok( (string) $url, '?' );
	$url  = strtok( $url, '#' );
	$cdn  = awr_canonical_base();
	$home = untrailingslashit( home_url( '/' ) );
	if ( $cdn === $home ) { return $url; }
	return preg_replace( '#^' . preg_quote( $home, '#' ) . '#', $cdn, $url );
}

/** Contexto SEO da rota atual. */
function awr_seo_context() {
	$c     = awr_company();
	$route = awr_current_route();
	$a     = awr_param_a();
	$b     = awr_param_b();
	$base  = array(
		'title'     => 'Bateria de Carro em Porto Alegre e Região | 35 Min',
		'desc'      => 'Bateria de carro em Porto Alegre, entregue e instalada no local em até 35 min. Moura, Heliar, Zetta e Excell com preço real, garantia e 10x sem juros.',

		'canonical' => home_url( '/' ),
		'noindex'   => false,
		'image'     => AWR_URI . '/assets/img/og-awr.jpg',
	);

	if ( $route && function_exists( 'awr_virtual_route_valid' ) && ! awr_virtual_route_valid( $route ) ) {
		return array(
			'title'     => 'Página não encontrada | AWR Baterias',
			'desc'      => 'O endereço informado não existe. Busque a bateria certa para o seu veículo na AWR Baterias.',
			'canonical' => '',
			'noindex'   => true,
			'image'     => '',
		);
	}

	switch ( $route ) {
		case 'buscar':
			$base['title'] = 'Bateria Certa para Seu Carro | Busque e Peça Agora';
			$base['desc']  = 'Descubra em segundos a bateria certa para o seu carro: amperagem, preço e entrega com instalação grátis em até 35 min em Porto Alegre.';
			$base['canonical'] = home_url( '/buscar/' );
			// Resultado com parâmetro é thin/duplicado: segue links, mas não indexa.
			if ( get_query_var( 'veiculo' ) || get_query_var( 'q' ) || get_query_var( 'ano' ) ) {
				$base['noindex'] = 'follow';
			}
			break;
		case 'hub_cidades':
			$base['title'] = 'Bateria de Carro por Cidade | Instalação em 35 min';
			$base['desc']  = 'Veja todas as cidades de Porto Alegre e Grande POA com entrega e instalação de bateria no local em até 35 min. 10x sem juros e garantia.';
			$base['canonical'] = home_url( '/baterias-em/' );
			break;
		case 'hub_marcas':
			$base['title'] = 'Bateria Moura, Heliar e Zetta | Entrega em 35 min';
			$base['desc']  = 'Moura, Heliar, Zetta, Excell e mais: todas as marcas de bateria automotiva entregues e instaladas em Porto Alegre e região, com garantia de fábrica.';
			$base['canonical'] = home_url( '/marca/' );
			break;
		case 'hub_aplicacoes':
			$base['title'] = 'Bateria por Aplicação | Pronta Entrega em 35 min';
			$base['desc']  = 'Carro, utilitário, caminhão, aplicativo, som ou start-stop: veja a bateria recomendada para cada aplicação, o preço atualizado e a troca no local.';
			$base['canonical'] = home_url( '/bateria-para/' );
			break;
		case 'hub_amperagens':
			$base['title'] = 'Bateria 40Ah a 150Ah | Instalação Grátis em 35 min';
			$base['desc']  = 'Escolha a amperagem da sua bateria e veja os modelos compatíveis com preço no Pix, 10x sem juros e instalação no local em até 35 min.';
			$base['canonical'] = home_url( '/baterias/amperagem/' );
			break;
		case 'hub_skus':
		case 'hub_skus_page':
			$pg = ( 'hub_skus_page' === $route ) ? max( 1, (int) $a ) : 1;
			$base['title'] = $pg > 1 ? "Modelos de Bateria — página {$pg} | AWR Baterias" : 'Modelos de Bateria de Carro | Entrega em 35 min';
			$base['desc']  = 'Catálogo completo de baterias Moura, Heliar, Zetta e Excell com entrega e instalação em até 35 minutos em Porto Alegre e região.';
			$base['canonical'] = $pg > 1 ? home_url( '/baterias/page/' . $pg . '/' ) : home_url( '/baterias/' );
			break;

		case 'cidade':
			$cidade = awr_cidade_by_slug( $a );
			if ( ! $cidade ) {
				$venda = awr_cidade_venda_by_slug( $a );
				if ( $venda ) {
					$vnome = $venda['nome'] ?? ucwords( str_replace( '-', ' ', $a ) );
					$base['title']     = awr_seo_trim( "Bateria de Carro em {$vnome} | Envio Rápido", 60 );
					$base['desc']      = awr_seo_trim( "Compre bateria automotiva para {$vnome}: Moura, Heliar, Zetta e Excell com nota fiscal, garantia e envio por transportadora. Peça agora no WhatsApp.", 155 );
					$base['canonical'] = home_url( "/baterias-em/{$a}/" );
					break;
				}
			}
			$nome   = $cidade ? $cidade['nome'] : ucwords( str_replace( '-', ' ', $a ) );
			$min    = $cidade && ! empty( $cidade['tempoEntregaMin'] ) ? (int) $cidade['tempoEntregaMin'] : 35;
			$bair   = $cidade && ! empty( $cidade['bairros'] ) ? implode( ', ', array_slice( (array) $cidade['bairros'], 0, 2 ) ) : '';
			$base['title'] = function_exists( 'awr_city_delivery_title' ) ? awr_city_delivery_title( $cidade ) : awr_seo_trim( "Bateria de Carro em {$nome} | Instalação Grátis {$min} min", 60 );
			// Conteúdo próprio da cidade mantém a descrição exclusiva.
			$ct = function_exists( 'awr_city_content_current' ) ? awr_city_content_current( $cidade ) : ( function_exists( 'awr_cidade_conteudo' ) ? awr_cidade_conteudo( $a ) : null );
			if ( $ct ) {
				$base['desc']      = awr_seo_trim( $ct['desc'], 155 );
				$base['canonical'] = home_url( "/baterias-em/{$a}/" );
				break;
			}
			$base['desc']  = $bair
				? "Carro não liga em {$nome}? Bateria Moura ou Heliar instalada em até {$min} min — {$bair} e região. 10x sem juros. Peça pelo WhatsApp."
				: "Carro não liga em {$nome}? Bateria Moura ou Heliar entregue e instalada em até {$min} min, com garantia de fábrica e 10x sem juros. Chame no WhatsApp.";
			$base['canonical'] = home_url( "/baterias-em/{$a}/" );
			break;


		case 'bairro':
			$cid  = awr_cidade_by_slug( $a );
			$bai  = awr_bairro_by_slug( $a, $b );
			$cn   = $cid ? $cid['nome'] : ucwords( str_replace( '-', ' ', $a ) );
			$bn   = $bai ? $bai['nome'] : ucwords( str_replace( '-', ' ', $b ) );
			$bpz  = awr_city_prazo( $cid );
			$base['title'] = awr_seo_trim( "Bateria no {$bn}, {$cn} | " . ( $bpz['rapida'] ? "Socorro em {$bpz['min']} min" : $bpz['titulo'] ), 60 );
			$base['desc']  = "Bateria arriada no {$bn}, {$cn}? Instalamos no local {$bpz['curto']}, a partir de R$ 329, com garantia e 10x sem juros. Peça pelo WhatsApp.";
			$base['canonical'] = home_url( "/baterias-bairro/{$a}/{$b}/" );
			break;

		case 'zona_poa':
			$z  = awr_zona_poa( $a );
			$pc = awr_cidade_by_slug( 'porto-alegre' );
			$mn = $pc && ! empty( $pc['tempoEntregaMin'] ) ? (int) $pc['tempoEntregaMin'] : 35;
			if ( $z ) {
				$base['title'] = awr_seo_trim( "Bateria na {$z['nome']} | Entrega em {$mn} min", 60 );
				$base['desc']  = 'Bateria entregue e instalada na ' . $z['nome'] . " em até {$mn} minutos, em " . count( (array) $z['bairros'] ) . ' bairros. Plantão das 06:30 às 22h. Peça pelo WhatsApp.';
				$base['canonical'] = home_url( "/baterias-porto-alegre/{$a}/" );
			}
			break;

		case 'hub_bairros':
			$cid  = awr_cidade_by_slug( $a );
			$cn   = $cid ? $cid['nome'] : ucwords( str_replace( '-', ' ', $a ) );
			$qtd  = count( awr_bairros_cidade( $a ) );
			$base['title'] = awr_seo_trim( "Bateria nos Bairros de {$cn} | Entrega Rápida", 60 );
			$base['desc']  = "Bateria entregue e instalada em {$qtd} bairros de {$cn}. Veja seu bairro, prazo e preço a partir de R$ 329, com 10x sem juros. Peça pelo WhatsApp.";
			$base['canonical'] = home_url( "/baterias-bairro/{$a}/" );
			break;

		case 'sku':
			$sku   = awr_sku_from_slug( $a );
			$pr    = awr_seo_preco_sku( $sku );
			$marca = function_exists( 'awr_brand_by_sku' ) ? awr_brand_by_sku( $sku ) : '';
			$amp   = function_exists( 'awr_extract_amperage' ) ? (int) awr_extract_amperage( $sku ) : 0;
			$produto = function_exists( 'awr_product_by_sku' ) ? awr_product_by_sku( $sku ) : null;
			$copy    = function_exists( 'awr_product_seo_copy' )
				? awr_product_seo_copy( $sku, $produto['name'] ?? '', $marca, $amp, $produto ? (float) ( $produto['price'] ?? 0 ) : 0 )
				: array( 'title' => "Bateria {$marca} {$amp}Ah {$sku}", 'desc' => "Bateria {$marca} {$amp}Ah {$sku} com entrega e instalação em Porto Alegre e região." );
			$base['title'] = $copy['title'];
			$base['desc']  = $copy['desc'];
			$base['canonical'] = home_url( "/bateria/{$a}/" );
			// SKU fora do catálogo = página vazia: segue links, mas não indexa.
			if ( ! awr_sku_existe( $sku ) ) { $base['noindex'] = 'follow'; }
			break;
		case 'amperagem':
			$base['title'] = awr_seo_trim( "Bateria {$a}Ah em Porto Alegre | Instalação Grátis", 60 );
			$base['desc']  = "Compre bateria {$a}Ah Moura, Heliar, Zetta ou Excell: preço à vista, instalação grátis em até 35 min em Porto Alegre e 10x sem juros. Peça agora.";
			$base['canonical'] = home_url( "/baterias/amperagem/{$a}/" );
			if ( ! awr_amperagem_tem_modelos( (int) $a ) ) { $base['noindex'] = 'follow'; }
			break;
		case 'baterias_de_carro':
			$base['title'] = 'Baterias de Carro em Porto Alegre: Preços e Entrega';
			$base['desc'] = 'Encontre a bateria certa pelo carro e ano, compare preços reais e peça com entrega, teste e instalação no local em Porto Alegre e região.';
			$base['canonical'] = home_url( '/baterias-de-carro/' );
			break;

		case 'marca':
			$m    = awr_marca_by_slug( $a );
			$nome = $m ? $m['nome'] : ucfirst( $a );
			$mpre = $m && ! empty( $m['faixaPreco'] ) ? preg_replace( '/^(R\$ ?[\d\.]+).*$/u', '$1', $m['faixaPreco'] ) : '';
			$mgar = $m && ! empty( $m['garantiaMeses'] ) ? (int) $m['garantiaMeses'] : 0;
			$mang = awr_marca_angulo( $a );
			$base['title'] = awr_seo_trim( awr_seo_variant( "mt{$a}", array_filter( array(
				$mpre ? "Bateria {$nome} em Porto Alegre a partir de {$mpre}" : "Bateria {$nome} em Porto Alegre | Instalação Grátis",
				"Bateria {$nome} em Porto Alegre | Chega em 35 min",
				$mgar ? "Bateria {$nome} | {$mgar} Meses de Garantia em POA" : "Bateria {$nome} em Porto Alegre | 10x sem Juros",
			) ) ), 60 );
			$base['desc'] = awr_seo_trim( awr_seo_variant( "md{$a}", array_filter( array(
				$mang
					? "Bateria {$nome}, {$mang['gancho']}: ideal para {$mang['publico']}" . ( $mpre ? ", a partir de {$mpre}" : '' ) . '. Entrega e instalação grátis em 35 min, com nota fiscal.'
					: null,
				$mang
					? "Bateria {$nome} original ({$mang['prova']}) entregue e trocada na sua porta em 35 min em Porto Alegre. Garantia de fábrica, Pix com desconto e 10x sem juros."
					: null,
				$mpre && $mgar
					? "Bateria {$nome} original a partir de {$mpre}, entregue e instalada de graça em até 35 min. {$mgar} meses de garantia, nota fiscal e 10x sem juros."
					: "Bateria {$nome} original entregue e instalada de graça em até 35 min em Porto Alegre. Garantia de fábrica, nota fiscal e 10x sem juros.",
				"Carro não liga? Levamos a bateria {$nome} certa até você e trocamos no local em 35 min, com garantia de fábrica, Pix com desconto e 10x sem juros.",
			) ) ), 155 );

			$base['canonical'] = home_url( "/marca/{$a}/" );
			break;
		case 'marca_cidade':
			$m = awr_marca_by_slug( $a );
			$cidade = awr_cidade_by_slug( $b );
			if ( ! $cidade && function_exists( 'awr_cidade_venda_by_slug' ) ) { $cidade = awr_cidade_venda_by_slug( $b ); }
			$nm = $m ? $m['nome'] : ucfirst( $a );
			$nc = $cidade ? $cidade['nome'] : ucwords( str_replace( '-', ' ', $b ) );
			$mcob = (bool) awr_cidade_by_slug( $b );
			$mpz  = awr_city_prazo( $cidade );
			$mmin = $mpz['min'];
			$mbai = $cidade && ! empty( $cidade['bairros'] ) ? implode( ', ', array_slice( (array) $cidade['bairros'], 0, 2 ) ) : '';
			$mcang = awr_marca_angulo( $a );
			if ( $mcob ) {
				$base['title'] = awr_seo_trim( awr_seo_variant( "mct{$a}{$b}", array(
					"Bateria {$nm} em {$nc} | {$mpz['titulo']}",
					$mpz['rapida'] ? "Bateria {$nm} em {$nc} | Instalação Grátis Hoje" : "Bateria {$nm} em {$nc} | {$mpz['titulo']}",
					$mpz['rapida'] ? "Bateria {$nm} em {$nc} | Troca no Local Hoje" : "Bateria {$nm} em {$nc} | Instalação no Local",
				) ), 60 );
				$base['desc'] = awr_seo_trim( awr_seo_variant( "mcd{$a}{$b}", array_filter( array(
					$mcang
						? "Bateria {$nm} em {$nc}, {$mcang['gancho']}: indicada para {$mcang['publico']}. Entrega e instalação grátis {$mpz['curto']}, com nota fiscal."
						: null,
					"Carro não liga em {$nc}? Levamos a {$nm} certa e trocamos na sua porta {$mpz['curto']}. Garantia de fábrica, Pix com desconto e 10x sem juros.",
					$mbai
						? "Bateria {$nm} em {$nc}: entrega e instalação grátis em {$mbai} e região {$mpz['curto']}, com nota fiscal, garantia e 10x sem juros."
						: "Bateria {$nm} em {$nc}: entrega e instalação grátis no local {$mpz['curto']}, com nota fiscal, garantia de fábrica e 10x sem juros.",
				) ) ), 155 );

			} else {
				$base['title'] = awr_seo_trim( "Bateria {$nm} em {$nc} | Preço e Envio Rápido", 60 );
				$base['desc']  = awr_seo_trim( "Bateria {$nm} original para {$nc} com preço à vista no Pix, nota fiscal e garantia de fábrica. Envio rápido com rastreio. Peça o orçamento no WhatsApp.", 155 );
			}

			$base['canonical'] = home_url( "/bateria/{$a}/{$b}/" );
			break;

		case 'shop':
		case 'shop_page':
		case 'shop_cat':
		case 'shop_cat_page': {
			$is_cat = in_array( $route, array( 'shop_cat', 'shop_cat_page' ), true );
			$cslug  = $is_cat ? $a : '';
			$term   = $cslug ? awr_shop_categoria_by_slug( $cslug ) : null;
			$pg     = 1;
			if ( 'shop_page' === $route ) { $pg = max( 1, (int) $a ); }
			if ( 'shop_cat_page' === $route ) { $pg = max( 1, (int) $b ); }
			$nome   = $term ? $term['nome'] : 'Loja de baterias';
			$base['title']     = awr_seo_trim( 'Comprar ' . $nome . ' On-line' . ( $pg > 1 ? " — página {$pg}" : '' ) . ' | Entrega em 35 min', 60 );
			$base['desc']      = awr_seo_trim( 'Compre ' . strtolower( $nome ) . ' on-line com entrega e instalação grátis em até 35 min em Porto Alegre e Grande POA. Pix com desconto e 10x sem juros.', 155 );
			$base['canonical'] = awr_shop_url( $cslug, $pg );
			if ( $pg > 1 ) { $base['noindex'] = 'follow'; }
			break;
		}
		case 'hub_categorias':
			$base['title'] = 'Bateria AGM, EFB e Náutica | Entrega e Instalação';
			$base['desc']  = 'Escolha por tecnologia: bateria AGM, EFB Start-Stop, náutica Moura Boat, tracionária, entrega perto de você e comparativo Moura x Heliar. Nota fiscal e garantia.';
			$base['canonical'] = home_url( '/categorias/' );
			break;
		case 'categoria':
			$ct = awr_categoria_seo_by_slug( $a );
			if ( $ct ) {
				$base['title'] = $ct['titulo'];
				$base['desc']  = $ct['descricao'];
			}
			$base['canonical'] = home_url( "/categorias/{$a}/" );
			break;
		case 'hub_ramos':
			$base['title'] = 'Bateria para Carro, Moto e Solar | Entrega Rápida';
			$base['desc']  = 'Baterias para cada aplicação em Porto Alegre: automotivo, motos, mobilidade elétrica, nobreak e CFTV, tracionária industrial e náutica.';
			$base['canonical'] = home_url( '/aplicacoes/' );
			break;
		case 'ramo':
			$ra = awr_ramo_by_slug( $a );
			$base['title'] = $ra ? $ra['titulo'] : 'Aplicações de baterias | AWR Baterias';
			$base['desc']  = $ra ? $ra['descricao'] : $base['desc'];
			$base['canonical'] = home_url( "/aplicacoes/{$a}/" );
			break;
		case 'moto_marca':
			$mb = awr_moto_brand( $a );
			if ( $mb ) {
				$mmods = function_exists( 'awr_moto_models_by_brand' ) ? awr_moto_models_by_brand( $a ) : array();
				$mnomes = array();
				foreach ( array_slice( $mmods, 0, 3 ) as $mm ) { $mnomes[] = $mm['modelo']; }
				$mlista = $mnomes ? implode( ', ', $mnomes ) : '';
				$base['title'] = awr_seo_trim( awr_seo_variant( "mmt{$a}", array(
					"Bateria de Moto {$mb['nome']} em POA | Troca no Local",
					"Bateria de Moto {$mb['nome']} | {$mb['total']} Modelos em POA",
					"Bateria {$mb['nome']} de Moto | Entrega e Instalação",
				) ), 60 );
				$base['desc'] = awr_seo_trim( awr_seo_variant( "mmd{$a}", array_filter( array(
					$mlista
						? "Bateria para moto {$mb['nome']} ({$mlista} e mais {$mb['total']} modelos): selada, AGM ou gel na amperagem certa, com troca no local em Porto Alegre."
						: null,
					"Bateria de moto {$mb['nome']} com amperagem conferida pelo modelo e ano, selada e pronta para instalar. Entrega e troca no local em Porto Alegre e região.",
					"Moto {$mb['nome']} não dá partida? Levamos a bateria certa até você, com nota fiscal, garantia de fábrica e instalação inclusa em Porto Alegre e região.",
				) ) ), 155 );
			}
			$base['canonical'] = home_url( "/baterias-para-moto/marca/{$a}/" );
			break;
		case 'segmento':
			$sg = awr_segmento_by_base( $a );
			if ( $sg ) {
				$base['title'] = $sg['hub']['titulo'];
				$base['desc']  = $sg['hub']['descricao'];
			}
			$base['canonical'] = home_url( "/{$a}/" );
			break;
		case 'estac_sub':
			$ep = function_exists( 'awr_est_pagina' ) ? awr_est_pagina( $b ) : null;
			if ( $ep ) {
				$base['title']     = $ep['title'];
				$base['desc']      = $ep['desc'];
				$base['canonical'] = awr_est_pagina_url( $b );
			}
			break;
		case 'segmento_cidade':
			$sg = awr_segmento_by_base( $a );
			$sc = $sg ? awr_segmento_conteudo_cidade( $sg, $b ) : null;
			if ( $sc ) {
				$base['title'] = $sc['titulo'];
				$base['desc']  = $sc['descricao'];
			}
			$scd  = $sg ? awr_segmento_cidade_by_slug( $b, $sg ) : null;
			$scn  = $scd ? $scd['nome'] : ucwords( str_replace( '-', ' ', $b ) );
			$senv = $scd && isset( $scd['modo'] ) && 'envio' === $scd['modo'];
			if ( $sg && 'estacionaria' === $sg['key'] ) {
				$base['title'] = awr_seo_trim( awr_seo_variant( "sect{$b}", array(
					"Bateria Estacionária para Nobreak em {$scn}",
					"Bateria de Nobreak e Solar em {$scn} | AWR",
					"Bateria Estacionária em {$scn} | Nobreak e Solar",
				) ), 60 );
				$base['desc'] = awr_seo_trim( $senv
					? "Bateria estacionária em {$scn} para nobreak, energia solar, CFTV e telecom: dimensionamento grátis do banco, nota fiscal em CNPJ e envio com rastreio."
					: "Bateria estacionária em {$scn} para nobreak, solar, CFTV e telecom: dimensionamento grátis, troca do banco no local, nota fiscal em CNPJ e recolhimento da usada.", 155 );
			} elseif ( $sg && 'caminhao' === $sg['key'] ) {
				$base['title'] = awr_seo_trim( awr_seo_variant( "scct{$b}", array(
					"Bateria de Caminhão em {$scn} | Troca no Local",
					"Bateria de Caminhão e Frota em {$scn} | AWR",
					"Bateria 150Ah a 225Ah em {$scn} | Caminhão",
				) ), 60 );
				$base['desc'] = awr_seo_trim( "Bateria de caminhão em {$scn}: 150Ah a 225Ah para diesel leve e pesado, atendimento a frotas no pátio, nota fiscal em CNPJ e garantia de fábrica.", 155 );
			} elseif ( $sg && 'moto' === $sg['key'] ) {
				$base['title'] = awr_seo_trim( awr_seo_variant( "smt{$b}", array(
					"Bateria de Moto em {$scn} | Troca no Local Hoje",
					"Bateria de Moto em {$scn} | Selada e AGM",
					"Bateria de Moto em {$scn} | Entrega Rápida",
				) ), 60 );
				$base['desc'] = awr_seo_trim( "Bateria de moto em {$scn}: selada, AGM ou gel na amperagem certa do seu modelo, com entrega, instalação no local, nota fiscal e garantia de fábrica.", 155 );
			}
			$base['canonical'] = home_url( "/{$a}/{$b}/" );
			break;

		case 'segmento_bairro':
			$sg  = awr_segmento_by_base( $a );
			$sc  = $sg ? awr_segmento_cidade_by_slug( $b, $sg ) : null;
			$c   = awr_param_c();
			$bai = $sc ? awr_bairro_by_slug( $sc['slug'], $c ) : null;
			if ( $sg && $sc && $bai ) {
				$base['title'] = $sg['nome'] . ' em ' . $bai['nome'] . ', ' . $sc['nome'] . ' | AWR';
				$base['desc']  = $sg['nome'] . ' no bairro ' . $bai['nome'] . ', em ' . $sc['nome'] . '. Orçamento pelo WhatsApp, entrega no endereço, nota fiscal e recolhimento da bateria usada.';
			}
			$base['canonical'] = home_url( "/{$a}/{$b}/{$c}/" );
			break;
		case 'b2b':
			$base['title'] = 'Soluções B2B em Baterias | AWR Baterias Porto Alegre';
			$base['desc']  = 'Fornecimento de baterias para empresas em Porto Alegre: solar off-grid, provedores de internet, agro, equipamentos médicos, lítio LiFePO4 e contratos de manutenção.';
			$base['canonical'] = home_url( '/solucoes-b2b/' );
			break;
		case 'aplicacao':
			$ap = awr_aplicacao_by_slug( $a );
			$nome = $ap ? $ap['nome'] : ucwords( str_replace( '-', ' ', $a ) );
			$base['title'] = awr_seo_trim( "Bateria para {$nome} | Troca no Local", 60 );
			$base['desc']  = "Bateria para {$nome} com atendimento no local em Porto Alegre e Grande POA: instalação em até 35 min, 10x sem juros e garantia de 24 meses.";
			$base['canonical'] = home_url( "/bateria-para/{$a}/" );
			break;
		case 'loja':
			$s = awr_store_by_slug( $a );
			$nome = $s ? $s['nome'] : ucwords( str_replace( '-', ' ', $a ) );
			$base['title'] = awr_seo_trim( "Loja de Baterias {$nome} | Entrega e Instalação Rápida", 60 );
			$base['desc']  = $s ? "AWR Baterias {$nome}: {$s['enderecoCompleto']}. Telefone {$s['telefone']}. Teste grátis, troca na hora e entrega em até 35 min." : $base['desc'];
			$base['canonical'] = home_url( "/lojas/{$a}/" );
			break;
		case 'lojas':
			$base['title'] = 'Lojas de Bateria em Porto Alegre | Visite Uma Loja';
			$base['desc']  = '6 lojas AWR na Grande Porto Alegre com teste grátis e troca na hora. Veja endereço, horário e ligue para a loja mais próxima de você.';
			$base['canonical'] = home_url( '/lojas/' );
			break;
		case 'blog':
			$base['title'] = 'Bateria de Carro: Guias e Dicas | AWR Baterias';
			$base['desc']  = 'Guias práticos sobre bateria automotiva: quando trocar, Moura x Heliar, amperagem correta e manutenção. Troca no local em até 35 min.';
			$base['canonical'] = home_url( '/blog/' );
			break;
		case 'post':
			$p = awr_post_by_slug( $a );
			if ( $p ) {
				$base['title'] = awr_seo_title_with_suffix( $p['titulo'] ?? '' );
				// v3.80.0 — o campo do dataset é "descricao"; "resumo" não existe e
				// fazia todos os posts caírem na description padrão do blog.
				$pd = (string) ( $p['descricao'] ?? $p['resumo'] ?? '' );
				if ( '' !== trim( $pd ) ) {
					$base['desc'] = awr_seo_trim( $pd, 155 );
				}
			}
			$base['canonical'] = home_url( "/blog/{$a}/" );
			break;
		case 'domicilio':
			$base['title'] = 'Bateria a Domicílio em Porto Alegre | Instalação no Local';
			$base['desc']  = 'Bateria a domicílio em Porto Alegre: entrega, teste e instalação no seu endereço, com nota fiscal, garantia de fábrica e 10x sem juros.';
			$base['canonical'] = home_url( '/bateria-a-domicilio-porto-alegre/' );
			break;
		case 'perto_de_mim':
			$base['title'] = 'Bateria de Carro Perto de Mim | 6 Lojas na Grande POA';
			$base['desc']  = 'Encontre a loja AWR Baterias mais perto de você em Porto Alegre, Canoas, Gravataí, São Leopoldo e Novo Hamburgo. Entrega e instalação no local.';
			$base['canonical'] = home_url( '/bateria-perto-de-mim/' );
			break;
		case 'socorro':
			$base['title'] = 'Socorro de Bateria em Porto Alegre | Carro Não Liga';
			$base['desc']  = 'Carro não liga? Socorro de bateria em Porto Alegre e região com teste de bateria e alternador no local, bateria nova instalada na hora e garantia.';
			$base['canonical'] = home_url( '/socorro-bateria/' );
			break;
		case 'comparar':
			$base['title'] = 'Comparar baterias de carro: Ah, CCA e garantia | AWR';
			$base['desc']  = 'Filtre baterias por amperagem, CCA e garantia e compare até 3 modelos com preços da tabela oficial AWR.';
			$base['canonical'] = home_url( '/comparar/' );
			break;
		case 'garantia':
			$base['title'] = 'Solicitar garantia de bateria | AWR Baterias';
			$base['desc']  = 'Abra sua solicitação de garantia: informe nota fiscal, modelo e problema e envie as fotos pelo WhatsApp.';
			$base['canonical'] = home_url( '/garantia/' );
			break;
		case 'rastrear_pedido':
			$base['title'] = 'Rastrear pedido de bateria | AWR Baterias';
			$base['desc']  = 'Acompanhe seu pedido AWR: informe o número e receba o status da entrega ou da transportadora no WhatsApp.';
			$base['canonical'] = home_url( '/rastrear-pedido/' );
			break;
		case 'central_tecnica':
			$base['title'] = 'Central Técnica AWR: guias de baterias';
			$base['desc']  = 'Guias técnicos sobre bateria de carro, moto, caminhão, estacionária, nobreak e solar: diagnóstico, escolha e dimensionamento.';
			$base['canonical'] = home_url( '/central-tecnica/' );
			break;
		case 'parceiros':
			$base['title'] = 'Seja parceiro AWR Baterias | Oficinas em POA';
			$base['desc']  = 'Cadastre sua oficina ou auto-elétrica como parceira AWR Baterias e ganhe comissão com entrega de bateria em 35 minutos.';
			$base['canonical'] = home_url( '/parceiros/' );
			break;
		case 'lp':
		case 'lp_alias':
			$lps = awr_lps();
			$lp  = $lps[ $a ] ?? null;
			if ( $lp ) {
				$base['title'] = $lp['h1'];
				$base['desc']  = $lp['sub'];
			}
			if ( $lp && ! empty( $lp['index'] ) ) {
				// LP de SEO: indexável e canônica na URL curta.
				$base['noindex']   = false;
				$base['canonical'] = home_url( "/{$a}/" );
			} else {
				$base['noindex']   = 'follow';
				$base['canonical'] = home_url( "/lp/{$a}/" );
			}
			break;

		case 'hub_veiculos':
			$base['title'] = 'Bateria por Modelo de Carro | Preço e Troca no Local';
			$base['desc']  = 'Encontre a bateria certa pelo modelo do seu veículo: preço atualizado, marcas Moura, Heliar, Zetta e Excell e entrega na sua cidade em 35 min.';
			$base['canonical'] = home_url( '/baterias-para/' );
			break;
		case 'veiculo_modelo':
			$vcm = awr_vc_model( $a );
			if ( $vcm ) {
				$vcl = awr_vc_label( $vcm );
				if ( ! empty( $vcm['familia'] ) ) {
					$vah   = awr_vc_amperagens( $vcm );
					$vahtx = $vah ? ( count( $vah ) > 1 ? reset( $vah ) . 'Ah a ' . end( $vah ) . 'Ah' : reset( $vah ) . 'Ah' ) : '60Ah';
					$base['title']     = awr_seo_trim( "Bateria {$vcl}: Qual Usar e Preço por Versão | AWR", 60 );
					$base['desc']      = awr_seo_trim( "Qual bateria usar no {$vcl} {$vcm['de']}–{$vcm['ate']}: {$vahtx} conforme versão e ano, Moura, Heliar, Zetta e Excell. Instalação grátis em até 35 min em POA.", 160 );
					$base['canonical'] = awr_vc_url( $vcm['slug'] );
					break;
				}
				$base['title'] = awr_seo_trim( awr_seo_variant( "vm{$a}", array(
					"Bateria para {$vcl} | Entrega e Instalação em 35 min",
					"Bateria para {$vcl} | Preço à Vista e Troca Grátis",
					"Bateria para {$vcl} | Instalação Grátis no Local",
				) ), 60 );
				$base['desc']  = awr_seo_trim( awr_seo_variant( "vmd{$a}", array(
					"Compre bateria para {$vcl} com entrega e instalação grátis em até 35 min em Porto Alegre, nota fiscal e 10x sem juros. Peça agora.",
					"Bateria para {$vcl} com preço à vista no Pix e troca grátis em até 35 min em Porto Alegre. Garantia de fábrica. Chame no WhatsApp.",
					"Carro não liga? Peça a bateria compatível com {$vcl}, instalação no local, garantia e nota fiscal. Compre agora.",
				) ), 155 );
				$base['canonical'] = awr_vc_url( $vcm['slug'] );
			}
			break;
		case 'veiculo_cidade':
			$vcm = awr_vc_model( $a );
			$vcc = awr_vc_cidade( $b );
			if ( $vcm && $vcc ) {
				$vct = awr_vc_content( $vcm, $vcc );
				$base['title'] = $vct['title'];
				$base['desc']  = $vct['desc'];
				$base['canonical'] = awr_vc_url( $vcm['slug'], $vcc['c']['slug'] );
				$base['faq']   = array();
				foreach ( $vct['faq'] as $vcf ) {
					$base['faq'][] = array( 'q' => $vcf['pergunta'], 'r' => $vcf['resposta'] );
				}
			}
			break;

		case 'cidade_legacy':
		case 'veiculo':
		case 'veiculo_ano':
			$marca_nome = awr_is_vehicle_brand( $a );
			if ( ! $marca_nome ) {
				$base['title'] = 'Página não encontrada | AWR Baterias';
				$base['desc'] = 'O endereço informado não existe. Busque a bateria certa para o seu veículo na AWR Baterias.';
				$base['canonical'] = '';
				$base['noindex'] = true;
				break;
			}
			$modelos = $b ? awr_vehicle_models( $a ) : array();
			$modelo  = isset( $modelos[ $b ] ) ? $modelos[ $b ]['nome'] : '';
			$ano     = 'veiculo_ano' === $route ? (int) awr_param_c() : 0;
			if ( $ano && $modelo ) {
				$base['title'] = awr_seo_trim( awr_seo_variant( "va{$a}{$b}{$ano}", array(
					"Bateria para {$modelo} {$ano} | Troca no Local em 35 min",
					"Bateria para {$marca_nome} {$modelo} {$ano} | Preço e Troca",
					"Bateria para {$modelo} {$ano} | Entrega e Instalação Hoje",
				) ), 60 );
				$base['desc']  = awr_seo_trim( awr_seo_variant( "vad{$a}{$b}{$ano}", array(
					"Compre bateria para {$marca_nome} {$modelo} {$ano}: modelo compatível, preço no Pix e instalação grátis em 35 min. Peça agora no WhatsApp.",
					"Bateria para {$marca_nome} {$modelo} {$ano} entregue e instalada em até 35 min, com nota fiscal e garantia. Compre agora pelo WhatsApp.",
					"Troque a bateria do {$marca_nome} {$modelo} {$ano} sem sair de casa: preço à vista, 10x sem juros e instalação no local em 35 min.",
				) ), 155 );
				$base['canonical'] = awr_vehicle_url( $marca_nome, $modelo, $ano );
				if ( ! awr_vehicle_variants( $a, $b, $ano ) ) { $base['noindex'] = 'follow'; }
			} elseif ( $modelo ) {
				$base['title'] = awr_seo_trim( awr_seo_variant( "vs{$a}{$b}", array(
					"Bateria para {$marca_nome} {$modelo} | Preço e Troca Grátis",
					"Bateria para {$modelo} | Instalação Grátis em 35 min",
					"Bateria para {$marca_nome} {$modelo} | Entrega Hoje em POA",
				) ), 60 );
				$base['desc']  = awr_seo_trim( awr_seo_variant( "vsd{$a}{$b}", array(
					"Compre bateria para {$marca_nome} {$modelo}: escolha o ano, veja o modelo compatível e receba com instalação grátis em até 35 min. Peça agora.",
					"Bateria para {$marca_nome} {$modelo} com preço no Pix, nota fiscal e garantia de fábrica. Troca grátis no local em 35 min. Chame no WhatsApp.",
					"Carro não liga? Peça a bateria certa para {$marca_nome} {$modelo}, com 10x sem juros e instalação no local em Porto Alegre. Compre agora.",
				) ), 155 );
				$base['canonical'] = awr_vehicle_url( $marca_nome, $modelo );
			} else {
				$base['title'] = awr_seo_trim( "Bateria para {$marca_nome} | Entrega e Instalação Grátis", 60 );
				$base['desc']  = "Baterias para todos os modelos {$marca_nome} com entrega e instalação grátis em até 35 min em Porto Alegre e Grande POA. 10x sem juros.";
				$base['canonical'] = home_url( "/baterias/{$a}/" );
			}
			break;
		case 'widget':
		case 'pedido':
			$base['noindex']   = true;
			$base['canonical'] = '';
			break;
	}

	/** Permite que páginas nativas (produto/post/página) assumam o SEO. */
	$base = apply_filters( 'awr_seo_context', $base, $route );

	$base['title']     = awr_seo_trim( $base['title'], 60 );
	$base['desc']      = awr_seo_trim( $base['desc'], 155 );
	$base['canonical'] = awr_canonical_url( $base['canonical'] );
	return $base;

}

/** O SKU existe no catálogo exportado? */
function awr_sku_existe( $sku ) {
	$sku = strtoupper( (string) $sku );
	foreach ( awr_sku_index() as $e ) {
		if ( $e['sku'] === $sku ) { return true; }
	}
	return false;
}

/** HTML das metatags da rota gerenciada pelo tema. */
function awr_seo_tags_html() {
	$ctx  = awr_seo_context();
	$out  = '<meta name="description" content="' . esc_attr( $ctx['desc'] ) . '">' . "\n";

	if ( 'follow' === $ctx['noindex'] ) {
		// Não indexa a página, mas segue os links internos (preserva o fluxo de rastreio).
		$out .= '<meta name="robots" content="noindex,follow">' . "\n";
		if ( $ctx['canonical'] ) {
			$out .= '<link rel="canonical" href="' . esc_url( $ctx['canonical'] ) . '">' . "\n";
		}
	} elseif ( $ctx['noindex'] ) {
		$out .= '<meta name="robots" content="noindex,nofollow">' . "\n";
	} elseif ( $ctx['canonical'] ) {
		$out .= '<link rel="canonical" href="' . esc_url( $ctx['canonical'] ) . '">' . "\n";
	}
	$out .= '<meta property="og:type" content="website">' . "\n";
	$out .= '<meta property="og:title" content="' . esc_attr( $ctx['title'] ) . '">' . "\n";
	$out .= '<meta property="og:description" content="' . esc_attr( $ctx['desc'] ) . '">' . "\n";
	if ( ! empty( $ctx['canonical'] ) ) {
		$out .= '<meta property="og:url" content="' . esc_url( $ctx['canonical'] ) . '">' . "\n";
	}
	$out .= '<meta name="twitter:card" content="summary_large_image">' . "\n";
	$out .= '<meta name="twitter:title" content="' . esc_attr( $ctx['title'] ) . '">' . "\n";
	$out .= '<meta name="twitter:description" content="' . esc_attr( $ctx['desc'] ) . '">' . "\n";
	if ( ! empty( $ctx['image'] ) ) {
		$out .= '<meta property="og:image" content="' . esc_url( $ctx['image'] ) . '">' . "\n";
		$out .= '<meta name="twitter:image" content="' . esc_url( $ctx['image'] ) . '">' . "\n";
	}
	return $out;
}

/**
 * Nas rotas virtuais do tema, qualquer plugin que imprima canonical/description/og
 * apontando para a home faz o Google descartar a página. Bufferizamos o wp_head,
 * removemos essas tags concorrentes e emitimos apenas as do tema.
 *
 * v3.86.0 — a limpeza passa a valer TAMBÉM com plugin de SEO ativo. Os filtros do
 * AIOSEO/Yoast/Rank Math não pegam nas rotas virtuais (não há post por trás da URL),
 * então o plugin imprimia um segundo canonical/description apontando para a home.
 */
function awr_seo_buffer_nivel( $set = null ) {
	static $nivel = 0;
	if ( null !== $set ) { $nivel = max( 0, (int) $set ); }
	return $nivel;
}

add_action( 'wp_head', function () {
	if ( ! awr_seo_managed_context() ) { return; }
	ob_start();
	awr_seo_buffer_nivel( ob_get_level() );
}, -99999 );

add_action( 'wp_head', function () {
	$nivel = awr_seo_buffer_nivel();
	if ( ! $nivel || ob_get_level() < $nivel ) { return; }
	// Um plugin pode abrir outro buffer dentro de wp_head e esquecer de fechá-lo.
	// Recolhe cada camada interna para o buffer do tema antes de processar o HTML.
	while ( ob_get_level() > $nivel ) {
		$interno = ob_get_clean();
		if ( false !== $interno ) { echo $interno; } // phpcs:ignore WordPress.Security.EscapeOutput
	}
	$html = ob_get_clean();
	awr_seo_buffer_nivel( 0 );
	if ( false === $html ) { $html = ''; }

	// Remove tags concorrentes (canonical, description, robots, og:*, twitter:*).
	$html = preg_replace( '#<link[^>]+rel=([\'"])canonical\1[^>]*>\s*#i', '', $html );
	$html = preg_replace( '#<meta[^>]+name=([\'"])(description|robots)\1[^>]*>\s*#i', '', $html );
	$html = preg_replace( '#<meta[^>]+property=([\'"])og:(title|description|url|type|image|site_name|locale)\1[^>]*>\s*#i', '', $html );
	$html = preg_replace( '#<meta[^>]+name=([\'"])twitter:(card|title|description|url|image|locale)\1[^>]*>\s*#i', '', $html );

	// Schema do plugin (Person/WebSite genéricos da home) — o tema publica o seu.
	$html = preg_replace( '#<script[^>]+class=([\'"])[^\'"]*aioseo-schema[^\'"]*\1[^>]*>.*?</script>\s*#is', '', $html );
	$html = preg_replace( '#<script[^>]+type=([\'"])application/ld\+json\1[^>]*>\s*\{[^<]*"@type"\s*:\s*"Person".*?</script>\s*#is', '', $html );

	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput
	echo awr_seo_tags_html(); // phpcs:ignore WordPress.Security.EscapeOutput
}, 99999 );


/** Bloqueia parâmetros de busca e endpoints técnicos no robots.txt. */
add_filter( 'robots_txt', function ( $output ) {
	// Linhas Sitemap (do WP ou de plugins) saem do meio das regras e vão para o final.
	$sitemaps = array( home_url( '/awr-sitemap.xml' ) );
	$output   = preg_replace_callback( '/^\s*Sitemap:\s*(\S+)\s*$/mi', function ( $m ) use ( &$sitemaps ) {
		$sitemaps[] = trim( $m[1] );
		return '';
	}, (string) $output );
	$output = rtrim( preg_replace( "/\n{3,}/", "\n\n", $output ) ) . "\n";
	// /wp-json/ inteiro não pode ser bloqueado: o Google usa a REST API do
	// WooCommerce para validar a loja (Merchant Center / Google for WooCommerce).
	$extra  = "Disallow: /*?q=\nDisallow: /*?veiculo=\nDisallow: /*?ano=\nDisallow: /widget-busca/\nDisallow: /pedido-confirmado/\nDisallow: /wp-json/awr/\n";
	// Storebot-Google valida compra/preço: precisa de acesso total.
	$extra .= "\nUser-agent: Storebot-Google\nAllow: /\n\n";
	foreach ( array_unique( $sitemaps ) as $sm ) { $extra .= 'Sitemap: ' . $sm . "\n"; }
	return $output . $extra;
}, PHP_INT_MAX );

/**
 * Existe um plugin de SEO ativo que reescreve title/meta?
 * Nesse caso o tema entrega os valores pelos filtros do plugin (evita tags duplicadas).
 */
function awr_seo_plugin_ativo() {
	return defined( 'AIOSEO_VERSION' ) || defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || class_exists( 'AIOSEO\\Plugin\\AIOSEO' );
}

/** Valor SEO da rota atual, ou o fallback do plugin quando não é rota do tema. */
function awr_seo_override( $campo, $fallback = '' ) {
	if ( ! awr_seo_managed_context() ) { return $fallback; }
	$ctx = awr_seo_context();
	switch ( $campo ) {
		case 'title':
			return $ctx['title'];
		case 'desc':
			return $ctx['desc'];
		case 'canonical':
			return $ctx['canonical'] ? $ctx['canonical'] : $fallback;
		case 'image':
			return $ctx['image'] ? $ctx['image'] : $fallback;
	}
	return $fallback;
}

// Título do documento — prioridade máxima para vencer AIOSEO/Yoast/Rank Math.
add_filter( 'pre_get_document_title', function ( $title ) {
	return awr_seo_managed_context() ? awr_seo_override( 'title', $title ) : $title;
}, PHP_INT_MAX );

// All in One SEO (AIOSEO).
foreach ( array( 'aioseo_title', 'aioseo_og_title', 'aioseo_twitter_title' ) as $awr_f ) {
	add_filter( $awr_f, function ( $v ) { return awr_seo_override( 'title', $v ); }, PHP_INT_MAX );
}
foreach ( array( 'aioseo_description', 'aioseo_og_description', 'aioseo_twitter_description' ) as $awr_f ) {
	add_filter( $awr_f, function ( $v ) { return awr_seo_override( 'desc', $v ); }, PHP_INT_MAX );
}
add_filter( 'aioseo_canonical_url', function ( $v ) { return awr_seo_override( 'canonical', $v ); }, PHP_INT_MAX );
add_filter( 'aioseo_og_image', function ( $v ) { return awr_seo_override( 'image', $v ); }, PHP_INT_MAX );
add_filter( 'aioseo_twitter_image', function ( $v ) { return awr_seo_override( 'image', $v ); }, PHP_INT_MAX );
add_filter( 'aioseo_robots_meta', function ( $v ) {
	if ( ! awr_seo_managed_context() ) { return $v; }
	$ctx = awr_seo_context();
	if ( 'follow' === $ctx['noindex'] ) { return 'noindex,follow'; }
	if ( $ctx['noindex'] ) { return 'noindex,nofollow'; }
	return $v;
}, PHP_INT_MAX );
// Schema do tema já cobre estas rotas virtuais — evita JSON-LD duplicado.
add_filter( 'aioseo_schema_output', function ( $graph ) {
	return awr_seo_managed_context() ? array() : $graph;
}, PHP_INT_MAX );

// Yoast SEO.
add_filter( 'wpseo_title', function ( $v ) { return awr_seo_override( 'title', $v ); }, PHP_INT_MAX );
add_filter( 'wpseo_metadesc', function ( $v ) { return awr_seo_override( 'desc', $v ); }, PHP_INT_MAX );
add_filter( 'wpseo_canonical', function ( $v ) { return awr_seo_override( 'canonical', $v ); }, PHP_INT_MAX );
add_filter( 'wpseo_opengraph_title', function ( $v ) { return awr_seo_override( 'title', $v ); }, PHP_INT_MAX );
add_filter( 'wpseo_opengraph_desc', function ( $v ) { return awr_seo_override( 'desc', $v ); }, PHP_INT_MAX );

// Rank Math.
add_filter( 'rank_math/frontend/title', function ( $v ) { return awr_seo_override( 'title', $v ); }, PHP_INT_MAX );
add_filter( 'rank_math/frontend/description', function ( $v ) { return awr_seo_override( 'desc', $v ); }, PHP_INT_MAX );
add_filter( 'rank_math/frontend/canonical', function ( $v ) { return awr_seo_override( 'canonical', $v ); }, PHP_INT_MAX );


/** JSON-LD LocalBusiness com todas as lojas (rodapé de todas as páginas). */
function awr_schema_localbusiness() {
	$c      = awr_company();
	$graph  = array();
	foreach ( awr_stores() as $s ) {
		$hours = array();
		if ( ! empty( $s['horarios']['semana'] ) && preg_match( '/(\d{2}:\d{2})\D+(\d{2}:\d{2})/', $s['horarios']['semana'], $m ) ) {
			$hours[] = array(
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => array( 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday' ),
				'opens'     => $m[1],
				'closes'    => $m[2],
			);
		}
		if ( ! empty( $s['horarios']['sabado'] ) && preg_match( '/(\d{2}:\d{2})\D+(\d{2}:\d{2})/', $s['horarios']['sabado'], $m2 ) ) {
			$hours[] = array(
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => array( 'Saturday' ),
				'opens'     => $m2[1],
				'closes'    => $m2[2],
			);
		}
		$graph[] = array(
			'@type'       => 'AutoPartsStore',
			'@id'         => home_url( '/lojas/' . $s['slug'] . '/' ),
			'name'        => 'AWR Baterias — ' . $s['nome'],
			// 5.46.0 — image e priceRange: recomendados pelo Google para LocalBusiness.
			'image'       => AWR_URI . '/assets/img/lojas/cover.jpg',
			'priceRange'  => '$$',
			'telephone'   => $s['telefone'],
			'url'         => home_url( '/lojas/' . $s['slug'] . '/' ),
			'address'     => array(
				'@type'           => 'PostalAddress',
				'streetAddress'   => $s['endereco'],
				'addressLocality' => $s['cidade'],
				'addressRegion'   => $s['estado'],
				'addressCountry'  => 'BR',
			),
			'geo'         => array( '@type' => 'GeoCoordinates', 'latitude' => $s['geo']['lat'], 'longitude' => $s['geo']['lng'] ),
			'openingHoursSpecification' => $hours,
			'areaServed'  => array_values( (array) ( $s['cidadesAtendidas'] ?? array() ) ),
		);
	}
	return array( '@context' => 'https://schema.org', '@graph' => $graph );
}

function awr_jsonld( $data ) {
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}

/**
 * FAQPage a partir da mesma lista usada no bloco visível ( array de q/r ).
 */
function awr_faq_jsonld( $itens, $id ) {
	$main = array();
	foreach ( (array) $itens as $f ) {
		$q = $f['q'] ?? $f['pergunta'] ?? '';
		$r = $f['r'] ?? $f['resposta'] ?? '';
		if ( '' === $q || '' === $r ) { continue; }
		$main[] = array(
			'@type'          => 'Question',
			'name'           => $q,
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $r ),
		);
	}
	if ( ! $main ) { return; }
	awr_jsonld( array(
		'@context'   => 'https://schema.org',
		'@type'      => 'FAQPage',
		'@id'        => $id,
		'mainEntity' => $main,
	) );
}

add_action( 'wp_footer', function () {
	awr_jsonld( awr_schema_localbusiness() );
}, 5 );

/**
 * Sitemaps do tema.
 *
 * /awr-sitemap.xml            índice
 * /awr-sitemap-cidades.xml    cidades + marca×cidade
 * /awr-sitemap-marcas.xml     marcas e aplicações
 * /awr-sitemap-skus.xml       modelos (paginado: -skus-2.xml, -skus-3.xml…)
 * /awr-sitemap-lojas.xml      lojas
 * /awr-sitemap-conteudo.xml   home, hubs e blog
 */
const AWR_SITEMAP_MAX = 1000;

add_action( 'init', function () {
	add_rewrite_rule( '^awr-sitemap\.xml$', 'index.php?awr_sitemap=index', 'top' );
	add_rewrite_rule( '^awr-sitemap-([a-z]+)(?:-([0-9]+))?\.xml$', 'index.php?awr_sitemap=$matches[1]&awr_sitemap_page=$matches[2]', 'top' );
	add_rewrite_tag( '%awr_sitemap%', '([a-z]+)' );
	add_rewrite_tag( '%awr_sitemap_page%', '([0-9]+)' );
} );

// O sitemap precisa continuar acessível mesmo antes de o administrador
// salvar os links permanentes. Detecta o endpoint diretamente pela URL.
add_action( 'parse_request', function ( $wp ) {
	$path = trim( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' );
	if ( 'awr-sitemap.xml' === $path ) {
		$wp->query_vars['awr_sitemap'] = 'index';
		return;
	}
	if ( preg_match( '/^awr-sitemap-([a-z]+)(?:-([0-9]+))?\.xml$/', $path, $m ) ) {
		$wp->query_vars['awr_sitemap'] = $m[1];
		$wp->query_vars['awr_sitemap_page'] = $m[2] ?? 1;
	}
}, 1 );
add_filter( 'query_vars', function ( $v ) { $v[] = 'awr_sitemap'; $v[] = 'awr_sitemap_page'; return $v; } );

/** URLs de cada seção do sitemap. */
function awr_sitemap_urls( $secao ) {
	$urls = array();
	switch ( $secao ) {
		case 'conteudo':
			$urls[] = home_url( '/' );
			$urls[] = home_url( '/buscar/' );
			$urls[] = home_url( '/baterias-em/' );
			$urls[] = home_url( '/marca/' );
			$urls[] = home_url( '/bateria-para/' );
			$urls[] = home_url( '/baterias/' );
			$urls[] = home_url( '/baterias/amperagem/' );
			$urls[] = home_url( '/baterias-para/' );
			foreach ( (array) awr_data( 'veiculos-prioritarios' ) as $vp ) { $urls[] = awr_vc_url( $vp['slug'] ); }
			$urls[] = home_url( '/lojas/' );
			$urls[] = home_url( '/blog/' );
			$urls[] = home_url( '/parceiros/' );
			$urls[] = home_url( '/bateria-a-domicilio-porto-alegre/' );
			$urls[] = home_url( '/bateria-perto-de-mim/' );
			$urls[] = home_url( '/socorro-bateria/' );
			$urls[] = home_url( '/loja/' );
			foreach ( awr_shop_categorias() as $sc ) { $urls[] = $sc['url']; }
			$urls[] = home_url( '/categorias/' );
			foreach ( awr_categorias_seo() as $ct ) { $urls[] = home_url( '/categorias/' . $ct['slug'] . '/' ); }
			foreach ( awr_lps() as $lslug => $lp ) {
				if ( ! empty( $lp['index'] ) ) { $urls[] = home_url( '/' . $lslug . '/' ); }
			}
			foreach ( awr_posts_data() as $p ) { $urls[] = home_url( '/blog/' . $p['slug'] . '/' ); }
			$total = max( 1, (int) ceil( count( awr_sku_index() ) / 60 ) );
			for ( $i = 2; $i <= $total; $i++ ) { $urls[] = home_url( '/baterias/page/' . $i . '/' ); }
			foreach ( awr_amperagens_disponiveis() as $ah ) { $urls[] = home_url( '/baterias/amperagem/' . $ah . '/' ); }
			break;
		case 'cidades':
			foreach ( awr_cidades() as $c ) { $urls[] = home_url( '/baterias-em/' . $c['slug'] . '/' ); }
			// Cidades de venda com envio — descobertas apenas pelo sitemap.
			foreach ( awr_cidades_venda() as $c ) { $urls[] = home_url( '/baterias-em/' . $c['slug'] . '/' ); }
			foreach ( awr_marcas() as $m ) {
				if ( empty( $m['cidadePages'] ) ) { continue; }
				foreach ( awr_cidades() as $c ) { $urls[] = home_url( '/bateria/' . $m['slug'] . '/' . $c['slug'] . '/' ); }
				foreach ( awr_marca_cidades_envio() as $cs ) {
					if ( awr_cidade_venda_by_slug( $cs ) ) { $urls[] = home_url( '/bateria/' . $m['slug'] . '/' . $cs . '/' ); }
				}
			}

			break;
		case 'bairros':
			foreach ( (array) awr_data( 'zonas-poa' ) as $zz ) { $urls[] = home_url( '/baterias-porto-alegre/' . $zz['slug'] . '/' ); }
			foreach ( awr_bairros_data() as $cb ) {
				$urls[] = home_url( '/baterias-bairro/' . $cb['cidadeSlug'] . '/' );
				foreach ( (array) $cb['bairros'] as $bb ) {
					$urls[] = home_url( '/baterias-bairro/' . $cb['cidadeSlug'] . '/' . $bb['slug'] . '/' );
				}
			}
			break;
		case 'segmentos':
			foreach ( awr_moto_brands() as $mb ) { $urls[] = awr_moto_brand_url( $mb['slug'] ); }
			if ( function_exists( 'awr_est_paginas' ) ) {
				foreach ( array_keys( awr_est_paginas() ) as $es ) { $urls[] = awr_est_pagina_url( $es ); }
			}
			foreach ( awr_segmentos() as $sg ) {
				$urls[] = awr_segmento_url( $sg );
				foreach ( awr_segmento_cidades( $sg ) as $sc ) {
					$urls[] = awr_segmento_url( $sg, $sc['slug'] );
					foreach ( awr_bairros_cidade( $sc['slug'] ) as $bb ) {
						$urls[] = awr_segmento_url( $sg, $sc['slug'] ) . $bb['slug'] . '/';
					}
				}
			}
			break;
		case 'marcas':
			foreach ( awr_marcas() as $m ) { $urls[] = home_url( '/marca/' . $m['slug'] . '/' ); }
			foreach ( awr_aplicacoes() as $a ) { $urls[] = home_url( '/bateria-para/' . $a['slug'] . '/' ); }
			$urls[] = home_url( '/aplicacoes/' );
			$urls[] = home_url( '/solucoes-b2b/' );
			foreach ( awr_ramos() as $r ) { $urls[] = home_url( '/aplicacoes/' . $r['slug'] . '/' ); }
			break;
		case 'lojas':
			foreach ( awr_stores() as $s ) { $urls[] = home_url( '/lojas/' . $s['slug'] . '/' ); }
			break;
		case 'skus':
			// O sitemap precisa listar SEMPRE a URL canônica. Quando o canonical
			// do SKU aponta para o permalink do produto (modo Merchant Center),
			// listar /bateria/{sku}/ fazia o Google marcar todas essas URLs como
			// "página alternativa com canônica adequada" e removê-las do índice.
			foreach ( awr_sku_index() as $e ) {
				$urls[] = function_exists( 'awr_produto_url_canonica' )
					? awr_produto_url_canonica( $e['sku'] )
					: home_url( '/bateria/' . awr_sku_slug( $e['sku'] ) . '/' );
			}
			break;
		case 'produtos':
			// 5.46.0 — Produtos publicados do WooCommerce que NÃO estão na tabela de
			// aplicação (estacionárias, moto, náutica, acessórios) não apareciam em
			// nenhum sitemap: o /sitemap.xml do plugin é redirecionado para o índice
			// do tema. Lista a mesma URL que o canonical do produto declara.
			if ( ! function_exists( 'wc_get_products' ) ) { break; }
			$ja = array_flip( awr_sitemap_urls( 'skus' ) );
			$ids = wc_get_products( array( 'status' => 'publish', 'visibility' => 'visible', 'limit' => 3000, 'return' => 'ids' ) );
			foreach ( (array) $ids as $pid ) {
				$wc  = wc_get_product( $pid );
				if ( ! $wc ) { continue; }
				$psk = strtoupper( trim( (string) $wc->get_sku() ) );
				// No modo "sku" o canonical vai para /bateria/{sku}/, que é noindex fora do catálogo.
				if ( $psk && function_exists( 'awr_produto_canonical_modo' ) && 'produto' !== awr_produto_canonical_modo() && ! awr_sku_existe( $psk ) ) { continue; }
				$u   = $psk && function_exists( 'awr_produto_url_canonica' ) ? awr_produto_url_canonica( $psk, (int) $pid ) : get_permalink( $pid );
				if ( $u && ! isset( $ja[ $u ] ) ) { $urls[] = $u; $ja[ $u ] = true; }
			}
			break;
		case 'veiculoscidade':
			// Gerada sob demanda por página (ver awr_render_sitemap).
			break;
		case 'veiculos':
			// Ordem importa: o sitemap é paginado de 1.000 em 1.000 e o Google
			// rastreia as primeiras páginas primeiro. Em ordem alfabética as
			// colheitadeiras (AGCO) ocupavam a página 1 e os carros de passeio
			// que realmente vendem ficavam nas últimas. Marcas prioritárias
			// primeiro; o resto segue na ordem original.
			$marcas_v    = awr_vehicle_brands();
			$prioritarias = apply_filters( 'awr_sitemap_marcas_veiculo', array(
				'volkswagen', 'chevrolet', 'fiat', 'ford', 'hyundai', 'toyota', 'renault',
				'honda', 'jeep', 'nissan', 'peugeot', 'citroen', 'kia', 'mitsubishi',
				'bmw', 'mercedes-benz', 'audi', 'volvo', 'byd', 'caoa-chery', 'ram',
			) );
			$ordenadas = array();
			foreach ( $prioritarias as $pslug ) {
				if ( isset( $marcas_v[ $pslug ] ) ) { $ordenadas[ $pslug ] = $marcas_v[ $pslug ]; }
			}
			foreach ( $marcas_v as $bslug => $bnome ) {
				if ( ! isset( $ordenadas[ $bslug ] ) ) { $ordenadas[ $bslug ] = $bnome; }
			}
			foreach ( $ordenadas as $bslug => $bnome ) {
				$urls[] = home_url( '/baterias/' . $bslug . '/' );
				foreach ( awr_vehicle_models( $bslug ) as $mslug => $m ) {
					$urls[]   = awr_vehicle_url( $bnome, $m['nome'] );
					$tem_mod  = (bool) awr_vehicle_variants( $bslug, $mslug );
					foreach ( awr_vehicle_years( $bslug, $mslug ) as $y ) {
						// 5.46.0 — ano sem bateria compatível responde 301 para o modelo
						// (template_include em inc/rewrites.php): não entra no sitemap.
						if ( $tem_mod && ! awr_vehicle_variants( $bslug, $mslug, $y ) ) { continue; }
						$urls[] = awr_vehicle_url( $bnome, $m['nome'], $y );
					}
				}
			}
			break;
	}
	return array_values( array_unique( $urls ) );
}

/**
 * Renderiza e envia o XML do sitemap. Encerra a requisição.
 *
 * @param string $secao index|conteudo|cidades|marcas|lojas|skus
 * @param int    $page  página (para skus).
 */
function awr_render_sitemap( $secao, $page = 1 ) {
	$secao = preg_replace( '/[^a-z]/', '', (string) $secao );
	$page  = max( 1, (int) $page );

	// Nenhum buffer/BOM antes da declaração XML. Removemos antes o flush
	// automático do WordPress no shutdown — com compressão zlib ativa ele
	// tentaria esvaziar um buffer já fechado e geraria um Notice de PHP.
	remove_action( 'shutdown', 'wp_ob_end_flush_all', 1 );
	remove_action( 'shutdown', 'awr_ob_end_flush_all', 1 );
	while ( ob_get_level() > 0 ) {
		if ( ! ob_end_clean() ) { break; }
	}

	if ( ! headers_sent() ) {
		status_header( 200 );
		nocache_headers();
		header( 'Content-Type: application/xml; charset=UTF-8' );
		// v5.12.0: sem noindex no sitemap (Search Console recusava leitura).
		header( 'Cache-Control: public, max-age=3600, s-maxage=43200', true );
	}

	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";

	if ( 'index' === $secao ) {
		$mapas = array( 'conteudo', 'cidades', 'bairros', 'marcas', 'segmentos', 'lojas', 'produtos' );
		foreach ( array( 'skus', 'veiculos' ) as $sec ) {
			$total = max( 1, (int) ceil( count( awr_sitemap_urls( $sec ) ) / AWR_SITEMAP_MAX ) );
			for ( $i = 1; $i <= $total; $i++ ) {
				$mapas[] = 1 === $i ? $sec : $sec . '-' . $i;
			}
		}
		// Veículo × cidade: paginado sem materializar todas as URLs.
		$total_vc = max( 1, (int) ceil( awr_vc_total_urls() / AWR_SITEMAP_MAX ) );
		for ( $i = 1; $i <= $total_vc; $i++ ) {
			$mapas[] = 1 === $i ? 'veiculoscidade' : 'veiculoscidade-' . $i;
		}
		echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		foreach ( $mapas as $m ) {
			echo '<sitemap><loc>' . esc_url( home_url( '/awr-sitemap-' . $m . '.xml' ) ) . '</loc></sitemap>' . "\n";
		}
		echo '</sitemapindex>';
		exit;
	}

	$cache_key = 'awr_sm_' . ( function_exists( 'awr_cache_ver' ) ? awr_cache_ver() : '0' ) . '_' . substr( md5( awr_canonical_base() ), 0, 6 ) . '_' . $secao . '_' . $page;
	$xml       = get_transient( $cache_key );
	if ( false === $xml ) {
		$urls = 'veiculoscidade' === $secao
			? awr_vc_sitemap_page( $page, AWR_SITEMAP_MAX )
			: awr_sitemap_urls( $secao );
		// Domínio canônico (satélites): o sitemap passa a listar as URLs do
		// domínio principal, reforçando a consolidação.
		$urls = array_map( 'awr_canonical_url', $urls );
		if ( ! $urls ) {
			echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"></urlset>';
			exit;
		}
		if ( 'veiculoscidade' !== $secao ) {
			$urls = array_slice( $urls, ( $page - 1 ) * AWR_SITEMAP_MAX, AWR_SITEMAP_MAX );
		}
		$xml  = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		foreach ( $urls as $u ) {
			$xml .= '<url><loc>' . esc_url( $u ) . '</loc><changefreq>weekly</changefreq></url>' . "\n";
		}
		$xml .= '</urlset>';
		set_transient( $cache_key, $xml, 12 * HOUR_IN_SECONDS );
	}
	echo $xml; // phpcs:ignore WordPress.Security.EscapeOutput
	exit;
}

/** Caminho da requisição → seção/página do sitemap (ou false). */
function awr_sitemap_from_request() {
	$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : ''; // phpcs:ignore
	$path = trim( $path, '/' );
	if ( '' === $path ) { return false; }

	// Suporta instalações em subdiretório.
	$base = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $base && 0 === strpos( $path, $base . '/' ) ) {
		$path = substr( $path, strlen( $base ) + 1 );
	}

	if ( 'awr-sitemap.xml' === $path ) { return array( 'index', 1 ); }
	if ( preg_match( '#^awr-sitemap-([a-z]+)(?:-([0-9]+))?\.xml$#', $path, $m ) ) {
		return array( $m[1], isset( $m[2] ) ? (int) $m[2] : 1 );
	}
	return false;
}

/**
 * Serve o sitemap bem cedo, independentemente das rewrite rules estarem
 * regravadas (evita 404 no Search Console após atualizar o tema).
 */
add_action( 'parse_request', function () {
	$hit = awr_sitemap_from_request();
	if ( $hit ) { awr_render_sitemap( $hit[0], $hit[1] ); }
}, 0 );

// Caminho normal (query vars via rewrite rule).
add_action( 'template_redirect', function () {
	$secao = get_query_var( 'awr_sitemap' );
	if ( ! $secao ) { return; }
	awr_render_sitemap( $secao, (int) get_query_var( 'awr_sitemap_page' ) );
} );

/**
 * Alias /sitemap.xml → índice do tema.
 *
 * Antes o alias desistia quando o sitemap nativo do WordPress estava ligado;
 * na prática /sitemap.xml caía em /wp-sitemap.xml, que só lista 1 página e as
 * taxonomias — nenhuma rota do tema (cidades, marcas, veículos, SKUs). O
 * Search Console ficava sem descobrir o site inteiro. Agora o índice do tema
 * responde sempre (filtrável por awr_sitemap_alias).
 */
add_action( 'parse_request', function () {
	$path = isset( $_SERVER['REQUEST_URI'] ) ? trim( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ), '/' ) : ''; // phpcs:ignore
	$alias = apply_filters( 'awr_sitemap_alias', array( 'sitemap.xml', 'sitemap_index.xml', 'wp-sitemap.xml' ) );
	if ( ! in_array( $path, (array) $alias, true ) ) { return; }
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) ) { return; }
	wp_safe_redirect( home_url( '/awr-sitemap.xml' ), 301 );
	exit;
}, 0 );

/**
 * O sitemap nativo do WordPress duplica conteúdo (usuários, taxonomias vazias)
 * e competia com o índice do tema. Fica desligado; /wp-sitemap.xml redireciona.
 */
add_filter( 'wp_sitemaps_enabled', '__return_false' );



/* ======================================================================
   v3.5.3 — SEO local por cidade: FAQ compartilhada (bloco visível + JSON-LD)
   e schema Service/FAQPage por cidade e por marca×cidade.
   ====================================================================== */

/**
 * Perguntas frequentes de uma cidade (opcionalmente de uma marca).
 *
 * @param array       $c     Registro de cidades.json.
 * @param array|null  $marca Registro de marcas.json ou null.
 * @return array Lista de array( 'q' => ..., 'r' => ... ).
 */
function awr_faq_cidade( $c, $marca = null ) {
	if ( ! $c ) { return array(); }
	$nome   = $c['nome'];
	$pz     = awr_city_prazo( $c );
	$bair   = ! empty( $c['bairros'] ) ? (array) $c['bairros'] : array();
	$b5     = $bair ? implode( ', ', array_slice( $bair, 0, 5 ) ) : $nome;
	$rota   = ! empty( $c['rotaLoja'] ) ? $c['rotaLoja'] : '';
	$nm     = $marca ? $marca['nome'] : '';

	if ( $marca ) {
		return array(
			array(
				'q' => "Vocês entregam bateria {$nm} em {$nome}?",
				'r' => "Sim. Levamos a bateria {$nm} até você em {$nome} {$pz['longo']}" . ( $rota ? ", {$rota}" : '' ) . ", atendendo bairros como {$b5}. A instalação e o teste do alternador são feitos no local, sem custo.",
			),
			array(
				'q' => "Qual a garantia da bateria {$nm}?",
				'r' => "Toda bateria {$nm} vendida pela AWR sai com nota fiscal e garantia de fábrica de até 24 meses, válida em {$nome} e em toda a rede autorizada.",
			),
			array(
				'q' => "Posso parcelar a bateria {$nm} em {$nome}?",
				'r' => "Sim: 10x sem juros no cartão ou preço à vista com desconto no Pix. A sua bateria velha ainda é abatida do valor final na troca.",
			),
		);
	}

	// FAQ própria da cidade (conteúdo exclusivo), quando disponível.
	if ( function_exists( 'awr_cidade_conteudo' ) ) {
		$awr_ct = awr_cidade_conteudo( $c['slug'] );
		if ( $awr_ct && ! empty( $awr_ct['faq'] ) ) {
			$awr_faq = array();
			foreach ( $awr_ct['faq'] as $awr_f ) {
				$awr_faq[] = array( 'q' => $awr_f['pergunta'], 'r' => $awr_f['resposta'] );
			}
			return $awr_faq;
		}
	}

	return array(
		array(
			'q' => "Em quanto tempo a bateria chega em {$nome}?",
			'r' => $pz['rapida'] ? "Em até {$pz['min']} minutos a partir da confirmação do pedido, dentro do horário de atendimento. Atendemos bairros como {$b5} e região." : "A entrega com instalação em {$nome} é {$pz['longo']}. Atendemos bairros como {$b5} e região.",
		),
		array(
			'q' => "Quais bairros de {$nome} vocês atendem?",
			'r' => $bair ? "Atendemos toda a cidade, incluindo " . implode( ', ', array_slice( $bair, 0, 10 ) ) . " e demais bairros de {$nome}." : "Atendemos toda a cidade de {$nome} e a Grande Porto Alegre.",
		),
		array(
			'q' => "Quanto custa a instalação da bateria em {$nome}?",
			'r' => "A instalação é gratuita. Você paga apenas a bateria, com preço à vista no Pix ou em 10x sem juros no cartão, e ainda recebe desconto pela bateria velha.",
		),
		array(
			'q' => 'Qual a garantia da bateria?',
			'r' => 'Baterias Moura, Heliar e Zetta com nota fiscal e garantia de fábrica de até 24 meses, com troca feita pela própria AWR.',
		),
		array(
			'q' => "Vocês testam o alternador em {$nome}?",
			'r' => "Sim. Antes de instalar, o técnico testa o alternador e o sistema de carga do veículo no local, em {$nome}, para confirmar que o problema é mesmo a bateria.",
		),
		array(
			'q' => "Qual o preço da bateria em {$nome}?",
			'r' => 'A partir de R$ 329 (60Ah Eletra). Parcele em até 10x sem juros nos cartões.',
		),
		array(
			'q' => "Qual a diferença entre Moura e Heliar em {$nome}?",
			'r' => 'Ambas são primeira linha. Moura é líder de mercado e dá até 24 meses de garantia. Heliar usa tecnologia Clarios, indicada para importados e Start-Stop. Nosso técnico confere seu carro antes de instalar.',
		),
		array(
			'q' => "Vocês atendem 24h em {$nome}?",
			'r' => awr_texto_horarios(),
		),
	);
}

/** Service + FAQPage específicos da cidade (e da marca, quando houver). */
function awr_schema_cidade( $c, $marca = null ) {
	if ( ! $c ) { return null; }
	$nome  = $c['nome'];
	$pz    = awr_city_prazo( $c );
	$nm    = $marca ? $marca['nome'] : '';
	$url   = $marca
		? home_url( '/bateria/' . $marca['slug'] . '/' . $c['slug'] . '/' )
		: home_url( '/baterias-em/' . $c['slug'] . '/' );
	$lojas = awr_stores_for_cidade( $c['slug'] );
	$loja  = $lojas ? $lojas[0] : null;

	$area = array( array( '@type' => 'City', 'name' => $nome, 'addressRegion' => $c['estado'] ?? 'RS' ) );
	foreach ( array_slice( (array) ( $c['bairros'] ?? array() ), 0, 14 ) as $b ) {
		$area[] = array( '@type' => 'Place', 'name' => $b . ', ' . $nome );
	}

	$service = array(
		'@type'       => 'Service',
		'@id'         => $url . '#service',
		'serviceType' => $nm
			? "Entrega e instalação de bateria {$nm} em {$nome}"
			: "Entrega e instalação de bateria automotiva em {$nome}",
		'name'        => $nm ? "Bateria {$nm} em {$nome}" : "Bateria automotiva em {$nome}",
		'description' => $c['textoIntro'] ?? "Bateria entregue e instalada no local em {$nome} {$pz['longo']}.",
		'url'         => $url,
		'areaServed'  => $area,
		'provider'    => $loja
			? array(
				'@type'     => 'AutoPartsStore',
				'@id'       => home_url( '/lojas/' . $loja['slug'] . '/' ),
				'name'      => 'AWR Baterias — ' . $loja['nome'],
				'telephone' => $loja['telefone'],
			)
			: array( '@type' => 'AutoPartsStore', 'name' => 'AWR Baterias' ),
		'offers'      => array(
			'@type'         => 'Offer',
			'availability'  => 'https://schema.org/InStock',
			'priceCurrency' => 'BRL',
			'url'           => $url,
		),
	);

	$faq = array();
	foreach ( awr_faq_cidade( $c, $marca ) as $item ) {
		$faq[] = array(
			'@type'          => 'Question',
			'name'           => $item['q'],
			'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $item['r'] ),
		);
	}

	$graph = array( $service );
	if ( $faq ) {
		$graph[] = array( '@type' => 'FAQPage', '@id' => $url . '#faq', 'mainEntity' => $faq );
	}
	return array( '@context' => 'https://schema.org', '@graph' => $graph );
}

add_action( 'wp_footer', function () {
	$route = awr_current_route();
	if ( 'cidade' === $route ) {
		$s = awr_schema_cidade( awr_cidade_by_slug( awr_param_a() ) );
		if ( $s ) { awr_jsonld( $s ); }
	} elseif ( 'marca_cidade' === $route ) {
		$s = awr_schema_cidade( awr_cidade_by_slug( awr_param_b() ), awr_marca_by_slug( awr_param_a() ) );
		if ( $s ) { awr_jsonld( $s ); }
	} elseif ( 'categoria' === $route ) {
		$ct = awr_categoria_seo_by_slug( awr_param_a() );
		if ( $ct && ! empty( $ct['faq'] ) ) {
			$url  = home_url( '/categorias/' . $ct['slug'] . '/' );
			$main = array();
			foreach ( (array) $ct['faq'] as $f ) {
				$main[] = array(
					'@type'          => 'Question',
					'name'           => $f['p'],
					'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f['r'] ),
				);
			}
			awr_jsonld( array(
				'@context'   => 'https://schema.org',
				'@type'      => 'FAQPage',
				'@id'        => $url . '#faq',
				'mainEntity' => $main,
			) );
		}
	}
}, 6 );

/**
 * Consolidação total (opcional): redireciona todas as URLs públicas para o
 * domínio canônico configurado em Ajustes → AWR Baterias. Ativar apenas em
 * domínios satélite quando o domínio secundário for descontinuado.
 */
add_action( 'template_redirect', function () {
	if ( ! get_option( 'awr_canonical_redirect' ) ) { return; }
	$cdn  = awr_canonical_base();
	$home = untrailingslashit( home_url( '/' ) );
	if ( $cdn === $home ) { return; }
	$req = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
	wp_redirect( $cdn . $req, 301 ); // phpcs:ignore WordPress.Security.SafeRedirect
	exit;
}, 0 );

/**
 * Alerta global no wp-admin quando a indexação está bloqueada
 * (Configurações → Leitura → "Impedir mecanismos de busca").
 */
add_action( 'admin_notices', function () {
	if ( get_option( 'blog_public' ) ) { return; }
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $screen && 'options-reading' === $screen->id ) { return; }
	echo '<div class="notice notice-error"><p><strong>AWR Baterias:</strong> a indexação do site está bloqueada em <a href="' . esc_url( admin_url( 'options-reading.php' ) ) . '">Configurações → Leitura</a> ("Impedir que mecanismos de busca indexem este site"). Desmarque para liberar o Google.</p></div>';
} );
