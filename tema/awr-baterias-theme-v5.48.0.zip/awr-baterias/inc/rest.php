<?php
/**
 * Endpoints REST do tema (namespace awr/v1) — usados pelo JS do widget.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// Os endpoints do tema são públicos. Páginas servidas de cache podem entregar
// um X-WP-Nonce expirado, e o WP aborta a chamada com rest_cookie_invalid_nonce
// antes de chegar na rota ("Loja recusou o pedido: A verificação cookie falhou").
// Prioridade 999: o core grava esse erro em rest_cookie_check_errors (prioridade 100),
// então o filtro precisa rodar depois. Só vale para as rotas públicas do tema.
function awr_rest_public_route() {
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
	$rr  = '';
	if ( isset( $GLOBALS['wp'] ) && isset( $GLOBALS['wp']->query_vars['rest_route'] ) ) {
		$rr = (string) $GLOBALS['wp']->query_vars['rest_route'];
	}
	if ( '' === $rr && isset( $_GET['rest_route'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$rr = (string) sanitize_text_field( wp_unslash( $_GET['rest_route'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}
	$alvo = $rr . ' ' . $uri;
	foreach ( array( 'sugestoes', 'produtos', 'pedido', 'nonce' ) as $rota ) {
		if ( false !== strpos( $alvo, '/awr/v1/' . $rota ) ) { return true; }
	}
	return false;
}

add_filter( 'rest_authentication_errors', function ( $result ) {
	if ( is_wp_error( $result ) && 'rest_cookie_invalid_nonce' === $result->get_error_code() && awr_rest_public_route() ) {
		return null;
	}
	return $result;
}, 999 );


add_action( 'rest_api_init', function () {
	// Consulta pública de prazo/frete por CEP (somente leitura, faixas oficiais).
	register_rest_route( 'awr/v1', '/frete', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$cep = substr( preg_replace( '/\D/', '', (string) $req->get_param( 'cep' ) ), 0, 8 );
			return rest_ensure_response( function_exists( 'awr_frete_por_cep' ) ? awr_frete_por_cep( $cep ) : array( 'tipo' => 'sem-cobertura', 'valor' => null, 'prazo' => 'Consulte a entrega no WhatsApp' ) );
		},
	) );
	// Diagnóstico (somente administrador): por que um SKU não traz preço/foto.
	register_rest_route( 'awr/v1', '/diag', array(
		'methods'             => 'GET',
		'permission_callback' => function () { return current_user_can( 'manage_options' ); },
		'callback'            => function ( WP_REST_Request $req ) {
			global $wpdb;
			$skus = array_slice( array_filter( array_map( 'trim', explode( ',', (string) $req->get_param( 'skus' ) ) ) ), 0, 12 );
			$out  = array();
			foreach ( $skus as $sku ) {
				$up  = strtoupper( $sku );
				$woo = function_exists( 'wc_get_product_id_by_sku' ) ? (int) wc_get_product_id_by_sku( $up ) : 0;
				$row = $wpdb->get_row( $wpdb->prepare( // phpcs:ignore WordPress.DB
					"SELECT pm.post_id, p.post_type, p.post_status FROM {$wpdb->postmeta} pm
					 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
					 WHERE pm.meta_key = '_sku' AND UPPER(TRIM(pm.meta_value)) = %s LIMIT 1",
					$up
				), ARRAY_A );
				$id   = awr_lookup_product_id( $up );
				$prod = $id && function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null;
				$key  = awr_prod_bundle_key( array( $up ) );
				$out[ $up ] = array(
					'woo_lookup_id' => $woo,
					'postmeta'      => $row,
					'resolved_id'   => $id,
					'price'         => $prod ? (float) $prod->get_price() : null,
					'has_image'     => $prod ? (bool) $prod->get_image_id() : false,
					'status'        => $prod ? $prod->get_status() : null,
					'cache_bundle'  => get_transient( $key ) ? 'presente' : 'vazio',
				);
			}
			return array(
				'woocommerce' => function_exists( 'wc_get_product' ),
				'theme'       => AWR_VERSION,
				'skus'        => $out,
			);
		},
	) );

	// Nonce fresco para o checkout: nunca pode ser cacheado.
	register_rest_route( 'awr/v1', '/nonce', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function () {
			if ( ! headers_sent() ) { nocache_headers(); }
			if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
			return array( 'nonce' => wp_create_nonce( 'wp_rest' ) );
		},
	) );


	register_rest_route( 'awr/v1', '/sugestoes', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'args'                => array( 'q' => array( 'type' => 'string' ) ),
		'callback'            => function ( WP_REST_Request $req ) {
			return awr_search_suggestions_response( $req->get_param( 'q' ) );
		},
	) );

	register_rest_route( 'awr/v1', '/produtos', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			return awr_search_products_response( $req->get_params() );
		},
	) );

	register_rest_route( 'awr/v1', '/pedido', array(
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$payload = $req->get_json_params();
			if ( ! is_array( $payload ) ) { $payload = $req->get_params(); }

			// Anti-spam simples: honeypot + rate-limit por IP.
			$hp = trim( (string) ( $payload['awr_hp'] ?? ( $payload['website'] ?? '' ) ) );
			if ( '' !== $hp ) {
				return new WP_Error( 'spam', 'Requisição inválida.', array( 'status' => 400 ) );
			}
			$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
			// 5.48.0 — atrás de Cloudflare/proxy, REMOTE_ADDR é o IP do proxy, compartilhado
			// por muitos clientes: o limite de 8 pedidos/10 min podia bloquear compras reais.
			foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR' ) as $awr_h ) {
				if ( ! empty( $_SERVER[ $awr_h ] ) ) {
					$ip .= '|' . sanitize_text_field( trim( explode( ',', wp_unslash( $_SERVER[ $awr_h ] ) )[0] ) );
					break;
				}
			}
			$key = 'awr_rl_' . md5( $ip );
			$use_cache = function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache();
			$hits = (int) ( $use_cache ? wp_cache_get( $key, 'awr' ) : get_transient( $key ) );
			if ( $hits > 8 ) {
				return new WP_Error( 'rate_limited', 'Muitas tentativas. Fale conosco pelo WhatsApp.', array( 'status' => 429 ) );
			}
			if ( $use_cache ) {
				wp_cache_set( $key, $hits + 1, 'awr', 10 * MINUTE_IN_SECONDS );
			} else {
				set_transient( $key, $hits + 1, 10 * MINUTE_IN_SECONDS );
			}


			if ( empty( $payload['nome'] ) || empty( $payload['telefone'] ) ) {
				return new WP_Error( 'invalid', 'Nome e telefone são obrigatórios.', array( 'status' => 400 ) );
			}
			return awr_create_order( $payload );
		},
	) );
} );
