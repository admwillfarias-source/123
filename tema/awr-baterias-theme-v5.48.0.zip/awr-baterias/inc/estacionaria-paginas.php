<?php
/**
 * 5.46.0 — Arquitetura comercial das baterias estacionárias.
 *
 * Páginas por aplicação (nobreak/UPS, alarme e segurança, energia solar,
 * condomínios e empresas) e por amperagem (só as que têm modelo no
 * catálogo — assets/data/estacionaria.json). Cada página tem texto, FAQ,
 * tabela de modelos e CTA próprios; nada é gerado por troca de palavra.
 *
 * URL: /baterias-estacionarias/{slug}/  (rota "estac_sub").
 * 70Ah e 100Ah ficaram de fora de propósito: não há modelo com essa
 * amperagem no catálogo, e uma página sem produto não vende.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Definição das páginas. */
function awr_est_paginas() {
	static $p = null;
	if ( null !== $p ) { return $p; }
	$p = array(
		'nobreak-e-ups'          => array(
			'tipo'    => 'aplicacao',
			'publico' => 'B2C e pequenas empresas',
			'tribos'  => array( 'ti' ),
			'termos'  => array( 'nobreak', 'ups', 'rack', 'pabx' ),
			'title'   => 'Bateria para Nobreak e UPS em Porto Alegre | AWR',
			'desc'    => 'Bateria estacionária para nobreak e UPS com dimensionamento grátis pela carga real, nota fiscal, troca no local na Grande POA e recolhimento da usada.',
			'h1'      => 'Bateria para nobreak e UPS',
			'lead'    => 'Nobreak apitando ou desligando antes da hora? Indicamos a bateria pela carga e pela autonomia que você precisa, com troca no local na Grande Porto Alegre.',
			'texto'   => array(
				'O nobreak usa bateria estacionária selada (VRLA), feita para ficar em flutuação — sempre carregada — e descarregar devagar quando a rede cai. Bateria automotiva no lugar dela dura pouco e pode estufar, porque foi projetada para um pico curto de corrente na partida.',
				'Para acertar o modelo, levamos em conta a potência real ligada no nobreak (em watts), quanto tempo ela precisa continuar funcionando e a tensão do banco. Com isso definimos a amperagem e a quantidade de baterias — e evitamos tanto o banco subdimensionado, que desliga cedo, quanto o superdimensionado, que custa mais sem necessidade.',
				'Quando o banco tem mais de uma bateria, a troca deve ser do conjunto inteiro: misturar baterias novas e velhas faz as novas trabalharem acima do limite e encurta a vida do banco.',
			),
			'faq'     => array(
				array( 'q' => 'Posso usar bateria de carro no nobreak?', 'r' => 'Não é recomendado. A bateria automotiva é feita para dar partida, não para ficar em flutuação e descarregar devagar. No nobreak ela perde capacidade rápido e pode estufar. O certo é a bateria estacionária selada (VRLA).' ),
				array( 'q' => 'Como saber a bateria certa do meu nobreak?', 'r' => 'Informe a marca e o modelo do nobreak, a tensão do banco (12V, 24V, 48V) e quantas baterias ele usa. Se quiser aumentar a autonomia, diga também a carga ligada em watts. Com esses dados indicamos o modelo e a quantidade.' ),
				array( 'q' => 'Preciso trocar todas as baterias do banco?', 'r' => 'Sim. Em bancos com duas ou mais baterias em série, trocar só uma desequilibra o conjunto e a nova acaba durando menos. A troca do banco completo é o que garante a autonomia esperada.' ),
				array( 'q' => 'Vocês recolhem a bateria velha?', 'r' => 'Sim. Em toda troca recolhemos o banco antigo e encaminhamos para reciclagem licenciada, conforme a Política Nacional de Resíduos Sólidos.' ),
			),
			'wa'      => 'Olá! Preciso de bateria para nobreak/UPS. Posso passar o modelo do nobreak para vocês indicarem a bateria certa?',
			'cta'     => 'Indicar a bateria do meu nobreak',
		),
		'alarme-e-seguranca'     => array(
			'tipo'    => 'aplicacao',
			'publico' => 'B2C, condomínios e instaladores',
			'tribos'  => array( 'ti' ),
			'termos'  => array( 'alarme', 'cftv', 'portão', 'portao', 'segurança', 'seguranca', 'cerca' ),
			'title'   => 'Bateria para Alarme, CFTV e Portão Automático | AWR',
			'desc'    => 'Bateria estacionária para central de alarme, CFTV, cerca elétrica e portão automático. Indicação pelo equipamento, nota fiscal e troca no local na Grande POA.',
			'h1'      => 'Bateria para alarme, CFTV e portão automático',
			'lead'    => 'Sem energia, o sistema de segurança precisa continuar gravando, monitorando e abrindo o portão. A bateria certa evita a janela cega justamente na hora da queda de luz.',
			'texto'   => array(
				'Centrais de alarme e cercas elétricas costumam usar baterias seladas pequenas, de 12V e baixa amperagem. Gravadores de CFTV com várias câmeras, portões automáticos e controle de acesso de condomínio pedem bancos maiores, porque a carga ligada é bem mais alta.',
				'A bateria de segurança fica meses em flutuação sem ser exigida. Por isso ela costuma falhar sem aviso: quando a luz cai, descobre-se que já não segura carga. O teste periódico e a troca preventiva custam menos do que uma gravação perdida ou um portão travado.',
				'Para as baterias seladas de 7Ah a 18Ah das centrais de alarme, consulte também a linha Moura para nobreak e segurança. Para CFTV, portão e controle de acesso, indicamos os modelos da tabela abaixo conforme a carga.',
			),
			'faq'     => array(
				array( 'q' => 'Qual bateria usa a central de alarme?', 'r' => 'A maioria das centrais residenciais usa bateria selada de 12V com baixa amperagem (na faixa de 7Ah). Confira a etiqueta da bateria atual ou o manual da central e envie a foto pelo WhatsApp que confirmamos o modelo.' ),
				array( 'q' => 'Quanto tempo o CFTV funciona sem energia?', 'r' => 'Depende da carga: quantas câmeras, o gravador e se há switch ou roteador ligados. Com a potência em watts e a autonomia desejada, calculamos a amperagem do banco — use a calculadora abaixo ou fale com a gente.' ),
				array( 'q' => 'Vocês atendem condomínio e empresa de segurança?', 'r' => 'Sim. Emitimos nota fiscal em CNPJ, fazemos cotação formal para síndico e administradora e trabalhamos com reposição programada para instaladores.' ),
				array( 'q' => 'De quanto em quanto tempo trocar a bateria do alarme?', 'r' => 'A vida útil varia com a temperatura do local e com a frequência de quedas de energia. O ideal é testar a autonomia periodicamente e trocar ao primeiro sinal de que ela não segura a carga.' ),
			),
			'wa'      => 'Olá! Preciso de bateria para alarme/CFTV/portão. Posso mandar a foto da bateria atual?',
			'cta'     => 'Mandar a foto da bateria atual',
			'links'   => array( array( 'url' => '/marca/moura-nobreak/', 'label' => 'Baterias Moura de 7Ah a 18Ah para alarme e nobreak' ) ),
		),
		'energia-solar'          => array(
			'tipo'    => 'aplicacao',
			'publico' => 'B2C e integradores',
			'tribos'  => array( 'solar' ),
			'termos'  => array( 'solar', 'off-grid', 'híbrid', 'hibrid' ),
			'title'   => 'Bateria para Energia Solar Off-Grid e Híbrida | AWR',
			'desc'    => 'Bateria estacionária para energia solar off-grid e híbrida: banco dimensionado pelo consumo e pela autonomia, nota fiscal em CPF ou CNPJ e envio para todo o RS.',
			'h1'      => 'Bateria para energia solar off-grid e híbrida',
			'lead'    => 'O banco de baterias é o que mantém o sistema solar funcionando à noite e em dias nublados. Dimensionamos pelo seu consumo real, sem custo.',
			'texto'   => array(
				'Em sistemas off-grid e híbridos a bateria trabalha em ciclo: carrega de dia e descarrega à noite, todos os dias. Por isso a escolha olha para a profundidade de descarga e para a vida em ciclos, não só para a amperagem. Descarregar o banco abaixo de 50% com frequência encurta muito a vida útil da bateria de chumbo-ácido.',
				'O dimensionamento parte do consumo diário em watts-hora, dos dias de autonomia desejados e da tensão do inversor (12V, 24V ou 48V). A partir disso definimos a amperagem e quantas baterias vão em série e em paralelo.',
				'Para integradores e instaladores trabalhamos com preço de parceiro, reposição programada e nota fiscal em CNPJ. Para quem está montando o próprio sistema, revisamos o projeto antes da compra.',
			),
			'faq'     => array(
				array( 'q' => 'Qual bateria usar em energia solar?', 'r' => 'Bateria estacionária de ciclo, dimensionada pelo consumo diário e pela autonomia. A bateria automotiva não é feita para descarga diária e dura pouco nesse uso.' ),
				array( 'q' => 'Quantas baterias preciso no sistema off-grid?', 'r' => 'Depende do consumo diário em Wh, dos dias de autonomia e da tensão do inversor. Use a calculadora abaixo como ponto de partida e confirme o banco com a nossa equipe antes de comprar.' ),
				array( 'q' => 'Vocês enviam para fora da Grande Porto Alegre?', 'r' => 'Sim. Fora da área de atendimento próprio a venda é com envio por transportadora, nota fiscal e frete cotado pelo WhatsApp.' ),
				array( 'q' => 'Posso misturar baterias de amperagens diferentes no banco?', 'r' => 'Não é recomendado. Baterias diferentes no mesmo banco carregam e descarregam de forma desigual, e a mais fraca limita o conjunto. Use modelos iguais e do mesmo lote.' ),
			),
			'wa'      => 'Olá! Preciso de bateria para sistema de energia solar. Podem me ajudar a dimensionar o banco?',
			'cta'     => 'Dimensionar meu banco solar',
		),
		'condominios-e-empresas' => array(
			'tipo'    => 'aplicacao',
			'publico' => 'B2B',
			'tribos'  => array( 'ti', 'b2b' ),
			'termos'  => array(),
			'title'   => 'Bateria Estacionária para Condomínios e Empresas | AWR',
			'desc'    => 'Baterias estacionárias para condomínios, administradoras e empresas: cotação formal, nota fiscal em CNPJ, troca programada do banco e recolhimento da usada.',
			'h1'      => 'Baterias estacionárias para condomínios e empresas',
			'lead'    => 'Portão, CFTV, iluminação de emergência, nobreak de servidor e telecom: cotação formal para síndico, administradora e compras, com nota em CNPJ.',
			'texto'   => array(
				'Em condomínio e empresa a bateria raramente é um item só: são vários equipamentos (portão, interfone, CFTV, iluminação de emergência, nobreak do servidor) com bancos de idades diferentes. Fazemos o levantamento e montamos uma proposta única, com o que precisa ser trocado agora e o que pode ser programado.',
				'A cotação sai em formato formal, pronta para assembleia ou para o setor de compras, com nota fiscal em CNPJ. Na troca, recolhemos as baterias antigas e damos destinação ambiental correta.',
				'Para empresas de TI, segurança eletrônica e administradoras com vários prédios, trabalhamos com preço por lote e reposição programada.',
			),
			'faq'     => array(
				array( 'q' => 'Vocês emitem nota fiscal em CNPJ?', 'r' => 'Sim. Emitimos nota em CNPJ e enviamos a cotação em formato formal para síndico, administradora ou setor de compras.' ),
				array( 'q' => 'Fazem levantamento das baterias do condomínio?', 'r' => 'Sim. Listamos os equipamentos com bateria (portão, CFTV, alarme, iluminação de emergência, nobreak) e indicamos o que trocar agora e o que pode ser programado.' ),
				array( 'q' => 'Atendem empresas fora de Porto Alegre?', 'r' => 'Na Grande Porto Alegre fazemos a troca no local. Nas demais cidades a venda é com envio por transportadora e nota fiscal.' ),
				array( 'q' => 'O que acontece com as baterias antigas?', 'r' => 'Recolhemos o banco antigo na troca e encaminhamos para reciclagem licenciada. Se precisar de documentação para auditoria, informe junto com o pedido de cotação.' ),
			),
			'wa'      => 'Olá! Sou de condomínio/empresa e preciso de cotação de baterias estacionárias com nota em CNPJ.',
			'cta'     => 'Pedir cotação com nota em CNPJ',
			'links'   => array( array( 'url' => '/solucoes-b2b/', 'label' => 'Soluções B2B: solar, provedores, agro e contratos de manutenção' ) ),
		),
	);
	// Páginas por amperagem: só onde existe modelo no catálogo.
	foreach ( array( 60, 150, 220 ) as $ah ) {
		$p[ $ah . 'ah' ] = array(
			'tipo'    => 'amperagem',
			'ah'      => $ah,
			'publico' => 'B2C e B2B',
			'tribos'  => array(),
			'termos'  => array(),
			'title'   => "Bateria Estacionária {$ah}Ah 12V | Preço e Indicação | AWR",
			'desc'    => "Bateria estacionária {$ah}Ah 12V para nobreak, energia solar e telecom. Confirmamos a aplicação antes da compra, com nota fiscal e troca no local na Grande POA.",
			'h1'      => "Bateria estacionária {$ah}Ah",
			'lead'    => "Modelos de {$ah}Ah em 12V com indicação pela aplicação: confirmamos se é a amperagem certa para a sua carga antes de você comprar.",
			'texto'   => array(), // montado em awr_est_pagina_texto_ah().
			'faq'     => array(),
			'wa'      => "Olá! Preciso de bateria estacionária {$ah}Ah. Podem confirmar o modelo e o preço?",
			'cta'     => "Confirmar a bateria {$ah}Ah",
		);
	}
	return $p;
}

function awr_est_pagina( $slug ) {
	$p = awr_est_paginas();
	return $p[ sanitize_title( (string) $slug ) ] ?? null;
}

function awr_est_pagina_url( $slug ) {
	return home_url( '/baterias-estacionarias/' . $slug . '/' );
}

/** Modelos da tabela oficial que atendem à página (por tribo, termo ou amperagem). */
function awr_est_pagina_modelos( $pg ) {
	$d   = function_exists( 'awr_data' ) ? (array) awr_data( 'estacionaria' ) : array();
	$out = array();
	foreach ( (array) ( $d['modelos'] ?? array() ) as $m ) {
		$ah = (int) $m['ah'];
		if ( 'amperagem' === $pg['tipo'] ) {
			if ( $ah === (int) $pg['ah'] ) { $out[] = $m; }
			continue;
		}
		$ok = in_array( $m['tribo'] ?? '', $pg['tribos'], true );
		foreach ( $pg['termos'] as $t ) {
			if ( false !== mb_stripos( (string) ( $m['aplicacao'] ?? '' ), $t ) ) { $ok = true; }
		}
		if ( $ok ) { $out[] = $m; }
	}
	return $out;
}

/** Texto e FAQ das páginas de amperagem, a partir dos modelos reais. */
function awr_est_pagina_texto_ah( $pg, $modelos ) {
	$ah   = (int) $pg['ah'];
	$usos = array();
	foreach ( $modelos as $m ) { $usos[] = $m['codigo'] . ' (' . $m['aplicacao'] . ')'; }
	$wh   = $ah * 12;
	$texto = array(
		"No catálogo da AWR, os modelos estacionários de {$ah}Ah em 12V são: " . implode( '; ', $usos ) . '.',
		"Uma bateria de {$ah}Ah em 12V guarda cerca de {$wh} Wh nominais. Na prática, para preservar a vida útil, considere usar no máximo metade disso por descarga e desconte a perda do inversor — a calculadora abaixo já faz essa conta.",
		"Antes de comprar, confirme se {$ah}Ah é mesmo a amperagem certa: em bancos de nobreak e solar, às vezes duas baterias menores em paralelo ou uma tensão de banco diferente resolvem melhor. Fazemos essa conferência sem custo.",
	);
	$faq = array(
		array( 'q' => "Para que serve a bateria estacionária {$ah}Ah?", 'r' => 'Nos modelos que trabalhamos: ' . implode( '; ', array_map( function ( $m ) { return $m['aplicacao']; }, $modelos ) ) . '. Confirmamos a aplicação pelo seu equipamento antes da compra.' ),
		array( 'q' => "Quanto tempo dura uma bateria {$ah}Ah sem energia?", 'r' => "Depende da carga ligada. Com descarga até 50% e inversor com cerca de 85% de rendimento, uma bateria de {$ah}Ah em 12V entrega por volta de " . (int) round( $wh * 0.5 * 0.85 ) . ' Wh úteis — por exemplo, uma carga de 100 W por cerca de ' . number_format( ( $wh * 0.5 * 0.85 ) / 100, 1, ',', '' ) . ' horas. É uma estimativa: confirme com a gente para o seu caso.' ),
		array( 'q' => 'Vocês fazem a troca no local?', 'r' => 'Na Grande Porto Alegre, sim, com recolhimento da bateria usada. Nas demais cidades a venda é com envio por transportadora e nota fiscal.' ),
	);
	return array( $texto, $faq );
}

/** Produtos estacionários da loja (Woo) que casam com a página. */
function awr_est_pagina_produtos( $pg ) {
	if ( ! function_exists( 'awr_shop_products_by_cat' ) ) { return array(); }
	$todos = (array) awr_shop_products_by_cat( 'estacionaria' );
	if ( 'amperagem' !== $pg['tipo'] ) { return $todos; }
	$out = array();
	foreach ( $todos as $p ) {
		$nome = (string) ( $p['name'] ?? '' );
		$ah   = (int) ( $p['amperagem'] ?? 0 );
		if ( ! $ah && preg_match( '/(\d{2,3})\s*ah/i', $nome, $m ) ) { $ah = (int) $m[1]; }
		if ( $ah === (int) $pg['ah'] ) { $out[] = $p; }
	}
	return $out;
}

/** Links da navegação entre as páginas estacionárias (hub ↔ subpáginas). */
function awr_est_paginas_nav( $atual = '' ) {
	$out = array();
	foreach ( awr_est_paginas() as $slug => $pg ) {
		if ( $slug === $atual ) { continue; }
		$out[] = array(
			'url'   => awr_est_pagina_url( $slug ),
			'label' => 'amperagem' === $pg['tipo'] ? 'Estacionária ' . $pg['ah'] . 'Ah' : $pg['h1'],
			'tipo'  => $pg['tipo'],
		);
	}
	return $out;
}
