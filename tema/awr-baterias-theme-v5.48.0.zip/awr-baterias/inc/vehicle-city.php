<?php
/**
 * Veículo × cidade — paridade com src/lib/vehicleCity.ts do app.
 *
 * /baterias-para/                        → hub de modelos
 * /baterias-para/{marca-modelo}/         → página do modelo
 * /baterias-para/{marca-modelo}/{cidade}/→ página local (entrega ou envio)
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Índice de modelos (marca+modelo): slug => dados. */
function awr_vc_models() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		$slug = awr_slugify( $it['ma'] . ' ' . $it['mo'] );
		if ( ! isset( $out[ $slug ] ) ) {
			$out[ $slug ] = array(
				'slug'        => $slug,
				'marca'       => $it['ma'],
				'modelo'      => $it['mo'],
				'marca_slug'  => awr_slugify( $it['ma'] ),
				'modelo_slug' => awr_slugify( $it['mo'] ),
				'de'          => (int) $it['d'],
				'ate'         => (int) $it['a'],
				'variantes'   => 1,
			);
		} else {
			$out[ $slug ]['de']        = min( $out[ $slug ]['de'], (int) $it['d'] );
			$out[ $slug ]['ate']       = max( $out[ $slug ]['ate'], (int) $it['a'] );
			$out[ $slug ]['variantes'] = $out[ $slug ]['variantes'] + 1;
		}
	}
	ksort( $out );
	return $out;
}

function awr_vc_model( $slug ) {
	$fam = awr_vc_familia( $slug );
	if ( $fam ) { return $fam; }
	$m = awr_vc_models();
	return isset( $m[ $slug ] ) ? $m[ $slug ] : null;
}

/**
 * Veículo prioritário (assets/data/veiculos-prioritarios.json, espelha
 * src/data/veiculosPrioritarios.ts): agrupa todas as versões do catálogo.
 */
function awr_vc_familia( $slug ) {
	static $cache = array();
	if ( array_key_exists( $slug, $cache ) ) { return $cache[ $slug ]; }
	$cache[ $slug ] = null;
	foreach ( (array) awr_data( 'veiculos-prioritarios' ) as $v ) {
		if ( $v['slug'] !== $slug ) { continue; }
		$re    = '/' . str_replace( '/', '\\/', $v['padrao'] ) . '/u';
		$items = array();
		foreach ( awr_batteries()['items'] as $it ) {
			if ( $it['ma'] === $v['marca'] && preg_match( $re, $it['mo'] ) ) { $items[] = $it; }
		}
		if ( ! $items ) { break; }
		$cache[ $slug ] = array(
			'slug'        => $v['slug'],
			'marca'       => $v['marca'],
			'modelo'      => $v['nome'],
			'label'       => $v['nome'],
			'familia'     => true,
			'itens'       => $items,
			'marca_slug'  => awr_slugify( $v['marca'] ),
			'modelo_slug' => $v['slug'],
			'de'          => min( array_map( function ( $i ) { return (int) $i['d']; }, $items ) ),
			'ate'         => max( array_map( function ( $i ) { return (int) $i['a']; }, $items ) ),
			'variantes'   => count( $items ),
		);
		break;
	}
	return $cache[ $slug ];
}

/** Linhas da tabela de versões do veículo (sem duplicatas). */
function awr_vc_versoes( $m ) {
	$out = array(); $seen = array();
	foreach ( awr_vc_items( $m ) as $it ) {
		$skus = awr_skus_from_items( array( $it ) );
		$key  = $it['d'] . '-' . $it['a'] . '-' . implode( ',', wp_list_pluck( $skus, 'sku' ) );
		if ( isset( $seen[ $key ] ) ) { continue; }
		$seen[ $key ] = true;
		$ahs = array();
		foreach ( $skus as $s ) { $ah = awr_extract_amperage( $s['sku'] ); if ( $ah ) { $ahs[ (int) $ah ] = (int) $ah; } }
		sort( $ahs );
		$out[] = array( 'versao' => $it['mo'], 'anos' => $it['d'] === $it['a'] ? (string) $it['d'] : $it['d'] . ' a ' . $it['a'], 'ahs' => $ahs, 'skus' => $skus );
	}
	usort( $out, function ( $a, $b ) { return strcmp( $a['anos'], $b['anos'] ); } );
	return $out;
}

/** Variantes (itens do catálogo) do modelo combinado. */
function awr_vc_items( $m ) {
	if ( ! empty( $m['itens'] ) ) { return $m['itens']; }
	return awr_vehicle_variants( $m['marca_slug'], $m['modelo_slug'] );
}

/** SKUs compatíveis com o modelo. */
function awr_vc_skus( $m ) {
	return awr_skus_from_items( awr_vc_items( $m ) );
}

/** Amperagens presentes nos SKUs do modelo. */
function awr_vc_amperagens( $m ) {
	$out = array();
	foreach ( awr_vc_skus( $m ) as $s ) {
		$ah = awr_extract_amperage( $s['sku'] );
		if ( $ah ) { $out[ (int) $ah ] = (int) $ah; }
	}
	sort( $out );
	return $out;
}

/** Nome apresentável do veículo. */
function awr_vc_label( $m ) {
	if ( ! empty( $m['label'] ) ) { return $m['label']; }
	$tc = function ( $s ) {
		$parts = explode( ' ', mb_strtolower( $s, 'UTF-8' ) );
		foreach ( $parts as $i => $w ) {
			if ( '' === $w ) { continue; }
			$parts[ $i ] = ( mb_strlen( $w, 'UTF-8' ) <= 2 && ! preg_match( '/^\d/', $w ) )
				? mb_strtoupper( $w, 'UTF-8' )
				: mb_strtoupper( mb_substr( $w, 0, 1, 'UTF-8' ), 'UTF-8' ) . mb_substr( $w, 1, null, 'UTF-8' );
		}
		return implode( ' ', $parts );
	};
	return trim( preg_replace( '/\s+/', ' ', $tc( $m['marca'] ) . ' ' . $tc( $m['modelo'] ) ) );
}

/** URL canônica veículo (+cidade). */
function awr_vc_url( $model_slug, $cidade_slug = '' ) {
	$u = '/baterias-para/' . $model_slug . '/';
	if ( $cidade_slug ) { $u .= $cidade_slug . '/'; }
	return home_url( $u );
}

/** Cidades disponíveis (cobertura + venda com envio), na ordem do app. */
function awr_vc_cidades() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$out = array();
	foreach ( awr_cidades() as $c ) { $out[] = array( 'mode' => 'cobertura', 'c' => $c ); }
	foreach ( awr_cidades_venda() as $c ) { $out[] = array( 'mode' => 'envio', 'c' => $c ); }
	return $out;
}

/**
 * Cidades que entram no SITEMAP veículo×cidade: TODAS (cobertura própria
 * + todas as cidades de venda com envio), ordenadas por prioridade de
 * rastreamento — cobertura (35 min) primeiro, depois capitais e maiores
 * mercados de envio, por fim a cauda longa. As páginas das primeiras
 * posições aparecem nas primeiras páginas do sitemap paginado.
 */
function awr_vc_cidades_sitemap() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$envio_foco = array(
		// RS — maiores cidades do interior.
		'caxias-do-sul', 'pelotas', 'santa-maria', 'passo-fundo', 'rio-grande',
		// SC — capital e maiores mercados.
		'florianopolis', 'joinville', 'blumenau', 'chapeco', 'sao-jose', 'criciuma',
		// SP — capital e maiores mercados.
		'sao-paulo', 'campinas', 'guarulhos', 'sao-bernardo-do-campo', 'osasco',
		'sorocaba', 'ribeirao-preto', 'sao-jose-dos-campos', 'santos',
		// PR — capital e maiores mercados.
		'curitiba', 'londrina', 'maringa', 'ponta-grossa', 'cascavel', 'foz-do-iguacu',
	);
	$cobertura = array();
	$foco      = array();
	$resto     = array();
	foreach ( awr_vc_cidades() as $vc ) {
		if ( 'cobertura' === $vc['mode'] ) {
			$cobertura[] = $vc;
		} elseif ( in_array( $vc['c']['slug'], $envio_foco, true ) ) {
			$foco[] = $vc;
		} else {
			$resto[] = $vc;
		}
	}
	$out = array_merge( $cobertura, $foco, $resto );
	return $out;
}

/** Modelos mais buscados — linkagem interna a partir das páginas de cidade. */
function awr_vc_populares() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$queridos = array(
		'Chevrolet Onix', 'Hyundai HB20', 'Volkswagen Gol', 'Toyota Corolla',
		'Honda Civic', 'Ford Ka', 'Fiat Uno', 'Fiat Palio', 'Fiat Strada',
		'Volkswagen Polo', 'Jeep Renegade', 'Toyota Hilux', 'Ford Ranger',
		'Chevrolet S10', 'Honda HR-V', 'Hyundai Creta', 'Nissan Kicks',
		'Volkswagen T-Cross', 'Chevrolet Tracker', 'Fiat Argo', 'Renault Kwid',
		'Fiat Toro', 'Fiat Mobi', 'Volkswagen Saveiro',
	);
	$out = array();
	$all = awr_vc_models();
	foreach ( $queridos as $q ) {
		$s = awr_slugify( $q );
		if ( isset( $all[ $s ] ) ) { $out[] = $all[ $s ]; }
	}
	return $out;
}

/** Resolve cidade por slug → array(mode, c) ou null. */
function awr_vc_cidade( $slug ) {
	$c = awr_cidade_by_slug( $slug );
	if ( $c ) { return array( 'mode' => 'cobertura', 'c' => $c ); }
	$c = awr_cidade_venda_by_slug( $slug );
	if ( $c ) { return array( 'mode' => 'envio', 'c' => $c ); }
	return null;
}

/** Hash determinístico (FNV-1a), igual ao do app. */
function awr_vc_hash( $s ) {
	$h = 2166136261;
	$len = strlen( $s );
	for ( $i = 0; $i < $len; $i++ ) {
		$h ^= ord( $s[ $i ] );
		$h  = ( $h * 16777619 ) & 0xFFFFFFFF;
	}
	return abs( $h );
}

function awr_vc_pick( $arr, $seed, $offset = 0 ) {
	return $arr[ ( $seed + $offset ) % count( $arr ) ];
}

/**
 * Conteúdo determinístico da página veículo × cidade.
 *
 * @param array $m     Modelo.
 * @param array $city  array(mode, c).
 * @return array
 */
function awr_vc_content( $m, $city ) {
	$label = awr_vc_label( $m );
	$seed  = awr_vc_hash( $m['slug'] . '|' . $city['c']['slug'] );
	$ahs   = awr_vc_amperagens( $m );
	$ahtxt = $ahs ? ( $ahs[0] . 'Ah' . ( count( $ahs ) > 1 ? ' a ' . end( $ahs ) . 'Ah' : '' ) ) : '60Ah';
	$anos  = $m['de'] === $m['ate'] ? (string) $m['de'] : $m['de'] . ' a ' . $m['ate'];
	$marcas = array();
	foreach ( awr_vc_skus( $m ) as $s ) { $marcas[ $s['brand'] ] = $s['brand']; }
	$marcas     = array_values( $marcas );
	$marcas_txt = $marcas ? implode( ', ', $marcas ) : 'Moura, Heliar, Zetta e Excell';
	$marca1     = $marcas ? $marcas[0] : 'Moura';
	$c          = $city['c'];

	if ( 'cobertura' === $city['mode'] ) {
		$pz      = awr_city_prazo( $c );
		$pz_tit  = $pz['rapida'] ? "Entrega em {$pz['min']} min" : $pz['titulo'];
		$bairros = array_slice( (array) ( $c['bairros'] ?? array() ), 0, 6 );
		$aberturas = array(
			"Precisa trocar a bateria do {$label} em {$c['nome']}? A AWR entrega e instala no local, {$c['transitoContexto']}.",
			"Bateria do {$label} descarregada em {$c['nome']}? Levamos a bateria certa até você, {$c['rotaLoja']}.",
			"Em {$c['nome']}, o {$label} sai com bateria nova instalada no mesmo dia — sem precisar guinchar o carro.",
		);
		$tecnicos = array(
			"As versões do {$label} fabricadas entre {$anos} usam bateria de {$ahtxt}. Levamos os modelos compatíveis ({$marcas_txt}) no veículo de atendimento e conferimos a polaridade antes de instalar.",
			"Para o {$label} {$anos}, a especificação de fábrica fica na faixa de {$ahtxt}. Trabalhamos com {$marcas_txt}, todas com nota fiscal e garantia de fábrica de até 24 meses.",
			"O {$label} {$anos} aceita bateria de {$ahtxt}. Antes de fechar o pedido confirmamos o ano e a versão para não errar terminal nem medida da caixa.",
		);
		$locais = array(
			'Atendemos ' . $c['nome'] . ' inteira — ' . implode( ', ', $bairros ) . ' e demais bairros — com referência ' . ( $c['pontoReferencia'] ?? 'a loja mais próxima' ) . '.',
			'A cobertura em ' . $c['nome'] . ' inclui ' . implode( ', ', $bairros ) . ', com saída ' . ( $c['rotaLoja'] ?? 'da loja mais próxima' ) . '.',
		);
		return array(
			'title'      => awr_seo_trim( awr_vc_titulo_base( $label, $c['nome'] ) . " | {$pz_tit}", 60 ),
			'desc'       => awr_seo_trim( awr_vc_pick( array(
				"Compre bateria {$ahtxt} para {$label} em {$c['nome']}: entrega e instalação grátis {$pz['curto']}, nota fiscal e 10x sem juros. Peça agora.",
				"Bateria para {$label} em {$c['nome']}, com amperagem compatível e instalação grátis {$pz['curto']}. Garantia de fábrica. Chame no WhatsApp.",
				"Carro não liga em {$c['nome']}? Peça a bateria {$ahtxt} para {$label}, com preço no Pix e troca no local {$pz['curto']}. Compre agora.",
			), $seed, 3 ), 155 ),
			'h1'         => "Bateria para {$label} em {$c['nome']}",
			'intro'      => awr_vc_pick( $aberturas, $seed ),
			'paragrafos' => array( awr_vc_pick( $tecnicos, $seed, 1 ), awr_vc_pick( $locais, $seed, 2 ) ),
			'entrega'    => "Entrega e instalação grátis {$pz['longo']} em {$c['nome']}. Pagamento no local com Pix (3% de desconto), débito ou crédito em 10x sem juros.",
			'faq'        => array(
				array(
					'pergunta' => "Qual bateria usar no {$label} em {$c['nome']}?",
					'resposta' => "O {$label} {$anos} usa bateria de {$ahtxt}. Em {$c['nome']} entregamos {$marcas_txt} com nota fiscal e garantia de fábrica de até 24 meses.",
				),
				array(
					'pergunta' => "Quanto tempo demora a entrega em {$c['nome']}?",
					'resposta' => $pz['rapida']
						? "A média em {$c['nome']} é de {$pz['min']} minutos, {$c['transitoContexto']}. O prazo é estimativa e depende do trânsito no momento do pedido."
						: "Em {$c['nome']} a entrega com instalação é {$pz['longo']}. Confirmamos o horário pelo WhatsApp antes da saída.",
				),
				array(
					'pergunta' => "A instalação da bateria do {$label} é cobrada?",
					'resposta' => "Não. A instalação no local é gratuita em {$c['nome']}, feita por técnico com ferramenta adequada, incluindo teste do alternador e descarte da bateria velha.",
				),
				array(
					'pergunta' => "Vocês dão desconto na bateria velha do {$label}?",
					'resposta' => "Sim. A bateria velha é aceita como base de troca e o desconto é abatido na hora, direto no valor final do pedido em {$c['nome']}.",
				),
			),
		);
	}

	$uf_nome  = $c['ufNome'] ?? $c['estado'];
	$contexto = $c['contexto'] ?? 'com envio por transportadora';
	$aberturas = array(
		"Vendemos e enviamos a bateria do {$label} para {$c['nome']} ({$uf_nome}) — {$contexto}.",
		"Quem tem {$label} em {$c['nome']} compra pelo WhatsApp e recebe por transportadora: {$contexto}.",
	);
	return array(
		'title'      => awr_seo_trim( awr_vc_titulo_base( $label, $c['nome'] ) . ' | Preço e Envio', 60 ),
		'desc'       => awr_seo_trim( "Compre bateria {$ahtxt} para {$label} em {$c['nome']}/{$c['estado']}, com nota fiscal, garantia e envio por transportadora. Peça agora no WhatsApp.", 155 ),
		'h1'         => "Bateria para {$label} em {$c['nome']}",
		'intro'      => awr_vc_pick( $aberturas, $seed ),
		'paragrafos' => array(
			"O {$label} {$anos} usa bateria de {$ahtxt}. Enviamos {$marcas_txt} para {$c['nome']}, sempre com nota fiscal em CPF ou CNPJ e garantia de fábrica de até 24 meses.",
			"O frete é cotado na hora pelo WhatsApp conforme o peso da bateria e o endereço em {$c['nome']}. A instalação fica por conta do cliente ou de uma oficina local de confiança.",
		),
		'entrega'    => "Envio por transportadora para {$c['nome']}/{$c['estado']}, com embalagem própria para bateria, nota fiscal e rastreio informado após a postagem.",
		'faq'        => array(
			array(
				'pergunta' => "Vocês entregam bateria de {$label} em {$c['nome']}?",
				'resposta' => "Sim, por transportadora. Em {$c['nome']} não fazemos instalação no local — enviamos a bateria com nota fiscal e garantia de fábrica.",
			),
			array(
				'pergunta' => "Qual amperagem da bateria do {$label}?",
				'resposta' => "As versões {$anos} usam bateria de {$ahtxt}. Confirme o ano e a versão pelo WhatsApp para conferirmos o modelo exato antes do envio.",
			),
			array(
				'pergunta' => "Como funciona a garantia em {$c['nome']}?",
				'resposta' => "A garantia é de fábrica e pode ser acionada em qualquer assistência autorizada da marca em {$c['nome']} ou região, mediante a nota fiscal.",
			),
			array(
				'pergunta' => "Quanto custa o frete para {$c['nome']}?",
				'resposta' => "O frete é cotado na hora pelo WhatsApp, com base no CEP de {$c['nome']} e no peso da bateria indicada para o {$label}.",
			),
		),
	);
}

/** Total de URLs veículo × cidade NO SITEMAP (todas as cidades com página ativa). */
function awr_vc_total_urls() {
	if ( function_exists( 'awr_idx_ativo' ) && awr_idx_ativo() ) { return awr_idx_vc_total(); }
	return count( awr_vc_models() ) * count( awr_vc_cidades_sitemap() );
}

/**
 * Modelos ordenados para o sitemap por score de popularidade (mesma
 * heurística do app: nº de variantes × 2 + amplitude de anos, com bônus
 * para marca de varejo, modelo campeão de busca e ano recente; penalidade
 * para linha agro/industrial). As combinações de maior demanda ficam nas
 * primeiras páginas do sitemap paginado.
 */
function awr_vc_models_sitemap() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$marcas_varejo = array(
		'FIAT', 'CHEVROLET', 'VOLKSWAGEN', 'FORD', 'HYUNDAI', 'TOYOTA', 'HONDA', 'RENAULT', 'JEEP', 'NISSAN',
		'PEUGEOT', 'CITROEN', 'KIA', 'MITSUBISHI', 'CHERY', 'SUZUKI', 'BMW', 'MERCEDES', 'MERCEDES-BENZ', 'AUDI',
		'VOLVO', 'LAND', 'RAM', 'DODGE', 'MINI', 'GWM', 'BYD', 'JAC', 'MG', 'SUBARU', 'LEXUS', 'TROLLER',
		'YAMAHA', 'KAWASAKI', 'HARLEY', 'DAFRA', 'SHINERAY', 'KYMCO', 'SUNDOWN', 'KTM',
	);
	$modelos_topo = array(
		'onix', 'gol', 'hb20', 'palio', 'uno', 'strada', 'toro', 'argo', 'cronos', 'mobi', 'siena', 'corolla',
		'civic', 'fit', 'city', 'renegade', 'compass', 'creta', 'duster', 'ecosport', 'ka', 'fiesta', 'focus',
		'polo', 'virtus', 't-cross', 'nivus', 'saveiro', 'voyage', 'fox', 'up', 'amarok', 'hilux', 's10', 'ranger',
		'tracker', 'spin', 'cobalt', 'prisma', 'celta', 'corsa', 'montana', 'kwid', 'sandero', 'logan', 'captur',
		'oroch', 'clio', 'march', 'versa', 'kicks', 'frontier', 'hr-v', 'wr-v', 'cr-v', 'sportage', 'cerato',
		'picanto', 'soul', 'tucson', 'santa fe', 'i30', 'elantra', 'asx', 'l200', 'pajero', 'outlander', 'tiggo',
		'jetta', 'golf', 'passat', 'biz', 'cg', 'titan', 'fan', 'bros', 'fazer', 'factor', 'xre', 'pop',
	);
	$termos_off = '/trator|colheitadeira|retroescavadeira|escavadeira|motoniveladora|carregadeira|empilhadeira|rolo compactador|pulverizador|guindaste|fora de estrada|onibus|ônibus|caminhao|caminhão|plataforma|cargo|constellation|worker|atego|accelo|axor|delivery|micro-?onibus|van carga/i';

	$models = array_values( awr_vc_models() );
	foreach ( $models as $i => $m ) {
		$modelo = function_exists( 'mb_strtolower' ) ? mb_strtolower( $m['modelo'], 'UTF-8' ) : strtolower( $m['modelo'] );
		$s      = ( (int) $m['variantes'] * 2 ) + ( $m['ate'] - $m['de'] );
		if ( $m['ate'] >= 2020 ) { $s += 30; }
		if ( in_array( strtoupper( $m['marca'] ), $marcas_varejo, true ) ) { $s += 200; }
		foreach ( $modelos_topo as $t ) {
			if ( false !== strpos( $modelo, $t ) ) { $s += 400; break; }
		}
		if ( preg_match( $termos_off, $modelo ) ) { $s -= 1000; }
		$models[ $i ]['score'] = $s;
	}
	usort(
		$models,
		function ( $a, $b ) {
			if ( $a['score'] === $b['score'] ) { return strcmp( $a['slug'], $b['slug'] ); }
			return $b['score'] - $a['score'];
		}
	);
	$out = $models;
	return $out;
}

/** Fatia paginada das URLs veículo × cidade do sitemap (sem materializar tudo). */
function awr_vc_sitemap_page( $page, $per ) {
	if ( function_exists( 'awr_idx_ativo' ) && awr_idx_ativo() ) { return awr_idx_vc_page( $page, $per ); }
	$models  = awr_vc_models_sitemap();
	$cidades = awr_vc_cidades_sitemap();
	$nc      = count( $cidades );
	$start   = max( 0, ( $page - 1 ) * $per );
	$end     = min( $start + $per, count( $models ) * $nc );
	$urls    = array();
	for ( $i = $start; $i < $end; $i++ ) {
		$m = $models[ intdiv( $i, $nc ) ];
		$c = $cidades[ $i % $nc ];
		$urls[] = awr_vc_url( $m['slug'], $c['c']['slug'] );
	}
	return $urls;
}

/**
 * 5.46.0 — "Bateria para {modelo} em {cidade}" sempre com a cidade: nomes de
 * modelo longos (máquinas, caminhões) faziam o corte em 60 caracteres engolir
 * a cidade e deixar o título terminando em "... em".
 */
function awr_vc_titulo_base( $label, $cidade ) {
	$fixo = 'Bateria para  em ' . $cidade;
	$max  = 60 - mb_strlen( $fixo );
	$lbl  = mb_strlen( $label ) > $max ? awr_seo_trim( $label, max( 10, $max ) ) : $label;
	return "Bateria para {$lbl} em {$cidade}";
}
