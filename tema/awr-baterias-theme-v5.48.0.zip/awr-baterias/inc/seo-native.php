<?php
/**
 * SEO das páginas nativas do WordPress (produtos da loja, posts do blog e
 * páginas antigas) — famílias que somam ~45 mil impressões/mês no Search
 * Console com CTR entre 0,2% e 1,4% porque o título vinha do plugin.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Títulos/descrições sob medida para os posts campeões de impressão. */
function awr_seo_posts_map() {
	return array(
		'quanto-custa-a-bateria-nova-do-dolphin-mini' => array(
			'title' => 'Bateria do Dolphin Mini: Preço Hoje e Troca no Local',
			'desc'  => 'Veja quanto custa a bateria nova do BYD Dolphin Mini, qual modelo é compatível e peça a sua com instalação grátis no local. Atendimento pelo WhatsApp.',
		),
		'quanto-dura-bateria-do-corolla'              => array(
			'title' => 'Quanto Dura a Bateria do Corolla? Troca em 35 min',
			'desc'  => 'Descubra a durabilidade real da bateria do Corolla, os sinais de que ela está no fim e troque hoje com entrega e instalação grátis. Peça pelo WhatsApp.',
		),
		'bateria-de-moto-quando-trocar'               => array(
			'title' => 'Bateria de Moto: Quando Trocar e Quanto Custa',
			'desc'  => 'Saiba quando trocar a bateria da sua moto, quanto custa hoje e como identificar o modelo certo. Entrega rápida em Porto Alegre e região pelo WhatsApp.',
		),
		'carro-nao-liga-faz-barulho-de-estalo-o-que-pode-ser' => array(
			'title' => 'Carro Não Liga e Faz Estalo? Resolva Hoje Mesmo',
			'desc'  => 'O estalo ao girar a chave quase sempre é bateria descarregada. Veja como confirmar e receba uma bateria nova instalada no local. Chame no WhatsApp agora.',
		),
		'guia-de-instalacao-segura-bateria-de-moto'   => array(
			'title' => 'Instalar Bateria de Moto: Passo a Passo Seguro',
			'desc'  => 'Guia rápido para trocar a bateria da moto sem danificar a parte elétrica, com a ordem certa dos polos. Precisa de bateria nova? Peça pelo WhatsApp.',
		),
	);
}

/** Páginas antigas do WordPress com muito volume de busca. */
function awr_seo_pages_map() {
	return array(
		'baterias-de-carro'                        => array(
			'title' => 'Bateria de Carro em POA | Entrega e Troca em 35 min',
			'desc'  => 'Bateria de carro Moura, Heliar, Zetta ou Excell entregue e instalada em até 35 min em Porto Alegre e região. Preço à vista no Pix. Peça pelo WhatsApp.',
		),
		'entrega-de-baterias-on-line-peca-ja-a-sua' => array(
			'title' => 'Entrega de Bateria On-line | Receba e Instale Hoje',
			'desc'  => 'Peça sua bateria on-line e receba com instalação grátis em até 35 min em Porto Alegre e região. Nota fiscal, garantia de fábrica e 10x sem juros.',
		),
		'baterias-moura-porto-alegre'              => array(
			'title' => 'Bateria Moura em Porto Alegre | Troca no Local Hoje',
			'desc'  => 'Bateria Moura original com garantia de fábrica, entregue e instalada no local em até 35 min em Porto Alegre. Preço à vista no Pix. Peça pelo WhatsApp.',
		),
	);
}

/** Nome comercial curto do produto, sem repetir a palavra "bateria". */
function awr_seo_produto_nome( $nome ) {
	$nome = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $nome ) ) );
	$nome = preg_replace( '/^bateria(s)?\s+/iu', '', $nome );
	return $nome;
}

/**
 * SEO das páginas nativas: retorna array com title/desc/canonical ou null
 * quando a página atual não é uma dessas famílias.
 */
function awr_seo_native_context() {
	static $ctx = false;
	if ( false !== $ctx ) { return $ctx; }
	$ctx = null;

	if ( is_admin() || awr_current_route() || is_front_page() || is_home() ) { return $ctx; }

	// 1) Produtos da loja (WooCommerce).
	if ( function_exists( 'is_product' ) && is_product() ) {
		$nome = awr_seo_produto_nome( get_the_title() );
		$slug = get_post_field( 'post_name', get_queried_object_id() );
		$wc   = function_exists( 'wc_get_product' ) ? wc_get_product( get_queried_object_id() ) : null;
		$val  = $wc ? (float) $wc->get_price() : 0;
		$sku   = $wc ? strtoupper( (string) $wc->get_sku() ) : '';
		$ah    = function_exists( 'awr_extract_amperage' ) ? (int) awr_extract_amperage( $sku, get_the_title() ) : 0;
		$marca = function_exists( 'awr_resolve_brand' ) ? awr_resolve_brand( $sku, get_the_title(), $wc ) : '';
		$copy  = function_exists( 'awr_product_seo_copy' )
			? awr_product_seo_copy( $sku, $nome, $marca, $ah, $val )
			: array( 'title' => "Bateria {$nome} | Entrega em Porto Alegre", 'desc' => "Bateria {$nome} com entrega e instalação em Porto Alegre e região." );
		// Consolida a duplicata nativa do Woo na rota pública estável por SKU.
		$canonical = $sku ? home_url( '/bateria/' . awr_sku_slug( $sku ) . '/' ) : get_permalink();

		$ctx  = array(
			'title'     => awr_seo_trim( $copy['title'], 60 ),
			'desc'      => awr_seo_trim( $copy['desc'], 155 ),
			'canonical' => $canonical,
		);
		return $ctx;
	}

	if ( ! is_singular( array( 'post', 'page' ) ) ) { return $ctx; }

	$slug = get_post_field( 'post_name', get_queried_object_id() );

	// 2) Posts do blog.
	if ( is_singular( 'post' ) ) {
		$map = awr_seo_posts_map();
		if ( isset( $map[ $slug ] ) ) {
			$ctx = array(
				'title'     => awr_seo_trim( $map[ $slug ]['title'], 60 ),
				'desc'      => awr_seo_trim( $map[ $slug ]['desc'], 155 ),
				'canonical' => get_permalink(),
			);
			return $ctx;
		}
		$titulo = get_the_title();
		$resumo = trim( wp_strip_all_tags( get_the_excerpt() ) );
		$ctx    = array(
			'title'     => awr_seo_title_with_suffix( $titulo ),
			'desc'      => awr_seo_trim(
				( $resumo ? $resumo . ' ' : '' ) . 'Precisa de bateria nova? Entrega e instalação grátis em até 35 min em Porto Alegre. Peça pelo WhatsApp.',
				155
			),
			'canonical' => get_permalink(),
		);
		return $ctx;
	}

	// 3) Páginas antigas de alto volume.
	$map = awr_seo_pages_map();
	if ( isset( $map[ $slug ] ) ) {
		$ctx = array(
			'title'     => awr_seo_trim( $map[ $slug ]['title'], 60 ),
			'desc'      => awr_seo_trim( $map[ $slug ]['desc'], 155 ),
			'canonical' => get_permalink(),
		);
	}
	return $ctx;
}

/** Aplica o contexto nativo por cima do contexto padrão do tema. */
add_filter( 'awr_seo_context', function ( $base ) {
	$n = awr_seo_native_context();
	if ( ! $n ) { return $base; }
	$base['title']     = $n['title'];
	$base['desc']      = $n['desc'];
	$base['canonical'] = $n['canonical'];
	$base['noindex']   = false;
	return $base;
}, 10 );
