<?php
/**
 * Redirecionamentos 301 das URLs legadas para as rotas novas do tema.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Mapa manual — path antigo (sem barras) => path novo (com barras).
 * Use para URLs que não seguem nenhum padrão.
 */
function awr_redirect_map() {
	return array(
		'baterias-100-amperes'      => '/baterias/amperagem/100/',
		'bateria-100-amperes'       => '/baterias/amperagem/100/',
		'baterias-em-caxias-do-sul' => '/baterias-em/caxias-do-sul/',
		'caxias-do-sul'             => '/baterias-em/caxias-do-sul/',
		'baterias-automotivas-em-caxias-do-sul' => '/baterias-em/caxias-do-sul/',
		'baterias-automotivas-moura-em-caxias-do-sul' => '/bateria/moura/caxias-do-sul/',
		'entrega-de-baterias'       => '/buscar/',
		'lojas-awr'                 => '/lojas/',
	);
}

/**
 * Normaliza um slug legado: tira acentos já convertidos, sufixos numéricos do
 * WordPress (-2, -3…), adjetivos que não mudam a intenção ("automotiva(s)",
 * "de-carro") e o marcador de venda/entrega.
 */
function awr_redirect_normalize( $path ) {
	$path = strtolower( trim( (string) $path, '/' ) );
	$path = preg_replace( '#-\d{1,2}$#', '', $path );
	$path = preg_replace( '#\b(automotivas?|automoveis|automovel|de-carro|de-carros|para-carro|para-carros|preco|precos|entrega-de|venda-de|loja-de)\b-?#', '', $path );
	$path = preg_replace( '#-{2,}#', '-', (string) $path );
	return trim( (string) $path, '-' );
}

/** Verdadeiro quando o slug corresponde a uma cidade atendida ou de venda. */
function awr_redirect_is_cidade( $slug ) {
	if ( awr_cidade_by_slug( $slug ) ) { return true; }
	return function_exists( 'awr_cidade_venda_by_slug' ) && awr_cidade_venda_by_slug( $slug );
}

/**
 * Páginas antigas com duas cidades no mesmo endereço
 * (ex.: baterias-em-gravatai-e-cachoeirinha) vão para a primeira cidade válida.
 */
function awr_redirect_cidade_composta( $slug ) {
	$partes = preg_split( '#-(?:e|ou)-#', (string) $slug );
	if ( ! is_array( $partes ) || count( $partes ) < 2 ) { return ''; }
	foreach ( $partes as $parte ) {
		$parte = trim( $parte, '-' );
		if ( $parte && awr_redirect_is_cidade( $parte ) ) { return $parte; }
	}
	return '';
}

/**
 * Etapa B do plano (301 das URLs antigas que ainda concorrem com /baterias-em/{cidade}/).
 * v5.15.0: fica DESLIGADA por padrão. Ligue em Ajustes > AWR Indexação, uma cidade por vez,
 * depois de ~3 semanas com o canonical (Etapa A) apontando para /baterias-em/{cidade}/.
 */
function awr_redirect_etapa_b_ativa() {
	return (bool) get_option( 'awr_etapa_b_301', true );
}

/**
 * Ordem da Etapa B: uma cidade por vez, 21 dias entre cada uma.
 * Começa pela de menos cliques (Guaíba) e termina na de mais (São Leopoldo).
 */
function awr_redirect_etapa_b_grupos() {
	return apply_filters( 'awr_redirect_etapa_b_grupos', array(
		array( 'bateria-guaiba' ),
		array( 'novo-hamburgo', 'bateria-novo-hamburgo', 'baterias-em-novo-hamburgo' ),
		array( 'sao-leopoldo', 'bateria-sao-leopoldo' ),
	) );
}

/** Data de início da Etapa B (gravada no primeiro uso). */
function awr_redirect_etapa_b_inicio() {
	$t = (int) get_option( 'awr_etapa_b_inicio', 0 );
	if ( ! $t ) { $t = time(); update_option( 'awr_etapa_b_inicio', $t, false ); }
	return $t;
}

/** Quantas cidades já estão liberadas (1 = só a primeira). */
function awr_redirect_etapa_b_liberadas() {
	$dias = (int) floor( ( time() - awr_redirect_etapa_b_inicio() ) / DAY_IN_SECONDS );
	return min( count( awr_redirect_etapa_b_grupos() ), 1 + (int) floor( $dias / 21 ) );
}

/** Slugs antigos com histórico de cliques que só recebem 301 na Etapa B. */
function awr_redirect_etapa_b_slugs() {
	return apply_filters( 'awr_redirect_etapa_b_slugs', array_merge( ...awr_redirect_etapa_b_grupos() ) );
}

/** Verdadeiro quando o slug é da Etapa B e ainda não chegou a vez dele. */
function awr_redirect_etapa_b_bloqueado( $path ) {
	if ( ! in_array( $path, awr_redirect_etapa_b_slugs(), true ) ) { return false; }
	if ( ! awr_redirect_etapa_b_ativa() ) { return true; }
	$lib = array_slice( awr_redirect_etapa_b_grupos(), 0, awr_redirect_etapa_b_liberadas() );
	return ! in_array( $path, $lib ? array_merge( ...$lib ) : array(), true );
}

/** Resolve o destino de um path legado, ou '' quando não há regra. */
function awr_redirect_target( $path ) {
	$path = strtolower( trim( (string) $path, '/' ) );
	if ( '' === $path ) { return ''; }
	if ( awr_redirect_etapa_b_bloqueado( $path ) ) { return ''; }

	$map = awr_redirect_map();
	if ( isset( $map[ $path ] ) ) { return $map[ $path ]; }

	$norm = awr_redirect_normalize( $path );
	if ( $norm && $norm !== $path ) {
		if ( isset( $map[ $norm ] ) ) { return $map[ $norm ]; }
		$alvo = awr_redirect_target( $norm );
		if ( $alvo ) { return $alvo; }
	}

	// Cidades combinadas: /baterias-em-gravatai-e-cachoeirinha/ → 1ª cidade.
	$sem_prefixo = preg_replace( '#^bateria(?:s)?(?:-em)?-#', '', $path );
	$composta    = awr_redirect_cidade_composta( $sem_prefixo );
	if ( $composta ) { return "/baterias-em/{$composta}/"; }

	// /bateria-{marca}-em-{cidade}/ e /{marca}-em-{cidade}/
	if ( preg_match( '#^(?:bateria(?:s)?-)?([a-z0-9]+)-em-([a-z0-9-]+)$#', $path, $m ) ) {
		if ( awr_marca_by_slug( $m[1] ) && awr_redirect_is_cidade( $m[2] ) ) {
			return "/bateria/{$m[1]}/{$m[2]}/";
		}
	}


	// /baterias-em-{cidade}/ , /bateria-em-{cidade}/ , /baterias-{cidade}/
	if ( preg_match( '#^bateria(?:s)?-em-([a-z0-9-]+)$#', $path, $m ) ) {
		if ( awr_cidade_by_slug( $m[1] ) || ( function_exists( 'awr_cidade_venda_by_slug' ) && awr_cidade_venda_by_slug( $m[1] ) ) ) {
			return "/baterias-em/{$m[1]}/";
		}
		return '/baterias-em/';
	}

	// /baterias-{n}-amperes/ , /bateria-{n}-amperes/ , /{n}-amperes/
	if ( preg_match( '#^(?:bateria(?:s)?-)?(\d{2,3})-amperes?$#', $path, $m ) ) {
		return '/baterias/amperagem/' . (int) $m[1] . '/';
	}

	// /bateria-{marca}/ , /baterias-{marca}/
	if ( preg_match( '#^bateria(?:s)?-([a-z0-9-]+)$#', $path, $m ) ) {
		if ( awr_marca_by_slug( $m[1] ) ) { return "/marca/{$m[1]}/"; }
		if ( awr_cidade_by_slug( $m[1] ) || ( function_exists( 'awr_cidade_venda_by_slug' ) && awr_cidade_venda_by_slug( $m[1] ) ) ) { return "/baterias-em/{$m[1]}/"; }
	}

	// /{cidade}/ solta (ex.: /novo-hamburgo/)
	if ( preg_match( '#^[a-z0-9-]+$#', $path ) && ( awr_cidade_by_slug( $path ) || ( function_exists( 'awr_cidade_venda_by_slug' ) && awr_cidade_venda_by_slug( $path ) ) ) ) {
		return "/baterias-em/{$path}/";
	}

	return '';
}

/**
 * Páginas antigas do WordPress que ainda existem, mas foram substituídas por
 * rotas do tema (evita duas URLs competindo pela mesma busca).
 */
function awr_redirect_legacy_pages() {
	$fixas = array(
		'baterias-automotivas-em-caxias-do-sul'       => '/baterias-em/caxias-do-sul/',
		'baterias-automotivas-moura-em-caxias-do-sul' => '/bateria/moura/caxias-do-sul/',
	);
	return apply_filters( 'awr_redirect_legacy_pages', $fixas );
}

/**
 * Páginas publicadas cujo slug já é coberto por uma rota do tema.
 * Em vez de uma lista fixa, varre o conteúdo real e casa com awr_redirect_target().
 *
 * @param bool $force Ignora o cache.
 * @return array slug => destino.
 */
function awr_redirect_legacy_scan( $force = false ) {
	$cache = get_transient( 'awr_legacy_redirects' );
	if ( ! $force && is_array( $cache ) ) { return $cache; }

	$map   = awr_redirect_legacy_pages();
	$slugs = get_posts( array(
		'post_type'        => 'page',
		'post_status'      => 'publish',
		'numberposts'      => 500,
		'fields'           => 'ids',
		'suppress_filters' => true,
	) );
	foreach ( $slugs as $id ) {
		$slug = get_post_field( 'post_name', $id );
		if ( ! $slug || isset( $map[ $slug ] ) ) { continue; }
		if ( (int) get_option( 'page_on_front' ) === (int) $id ) { continue; }
		$alvo = awr_redirect_target( $slug );
		if ( $alvo && untrailingslashit( $alvo ) !== '/' . $slug ) { $map[ $slug ] = $alvo; }
	}
	set_transient( 'awr_legacy_redirects', $map, DAY_IN_SECONDS );
	return $map;
}

add_action( 'template_redirect', function () {
	if ( is_admin() || wp_doing_ajax() || awr_current_route() ) { return; }
	if ( ! is_singular( 'page' ) ) { return; }
	$slug = get_post_field( 'post_name', get_queried_object_id() );
	$map  = awr_redirect_legacy_scan();
	if ( empty( $map[ $slug ] ) ) { return; }
	wp_safe_redirect( home_url( $map[ $slug ] ), 301 );
	exit;
}, 1 );

/** Aplica o 301 antes do WordPress resolver o 404. */
add_action( 'template_redirect', function () {
	if ( is_admin() || is_robots() || is_feed() || wp_doing_ajax() ) { return; }
	if ( awr_current_route() ) { return; }          // rota virtual válida do tema.
	if ( ! is_404() ) { return; }                   // não mexe em conteúdo existente.

	$uri  = wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
	$qs   = (string) wp_parse_url( $uri, PHP_URL_QUERY );

	// xmlrpc/jetpack: rotas usadas pela conexão WordPress.com (Google for WooCommerce).
	if ( preg_match( '#(wp-admin|wp-json|wp-content|wp-includes|xmlrpc\.php|jetpack|\.[a-z0-9]{2,4}$)#i', $path ) ) { return; }

	$home_path = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	$rel       = trim( $path, '/' );
	if ( $home_path && 0 === strpos( $rel, $home_path . '/' ) ) {
		$rel = substr( $rel, strlen( $home_path ) + 1 );
	}

	$target = awr_redirect_target( $rel );
	if ( ! $target ) { return; }

	$url = home_url( $target );
	if ( $qs ) { $url .= '?' . $qs; }
	if ( untrailingslashit( $url ) === untrailingslashit( home_url( $path ) ) ) { return; }

	wp_safe_redirect( $url, 301 );
	exit;
}, 1 );

/**
 * 5.48.0 — /home/ (página antiga do WordPress) duplicava a página inicial.
 * Só redireciona quando a página "home" NÃO é a própria página inicial
 * (senão o WordPress já resolve sozinho e um 301 aqui geraria loop).
 */
add_action( 'template_redirect', function () {
	if ( is_admin() || wp_doing_ajax() || is_front_page() || ! is_singular( 'page' ) ) { return; }
	if ( 'home' !== get_post_field( 'post_name', get_queried_object_id() ) ) { return; }
	wp_safe_redirect( home_url( '/' ), 301 );
	exit;
}, 1 );
