<?php
/**
 * Compatibilidade com Google Merchant Center / Google for WooCommerce.
 *
 * O tema assume o template e o SEO das páginas de produto. Isso criava três
 * incompatibilidades com o Merchant Center:
 *
 *  1. canonical da página do produto apontava para a rota /bateria/{sku}/ —
 *     o link do feed (permalink do Woo) não batia com o canonical e os itens
 *     eram recusados ("página de destino não corresponde").
 *  2. o schema Product do tema não trazia GTIN, categoria, galeria nem
 *     vendedor — dados que o Merchant usa para validar e enriquecer o item.
 *  3. o template próprio não disparava os hooks de produto do WooCommerce,
 *     então extensões (Google for WooCommerce, pixels, etc.) nunca injetavam
 *     o código delas na página.
 *
 * Ajustes → AWR Merchant Center mostra o diagnóstico completo da loja.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ---------------------------------------------------------------------
   1) Canonical das páginas de produto
   --------------------------------------------------------------------- */

/** 'produto' = permalink do Woo (compatível com Merchant); 'sku' = rota /bateria/{sku}/. */
function awr_produto_canonical_modo() {
	$modo = (string) get_option( 'awr_produto_canonical', 'produto' );
	return 'sku' === $modo ? 'sku' : 'produto';
}

/** Permalink do produto WooCommerce de um SKU (vazio quando não existe). */
function awr_produto_permalink_por_sku( $sku ) {
	$sku = strtoupper( trim( (string) $sku ) );
	if ( '' === $sku || ! function_exists( 'awr_lookup_product_id' ) ) { return ''; }
	$id = (int) awr_lookup_product_id( $sku );
	if ( ! $id || 'publish' !== get_post_status( $id ) ) { return ''; }
	$url = get_permalink( $id );
	return $url ? $url : '';
}

/** URL canônica oficial de um SKU, conforme o modo configurado. */
function awr_produto_url_canonica( $sku, $post_id = 0 ) {
	$sku = strtoupper( trim( (string) $sku ) );
	if ( 'produto' === awr_produto_canonical_modo() ) {
		$url = $post_id ? get_permalink( $post_id ) : awr_produto_permalink_por_sku( $sku );
		if ( $url ) { return $url; }
	}
	return $sku ? home_url( '/bateria/' . awr_sku_slug( $sku ) . '/' ) : home_url( '/' );
}

/**
 * Reescreve o canonical do produto nativo e da rota /bateria/{sku}/ para a
 * mesma URL — feed, canonical e página de destino sempre coincidem.
 * Prioridade 20: roda depois do contexto nativo (inc/seo-native.php).
 */
add_filter( 'awr_seo_context', function ( $base, $route = '' ) {
	if ( 'produto' !== awr_produto_canonical_modo() ) { return $base; }

	if ( function_exists( 'is_product' ) && is_product() ) {
		$base['canonical'] = get_permalink( get_queried_object_id() );
		return $base;
	}

	if ( 'sku' === $route ) {
		$url = awr_produto_permalink_por_sku( awr_sku_from_slug( awr_param_a() ) );
		if ( $url ) { $base['canonical'] = $url; }
	}

	return $base;
}, 20, 2 );

/**
 * Duas URLs com o mesmo conteúdo (/bateria/{sku}/ e o permalink do produto)
 * dividem o posicionamento: a rota apontava para o produto pelo canonical, mas
 * continuava respondendo 200 e sendo listada nos links internos. Com o modo
 * "permalink do produto" ativo, a rota passa a redirecionar (301) para a página
 * oficial — um único endereço acumula histórico, links e avaliações.
 */
add_action( 'template_redirect', function () {
	if ( is_admin() || wp_doing_ajax() ) { return; }
	if ( 'produto' !== awr_produto_canonical_modo() ) { return; }
	if ( ! function_exists( 'awr_current_route' ) || 'sku' !== awr_current_route() ) { return; }
	if ( ! apply_filters( 'awr_sku_redirect_produto', true ) ) { return; }

	$url = awr_produto_permalink_por_sku( awr_sku_from_slug( (string) awr_param_a() ) );
	if ( ! $url ) { return; }

	$atual = home_url( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( untrailingslashit( $atual ) === untrailingslashit( $url ) ) { return; }

	wp_safe_redirect( $url, 301 );
	exit;
}, 2 );

/* ---------------------------------------------------------------------
   2) Schema Product completo para o Merchant Center
   --------------------------------------------------------------------- */

/** Código de barras (GTIN/EAN/UPC) cadastrado no produto. */
function awr_produto_gtin( $wc_product ) {
	if ( ! $wc_product || ! method_exists( $wc_product, 'get_meta' ) ) { return ''; }
	foreach ( array( '_global_unique_id', '_gtin', '_ean', '_upc', '_wpm_gtin_code', 'hwp_var_gtin' ) as $key ) {
		$v = preg_replace( '/\D+/', '', (string) $wc_product->get_meta( $key, true ) );
		if ( $v && in_array( strlen( $v ), array( 8, 12, 13, 14 ), true ) ) { return $v; }
	}
	return '';
}

/** Categoria principal do produto (texto exigido pelo Merchant). */
function awr_produto_categoria_nome( $wc_product ) {
	if ( ! $wc_product || ! method_exists( $wc_product, 'get_id' ) ) { return ''; }
	$terms = get_the_terms( $wc_product->get_id(), 'product_cat' );
	if ( ! $terms || is_wp_error( $terms ) ) { return ''; }
	$nomes = wp_list_pluck( $terms, 'name' );
	return (string) reset( $nomes );
}

/**
 * Enriquece o schema Product com os campos que o Merchant Center lê:
 * url coerente com o canonical, GTIN, categoria, galeria, peso e vendedor.
 */
add_filter( 'awr_product_schema', function ( $schema, $p, $wc_product ) {
	if ( ! is_array( $schema ) || empty( $schema['@type'] ) ) { return $schema; }

	$sku = strtoupper( (string) ( $schema['sku'] ?? ( $p['sku'] ?? '' ) ) );
	$url = awr_produto_url_canonica( $sku, $wc_product && method_exists( $wc_product, 'get_id' ) ? (int) $wc_product->get_id() : 0 );

	$schema['@id'] = $url . '#produto';
	$schema['url'] = $url;
	if ( isset( $schema['offers'] ) && is_array( $schema['offers'] ) ) {
		$schema['offers']['url']             = $url;
		$schema['offers']['sku']             = $sku;
		$schema['offers']['priceValidUntil'] = gmdate( 'Y-m-d', time() + 180 * DAY_IN_SECONDS );
		$schema['offers']['seller']          = array(
			'@type' => 'Organization',
			'name'  => 'AWR Baterias',
			'url'   => home_url( '/' ),
		);
	}

	// GTIN: o do produto; se faltar, o da tabela oficial por modelo.
	$gtin = awr_produto_gtin( $wc_product );
	if ( ! $gtin && function_exists( 'awr_gtin_por_modelo' ) ) { $gtin = awr_gtin_por_modelo( $sku ); }
	if ( $gtin ) {
		$schema['gtin'] = $gtin;
		$len = strlen( $gtin );
		if ( 8 === $len )  { $schema['gtin8'] = $gtin; }
		if ( 12 === $len ) { $schema['gtin12'] = $gtin; }
		if ( 13 === $len ) { $schema['gtin13'] = $gtin; }
		if ( 14 === $len ) { $schema['gtin14'] = $gtin; }
	}
	// Sem GTIN conhecido, o identificador exigido pelo Google é marca + MPN.
	// Nunca reaproveitar o GTIN de outro modelo: duplicar código reprova o item.
	if ( $sku && empty( $schema['mpn'] ) ) { $schema['mpn'] = $sku; }

	$cat = awr_produto_categoria_nome( $wc_product );
	if ( $cat ) { $schema['category'] = $cat; }

	// Atributos técnicos que o Google usa para casar o produto no catálogo.
	if ( function_exists( 'awr_bateria_tecnologia' ) ) {
		$nome_prod = (string) ( $schema['name'] ?? '' );
		$ah        = (int) ( $p['amperagem'] ?? 0 );
		if ( ! $ah && function_exists( 'awr_gtin_info' ) ) {
			$info = awr_gtin_info( $sku );
			$ah   = $info ? $info['ah'] : 0;
		}
		$props = array( array( 'name' => 'Tensão', 'value' => '12V' ) );
		$tec   = awr_bateria_tecnologia( $sku, $nome_prod );
		if ( $tec ) { $props[] = array( 'name' => 'Tecnologia', 'value' => $tec ); }
		if ( $ah )  { $props[] = array( 'name' => 'Capacidade', 'value' => $ah . 'Ah' ); }
		$pol = awr_bateria_polaridade( $sku );
		if ( $pol ) { $props[] = array( 'name' => 'Polaridade', 'value' => $pol ); }

		$lista = array();
		foreach ( $props as $prop ) {
			$lista[] = array( '@type' => 'PropertyValue', 'name' => $prop['name'], 'value' => $prop['value'] );
		}
		$schema['additionalProperty'] = $lista;
	}

	// Condição de casco declarada na oferta: o preço do anúncio precisa bater
	// com o preço da página de destino, inclusive nas condições.
	if ( isset( $schema['offers'] ) && is_array( $schema['offers'] ) && isset( $schema['offers']['price'] ) ) {
		$schema['offers']['priceSpecification'] = array(
			'@type'                 => 'UnitPriceSpecification',
			'price'                 => $schema['offers']['price'],
			'priceCurrency'         => 'BRL',
			'valueAddedTaxIncluded' => true,
			'description'           => 'Preço à vista válido com a devolução do casco (bateria usada) no ato da entrega.',
		);
	}

	// Galeria: o Merchant aceita imagens adicionais e melhora a aprovação.
	if ( $wc_product && method_exists( $wc_product, 'get_gallery_image_ids' ) ) {
		$imgs = isset( $schema['image'] ) ? (array) $schema['image'] : array();
		foreach ( (array) $wc_product->get_gallery_image_ids() as $img_id ) {
			$src = wp_get_attachment_image_url( (int) $img_id, 'large' );
			if ( $src ) { $imgs[] = $src; }
		}
		$imgs = array_values( array_unique( array_filter( $imgs ) ) );
		if ( $imgs ) { $schema['image'] = $imgs; }
	}

	// Peso: usado na validação de frete de itens pesados (bateria).
	if ( $wc_product && method_exists( $wc_product, 'get_weight' ) ) {
		$peso = (float) $wc_product->get_weight();
		if ( $peso > 0 ) {
			$schema['weight'] = array( '@type' => 'QuantitativeValue', 'value' => $peso, 'unitCode' => 'KGM' );
		}
	}

	return $schema;
}, 10, 3 );

/* ---------------------------------------------------------------------
   3) Hooks de produto do WooCommerce no template próprio
   --------------------------------------------------------------------- */

/** Dispara os hooks que as extensões do Woo (inclusive a do Google) esperam. */
function awr_produto_hooks_woo( $quando, $wc_product = null ) {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
	if ( $wc_product ) { $GLOBALS['product'] = $wc_product; }
	if ( 'antes' === $quando ) {
		do_action( 'woocommerce_before_main_content' );
		do_action( 'woocommerce_before_single_product' );
	} else {
		do_action( 'woocommerce_after_single_product' );
		do_action( 'woocommerce_after_main_content' );
	}
}

/* ---------------------------------------------------------------------
   4) Estilos do WooCommerce nas telas de loja
   --------------------------------------------------------------------- */

/**
 * Os estilos de blocos do WooCommerce voltam nas telas de loja
 * (ver awr_is_woo_screen em inc/isolation.php) — carrinho e finalização
 * são rastreados pelo Google para validar preço e disponibilidade.
 */

/* ---------------------------------------------------------------------
   5) Diagnóstico — Ajustes → AWR Merchant Center
   --------------------------------------------------------------------- */

/** Executa as checagens e devolve linhas de diagnóstico. */
function awr_merchant_checks() {
	$linhas = array();
	$add    = function ( $ok, $titulo, $detalhe ) use ( &$linhas ) {
		$linhas[] = array( 'ok' => $ok, 'titulo' => $titulo, 'detalhe' => $detalhe );
	};

	$woo = class_exists( 'WooCommerce' );
	$add( $woo, 'WooCommerce ativo', $woo ? 'OK' : 'Instale e ative o WooCommerce.' );

	if ( $woo ) {
		$pais   = (string) get_option( 'woocommerce_default_country', '' );
		$end    = trim( (string) get_option( 'woocommerce_store_address', '' ) );
		$cidade = trim( (string) get_option( 'woocommerce_store_city', '' ) );
		$cep    = trim( (string) get_option( 'woocommerce_store_postcode', '' ) );
		$completo = $pais && $end && $cidade && $cep;
		$add( $completo, 'Endereço da loja completo', $completo
			? trim( "$end, $cidade — $cep ($pais)" )
			: 'Preencha país, endereço, cidade e CEP em WooCommerce → Definições → Geral.' );

		$moeda = (string) get_option( 'woocommerce_currency', '' );
		$add( 'BRL' === $moeda, 'Moeda da loja', $moeda ? $moeda : 'não definida' );
	}

	// URL do site: divergência de esquema/www derruba a reivindicação no Merchant.
	$home = wp_parse_url( home_url( '/' ) );
	$site = wp_parse_url( site_url( '/' ) );
	$mesma = ( ( $home['scheme'] ?? '' ) === ( $site['scheme'] ?? '' ) ) && ( ( $home['host'] ?? '' ) === ( $site['host'] ?? '' ) );
	$add( $mesma && 'https' === ( $home['scheme'] ?? '' ), 'Endereço do site (HTTPS e domínio)',
		home_url( '/' ) . ( $mesma ? '' : ' ≠ ' . site_url( '/' ) ) . ' — registre exatamente este domínio no Merchant Center.' );

	$canon = trim( (string) get_option( 'awr_canonical_domain', '' ) );
	$add( '' === $canon || untrailingslashit( $canon ) === untrailingslashit( home_url( '/' ) ),
		'Domínio canônico do tema',
		'' === $canon ? 'Usando o próprio domínio (correto para a loja principal).'
			: 'Canonical apontando para ' . esc_html( $canon ) . ' — o Merchant Center recusa itens cuja página aponta para outro domínio. Esta instalação só pode vender pelo Merchant se o canonical for o próprio domínio.' );

	$modo = awr_produto_canonical_modo();
	$add( 'produto' === $modo, 'Canonical das páginas de produto',
		'produto' === $modo ? 'Autorreferenciado no permalink do produto (compatível com o feed).'
			: 'Apontando para /bateria/{sku}/ — o link do feed não bate com o canonical. Mude para "Permalink do produto" abaixo.' );

	$publico = (bool) get_option( 'blog_public' );
	$add( $publico, 'Indexação liberada', $publico ? 'OK' : 'Configurações → Leitura está bloqueando mecanismos de busca.' );

	// xmlrpc.php (usado pela conexão WordPress.com da extensão do Google).
	$r = wp_remote_post( site_url( '/xmlrpc.php' ), array( 'timeout' => 8, 'body' => '<?xml version="1.0"?><methodCall><methodName>demo.sayHello</methodName><params></params></methodCall>' ) );
	if ( is_wp_error( $r ) ) {
		$add( false, 'xmlrpc.php acessível', 'Falha na chamada: ' . $r->get_error_message() );
	} else {
		$code = (int) wp_remote_retrieve_response_code( $r );
		$add( 200 === $code, 'xmlrpc.php acessível', 'HTTP ' . $code . ( 200 === $code ? '' : ' — plugin de segurança ou hospedagem bloqueando.' ) );
	}

	// REST API pública.
	$r2 = wp_remote_get( rest_url( 'wp/v2/types' ), array( 'timeout' => 8 ) );
	if ( is_wp_error( $r2 ) ) {
		$add( false, 'REST API acessível', $r2->get_error_message() );
	} else {
		$c2 = (int) wp_remote_retrieve_response_code( $r2 );
		$add( $c2 < 400, 'REST API acessível', 'HTTP ' . $c2 );
	}

	$plugin = defined( 'WC_GLA_VERSION' ) || class_exists( 'Automattic\\Jetpack\\Connection\\Manager' );
	$add( $plugin, 'Extensão Google for WooCommerce', $plugin ? 'Detectada.' : 'Não detectada — instale "Google for WooCommerce" em Plugins.' );

	if ( $woo ) {
		global $wpdb;
		$ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type='product' AND post_status='publish' LIMIT 500" ); // phpcs:ignore WordPress.DB
		$sem_preco = 0; $sem_img = 0; $sem_cat = 0; $sem_gtin = 0; $sem_marca = 0; $sem_sku = 0;
		foreach ( $ids as $id ) {
			$prod = wc_get_product( (int) $id );
			if ( ! $prod ) { continue; }
			if ( ! (float) $prod->get_price() ) { $sem_preco++; }
			if ( ! $prod->get_image_id() ) { $sem_img++; }
			if ( ! awr_produto_categoria_nome( $prod ) ) { $sem_cat++; }
			if ( ! awr_produto_gtin( $prod ) && ! awr_gtin_por_modelo( $prod->get_sku() ) ) { $sem_gtin++; }
			if ( ! trim( (string) $prod->get_sku() ) ) { $sem_sku++; }
			if ( function_exists( 'awr_resolve_brand' ) && ! awr_resolve_brand( $prod->get_sku(), $prod->get_name(), $prod ) ) { $sem_marca++; }
		}
		$total = count( $ids );
		$add( 0 === $sem_preco, 'Produtos com preço', ( $total - $sem_preco ) . ' de ' . $total );
		$add( 0 === $sem_img, 'Produtos com foto', ( $total - $sem_img ) . ' de ' . $total );
		$add( 0 === $sem_cat, 'Produtos com categoria', ( $total - $sem_cat ) . ' de ' . $total );
		$add( 0 === $sem_sku, 'Produtos com SKU', ( $total - $sem_sku ) . ' de ' . $total );
		$add( 0 === $sem_marca, 'Produtos com marca identificada', ( $total - $sem_marca ) . ' de ' . $total );
		$add( 0 === $sem_gtin, 'Produtos com código de barras (GTIN/EAN)', ( $total - $sem_gtin ) . ' de ' . $total
			. ' — contando a tabela de modelos do tema. Os que sobraram vão para o Google com marca + código do modelo (identificador aceito). Use "Aplicar códigos de barras da tabela" em Ajustes → AWR Produtos (Merchant).' );
	}

	return $linhas;
}

/* ---------------------------------------------------------------------
   6) Conexão WordPress.com (Jetpack) — exigida pelo Google for WooCommerce
   --------------------------------------------------------------------- */

/** Chamada externa curta; devolve array{code:int,body:string,erro:string}. */
function awr_http_probe( $url, $args = array() ) {
	$args = wp_parse_args( $args, array(
		'timeout'    => 8,
		'redirection' => 3,
		'user-agent' => 'Mozilla/5.0 (compatible; AWR-Diagnostico/1.0)',
	) );
	$r = isset( $args['body'] ) ? wp_remote_post( $url, $args ) : wp_remote_get( $url, $args );
	if ( is_wp_error( $r ) ) {
		return array( 'code' => 0, 'body' => '', 'erro' => $r->get_error_message() );
	}
	return array(
		'code' => (int) wp_remote_retrieve_response_code( $r ),
		'body' => (string) wp_remote_retrieve_body( $r ),
		'erro' => '',
	);
}

/** Explica um código HTTP de bloqueio em linguagem direta. */
function awr_http_motivo( $code, $erro ) {
	if ( $erro ) { return 'Falha na chamada: ' . $erro . ' — firewall, DNS interno ou site fora do ar para ele mesmo.'; }
	switch ( true ) {
		case 200 === $code || 201 === $code: return 'OK (HTTP 200).';
		case 401 === $code: return 'HTTP 401 — o site pede senha (proteção de ambiente/htpasswd). Libere ou desative.';
		case 403 === $code: return 'HTTP 403 — bloqueado por plugin de segurança, WAF da hospedagem ou Cloudflare.';
		case 404 === $code: return 'HTTP 404 — o arquivo/rota não existe ou foi desativado na hospedagem.';
		case 405 === $code || 406 === $code: return 'HTTP ' . $code . ' — o servidor recusa o método usado (regra de segurança).';
		case 429 === $code: return 'HTTP 429 — limite de requisições (Cloudflare ou hospedagem).';
		case $code >= 500: return 'HTTP ' . $code . ' — erro no servidor ao responder.';
		case $code >= 300 && $code < 400: return 'HTTP ' . $code . ' — redirecionamento; confira www/HTTPS no endereço do site.';
	}
	return 'HTTP ' . $code;
}

/** Checagens específicas da conexão WordPress.com (cache curto de 60 s). */
function awr_jetpack_checks() {
	$cache = get_transient( 'awr_jetpack_checks' );
	if ( is_array( $cache ) ) { return $cache; }

	$linhas = array();
	$add    = function ( $ok, $titulo, $detalhe ) use ( &$linhas ) {
		$linhas[] = array( 'ok' => $ok, 'titulo' => $titulo, 'detalhe' => $detalhe );
	};

	// 1) xmlrpc.php com os métodos que o Jetpack usa de verdade.
	$xml_demo = awr_http_probe( site_url( '/xmlrpc.php' ), array(
		'body'    => '<?xml version="1.0"?><methodCall><methodName>demo.sayHello</methodName><params></params></methodCall>',
		'headers' => array( 'Content-Type' => 'text/xml' ),
	) );
	$add( 200 === $xml_demo['code'], 'xmlrpc.php responde', awr_http_motivo( $xml_demo['code'], $xml_demo['erro'] ) );

	$xml_jp = awr_http_probe( site_url( '/xmlrpc.php' ), array(
		'body'    => '<?xml version="1.0"?><methodCall><methodName>system.listMethods</methodName><params></params></methodCall>',
		'headers' => array( 'Content-Type' => 'text/xml' ),
	) );
	$tem_jp = 200 === $xml_jp['code'] && false !== strpos( $xml_jp['body'], 'jetpack.' );
	$add( $tem_jp, 'xmlrpc.php aceita os métodos do Jetpack',
		200 !== $xml_jp['code']
			? awr_http_motivo( $xml_jp['code'], $xml_jp['erro'] )
			: ( $tem_jp ? 'Métodos jetpack.* disponíveis.' : 'Responde, mas sem os métodos jetpack.* — plugin de segurança filtrando o xmlrpc ou Jetpack inativo.' ) );

	// 2) REST API: raiz e rota de conexão do Jetpack.
	$rest = awr_http_probe( rest_url() );
	$add( $rest['code'] > 0 && $rest['code'] < 400, 'REST API pública (/wp-json/)', awr_http_motivo( $rest['code'], $rest['erro'] ) );

	$jp_rest = awr_http_probe( rest_url( 'jetpack/v4/connection' ) );
	$add( $jp_rest['code'] > 0 && $jp_rest['code'] < 400, 'Rota /wp-json/jetpack/v4/connection',
		404 === $jp_rest['code']
			? 'HTTP 404 — o Jetpack (usado pela extensão do Google) não está ativo neste site.'
			: awr_http_motivo( $jp_rest['code'], $jp_rest['erro'] ) );

	// 3) O site responde para o mundo externo (e para ele mesmo).
	$home = awr_http_probe( home_url( '/' ) );
	$add( 200 === $home['code'], 'Site acessível pela internet', awr_http_motivo( $home['code'], $home['erro'] ) );

	// 4) Estado do Jetpack.
	if ( class_exists( 'Jetpack_Options' ) ) {
		$blog_id = Jetpack_Options::get_option( 'id' );
		$token   = Jetpack_Options::get_option( 'blog_token' );
		$add( (bool) ( $blog_id && $token ), 'Site registrado no WordPress.com',
			$blog_id && $token ? 'Registrado (ID ' . esc_html( (string) $blog_id ) . ').'
				: 'Ainda não registrado — é exatamente a etapa que está voltando ao início.' );
	} else {
		$add( false, 'Site registrado no WordPress.com', 'Jetpack não detectado — instale/ative a extensão Google for WooCommerce completa.' );
	}

	if ( class_exists( 'Automattic\\Jetpack\\Connection\\Manager' ) ) {
		$mgr = new Automattic\Jetpack\Connection\Manager( 'google-listings-and-ads' );
		$ok  = method_exists( $mgr, 'is_connected' ) ? (bool) $mgr->is_connected() : false;
		$dono = method_exists( $mgr, 'has_connected_owner' ) ? (bool) $mgr->has_connected_owner() : false;
		$add( $ok && $dono, 'Usuário-dono conectado',
			$ok && $dono ? 'Conexão ativa com usuário responsável.' : 'Sem usuário conectado — refaça o assistente já logado como administrador em uma única conta Google.' );
	}

	// 5) Endereço coerente (divergência derruba a autorização de volta ao início).
	$h = wp_parse_url( home_url( '/' ) );
	$s = wp_parse_url( site_url( '/' ) );
	$iguais = ( $h['scheme'] ?? '' ) === ( $s['scheme'] ?? '' ) && ( $h['host'] ?? '' ) === ( $s['host'] ?? '' );
	$add( $iguais && 'https' === ( $h['scheme'] ?? '' ), 'Endereço do WordPress e do site coincidem',
		$iguais ? ( 'https' === ( $h['scheme'] ?? '' ) ? home_url( '/' ) : 'Sem HTTPS: ' . home_url( '/' ) )
			: home_url( '/' ) . ' ≠ ' . site_url( '/' ) . ' — ajuste em Configurações → Geral (mesmo www e mesmo https).' );

	// 6) Usuário atual.
	$u = wp_get_current_user();
	$pode = $u && $u->exists() && user_can( $u, 'manage_options' ) && is_email( $u->user_email );
	$add( $pode, 'Usuário administrador com e-mail válido',
		$pode ? $u->user_email : 'Conecte usando um administrador com e-mail real — a conexão falha em silêncio caso contrário.' );

	// 7) Indexação/manutenção e plugins que costumam bloquear.
	$suspeitos = array(
		'Wordfence'        => 'wordfence/wordfence.php',
		'iThemes/Solid'    => 'better-wp-security/better-wp-security.php',
		'All In One WP Sec'=> 'all-in-one-wp-security-and-firewall/wp-security.php',
		'Sucuri'           => 'sucuri-scanner/sucuri.php',
		'Disable XML-RPC'  => 'disable-xml-rpc/disable-xml-rpc.php',
		'WPS Hide Login'   => 'wps-hide-login/wps-hide-login.php',
		'LiteSpeed Cache'  => 'litespeed-cache/litespeed-cache.php',
		'WP Rocket'        => 'wp-rocket/wp-rocket.php',
	);
	if ( ! function_exists( 'is_plugin_active' ) ) { include_once ABSPATH . 'wp-admin/includes/plugin.php'; }
	$ativos = array();
	foreach ( $suspeitos as $nome => $arquivo ) {
		if ( is_plugin_active( $arquivo ) ) { $ativos[] = $nome; }
	}
	$add( empty( $ativos ), 'Plugins que costumam bloquear a conexão',
		$ativos ? implode( ', ', $ativos ) . ' — desative temporariamente (ou libere xmlrpc.php e /wp-json/) e refaça a conexão.'
			: 'Nenhum plugin conhecido de bloqueio ativo.' );

	set_transient( 'awr_jetpack_checks', $linhas, MINUTE_IN_SECONDS );
	return $linhas;
}

add_action( 'admin_menu', function () {
	add_options_page( 'AWR Merchant Center', 'AWR Merchant Center', 'manage_options', 'awr-merchant', 'awr_merchant_page' );
} );

/**
 * Limpa os tokens de conexão WordPress.com/Jetpack presos no banco.
 *
 * Sites clonados ou restaurados (Duplicator) mantêm blog_id e chaves antigas
 * gravadas em wp_options. O WordPress.com valida a chave, não bate, e troca o
 * botão "Aprovar" por "Voltar para o site". Apagar as chaves faz o site ser
 * tratado como um registro novo.
 *
 * @return array Lista de linhas do relatório da limpeza.
 */
function awr_reset_wpcom_tokens() {
	global $wpdb;
	$log = array();

	// 1) Desconexão pelas APIs oficiais quando o Jetpack está carregado.
	if ( class_exists( 'Automattic\\Jetpack\\Connection\\Manager' ) ) {
		try {
			$mgr = new Automattic\Jetpack\Connection\Manager( 'google-listings-and-ads' );
			if ( method_exists( $mgr, 'disconnect_site_wpcom' ) ) { $mgr->disconnect_site_wpcom( true ); }
			if ( method_exists( $mgr, 'delete_all_connection_tokens' ) ) { $mgr->delete_all_connection_tokens( true ); }
			$log[] = 'Desconexão oficial do Jetpack executada.';
		} catch ( \Throwable $e ) {
			$log[] = 'API do Jetpack indisponível — seguindo pela limpeza direta do banco.';
		}
	} else {
		$log[] = 'Jetpack não carregado — limpeza feita direto no banco.';
	}

	// 2) Opções nominais da conexão.
	$opcoes = array(
		'jetpack_options', 'jetpack_private_options', 'jetpack_id', 'jetpack_blog_token',
		'jetpack_user_token', 'jetpack_user_tokens', 'jetpack_master_user', 'jetpack_secrets',
		'jetpack_unique_connection_options', 'jetpack_connection_active_plugins',
		'jetpack_sync_error_idc', 'jetpack_migrate_for_idc', 'jetpack_safe_mode_confirmed',
		'jetpack_activated', 'jetpack_active_modules', 'jetpack_available_modules',
		'jetpack_register_nonce', 'jetpack_connection_xmlrpc_verified',
		'jetpack_connection_secrets', 'jetpack_connection_active_connection_owner',
		'jetpack_the_real_secret', 'jetpack_next_sync_time',
		'gla_connected', 'gla_wp_tos_accepted', 'gla_google_connected',
	);
	$removidas = 0;
	foreach ( $opcoes as $o ) {
		if ( delete_option( $o ) ) { $removidas++; }
		delete_site_option( $o );
	}
	$log[] = $removidas . ' registro(s) nomeado(s) removido(s).';

	// 3) Varredura por prefixo (tokens e segredos gerados dinamicamente).
	$prefixos = $wpdb->get_col(
		"SELECT option_name FROM {$wpdb->options}
		 WHERE option_name LIKE 'jetpack\_%'
		    OR option_name LIKE 'jpsq\_%'
		    OR option_name LIKE '\_transient\_jetpack\_%'
		    OR option_name LIKE '\_transient\_timeout\_jetpack\_%'
		    OR option_name LIKE 'jetpack\_sync\_%'"
	);
	foreach ( (array) $prefixos as $nome ) { delete_option( $nome ); }
	$log[] = count( (array) $prefixos ) . ' chave(s) residual(is) de sincronização apagada(s).';

	// 4) Caches do diagnóstico e do WooCommerce.
	delete_transient( 'awr_jetpack_checks' );
	delete_transient( 'awr_merchant_checks' );
	if ( function_exists( 'wp_cache_flush' ) ) { wp_cache_flush(); }
	$log[] = 'Cache do diagnóstico limpo.';

	return $log;
}

/** Processa o clique do botão de reset. */
add_action( 'admin_init', function () {
	if ( ! isset( $_POST['awr_reset_wpcom'] ) ) { return; }
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	check_admin_referer( 'awr_reset_wpcom' );
	set_transient( 'awr_reset_wpcom_log', awr_reset_wpcom_tokens(), 5 * MINUTE_IN_SECONDS );
	wp_safe_redirect( add_query_arg( array( 'page' => 'awr-merchant', 'awr_reset' => '1' ), admin_url( 'options-general.php' ) ) );
	exit;
} );

/** Tela de diagnóstico. */
function awr_merchant_page() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }
	echo '<div class="wrap"><h1>AWR Merchant Center</h1>';
	echo '<p>Checagens do que costuma impedir a conexão entre WooCommerce e Google Merchant Center.</p>';
	echo '<table class="widefat striped"><thead><tr><th style="width:32px"></th><th>Item</th><th>Situação</th></tr></thead><tbody>';
	foreach ( awr_merchant_checks() as $l ) {
		printf(
			'<tr><td>%s</td><td><strong>%s</strong></td><td>%s</td></tr>',
			$l['ok'] ? '✅' : '⚠️',
			esc_html( $l['titulo'] ),
			esc_html( $l['detalhe'] )
		);
	}
	echo '</tbody></table>';

	echo '<h2>Conexão WordPress.com</h2>';
	echo '<p>Quando o assistente do Google volta para o início, o motivo costuma estar aqui.</p>';
	echo '<table class="widefat striped"><thead><tr><th style="width:32px"></th><th>Item</th><th>Situação</th></tr></thead><tbody>';
	foreach ( awr_jetpack_checks() as $l ) {
		printf(
			'<tr><td>%s</td><td><strong>%s</strong></td><td>%s</td></tr>',
			$l['ok'] ? '✅' : '⚠️',
			esc_html( $l['titulo'] ),
			esc_html( $l['detalhe'] )
		);
	}
	echo '</tbody></table>';

	// Botão de reset dos tokens presos.
	$log = get_transient( 'awr_reset_wpcom_log' );
	if ( is_array( $log ) ) {
		delete_transient( 'awr_reset_wpcom_log' );
		echo '<div class="notice notice-success"><p><strong>Tokens limpos com sucesso.</strong></p><ul style="list-style:disc;margin-left:20px">';
		foreach ( $log as $linha ) { echo '<li>' . esc_html( $linha ) . '</li>'; }
		echo '</ul><p>Agora vá em <strong>Marketing → Google for WooCommerce</strong> e clique em <strong>Conectar</strong>. A tela do WordPress.com deve mostrar o botão <strong>Aprovar</strong>.</p></div>';
	}

	echo '<div style="border:1px solid #d63638;border-left-width:4px;background:#fff;padding:12px 16px;margin:16px 0">';
	echo '<h3 style="margin-top:0">Limpar tokens e reiniciar a conexão do WordPress.com</h3>';
	echo '<p>Use quando a tela do WordPress.com mostra <strong>“Voltar para o site”</strong> em vez de <strong>“Aprovar”</strong>. Apaga o registro antigo (ID e chaves de segurança gravadas no banco) para o site ser tratado como uma conexão nova. Nenhum produto, pedido ou conteúdo é afetado.</p>';
	echo '<form method="post">';
	wp_nonce_field( 'awr_reset_wpcom' );
	echo '<button type="submit" name="awr_reset_wpcom" value="1" class="button button-primary" onclick="return confirm(\'Apagar os tokens de conexão do WordPress.com? Você precisará conectar novamente em Marketing → Google for WooCommerce.\')">Limpar tokens e reiniciar conexão</button>';
	echo '</form></div>';

	echo '<p><em>Teste de 5 minutos:</em> ative um tema padrão (Twenty Twenty-Four), tente conectar de novo e volte para o tema AWR. Se falhar igual, o bloqueio é do servidor/Cloudflare, não do tema.</p>';

	echo '<h2>Canonical dos produtos</h2><form method="post" action="options.php">';
	settings_fields( 'awr_merchant' );
	do_settings_sections( 'awr-merchant' );
	submit_button();
	echo '</form></div>';
}

add_action( 'admin_init', function () {
	register_setting( 'awr_merchant', 'awr_produto_canonical', array(
		'sanitize_callback' => function ( $v ) { return 'sku' === $v ? 'sku' : 'produto'; },
		'default'           => 'produto',
	) );
	add_settings_section( 'awr_merchant_canon', '', '__return_false', 'awr-merchant' );
	add_settings_field( 'awr_produto_canonical', 'Página oficial do produto', function () {
		$modo = awr_produto_canonical_modo();
		echo '<label><input type="radio" name="awr_produto_canonical" value="produto" ' . checked( 'produto', $modo, false ) . '> Permalink do produto (recomendado — compatível com Merchant Center)</label><br>';
		echo '<label><input type="radio" name="awr_produto_canonical" value="sku" ' . checked( 'sku', $modo, false ) . '> Rota /bateria/{sku}/ (comportamento antigo)</label>';
	}, 'awr-merchant', 'awr_merchant_canon' );
} );
