<?php
/** Fonte única das promessas comerciais por cidade. @package awr */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function awr_city_delivery_mode( $cidade ) {
	return isset( $cidade['entregaModo'] ) ? (string) $cidade['entregaModo'] : 'consultar';
}

function awr_city_delivery_promise( $cidade ) {
	$modo = awr_city_delivery_mode( $cidade );
	if ( 'rapida' === $modo ) { return 'em até ' . (int) $cidade['tempoEntregaMin'] . ' minutos'; }
	if ( 'ate-17h' === $modo ) { return 'durante o dia para pedidos confirmados até as 17h'; }
	if ( 'dia-seguinte' === $modo ) { return 'no dia seguinte'; }
	return 'com prazo confirmado pelo WhatsApp';
}

function awr_city_delivery_badge( $cidade ) {
	$modo = awr_city_delivery_mode( $cidade );
	if ( 'rapida' === $modo ) { return 'Entrega em até ' . (int) $cidade['tempoEntregaMin'] . ' min'; }
	if ( 'ate-17h' === $modo ) { return 'Entrega durante o dia · pedidos até 17h'; }
	if ( 'dia-seguinte' === $modo ) { return 'Entrega no dia seguinte'; }
	return 'Prazo confirmado no WhatsApp';
}

function awr_city_delivery_title( $cidade ) {
	$nome = $cidade['nome'];
	$modo = awr_city_delivery_mode( $cidade );
	if ( 'rapida' === $modo ) { return "Bateria em {$nome}: Instalação em " . (int) $cidade['tempoEntregaMin'] . ' min'; }
	if ( 'ate-17h' === $modo ) { return "Bateria em {$nome}: Entrega no Mesmo Dia"; }
	if ( 'dia-seguinte' === $modo ) { return "Bateria em {$nome}: Entrega no Dia Seguinte"; }
	return "Bateria em {$nome}: Entrega e Instalação";
}

function awr_city_delivery_description( $cidade ) {
	return awr_seo_trim( 'Bateria de carro em ' . $cidade['nome'] . ' com entrega ' . awr_city_delivery_promise( $cidade ) . ', instalação no local, teste do alternador, nota fiscal e garantia. Peça pelo WhatsApp.', 155 );
}

/** Normaliza o conteúdo editorial antigo pela promessa comercial vigente. */
function awr_city_content_current( $cidade ) {
	$slug = $cidade['slug'];
	$old  = function_exists( 'awr_cidade_conteudo' ) ? awr_cidade_conteudo( $slug ) : null;
	$p    = awr_city_delivery_promise( $cidade );
	$local = array(
		'nova-santa-rita' => array( 'Nova Santa Rita é atendida pela unidade de Canoas, com saída pela BR-386. Pedidos confirmados até as 17h entram na rota de entrega do dia.', 'Trajetos pela BR-386, uso de acessórios e períodos com o veículo parado aumentam o esforço do sistema de partida.', 'Atendemos a área central, Berto Círio e os principais acessos industriais e residenciais.' ),
		'eldorado-do-sul' => array( 'Eldorado do Sul é atendida pela unidade Medianeira, com travessia pela ponte do Guaíba e entrega programada para o dia seguinte.', 'O deslocamento pela BR-290 e o trânsito lento exigem bateria com boa reserva de carga.', 'Atendemos Centro, Parque Eldorado, Sans Souci e os acessos da BR-290 e RS-030.' ),
		'guaiba' => array( 'Guaíba é atendida pela unidade Medianeira. A bateria correta é separada após a confirmação do veículo e entregue no dia seguinte.', 'Trânsito de travessia, trajetos curtos e veículos parados reduzem a recarga disponível entre as partidas.', 'A cobertura inclui Centro, Cohab, Parque 35, Santa Rita, Columbia City e Pedras Brancas.' ),
	);
	$extra = isset( $local[ $slug ] ) ? $local[ $slug ] : null;
	return array(
		'title' => awr_city_delivery_title( $cidade ),
		'desc' => awr_city_delivery_description( $cidade ),
		'h1' => 'Troca de bateria em ' . $cidade['nome'] . ' com instalação ' . $p,
		'subtitulo' => 'Bateria certa, teste do alternador e instalação no local ' . $p . '.',
		'abertura' => array( $extra ? $extra[0] : 'A AWR atende ' . $cidade['nome'] . ' ' . $p . ', com instalação no local e teste gratuito do alternador.', 'Trabalhamos com Moura, Heliar, Zetta e Excell, com nota fiscal, garantia de fábrica e pagamento no Pix ou cartão.' ),
		'motivo' => $extra ? $extra[1] : ( $old['motivo'] ?? 'Trajetos curtos e trânsito lento reduzem a recarga da bateria e antecipam falhas na partida.' ),
		'bairrosTexto' => $old['bairrosTexto'] ?? 'Atendemos ' . implode( ', ', (array) $cidade['bairros'] ) . ', com prazo confirmado antes da saída.',
		'marcas' => $old['marcas'] ?? array( 'moura' => 'Linha Moura convencional, EFB e AGM com garantia de fábrica.', 'heliar' => 'Linha Heliar para veículos convencionais e Start-Stop.', 'zetta' => 'Linha Zetta com custo-benefício e garantia.' ),
		'faq' => array(
			array( 'pergunta' => 'Qual é o prazo de entrega da bateria em ' . $cidade['nome'] . '?', 'resposta' => 'A entrega é ' . $p . '. Confirmamos a previsão e a disponibilidade no WhatsApp.' ),
			array( 'pergunta' => 'A instalação é feita no local?', 'resposta' => 'Sim. Instalamos, testamos o alternador e recolhemos a bateria usada.' ),
			array( 'pergunta' => 'Vocês têm bateria EFB e AGM?', 'resposta' => 'Sim. Confirmamos pelo modelo e ano se o veículo exige bateria convencional, EFB ou AGM.' ),
			array( 'pergunta' => 'A bateria tem nota fiscal e garantia?', 'resposta' => 'Sim. Todos os modelos têm nota fiscal e garantia de fábrica.' ),
		),
		'prova' => $extra ? $extra[2] : ( $old['prova'] ?? 'Atendimento no endereço com o modelo conferido antes da saída.' ),
	);
}

/**
 * 5.46.0 — Prazo pronto para títulos, descrições e textos.
 * Antes, várias rotas liam tempoEntregaMin direto: nas cidades sem entrega
 * rápida (valor 0) o Google exibia "Entrega em 0 min" ou o atalho "35 min",
 * prometendo um prazo que a operação não cumpre. Nas cidades com entrega
 * rápida o texto gerado é idêntico ao anterior.
 */
function awr_city_prazo( $cidade ) {
	$modo   = $cidade ? awr_city_delivery_mode( $cidade ) : 'consultar';
	$min    = $cidade && ! empty( $cidade['tempoEntregaMin'] ) ? (int) $cidade['tempoEntregaMin'] : 0;
	$rapida = 'rapida' === $modo && $min > 0;
	if ( $rapida ) {
		return array( 'rapida' => true, 'min' => $min, 'curto' => "em até {$min} min", 'longo' => "em até {$min} minutos", 'titulo' => "Chega em {$min} min", 'botao' => "{$min} min" );
	}
	$mapa = array(
		'ate-17h'      => array( 'no mesmo dia', 'no mesmo dia para pedidos confirmados até as 17h', 'Entrega no Mesmo Dia', 'mesmo dia' ),
		'dia-seguinte' => array( 'no dia seguinte', 'no dia seguinte', 'Entrega no Dia Seguinte', 'dia seguinte' ),
	);
	$t = $mapa[ $modo ] ?? array( 'com prazo confirmado no WhatsApp', 'com prazo confirmado pelo WhatsApp', 'Entrega e Instalação', 'prazo no WhatsApp' );
	return array( 'rapida' => false, 'min' => 0, 'curto' => $t[0], 'longo' => $t[1], 'titulo' => $t[2], 'botao' => $t[3] );
}
