<?php
/**
 * Busca de veículos / SKU / amperagem — porte de src/data/vehicles.ts.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

const AWR_SYNONYMS = array(
	'vw'       => array( 'volkswagen' ),
	'volks'    => array( 'volkswagen' ),
	'mb'       => array( 'mercedes', 'benz' ),
	'merc'     => array( 'mercedes' ),
	'mercedes' => array( 'mercedes', 'benz' ),
	'benz'     => array( 'mercedes', 'benz' ),
	'gm'       => array( 'chevrolet' ),
	'chevy'    => array( 'chevrolet' ),
	'hatch'    => array( 'hatch', 'hacth' ),
	'hacth'    => array( 'hatch', 'hacth' ),
	'sedan'    => array( 'sedan', 'sedam' ),
	'sedam'    => array( 'sedan', 'sedam' ),
	'plus'     => array( 'plus', 'sedan' ),
	'triton'   => array( 'triton', 'l200' ),
	'l200'     => array( 'l200', 'triton' ),
);

const AWR_STOPWORDS = array( 'novo', 'nova', 'new', 'carro', 'bateria', 'para', 'do', 'da', 'de' );

function awr_normalize( $s ) {
	$s = mb_strtolower( (string) $s, 'UTF-8' );
	$s = remove_accents( $s );
	$s = preg_replace( '/[^a-z0-9\s]/', ' ', $s );
	return trim( preg_replace( '/\s+/', ' ', $s ) );
}

/** Normalização sem espaços/hífens: "hr v" => "hrv", "rav 4" => "rav4". */
function awr_compact( $s ) {
	return preg_replace( '/\s+/', '', awr_normalize( $s ) );
}


function awr_slugify( $s ) {
	return sanitize_title( remove_accents( (string) $s ) );
}

/** Distância de edição ≤ 1 (substituição, inserção, remoção ou transposição)? */
function awr_edit_distance_max1( $a, $b ) {
	$la = strlen( $a ); $lb = strlen( $b );
	if ( abs( $la - $lb ) > 1 ) { return false; }
	if ( $a === $b ) { return true; }
	if ( $la === $lb ) {
		$diffs = 0; $idx = array();
		for ( $i = 0; $i < $la; $i++ ) {
			if ( $a[ $i ] !== $b[ $i ] ) { $diffs++; $idx[] = $i; if ( $diffs > 2 ) { return false; } }
		}
		if ( 1 === $diffs ) { return true; }
		return 2 === $diffs && $idx[1] === $idx[0] + 1 && $a[ $idx[0] ] === $b[ $idx[1] ] && $a[ $idx[1] ] === $b[ $idx[0] ];
	}
	$s = $la < $lb ? $a : $b;
	$l = $la < $lb ? $b : $a;
	$i = 0; $j = 0; $skipped = false;
	$ls = strlen( $s ); $ll = strlen( $l );
	while ( $i < $ls && $j < $ll ) {
		if ( $s[ $i ] === $l[ $j ] ) { $i++; $j++; continue; }
		if ( $skipped ) { return false; }
		$skipped = true;
		$j++;
	}
	return true;
}

/**
 * Pontua o casamento de um token (e sinônimos) com um item do catálogo.
 * Prioridade: palavra inteira do MODELO > início do modelo > marca exata
 * > erro de digitação no modelo > substring compacta. Substring solta na
 * marca NÃO pontua — era o que fazia "ka" casar com KAWASAKI e esconder
 * o Ford Ka. Espelho de scoreTokenInItem em src/data/vehicles.ts.
 */
function awr_score_token_in_item( $alts, $brand, $model, $brand_c, $model_c ) {
	$model_words = array_filter( explode( ' ', $model ) );
	$brand_words = array_filter( explode( ' ', $brand ) );
	$best = -1;
	foreach ( $alts as $a ) {
		$ac = preg_replace( '/\s+/', '', $a );
		if ( '' === $a ) { continue; }
		$al = strlen( $a ); $acl = strlen( $ac );
		// 1) Palavra inteira do modelo ("ka" === "KA" do Ford Ka)
		if ( in_array( $a, $model_words, true ) ) { $best = max( $best, 100 + $al ); continue; }
		// 2) Modelo começa com o token
		if ( 0 === strpos( $model, $a ) ) { $best = max( $best, 70 + $al ); continue; }
		// 3) Marca exata ou palavra inteira da marca ("nissan", "volkswagen")
		if ( $brand === $a || in_array( $a, $brand_words, true ) ) { $best = max( $best, 40 + $al ); continue; }
		// 4) Erro de digitação no modelo: 1 letra de diferença, tokens de 4+ letras
		if ( $al >= 4 ) {
			foreach ( $model_words as $w ) {
				if ( strlen( $w ) >= 4 && $w[0] === $a[0] && awr_edit_distance_max1( $a, $w ) ) {
					$best = max( $best, 25 + $al );
					break;
				}
			}
			if ( $best >= 25 ) { continue; }
		}
		// 5) Substring do modelo ("icks" => KICKS)
		if ( $al >= 3 && false !== strpos( $model, $a ) ) { $best = max( $best, 12 + $al ); continue; }
		// 6) Forma compacta sem espaços/hífens ("hrv" => "hr v")
		if ( $acl >= 3 && false !== strpos( $model_c, $ac ) ) { $best = max( $best, 8 + $acl ); continue; }
		// 7) Por último: substring da marca ("kawa" => KAWASAKI) — nunca acima de modelo
		if ( $al >= 3 && ( false !== strpos( $brand, $a ) || false !== strpos( $brand_c, $ac ) ) ) { $best = max( $best, 2 + $al ); }
	}
	return $best;
}

/** Sugestões agrupadas por marca|modelo|período. */
function awr_search_suggestions( $query, $limit = 12 ) {
	$q = awr_normalize( $query );
	if ( mb_strlen( $q ) < 2 ) { return array(); }
	$tokens     = array_filter( explode( ' ', $q ) );
	$year       = null;
	$text_tokens = array();
	foreach ( $tokens as $t ) {
		if ( null === $year && preg_match( '/^(19|20)\d{2}$/', $t ) ) { $year = (int) $t; continue; }
		if ( in_array( $t, AWR_STOPWORDS, true ) ) { continue; }
		$text_tokens[] = $t;
	}
	$alts = array();
	foreach ( $text_tokens as $t ) {
		$alts[] = isset( AWR_SYNONYMS[ $t ] ) ? array_unique( array_merge( array( $t ), AWR_SYNONYMS[ $t ] ) ) : array( $t );
	}
	if ( empty( $alts ) && ! $year ) { return array(); }

	$items   = awr_batteries()['items'];
	$scored  = array();
	$partial = array();
	$total   = count( $alts );
	foreach ( $items as $it ) {
		if ( $year && ( $year < $it['d'] || $year > $it['a'] ) ) { continue; }
		$brand   = awr_normalize( $it['ma'] );
		$model   = awr_normalize( $it['mo'] );
		$brand_c = preg_replace( '/\s+/', '', $brand );
		$model_c = preg_replace( '/\s+/', '', $model );
		$hits  = 0;
		$score = 0;
		foreach ( $alts as $group ) {
			$best = awr_score_token_in_item( $group, $brand, $model, $brand_c, $model_c );
			if ( $best < 0 ) { continue; }
			$hits++;
			$score += $best;
		}
		if ( $year ) { $score += 5; }
		$row = array( 'it' => $it, 'score' => $score, 'hits' => $hits );
		if ( $hits === $total ) { $scored[] = $row; } elseif ( $hits > 0 ) { $partial[] = $row; }
	}
	// Fallback: nenhuma linha casa com todas as palavras => melhor correspondência parcial.
	$pool = ! empty( $scored ) ? $scored : $partial;
	usort( $pool, function ( $x, $y ) {
		return ( $y['hits'] <=> $x['hits'] ) ?: ( ( $y['score'] <=> $x['score'] ) ?: ( $y['it']['a'] <=> $x['it']['a'] ) );
	} );

	$groups = array();
	foreach ( $pool as $row ) {
		$it  = $row['it'];
		$key = $it['ma'] . '|' . $it['mo'] . '|' . $it['d'] . '-' . $it['a'];

		if ( ! isset( $groups[ $key ] ) ) {
			if ( count( $groups ) >= $limit ) { break; }
			$ylabel          = $it['d'] === $it['a'] ? (string) $it['d'] : $it['d'] . '-' . $it['a'];
			$groups[ $key ] = array(
				'brand'     => $it['ma'],
				'model'     => $it['mo'],
				'yearStart' => $it['d'],
				'yearEnd'   => $it['a'],
				'year'      => $year ? $year : $it['a'],
				'label'     => $it['ma'] . ' ' . $it['mo'] . ' (' . $ylabel . ')',
				'slug'      => awr_slugify( $it['ma'] . '-' . $it['mo'] ),
				'items'     => array( $it ),
			);
		} else {
			$groups[ $key ]['items'][] = $it;
		}
	}
	return array_values( $groups );
}

/** Variantes compatíveis com marca+modelo+ano. */
function awr_vehicle_items( $brand, $model, $year ) {
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		if ( $it['ma'] === $brand && $it['mo'] === $model && $year >= $it['d'] && $year <= $it['a'] ) {
			$out[] = $it;
		}
	}
	return $out;
}

/** Resolve slug "chevrolet-onix" + ano nas variantes. */
function awr_vehicle_by_slug( $slug, $year = 0 ) {
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		if ( awr_slugify( $it['ma'] . '-' . $it['mo'] ) !== $slug ) { continue; }
		if ( $year && ( $year < $it['d'] || $year > $it['a'] ) ) { continue; }
		$out[] = $it;
	}
	return $out;
}

const AWR_BRAND_KEYS = array( 'm' => 'Moura', 'z' => 'Zetta', 'h' => 'Heliar', 'e' => 'Excell', 'h65' => 'Heliar', 'el' => 'Eletran' );

/** Cache de objeto simples (grupo awr), com fallback silencioso. */
function awr_cache_remember( $key, $callback ) {
	$ext = function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache();
	$ck  = $key . '_' . AWR_VERSION;
	if ( $ext ) {
		$hit = wp_cache_get( $ck, 'awr' );
		if ( is_array( $hit ) ) { return $hit; }
	}
	$val = call_user_func( $callback );
	if ( $ext ) { wp_cache_set( $ck, $val, 'awr', DAY_IN_SECONDS ); }
	return $val;
}

/**
 * 5.46.0 — Slug público do SKU em /bateria/{slug}/. Para SKUs comuns é o
 * próprio SKU em minúsculas (URL inalterada). SKUs com espaço, vírgula ou
 * barra ("HTX14 12", "MA8,6E", "HE60HD / H65HD") geravam URLs inválidas no
 * sitemap, com canonical diferente e página "SKU não encontrado".
 */
function awr_sku_slug( $sku ) {
	return sanitize_title( strtolower( (string) $sku ) );
}

/** SKU do catálogo a partir do slug da URL (inverso de awr_sku_slug). */
function awr_sku_from_slug( $slug ) {
	static $mapa = null;
	if ( null === $mapa ) {
		$mapa = array();
		foreach ( awr_sku_index() as $e ) {
			$k = awr_sku_slug( $e['sku'] );
			if ( ! isset( $mapa[ $k ] ) ) { $mapa[ $k ] = $e['sku']; }
		}
	}
	$slug = sanitize_title( (string) $slug );
	return $mapa[ $slug ] ?? strtoupper( $slug );
}

function awr_sku_index() {
	static $idx = null;
	if ( null !== $idx ) { return $idx; }
	$idx = awr_cache_remember( 'skuidx', function () {
		$out  = array();
		$seen = array();
		foreach ( awr_batteries()['items'] as $it ) {
			foreach ( AWR_BRAND_KEYS as $k => $brand ) {
				$raw = isset( $it[ $k ] ) ? trim( (string) $it[ $k ] ) : '';
				if ( '' === $raw ) { continue; }
				$sku = strtoupper( $raw );
				$key = $brand . '|' . $sku;
				if ( isset( $seen[ $key ] ) ) { continue; }
				$seen[ $key ] = true;
				$out[]        = array( 'sku' => $sku, 'brand' => $brand );
			}
		}
		return $out;
	} );
	return $idx;
}


/** Marca real associada ao SKU no catálogo de compatibilidade. */
function awr_brand_by_sku( $sku ) {
	$sku = strtoupper( trim( (string) $sku ) );
	foreach ( awr_sku_index() as $entry ) {
		if ( $entry['sku'] === $sku ) { return $entry['brand']; }
	}
	return '';
}

/** Amperagem provável a partir do SKU/nome. */
function awr_extract_amperage( ...$parts ) {
	$hay = strtoupper( implode( ' ', array_filter( $parts ) ) );
	if ( preg_match( '/(\d{2,3})\s*AH/', $hay, $m ) ) {
		$n = (int) $m[1];
		if ( $n >= 20 && $n <= 260 ) { return $n; }
	}
	if ( preg_match( '/(?<![A-Z0-9])(\d{2,3})(?=[A-Z]|$)/', $hay, $m ) ) {
		$n = (int) $m[1];
		if ( $n >= 20 && $n <= 260 ) { return $n; }
	}
	return 0;
}

function awr_search_by_sku( $query, $limit = 5 ) {
	$q = strtoupper( preg_replace( '/\s+/', '', (string) $query ) );
	if ( strlen( $q ) < 2 ) { return array(); }
	$exact = null; $starts = array(); $contains = array();
	foreach ( awr_sku_index() as $e ) {
		if ( $e['sku'] === $q ) { $exact = $e; continue; }
		if ( 0 === strpos( $e['sku'], $q ) ) { $starts[] = $e; }
		elseif ( false !== strpos( $e['sku'], $q ) ) { $contains[] = $e; }
	}
	$out = $exact ? array_merge( array( $exact ), $starts, $contains ) : array_merge( $starts, $contains );
	return array_slice( $out, 0, $limit );
}

function awr_search_by_amperage( $ah, $limit = 60 ) {
	$ah = (int) $ah;
	if ( $ah <= 0 ) { return array(); }
	$out = array();
	foreach ( awr_sku_index() as $e ) {
		if ( awr_extract_amperage( $e['sku'] ) === $ah ) { $out[] = $e; }
		if ( count( $out ) >= $limit ) { break; }
	}
	return $out;
}

/**
 * Amperagens realmente disponíveis (compatibilidade + catálogo WooCommerce).
 * Só entram valores que geram pelo menos um modelo na página.
 */
function awr_amperagens_disponiveis() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$out = awr_cache_remember( 'amperagens_v2', function () {
		$set = array();

		foreach ( awr_sku_index() as $e ) {
			$ah = awr_extract_amperage( $e['sku'] );
			if ( $ah >= 30 && $ah <= 260 ) { $set[ $ah ] = true; }
		}

		// Catálogo WooCommerce: traz 72Ah, 180Ah, 220Ah e demais itens fora da tabela.
		if ( function_exists( 'awr_shop_amperage_index' ) ) {
			foreach ( array_keys( awr_shop_amperage_index() ) as $ah ) {
				$ah = (int) $ah;
				if ( $ah >= 30 && $ah <= 260 ) { $set[ $ah ] = true; }
			}
		}

		$list = array_keys( $set );
		sort( $list );
		return $list;
	} );
	return $out;
}

/** Existe pelo menos um modelo para a amperagem? */
function awr_amperagem_tem_modelos( $ah ) {
	$ah = (int) $ah;
	if ( $ah <= 0 ) { return false; }
	if ( awr_search_by_amperage( $ah, 1 ) ) { return true; }
	$idx = function_exists( 'awr_shop_amperage_index' ) ? awr_shop_amperage_index() : array();
	return ! empty( $idx[ $ah ] );
}




/** Desconto de casco por amperagem (porte de priceFloor.ts). */
function awr_desconto_casco( $ah ) {
	$ah = (int) $ah;
	if ( $ah <= 0 ) { return 40; }
	if ( $ah <= 50 ) { return 40; }
	if ( $ah <= 70 ) { return 60; }
	if ( $ah <= 90 ) { return 80; }
	return 100;
}

/** Lista de SKUs de um conjunto de variantes, com a marca. */
function awr_skus_from_items( $items ) {
	$out = array();
	foreach ( $items as $it ) {
		foreach ( AWR_BRAND_KEYS as $k => $brand ) {
			$raw = isset( $it[ $k ] ) ? trim( (string) $it[ $k ] ) : '';
			if ( '' === $raw ) { continue; }
			$out[ strtoupper( $raw ) ] = array( 'sku' => strtoupper( $raw ), 'brand' => $brand );
		}
	}
	return array_values( $out );
}

/* ======================================================================
   v3.5.0 — índice de veículos para as rotas de SEO
   /baterias/{marca}/ /baterias/{marca}/{modelo}/ /baterias/{marca}/{modelo}/{ano}/
   ====================================================================== */

/** Marcas de veículo do catálogo: slug => nome. */
function awr_vehicle_brands() {
	static $out = null;
	if ( null !== $out ) { return $out; }
	$out = awr_cache_remember( 'vbrands', function () {
		$list = array();
		foreach ( awr_batteries()['items'] as $it ) {
			$list[ awr_slugify( $it['ma'] ) ] = $it['ma'];
		}
		ksort( $list );
		return $list;
	} );
	return $out;
}


/** O slug é uma marca de veículo? */
function awr_is_vehicle_brand( $slug ) {
	$b = awr_vehicle_brands();
	return isset( $b[ $slug ] ) ? $b[ $slug ] : '';
}

/** Modelos de uma marca: slug => array(nome, ano_min, ano_max). */
function awr_vehicle_models( $brand_slug ) {
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		if ( awr_slugify( $it['ma'] ) !== $brand_slug ) { continue; }
		$k = awr_slugify( $it['mo'] );
		if ( ! isset( $out[ $k ] ) ) {
			$out[ $k ] = array( 'nome' => $it['mo'], 'de' => (int) $it['d'], 'ate' => (int) $it['a'] );
		} else {
			$out[ $k ]['de']  = min( $out[ $k ]['de'], (int) $it['d'] );
			$out[ $k ]['ate'] = max( $out[ $k ]['ate'], (int) $it['a'] );
		}
	}
	ksort( $out );
	return $out;
}

/** Variantes de um modelo (marca+modelo em slug), opcionalmente filtradas por ano. */
function awr_vehicle_variants( $brand_slug, $model_slug, $year = 0 ) {
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		if ( awr_slugify( $it['ma'] ) !== $brand_slug ) { continue; }
		if ( awr_slugify( $it['mo'] ) !== $model_slug ) { continue; }
		if ( $year && ( $year < $it['d'] || $year > $it['a'] ) ) { continue; }
		$out[] = $it;
	}
	return $out;
}

/** Anos indexáveis de um modelo (últimos ~22 anos até o ano corrente + 1). */
function awr_vehicle_years( $brand_slug, $model_slug ) {
	$min = 9999; $max = 0;
	foreach ( awr_vehicle_variants( $brand_slug, $model_slug ) as $it ) {
		$min = min( $min, (int) $it['d'] );
		$max = max( $max, (int) $it['a'] );
	}
	if ( ! $max ) { return array(); }
	// Teto: ano corrente + 1. Sem isso, dados corrompidos (ex.: "a":9170)
	// geram milhares de URLs de ano que o rewrite (19|20)xx não aceita → 404.
	$max   = min( $max, (int) gmdate( 'Y' ) + 1 );
	$floor = max( $min, (int) gmdate( 'Y' ) - 22 );
	if ( $floor > $max ) { return array(); }
	$out   = array();
	for ( $y = $floor; $y <= $max; $y++ ) { $out[] = $y; }
	return $out;
}

/** URL canônica de um veículo. */
function awr_vehicle_url( $marca, $modelo, $ano = 0 ) {
	$u = '/baterias/' . awr_slugify( $marca ) . '/' . awr_slugify( $modelo ) . '/';
	if ( $ano ) { $u .= (int) $ano . '/'; }
	return home_url( $u );
}
