<?php
/**
 * Camada de performance de assets (v3.28.0).
 *
 * - CSS crítico inline + bundle carregado sem bloquear a renderização.
 * - Fontes hospedadas no próprio tema (sem Google Fonts).
 * - WooCommerce/jQuery removidos das telas de conteúdo.
 * - Pixels de terceiros só depois da primeira interação/idle.
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** A tela atual precisa do JavaScript do WooCommerce? */
function awr_screen_needs_woo() {
	if ( is_admin() ) { return true; }
	if ( ! class_exists( 'WooCommerce' ) ) { return false; }
	if ( is_user_logged_in() ) { return true; }
	if ( function_exists( 'is_woocommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) ) { return true; }
	if ( function_exists( 'WC' ) && WC() && WC()->cart && ! WC()->cart->is_empty() ) { return true; }
	return in_array( awr_current_route(), array( 'pedido', 'produto', 'sku', 'buscar', 'widget', 'baterias_de_carro' ), true );
}

/**
 * Fora da loja o tema não usa jQuery nem os scripts do Woo: eles sozinhos
 * respondem por boa parte do tempo de bloqueio no mobile.
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( awr_screen_needs_woo() ) { return; }

	$scripts = array(
		'wc-add-to-cart', 'woocommerce', 'wc-cart-fragments', 'wc-jquery-blockui', 'jquery-blockui',
		'wc-js-cookie', 'js-cookie', 'sourcebuster-js', 'wc-order-attribution', 'wc-single-product',
		'wc-password-strength-meter', 'selectWoo', 'wc-country-select', 'wc-address-i18n',
	);
	foreach ( $scripts as $handle ) { wp_dequeue_script( $handle ); wp_deregister_script( $handle ); }

	$styles = array(
		'woocommerce-general', 'woocommerce-layout', 'woocommerce-smallscreen',
		'wc-blocks-style', 'wc-blocks-integration', 'brands-styles', 'select2',
	);
	foreach ( $styles as $handle ) { wp_dequeue_style( $handle ); }

	// jQuery só permanece quando algum plugin realmente depende dela na tela
	// (a varredura abaixo, em wp_print_scripts, confirma e reverte se preciso).
	wp_dequeue_script( 'jquery' );
	wp_dequeue_script( 'jquery-core' );
	wp_dequeue_script( 'jquery-migrate' );
}, 99 );

/**
 * Sem jQuery na página, nenhum script que dependa dela pode continuar na fila:
 * era daí que vinha o "ReferenceError: jQuery is not defined" do
 * woocommerce-analytics, que ainda custava tempo da thread principal.
 *
 * Handles listados em `awr_keep_jquery_handles` invertem a decisão: em vez de
 * remover o script, o tema devolve o jQuery à fila.
 */
add_action( 'wp_print_scripts', function () {
	if ( is_admin() || awr_screen_needs_woo() ) { return; }

	$wp_scripts = wp_scripts();
	if ( ! $wp_scripts || in_array( 'jquery-core', (array) $wp_scripts->queue, true ) ) { return; }

	$dependentes = array();
	foreach ( (array) $wp_scripts->queue as $handle ) {
		if ( ! isset( $wp_scripts->registered[ $handle ] ) ) { continue; }
		$deps = (array) $wp_scripts->registered[ $handle ]->deps;
		if ( array_intersect( $deps, array( 'jquery', 'jquery-core', 'jquery-migrate' ) ) ) {
			$dependentes[] = $handle;
		}
	}
	// Scripts que trazem o próprio uso de jQuery sem declarar dependência.
	foreach ( array( 'woocommerce-analytics', 'wc-analytics', 'language-switcher' ) as $extra ) {
		if ( in_array( $extra, (array) $wp_scripts->queue, true ) ) { $dependentes[] = $extra; }
	}
	$dependentes = array_values( array_unique( $dependentes ) );
	if ( ! $dependentes ) { return; }

	$manter = (array) apply_filters( 'awr_keep_jquery_handles', array() );
	if ( array_intersect( $dependentes, $manter ) ) {
		wp_enqueue_script( 'jquery' );
		return;
	}
	foreach ( $dependentes as $handle ) { wp_dequeue_script( $handle ); }
}, 5 );



/** O carrinho por AJAX do Woo dispara consultas em toda página de conteúdo. */
add_filter( 'woocommerce_enqueue_styles', function ( $styles ) {
	return awr_screen_needs_woo() ? $styles : array();
} );

/* ---------------------------------------------------------------------
   CSS: crítico inline, bundle assíncrono, fontes locais
   --------------------------------------------------------------------- */

/**
 * URL da fonte. Usa a rota /awr-font/ (cache imutável de 1 ano) apenas depois
 * que as regras de reescrita desta versão foram gravadas; antes disso segue
 * pelo caminho normal do tema, para nunca quebrar a tipografia.
 */
function awr_font_url( $file ) {
	// v5.36.1 — arquivo real por padrão: a rota /awr-font/ subia o WordPress
	// inteiro a cada fonte e, sem extensão na URL, a CDN não guardava em cache.
	if ( apply_filters( 'awr_assets_via_php', false ) && get_option( 'awr_rewrite_version' ) === AWR_VERSION ) {
		// Sem extensão .woff2 na URL: várias hospedagens tentam servir URLs
		// terminadas em .woff2 como arquivo estático e respondem 404 antes
		// de chegar ao WordPress.
		return home_url( '/awr-font/' . pathinfo( $file, PATHINFO_FILENAME ) );
	}
	return AWR_URI . '/assets/fonts/' . $file;
}

/** CSS crítico do topo, impresso direto no <head>. */
add_action( 'wp_head', function () {
	if ( is_admin() ) { return; }
	$critical = AWR_DIR . '/assets/css/awr-critical.css';
	$fonts    = AWR_DIR . '/assets/css/awr-fonts.css';
	$css      = '';
	foreach ( array( $fonts, $critical ) as $file ) {
		if ( file_exists( $file ) ) { $css .= file_get_contents( $file ); } // phpcs:ignore WordPress.WP.AlternativeFunctions
	}
	if ( '' === $css ) { return; }
	foreach ( array( 'Figtree.woff2', 'Outfit.woff2' ) as $font ) {
		$css = str_replace( '../fonts/' . $font, awr_font_url( $font ), $css );
		echo '<link rel="preload" as="font" type="font/woff2" crossorigin href="' . esc_url( awr_font_url( $font ) ) . '">' . "\n";
	}
	echo '<style id="awr-critical">' . $css . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}, 2 );

/**
 * v5.6.0 — LCP: folhas de estilo de plugins que não existem nas telas de
 * conteúdo saíam bloqueando a primeira pintura (cada uma custa uma ida e
 * volta no 4G). Fora da loja elas simplesmente não entram na página.
 */
add_action( 'wp_enqueue_scripts', function () {
	if ( is_admin() || awr_screen_needs_woo() ) { return; }
	$remover = (array) apply_filters( 'awr_remover_css_handles', array(
		'mediaelement', 'wp-mediaelement',
		'jetpack-block-podcast-episode', 'jetpack-forms-layout', 'jetpack-blocks-style',
		'jetpack_css', 'jetpack-layout-grid', 'sharedaddy', 'social-logos',
		'classic-theme-styles', 'wp-block-library-theme',
	) );
	foreach ( $remover as $handle ) { wp_dequeue_style( $handle ); wp_deregister_style( $handle ); }
}, 100 );

/** O bundle completo deixa de bloquear o primeiro pixel pintado. */
add_filter( 'style_loader_tag', function ( $tag, $handle, $href ) {
	if ( is_admin() ) { return $tag; }
	$async = array( 'awr-parity', 'awr-style', 'awr-main', 'awr-v3', 'awr-overrides', 'awr-final' );
	if ( 0 === strpos( $handle, 'awr-page-' ) ) { $async[] = $handle; }
	// v5.6.0 — fora da loja, nenhum CSS de plugin precisa bloquear a primeira tela.
	$plugin_css = ! awr_screen_needs_woo() && ! in_array( $handle, array( 'awr-critical', 'awr-fonts' ), true );
	if ( ! in_array( $handle, $async, true ) && ! $plugin_css ) { return $tag; }
	return '<link rel="stylesheet" href="' . esc_url( $href ) . '" media="print" onload="this.media=\'all\';this.onload=null">'
		. '<noscript><link rel="stylesheet" href="' . esc_url( $href ) . '"></noscript>' . "\n";
}, 20, 3 );

/* ---------------------------------------------------------------------
   Terceiros: sobem só depois da primeira interação ou no idle
   --------------------------------------------------------------------- */

/**
 * Handles de pixel que não precisam existir no carregamento inicial.
 * O `google_gtagjs` NÃO entra aqui: adiar o gtag faz o GA4/Ads perderem
 * as sessões curtas e o Google reportar "coleta de dados não ativa".
 */
function awr_delayed_script_handles() {
	return apply_filters( 'awr_delayed_script_handles', array(
		'reddit_tracking', 'snapchat_tracking',
		'googlesitekit-events-provider-woocommerce', 'googlesitekit-consent-mode',
		// v3.78.0 — medição e tradução não precisam existir na primeira tela.
		'googlesitekit-events-provider-content-events',
		'jetpack-stats', 'woocommerce-analytics-client', 'universally-switcher',
		// v3.79.0 — sobras medidas no PageSpeed (consent mode, tradutor, Woo analytics).
		'language-switcher', 'googlesitekit-modules-analytics-4', 'googlesitekit-events-provider-easy-digital-downloads',
		'wc-analytics', 'woocommerce-analytics', 'jetpack-boost-critical-css',
	) );
}

add_filter( 'script_loader_tag', function ( $tag, $handle, $src ) {
	if ( is_admin() || ! in_array( $handle, awr_delayed_script_handles(), true ) ) { return $tag; }
	return '<script type="text/awr-delayed" data-src="' . esc_url( $src ) . '" data-handle="' . esc_attr( $handle ) . '"></script>' . "\n";
}, 20, 3 );

/** Carregador dos scripts adiados. */
add_action( 'wp_footer', function () {
	if ( is_admin() ) { return; }
	?>
<script data-cfasync="false">
(function(){
  var done=false;
  function go(){
    if(done) return; done=true;
    var list=document.querySelectorAll('script[type="text/awr-delayed"]');
    for(var i=0;i<list.length;i++){
      var old=list[i],s=document.createElement('script');
      s.src=old.getAttribute('data-src'); s.async=true; s.setAttribute('data-cfasync','false');
      document.head.appendChild(s);
    }
  }
  var ev=['pointerdown','keydown','scroll','touchstart'];
  function on(){ ev.forEach(function(e){window.removeEventListener(e,on);}); go(); }
  ev.forEach(function(e){ window.addEventListener(e,on,{passive:true,once:true}); });
  if('requestIdleCallback' in window) requestIdleCallback(go,{timeout:5000}); else setTimeout(go,4000);
})();
</script>
	<?php
}, 99 );

/* ---------------------------------------------------------------------
   Fontes com cache longo — independe do TTL curto da hospedagem
   --------------------------------------------------------------------- */

/** /awr-font/{arquivo} servido com cache imutável de 1 ano (sem .woff2 na URL). */
add_action( 'init', function () {
	add_rewrite_rule( '^awr-font/([A-Za-z0-9_-]+)$', 'index.php?awr_font=$matches[1]', 'top' );
} );

add_filter( 'query_vars', function ( $vars ) {
	$vars[] = 'awr_font';
	return $vars;
} );

add_action( 'template_redirect', function () {
	$font = get_query_var( 'awr_font' );
	if ( ! $font ) { return; }
	$path = AWR_DIR . '/assets/fonts/' . $font . '.woff2';
	if ( ! file_exists( $path ) ) { status_header( 404 ); exit; }
	header( 'Content-Type: font/woff2' );
	header( 'Cache-Control: public, max-age=31536000, immutable' );
	header( 'Access-Control-Allow-Origin: *' );
	header( 'Content-Length: ' . filesize( $path ) );
	readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
} );

/* ---------------------------------------------------------------------
   CSS/JS do tema com cache imutável — a hospedagem devolve só 4h
   --------------------------------------------------------------------- */

/**
 * /awr-asset/{css|js}/{nome} serve assets/css/{nome}.css e assets/js/{nome}.js
 * com 1 ano de cache imutável. A extensão fica fora do fim da URL porque
 * várias hospedagens tentam servir URLs terminadas em .css/.js como arquivo
 * estático e respondem 404 antes de chegar ao WordPress.
 */
add_action( 'init', function () {
	add_rewrite_rule( '^awr-asset/(css|js)/([A-Za-z0-9_.-]+)/?$', 'index.php?awr_asset_ext=$matches[1]&awr_asset_file=$matches[2]', 'top' );
} );

add_filter( 'query_vars', function ( $vars ) {
	$vars[] = 'awr_asset_ext';
	$vars[] = 'awr_asset_file';
	return $vars;
} );

add_action( 'template_redirect', function () {
	$ext  = (string) get_query_var( 'awr_asset_ext' );
	$file = (string) get_query_var( 'awr_asset_file' );
	if ( '' === $ext || '' === $file ) { return; }
	if ( ! in_array( $ext, array( 'css', 'js' ), true ) || false !== strpos( $file, '..' ) ) {
		status_header( 404 );
		exit;
	}

	$base = realpath( AWR_DIR . '/assets/' . $ext );
	$path = realpath( AWR_DIR . '/assets/' . $ext . '/' . $file . '.' . $ext );
	if ( ! $base || ! $path || 0 !== strpos( $path, $base ) || ! is_file( $path ) ) {
		status_header( 404 );
		exit;
	}

	header( 'Content-Type: ' . ( 'css' === $ext ? 'text/css' : 'application/javascript' ) . '; charset=UTF-8' );
	header( 'Cache-Control: public, max-age=31536000, immutable' );
	header( 'Vary: Accept-Encoding' );
	header( 'Access-Control-Allow-Origin: *' );
	header( 'X-Content-Type-Options: nosniff' );
	header( 'Content-Length: ' . filesize( $path ) );
	readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
} );

/** A rota só entra em uso depois que as regras desta versão foram gravadas. */
function awr_asset_route_ativa() {
	return get_option( 'awr_rewrite_version' ) === AWR_VERSION;
}

/**
 * URL de um asset do tema pela rota imutável (com fallback para o caminho
 * normal). A querystring `?ver=` é preservada: ao atualizar o tema, o endereço
 * muda e o navegador baixa a versão nova.
 */
function awr_asset_cached_url( $url ) {
	// v5.36.1 — desligado por padrão: cada CSS/JS pela rota /awr-asset/ era uma
	// execução completa de PHP (WordPress + WooCommerce) e a CDN não guardava a
	// resposta. As rotas continuam respondendo para HTML antigo ainda em cache.
	if ( ! apply_filters( 'awr_assets_via_php', false ) ) { return $url; }
	if ( ! is_string( $url ) || '' === $url || ! awr_asset_route_ativa() ) { return $url; }

	$prefix = AWR_URI . '/assets/';
	if ( 0 !== strpos( $url, $prefix ) ) { return $url; }

	$rest  = substr( $url, strlen( $prefix ) );
	$query = '';
	if ( false !== strpos( $rest, '?' ) ) {
		list( $rest, $query ) = explode( '?', $rest, 2 );
		$query = '?' . $query;
	}
	if ( ! preg_match( '#^(css|js)/([A-Za-z0-9_.-]+)\.(css|js)$#', $rest, $m ) || $m[1] !== $m[3] ) {
		return $url;
	}
	// Barra final obrigatória: sem ela o canonical do WordPress responde 301 e
	// o navegador gasta uma ida e volta extra antes de receber o CSS/JS.
	return home_url( '/awr-asset/' . $m[1] . '/' . $m[2] . '/' ) . $query;
}

foreach ( array( 'style_loader_src', 'script_loader_src' ) as $awr_src_filter ) {
	add_filter( $awr_src_filter, function ( $src ) {
		return is_admin() ? $src : awr_asset_cached_url( $src );
	}, 20 );
}
unset( $awr_src_filter );

/**
 * 5.47.0 — Foto do hero da home pré-carregada. No celular ela passou a aparecer
 * logo abaixo do título e vira o maior elemento da primeira tela (LCP): sem o
 * preload o navegador só a descobriria depois de ler o CSS.
 */
add_action( 'wp_head', function () {
	if ( is_admin() || ! is_front_page() ) { return; }
	$dir = '/assets/img/hero-awr-moura-cut-';
	if ( ! file_exists( AWR_DIR . $dir . '460.webp' ) ) { return; }
	printf(
		'<link rel="preload" as="image" type="image/webp" fetchpriority="high" imagesrcset="%s 1x, %s 2x">' . "\n",
		esc_url( AWR_URI . $dir . '460.webp' ),
		esc_url( AWR_URI . $dir . '920.webp' )
	);
}, 1 );
