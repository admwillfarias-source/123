<?php
/**
 * /baterias-estacionarias/ · /baterias-para-caminhao/ · /baterias-para-moto/
 * Hub da categoria (paridade com SegmentoHub do app).
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$seg = awr_segmento_by_base( awr_param_a() );
if ( ! $seg ) { get_template_part( '404' ); get_footer(); return; }
$hub = (array) $seg['hub'];
$wa  = awr_wa( $seg['wa'] );
?>
<?php
awr_part( 'segmento-hero', array(
	'seg'   => $seg,
	'h1'    => $hub['h1'],
	'lead'  => $hub['tagline'],
	'atual' => $seg['nome'],
	'wa'    => $wa,
) );
?>

<?php awr_part( 'mais-vendidos', array( 'segmento' => $seg['key'] ) ); ?>
<div class="awr-hub-body awr-hub-body--narrow">
	<?php foreach ( (array) $hub['intro'] as $par ) : ?>
		<p><?php echo esc_html( $par ); ?></p>
	<?php endforeach; ?>
</div>

<?php if ( 'estacionaria' === $seg['key'] && function_exists( 'awr_est_paginas_nav' ) ) : ?>
<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Escolha pela aplicação ou pela amperagem</h2>
		<ul class="awr-app-outras">
			<?php foreach ( awr_est_paginas_nav() as $awr_n ) : ?>
				<li><a href="<?php echo esc_url( $awr_n['url'] ); ?>"><div><h3><?php echo esc_html( $awr_n['label'] ); ?></h3><p><?php echo 'amperagem' === $awr_n['tipo'] ? 'Modelos, aplicações e autonomia estimada' : 'Indicação pelo equipamento, nota fiscal e troca no local'; ?></p></div><span class="awr-app-outras__arrow" aria-hidden="true">→</span></a></li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
<?php endif; ?>

<?php awr_part( 'segmento-corpo', array( 'seg' => $seg ) ); ?>

<section class="awr-app-section">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Cidades atendidas</h2>
		<?php if ( 'estacionaria' === $seg['key'] ) : ?>
			<p class="awr-est__lead">Entrega e instalação própria na região metropolitana de Porto Alegre. Nas demais cidades a venda é feita com envio por transportadora, nota fiscal em CNPJ ou CPF e frete cotado na hora pelo WhatsApp.</p>
		<?php endif; ?>
		<?php foreach ( awr_segmento_cidades_por_uf( $seg ) as $awr_uf => $awr_lista ) : ?>
			<h3 class="awr-app-section__uf"><?php echo esc_html( $awr_uf ); ?></h3>
			<ul class="awr-app-outras">
				<?php foreach ( $awr_lista as $c ) : ?>
					<li>
						<a href="<?php echo esc_url( awr_segmento_url( $seg, $c['slug'] ) ); ?>">
							<div>
								<h4><?php echo esc_html( $seg['nome'] ); ?> em <?php echo esc_html( $c['nome'] ); ?></h4>
								<p><?php echo ( isset( $c['modo'] ) && 'envio' === $c['modo'] ) ? 'Venda com envio por transportadora' : 'Entrega e instalação no local'; ?></p>
							</div>
							<span class="awr-app-outras__arrow" aria-hidden="true">→</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endforeach; ?>
	</div>
</section>


<?php if ( 'moto' === $seg['key'] ) : ?>
	<div class="awr-hub-body">
		<?php awr_part( 'moto-blocos', array( 'cidade' => '', 'cidade_nome' => '' ) ); ?>
		<?php awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes sobre bateria de moto', 'itens' => awr_moto_faq() ) ); ?>
	</div>
<?php endif; ?>

<?php awr_part( 'prova-social' ); ?>
<?php get_footer(); ?>
