<?php
/**
 * /bateria/{sku}/ — página do SKU.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$sku      = awr_sku_from_slug( awr_param_a() );
$produtos = awr_products_by_skus( array( array( 'sku' => $sku, 'brand' => awr_brand_by_sku( $sku ) ) ) );
$p        = $produtos ? $produtos[0] : null;
$ah       = $p ? (int) $p['amperagem'] : awr_extract_amperage( $sku );

// Veículos compatíveis com este SKU, agrupados por marca.
$compat = awr_product_compat_grouped( $sku );
$faq    = awr_product_faq( $sku, $p['name'] ?? '', $p['brand'] ?? awr_brand_by_sku( $sku ), $ah );
?>
<div class="awr-container">
	<?php
	$awr_marca_sku = function_exists( 'awr_brand_by_sku' ) ? awr_brand_by_sku( $sku ) : '';
	awr_part( 'hero', array(
		'eyebrow' => 'Modelo de bateria',
		'h1'      => awr_product_seo_name( $sku, $p['name'] ?? '', $awr_marca_sku, $ah ) . ' Original',
		'lead'    => 'Confira preço atualizado, veículos compatíveis, garantia de fábrica e entrega com instalação grátis em Porto Alegre e região.',
		'wa'      => "Olá! Quero saber o preço e a disponibilidade da bateria {$sku}.",
		'wa_label'=> 'Falar com um atendente',
		'trilha'  => array( array( 'nome' => 'Modelos de bateria', 'url' => home_url( '/baterias/' ) ) ),
		'atual'   => $sku,
	) );
	?>

	<section class="awr-cards">
		<?php
		if ( $p ) {
			awr_part( 'card-bateria', array( 'produto' => $p ) );
		} else {
			echo '<p class="awr-lead">Não encontramos este SKU no catálogo online. Fale com a central e confirmamos disponibilidade na hora.</p>';
		}
		?>
	</section>

	<?php if ( $ah ) : ?>
		<p class="awr-lead"><a href="<?php echo esc_url( home_url( '/baterias/amperagem/' . $ah . '/' ) ); ?>">Ver todas as baterias de <?php echo esc_html( $ah ); ?>Ah →</a></p>
	<?php endif; ?>

	<?php awr_part( 'ficha-tecnica', array( 'sku' => $sku ) ); ?>
	<?php awr_part( 'produto-seo', array( 'sku' => $sku, 'marca' => $awr_marca_sku, 'ah' => $ah ) ); ?>

	<?php if ( $compat ) : ?>
		<section class="awr-block awr-compat">
			<h2 class="awr-section-title">Descubra se a bateria <?php echo esc_html( $sku ); ?> serve no seu carro</h2>
			<?php awr_part( 'compat-marcas', array( 'grupos' => $compat ) ); ?>
		</section>
	<?php endif; ?>
	<?php awr_part( 'faq', array( 'titulo' => 'Perguntas sobre esta bateria', 'itens' => $faq ) ); ?>

	<?php awr_part( 'search', array( 'titulo' => 'Prefere buscar pelo seu carro?' ) ); ?>

	<?php awr_part( 'links-internos', array( 'tipo' => 'sku', 'slug' => $sku, 'ah' => $ah ) ); ?>
	<?php
	if ( $p ) {
		$wc = ! empty( $p['id'] ) && function_exists( 'wc_get_product' ) ? wc_get_product( $p['id'] ) : null;
		$schema = awr_product_schema( $p, $wc );
		if ( $schema ) { awr_jsonld( $schema ); }
	}
	awr_product_faq_schema( $faq );
	?>

</div>
<?php get_footer(); ?>
