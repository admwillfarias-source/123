<?php
/**
 * /baterias-para/{marca-modelo}/ — hub do modelo com as cidades atendidas.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$m = awr_vc_model( awr_param_a() );
if ( ! $m ) { get_template_part( '404' ); return; }

$label    = awr_vc_label( $m );
$anos     = $m['de'] === $m['ate'] ? (string) $m['de'] : $m['de'] . ' a ' . $m['ate'];
$ahs      = awr_vc_amperagens( $m );
$ahtxt    = $ahs ? ( $ahs[0] . 'Ah' . ( count( $ahs ) > 1 ? ' a ' . end( $ahs ) . 'Ah' : '' ) ) : '60Ah';
$produtos = awr_products_by_skus( awr_vc_skus( $m ) );
$compat_checkout = array();
foreach ( array_slice( $produtos, 0, 3 ) as $produto ) {
	$compat_checkout[] = array(
		'sku'      => (string) ( $produto['sku'] ?? '' ),
		'nome'     => (string) ( $produto['nome'] ?? $produto['name'] ?? $produto['sku'] ?? '' ),
		'preco'    => (float) ( $produto['price'] ?? $produto['preco'] ?? 0 ),
		'casco'    => (float) ( $produto['casco'] ?? 0 ),
		'image'    => (string) ( $produto['image'] ?? $produto['imagem'] ?? '' ),
		'garantia' => (string) ( $produto['garantia'] ?? '' ),
		'veiculo'  => $label,
	);
}

get_header();
?>
<div class="awr-container awr-veiculo">
	<?php
	awr_part( 'hero', array(
		'eyebrow' => 'Baterias por veículo',
		'h1'      => 'Bateria para ' . $label,
		'lead'    => sprintf( 'O %s usa bateria de %s. Veja os modelos compatíveis, preço atualizado e escolha sua cidade para conferir entrega ou envio.', $label . ' ' . $anos, $ahtxt ),
		'wa'      => "Olá! Preciso da bateria do meu {$label}. Podem me passar preço e prazo?",
		'wa_label'=> 'Falar com um atendente',
		'trilha'  => array( array( 'nome' => 'Baterias por veículo', 'url' => home_url( '/baterias-para/' ) ) ),
		'atual'   => "Bateria para {$label}",
	) );
	?>

	<?php if ( ! empty( $m['familia'] ) ) : $versoes = awr_vc_versoes( $m ); ?>
	<section class="awr-block awr-veiculo-versoes">
		<h2 class="awr-section-title">Qual bateria usar no <?php echo esc_html( $label ); ?> por versão e ano</h2>
		<p>Tabela de compatibilidade do catálogo AWR. Confirme a versão do seu <?php echo esc_html( $label ); ?> (com ou sem start-stop, motor) antes da compra.</p>
		<div class="awr-table-wrap"><table class="awr-table">
			<thead><tr><th>Versão</th><th>Anos</th><th>Amperagem</th><th>Modelos compatíveis</th></tr></thead>
			<tbody>
			<?php foreach ( $versoes as $v ) : ?>
				<tr>
					<td><?php echo esc_html( $v['versao'] ); ?></td>
					<td><?php echo esc_html( $v['anos'] ); ?></td>
					<td><?php echo esc_html( $v['ahs'] ? implode( ' / ', array_map( function ( $a ) { return $a . 'Ah'; }, $v['ahs'] ) ) : '—' ); ?></td>
					<td><?php
					$links = array();
					foreach ( $v['skus'] as $sk ) { $links[] = '<a href="' . esc_url( home_url( '/bateria/' . awr_sku_slug( $sk['sku'] ) . '/' ) ) . '">' . esc_html( $sk['brand'] . ' ' . $sk['sku'] ) . '</a>'; }
					echo implode( ', ', $links ); // phpcs:ignore -- escapado acima.
					?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table></div>
	</section>
	<?php endif; ?>

	<?php if ( $produtos ) : ?>
		<script type="application/json" id="awr-static-compat"><?php echo wp_json_encode( $compat_checkout, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?></script>
		<section class="awr-results awr-results--static" aria-label="Baterias compatíveis">
			<div class="awr-cards">
				<?php foreach ( $produtos as $p ) { awr_part( 'card-bateria', array( 'produto' => $p, 'veiculo' => $label ) ); } ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="awr-block">
		<h2 class="awr-section-title">Cidades com entrega e instalação</h2>
		<ul class="awr-chips">
			<?php foreach ( awr_cidades() as $c ) : ?>
				<li><a class="awr-chip" href="<?php echo esc_url( awr_vc_url( $m['slug'], $c['slug'] ) ); ?>">Bateria <?php echo esc_html( $label . ' em ' . $c['nome'] ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</section>

	<section class="awr-block">
		<h2 class="awr-section-title">Cidades com envio por transportadora</h2>
		<ul class="awr-chips">
			<?php foreach ( awr_cidades_venda() as $c ) : ?>
				<li><a class="awr-chip" href="<?php echo esc_url( awr_vc_url( $m['slug'], $c['slug'] ) ); ?>"><?php echo esc_html( $c['nome'] . '/' . $c['estado'] ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	</section>

	<?php awr_blog_guias_bloco( 'Guias para escolher e cuidar da bateria', awr_blog_chips_por( 'porVeiculo', $m['slug'] ) ); ?>
	<?php awr_part( 'search', array( 'titulo' => 'Buscar a bateria de outro veículo' ) ); ?>
	<?php awr_product_item_list_schema( $produtos, 'Baterias compatíveis com ' . $label ); ?>
</div>
<?php
get_footer();
