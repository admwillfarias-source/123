<?php
/**
 * /baterias-estacionarias/{aplicação|amperagem}/ — 5.46.0.
 * Conteúdo em inc/estacionaria-paginas.php.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$awr_slug = awr_param_b();
$awr_pg   = awr_est_pagina( $awr_slug );
$awr_seg  = awr_segmento_by_base( 'baterias-estacionarias' );
if ( ! $awr_pg || ! $awr_seg ) { get_template_part( '404' ); get_footer(); return; }

$awr_mod = awr_est_pagina_modelos( $awr_pg );
$awr_txt = $awr_pg['texto'];
$awr_faq = $awr_pg['faq'];
if ( 'amperagem' === $awr_pg['tipo'] ) {
	list( $awr_txt, $awr_faq ) = awr_est_pagina_texto_ah( $awr_pg, $awr_mod );
}
$awr_wa  = awr_wa( $awr_pg['wa'] );
$awr_url = awr_est_pagina_url( $awr_slug );

awr_part( 'segmento-hero', array(
	'seg'    => $awr_seg,
	'h1'     => $awr_pg['h1'],
	'lead'   => $awr_pg['lead'],
	'trilha' => array( array( 'nome' => $awr_seg['nome'], 'url' => awr_segmento_url( $awr_seg ) ) ),
	'atual'  => $awr_pg['h1'],
	'wa'     => $awr_wa,
	'modo'   => 'atendimento',
) );
?>

<section class="awr-app-section awr-est">
	<div class="awr-hub-body awr-hub-body--narrow">
		<?php foreach ( (array) $awr_txt as $awr_par ) : ?>
			<p><?php echo esc_html( $awr_par ); ?></p>
		<?php endforeach; ?>
		<?php foreach ( (array) ( $awr_pg['links'] ?? array() ) as $awr_l ) : ?>
			<p><a href="<?php echo esc_url( home_url( $awr_l['url'] ) ); ?>"><?php echo esc_html( $awr_l['label'] ); ?> →</a></p>
		<?php endforeach; ?>
		<p>
			<a class="awr-est-wa" target="_top" rel="noopener" data-awr-source="estac_<?php echo esc_attr( $awr_slug ); ?>" data-awr-est-lead="<?php echo esc_attr( $awr_slug ); ?>" href="<?php echo esc_url( $awr_wa ); ?>"><?php echo esc_html( $awr_pg['cta'] ); ?></a>
		</p>
	</div>
</section>

<?php
$awr_prod = awr_est_pagina_produtos( $awr_pg );
if ( $awr_prod ) {
	echo '<section class="awr-app-section awr-est"><div class="awr-hub-body">';
	awr_part( 'produtos-woo', array(
		'produtos' => $awr_prod,
		'titulo'   => 'amperagem' === $awr_pg['tipo'] ? 'Baterias estacionárias ' . $awr_pg['ah'] . 'Ah disponíveis na loja' : 'Baterias estacionárias disponíveis na loja',
		'lead'     => 'Preço e estoque reais. Compre pelo site ou confirme a aplicação no WhatsApp.',
	) );
	echo '</div></section>';
}
?>

<?php if ( $awr_mod ) : ?>
<section class="awr-app-section awr-app-section--muted awr-est">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title"><?php echo esc_html( 'amperagem' === $awr_pg['tipo'] ? 'Modelos de ' . $awr_pg['ah'] . 'Ah' : 'Modelos indicados' ); ?></h2>
		<div class="awr-est-tabela-wrap">
			<table class="awr-est-tabela">
				<thead><tr><th>Modelo</th><th>Tensão</th><th>Capacidade</th><th>Indicado para</th><th>Preço</th></tr></thead>
				<tbody>
					<?php foreach ( $awr_mod as $m ) : ?>
						<tr>
							<td class="awr-est-tabela__modelo"><?php echo esc_html( $m['codigo'] ); ?></td>
							<td><?php echo esc_html( $m['tensao'] ); ?></td>
							<td><?php echo esc_html( $m['ah'] ); ?></td>
							<td><?php echo esc_html( $m['aplicacao'] ); ?></td>
							<td><a class="awr-est-link" target="_top" rel="noopener" data-awr-est-lead="modelo" data-awr-est-modelo="<?php echo esc_attr( $m['codigo'] ); ?>" href="<?php echo esc_url( awr_wa( sprintf( 'Olá! Quero o preço da bateria %1$s (%2$s %3$s). Tem disponível?', $m['codigo'], $m['tensao'], $m['ah'] ) ) ); ?>">Consultar preço</a></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<p class="awr-est__nota">Disponibilidade e preço variam por lote e por marca. Confirme no WhatsApp antes de fechar o pedido.</p>
	</div>
</section>
<?php endif; ?>

<section class="awr-app-section awr-est">
	<div class="awr-hub-body">
		<div class="awr-est-calc" data-awr-calc data-cidade="">
			<h2 class="awr-app-section__title">Calculadora de autonomia</h2>
			<p class="awr-est__lead">Informe a carga em watts e quanto tempo ela precisa continuar ligada. O cálculo considera o rendimento do inversor e descarga máxima de 50%.</p>
			<div class="awr-est-calc__grid">
				<label>Carga (W)<input type="number" inputmode="numeric" min="1" value="300" data-calc-watts></label>
				<label>Autonomia (horas)<input type="number" inputmode="decimal" min="0.5" step="0.5" value="2" data-calc-horas></label>
				<label>Tensão do banco<select data-calc-tensao><option value="12">12V</option><option value="24">24V</option><option value="48">48V</option></select></label>
			</div>
			<button type="button" class="awr-est-calc__btn" data-calc-run>Calcular Ah necessário</button>
			<div class="awr-est-calc__out" data-calc-out hidden></div>
		</div>
	</div>
</section>

<?php if ( $awr_faq ) : ?>
<section class="awr-app-section awr-app-section--muted awr-est">
	<div class="awr-hub-body awr-hub-body--narrow">
		<?php awr_part( 'faq', array( 'titulo' => 'Perguntas frequentes', 'itens' => $awr_faq ) ); ?>
	</div>
</section>
<?php endif; ?>

<section class="awr-app-section awr-est">
	<div class="awr-hub-body">
		<h2 class="awr-app-section__title">Outras baterias estacionárias</h2>
		<ul class="awr-app-outras">
			<?php foreach ( awr_est_paginas_nav( $awr_slug ) as $awr_n ) : ?>
				<li><a href="<?php echo esc_url( $awr_n['url'] ); ?>"><div><h3><?php echo esc_html( $awr_n['label'] ); ?></h3></div><span class="awr-app-outras__arrow" aria-hidden="true">→</span></a></li>
			<?php endforeach; ?>
			<li><a href="<?php echo esc_url( awr_segmento_url( $awr_seg ) ); ?>"><div><h3>Todas as baterias estacionárias e cidades atendidas</h3></div><span class="awr-app-outras__arrow" aria-hidden="true">→</span></a></li>
		</ul>
	</div>
</section>

<?php
// FAQPage com o mesmo texto do bloco visível (a trilha sai no template-parts/breadcrumb).
if ( $awr_faq ) { awr_faq_jsonld( $awr_faq, $awr_url . '#faq' ); }
get_footer();
