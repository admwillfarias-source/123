<?php
/**
 * /baterias-em/ — hub de todas as cidades atendidas.
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<section class="awr-hub-hero">
	<div class="awr-hub-hero__inner">
		<?php awr_part( 'breadcrumb', array( 'atual' => 'Cidades atendidas' ) ); ?>
		<h1 class="awr-hub-hero__title">Todas as cidades atendidas em Porto Alegre e Grande Porto Alegre</h1>
		<p class="awr-hub-hero__lead">
			Escolha a sua cidade para ver o tempo de entrega, as lojas mais próximas e o preço da bateria
			do seu carro. Instalação no local, 24 meses de garantia e desconto na bateria velha.
		</p>
	</div>
</section>

<?php awr_part( 'searchband' ); ?>


<div class="awr-hub-body">
	<ul class="awr-hub-grid">
		<?php foreach ( awr_cidades() as $c ) : ?>
			<li class="awr-hub-card">
				<h2 class="awr-hub-card__title"><a href="<?php echo esc_url( home_url( '/baterias-em/' . $c['slug'] . '/' ) ); ?>">Bateria em <?php echo esc_html( $c['nome'] ); ?></a></h2>
				<p class="awr-hub-card__meta"><?php echo esc_html( awr_city_delivery_badge( $c ) ); ?><?php echo ! empty( $c['pontoReferencia'] ) ? ' · ' . esc_html( $c['pontoReferencia'] ) : ''; ?></p>
				<?php if ( ! empty( $c['bairros'] ) ) : ?>
					<p class="awr-hub-card__extra"><?php echo esc_html( implode( ' · ', array_slice( (array) $c['bairros'], 0, 8 ) ) ); ?></p>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>

	<h2 class="awr-section-title">Envio de baterias para o interior do RS em 1 a 2 dias úteis</h2>
	<p>Para os principais polos do Rio Grande do Sul, vendemos baterias com pagamento via Pix, nota fiscal, garantia e envio por transportadora. A instalação fica por conta do cliente ou de uma oficina local.</p>
	<ul class="awr-hub-grid">
		<?php foreach ( awr_cidades_venda() as $c ) : if ( 'RS' !== ( $c['estado'] ?? '' ) ) { continue; } ?>
			<li class="awr-hub-card">
				<h3 class="awr-hub-card__title"><a href="<?php echo esc_url( home_url( '/baterias-em/' . $c['slug'] . '/' ) ); ?>">Bateria em <?php echo esc_html( $c['nome'] ); ?></a></h3>
				<p class="awr-hub-card__meta">Envio por transportadora em 1 a 2 dias úteis</p>
			</li>
		<?php endforeach; ?>
	</ul>

	<?php awr_part( 'search', array( 'titulo' => 'Veja o preço da bateria do seu carro' ) ); ?>
	<?php awr_part( 'links-internos', array( 'tipo' => 'amperagem' ) ); ?>
</div>
<?php get_footer(); ?>
