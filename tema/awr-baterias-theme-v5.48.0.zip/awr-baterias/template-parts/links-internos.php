<?php
/**
 * Blocos de links internos (ramificações de SEO).
 *
 * Uso: awr_part( 'links-internos', array( 'tipo' => 'cidade', 'slug' => 'canoas' ) );
 * Tipos: cidade | marca | marca_cidade | sku | amperagem | aplicacao | conteudo
 *
 * @package awr
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$args = wp_parse_args( $args ?? array(), array( 'tipo' => '', 'slug' => '', 'slug_b' => '', 'ah' => 0 ) );
$tipo = $args['tipo'];

/** Renderiza uma lista de chips. */
if ( ! function_exists( 'awr_chips' ) ) {
	function awr_chips( $titulo, $itens ) {
		$itens = array_filter( $itens );
		if ( ! $itens ) { return; }
		echo '<h2 class="awr-section-title">' . esc_html( $titulo ) . '</h2>';
		echo '<ul class="awr-chips">';
		foreach ( $itens as $it ) {
			echo '<li><a class="awr-chip" href="' . esc_url( $it['url'] ) . '">' . esc_html( $it['label'] ) . '</a></li>';
		}
		echo '</ul>';
	}
}

$cidades = awr_cidades();
$marcas  = awr_marcas();
?>
<section class="awr-block awr-links-internos" aria-label="Links relacionados">
<?php
if ( 'cidade' === $tipo ) {
	$c    = awr_cidade_by_slug( $args['slug'] );
	$nome = $c ? $c['nome'] : ucwords( str_replace( '-', ' ', $args['slug'] ) );

	$vizinhas = array();
	foreach ( $cidades as $item ) {
		if ( $item['slug'] === $args['slug'] ) { continue; }
		$vizinhas[] = array( 'url' => home_url( '/baterias-em/' . $item['slug'] . '/' ), 'label' => 'Bateria em ' . $item['nome'] );
	}
	awr_chips( 'Também atendemos', array_slice( $vizinhas, 0, 14 ) );

	$ahs = array();
	foreach ( array( 45, 50, 60, 70, 80, 90, 100, 150 ) as $ah ) {
		$ahs[] = array( 'url' => home_url( '/baterias/amperagem/' . $ah . '/' ), 'label' => $ah . 'Ah' );
	}
	awr_chips( 'Baterias por amperagem', $ahs );

	echo '<p class="awr-lead"><a href="' . esc_url( home_url( '/baterias-em/' ) ) . '">Ver todas as cidades atendidas →</a></p>';
} elseif ( 'marca' === $tipo ) {
	$m    = awr_marca_by_slug( $args['slug'] );
	$nome = $m ? $m['nome'] : ucfirst( $args['slug'] );
	$out  = array();
	foreach ( $marcas as $item ) {
		if ( $item['slug'] === $args['slug'] ) { continue; }
		$out[] = array( 'url' => home_url( '/marca/' . $item['slug'] . '/' ), 'label' => 'Bateria ' . $item['nome'] );
	}
	if ( $m && ! empty( $m['cidadePages'] ) ) {
		$cid = array();
		foreach ( $cidades as $item ) {
			$cid[] = array( 'url' => home_url( '/bateria/' . $m['slug'] . '/' . $item['slug'] . '/' ), 'label' => 'Bateria ' . $nome . ' em ' . $item['nome'] );
		}
		foreach ( awr_marca_cidades_envio() as $awr_ce ) {
			$cv = awr_cidade_venda_by_slug( $awr_ce );
			if ( $cv ) { $cid[] = array( 'url' => home_url( '/bateria/' . $m['slug'] . '/' . $cv['slug'] . '/' ), 'label' => 'Bateria ' . $nome . ' em ' . $cv['nome'] ); }
		}
		awr_chips( 'Bateria ' . $nome . ' por cidade', array_slice( $cid, 0, 14 ) );
	}
	awr_chips( 'Outras marcas', $out );

	echo '<p class="awr-lead"><a href="' . esc_url( home_url( '/baterias/' ) ) . '">Ver todos os modelos de bateria →</a> · <a href="' . esc_url( home_url( '/baterias-em/' ) ) . '">cidades atendidas</a></p>';
} elseif ( 'marca_cidade' === $tipo ) {
	$m = awr_marca_by_slug( $args['slug'] );
	$c = awr_cidade_by_slug( $args['slug_b'] );
	if ( ! $c ) { $c = awr_cidade_venda_by_slug( $args['slug_b'] ); }
	$out = array();
	foreach ( $marcas as $item ) {
		if ( $item['slug'] === $args['slug'] ) { continue; }
		$out[] = array(
			'url'   => home_url( '/bateria/' . $item['slug'] . '/' . $args['slug_b'] . '/' ),
			'label' => 'Bateria ' . $item['nome'] . ( $c ? ' em ' . $c['nome'] : '' ),
		);
	}
	awr_chips( 'Outras marcas nesta cidade', $out );

	$out2 = array();
	foreach ( $cidades as $item ) {
		if ( $item['slug'] === $args['slug_b'] ) { continue; }
		$out2[] = array(
			'url'   => home_url( '/bateria/' . $args['slug'] . '/' . $item['slug'] . '/' ),
			'label' => ( $m ? $m['nome'] : '' ) . ' em ' . $item['nome'],
		);
	}
	awr_chips( 'Esta marca em outras cidades', array_slice( $out2, 0, 14 ) );
} elseif ( 'sku' === $tipo ) {
	$ah = (int) $args['ah'];
	if ( $ah ) {
		awr_chips( 'Baterias equivalentes', array(
			array( 'url' => home_url( '/baterias/amperagem/' . $ah . '/' ), 'label' => 'Todas as baterias ' . $ah . 'Ah' ),
		) );
	}
	$out = array();
	foreach ( $marcas as $item ) {
		$out[] = array( 'url' => home_url( '/marca/' . $item['slug'] . '/' ), 'label' => 'Bateria ' . $item['nome'] );
	}
	awr_chips( 'Marcas que trabalhamos', $out );

	$out2 = array();
	foreach ( array_slice( $cidades, 0, 12 ) as $item ) {
		$out2[] = array( 'url' => home_url( '/baterias-em/' . $item['slug'] . '/' ), 'label' => 'Entrega em ' . $item['nome'] );
	}
	awr_chips( 'Onde entregamos', $out2 );
} elseif ( 'amperagem' === $tipo ) {
	$ah  = (int) $args['ah'];
	$out = array();
	foreach ( array( 40, 45, 50, 60, 70, 80, 90, 100, 150 ) as $item ) {
		if ( $item === $ah ) { continue; }
		$out[] = array( 'url' => home_url( '/baterias/amperagem/' . $item . '/' ), 'label' => $item . 'Ah' );
	}
	awr_chips( 'Outras amperagens', $out );

	$out2 = array();
	foreach ( array_slice( $cidades, 0, 12 ) as $item ) {
		$out2[] = array( 'url' => home_url( '/baterias-em/' . $item['slug'] . '/' ), 'label' => 'Bateria em ' . $item['nome'] );
	}
	awr_chips( 'Entrega por cidade', $out2 );
} elseif ( 'aplicacao' === $tipo ) {
	$out = array();
	foreach ( awr_aplicacoes() as $item ) {
		if ( $item['slug'] === $args['slug'] ) { continue; }
		$out[] = array( 'url' => home_url( '/bateria-para/' . $item['slug'] . '/' ), 'label' => 'Bateria para ' . $item['nome'] );
	}
	awr_chips( 'Outras aplicações', $out );
	echo '<p class="awr-lead"><a href="' . esc_url( home_url( '/bateria-para/' ) ) . '">Ver todas as aplicações →</a></p>';
} elseif ( 'conteudo' === $tipo ) {
	$out = array();
	foreach ( awr_posts_data() as $item ) {
		if ( $item['slug'] === $args['slug'] ) { continue; }
		$out[] = array( 'url' => home_url( '/blog/' . $item['slug'] . '/' ), 'label' => $item['titulo'] ?? $item['slug'] );
	}
	awr_chips( 'Continue lendo', array_slice( $out, 0, 8 ) );

	$awr_bl = array();
	foreach ( (array) ( awr_blog_links()['posts'] ?? array() ) as $awr_bp ) {
		if ( $awr_bp['slug'] !== $args['slug'] ) { continue; }
		foreach ( (array) $awr_bp['marcas'] as $awr_m ) {
			$awr_bl[] = array( 'url' => home_url( '/marca/' . $awr_m . '/' ), 'label' => 'Bateria ' . ucfirst( $awr_m ) . ': modelos e preços' );
		}
		foreach ( (array) $awr_bp['veiculos'] as $awr_v ) {
			$awr_bl[] = array( 'url' => home_url( '/baterias-para/' . $awr_v . '/' ), 'label' => 'Qual bateria usar no ' . awr_blog_veiculo_nome( $awr_v ) );
		}
	}
	awr_chips( 'Baterias citadas neste guia', $awr_bl );

	// 5.46.0 — guias de nobreak/solar/alarme levam às páginas comerciais estacionárias.
	if ( function_exists( 'awr_est_pagina_url' ) ) {
		$awr_est_map = array(
			'nobreak'  => array( 'nobreak-e-ups', 'Bateria para nobreak e UPS' ),
			'ups'      => array( 'nobreak-e-ups', 'Bateria para nobreak e UPS' ),
			'solar'    => array( 'energia-solar', 'Bateria para energia solar' ),
			'alarme'   => array( 'alarme-e-seguranca', 'Bateria para alarme, CFTV e portão' ),
			'cftv'     => array( 'alarme-e-seguranca', 'Bateria para alarme, CFTV e portão' ),
			'estacion' => array( 'condominios-e-empresas', 'Estacionárias para condomínios e empresas' ),
		);
		$awr_est_l = array();
		foreach ( $awr_est_map as $awr_k => $awr_v ) {
			if ( false !== strpos( (string) $args['slug'], $awr_k ) ) { $awr_est_l[ $awr_v[0] ] = array( 'url' => awr_est_pagina_url( $awr_v[0] ), 'label' => $awr_v[1] ); }
		}
		if ( $awr_est_l ) { awr_chips( 'Baterias estacionárias', array_values( $awr_est_l ) ); }
	}

	$out2 = array();
	foreach ( array_slice( $cidades, 0, 8 ) as $item ) {
		$out2[] = array( 'url' => home_url( '/baterias-em/' . $item['slug'] . '/' ), 'label' => 'Bateria em ' . $item['nome'] );
	}
	awr_chips( 'Entrega e instalação', $out2 );

	$out3 = array();
	foreach ( array_slice( awr_vehicle_brands(), 0, 14, true ) as $bslug => $bnome ) {
		$out3[] = array( 'url' => home_url( '/baterias/' . $bslug . '/' ), 'label' => 'Bateria para ' . $bnome );
	}
	awr_chips( 'Bateria por fabricante', $out3 );

	$out4 = array();
	foreach ( awr_lps() as $lslug => $lp ) {
		if ( empty( $lp['index'] ) ) { continue; }
		$out4[] = array( 'url' => home_url( '/' . $lslug . '/' ), 'label' => $lp['h1'] );
	}
	awr_chips( 'Serviços em destaque', $out4 );
} elseif ( 'home' === $tipo ) {
	$out = array();
	foreach ( $marcas as $item ) {
		$out[] = array( 'url' => home_url( '/marca/' . $item['slug'] . '/' ), 'label' => 'Bateria ' . $item['nome'] );
	}
	awr_chips( 'Marcas que trabalhamos', $out );

	$out2 = array();
	foreach ( awr_aplicacoes() as $item ) {
		$out2[] = array( 'url' => home_url( '/bateria-para/' . $item['slug'] . '/' ), 'label' => 'Bateria para ' . $item['nome'] );
	}
	awr_chips( 'Bateria por tipo de uso', $out2 );

	$out3 = array();
	foreach ( array( 45, 50, 60, 70, 80, 90, 100, 150 ) as $item ) {
		$out3[] = array( 'url' => home_url( '/baterias/amperagem/' . $item . '/' ), 'label' => $item . 'Ah' );
	}
	awr_chips( 'Baterias por amperagem', $out3 );

	echo '<p class="awr-lead"><a href="' . esc_url( home_url( '/baterias/' ) ) . '">Todos os modelos de bateria →</a> · <a href="' . esc_url( home_url( '/baterias-em/' ) ) . '">cidades atendidas</a> · <a href="' . esc_url( home_url( '/lojas/' ) ) . '">nossas lojas</a></p>';
}

?>
</section>
