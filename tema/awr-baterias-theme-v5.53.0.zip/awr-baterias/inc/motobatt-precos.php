<?php
/**
 * 5.53.0 — Configurações → AWR Motobatt.
 *
 * Mostra, para cada código Motobatt do catálogo de motos (chaves mb/li em
 * assets/data/batteries.json), se a loja WooCommerce tem o produto e qual o
 * preço que as páginas de moto estão exibindo. A busca é a mesma das páginas
 * (awr_product_by_sku → awr_lookup_product_id, tolerante a "-BS", espaço e
 * código só no nome do produto).
 *
 * @package awr
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Códigos Motobatt do catálogo: código => array( tipo, modelos ). */
function awr_motobatt_codigos() {
	$out = array();
	foreach ( awr_batteries()['items'] as $it ) {
		foreach ( array( 'mb' => 'AGM', 'li' => 'Lítio' ) as $k => $tipo ) {
			$c = strtoupper( trim( (string) ( $it[ $k ] ?? '' ) ) );
			if ( '' === $c ) { continue; }
			if ( ! isset( $out[ $c ] ) ) { $out[ $c ] = array( 'tipo' => $tipo, 'modelos' => 0, 'ex' => array() ); }
			$out[ $c ]['modelos']++;
			if ( count( $out[ $c ]['ex'] ) < 3 ) { $out[ $c ]['ex'][] = awr_nome_veiculo( $it['ma'] . ' ' . $it['mo'] ); }
		}
	}
	uasort( $out, function ( $a, $b ) { return $b['modelos'] <=> $a['modelos']; } );
	return $out;
}

add_action( 'admin_menu', function () {
	add_options_page( 'AWR Motobatt', 'AWR Motobatt', 'manage_woocommerce', 'awr-motobatt', 'awr_motobatt_page' );
} );

function awr_motobatt_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
	$cods = awr_motobatt_codigos();
	if ( function_exists( 'awr_prime_products' ) ) { awr_prime_products( array_keys( $cods ) ); }
	$ok = 0;
	$linhas = array();
	foreach ( $cods as $c => $d ) {
		$p = function_exists( 'awr_product_by_sku' ) ? awr_product_by_sku( $c ) : null;
		if ( $p && (float) $p['price'] > 0 ) { $ok++; }
		$linhas[] = array( $c, $d, $p );
	}
	?>
	<div class="wrap">
		<h1>AWR Motobatt — preços das baterias de moto</h1>
		<p>As páginas de moto buscam o preço no WooCommerce pelo SKU do código Motobatt. O SKU pode estar escrito com ou sem "-BS", com espaço ou hífen, ou o código pode aparecer só no nome do produto (ex.: "Bateria Motobatt MBTX9U").</p>
		<p><strong><?php echo (int) $ok; ?> de <?php echo (int) count( $cods ); ?> códigos com preço na loja.</strong> Os que faltam aparecem como "preço no WhatsApp" nas páginas de moto. Cadastre o produto com o código no campo SKU para o preço aparecer (o cache de produtos se renova em até 1 hora).</p>
		<table class="widefat striped">
			<thead><tr><th>Código</th><th>Linha</th><th>Modelos de moto</th><th>Exemplos</th><th>Produto na loja</th><th>SKU na loja</th><th>Preço</th></tr></thead>
			<tbody>
				<?php foreach ( $linhas as $l ) : list( $c, $d, $p ) = $l; ?>
					<tr>
						<td><code><?php echo esc_html( $c ); ?></code></td>
						<td><?php echo esc_html( $d['tipo'] ); ?></td>
						<td><?php echo (int) $d['modelos']; ?></td>
						<td><?php echo esc_html( implode( ', ', $d['ex'] ) ); ?></td>
						<td><?php echo $p ? '<a href="' . esc_url( get_edit_post_link( (int) $p['id'] ) ) . '">' . esc_html( $p['name'] ) . '</a>' : '<span style="color:#b32d2e">não encontrado</span>'; ?></td>
						<td><?php echo $p ? esc_html( $p['sku'] ) : '—'; ?></td>
						<td><?php echo $p && (float) $p['price'] > 0 ? esc_html( 'R$ ' . number_format( (float) $p['price'], 2, ',', '.' ) ) : '—'; ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<?php
}
