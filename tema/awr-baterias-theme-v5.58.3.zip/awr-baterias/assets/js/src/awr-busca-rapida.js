/* AWR 5.58.1 — Busca rápida, versão contida: sugestões locais (AWRSugest), resultado
   em cache (sessionStorage, 10 min) e pré-busca SÓ no toque/clique na sugestão.
   Sem pedidos automáticos (hover ou timer) e com trava de no máximo 20 pedidos
   de busca por minuto nesta aba. Ligado ao awr-search.js por window.awrY. */
(function () {
	'use strict';
	var voando = {}, base = null, TTL = 6e5, janela = [], LIMITE = 20;
	function chave(e) { var o = {}; Object.keys(e || {}).sort().forEach(function (k) { if (e[k] !== '' && e[k] != null) o[k] = e[k]; }); return 'awr_pc2:' + JSON.stringify(o); }
	function ler(k) { try { var v = JSON.parse(sessionStorage.getItem(k) || 'null'); return v && Date.now() - v.t < TTL ? v.d : null; } catch (x) { return null; } }
	function gravar(k, d) { try { sessionStorage.setItem(k, JSON.stringify({ t: Date.now(), d: d })); } catch (x) {} }
	/* Trava: no máximo LIMITE pedidos ao servidor por minuto nesta aba; acima disso, espera a vez. */
	function vez() {
		var agora = Date.now();
		janela = janela.filter(function (t) { return agora - t < 6e4; });
		if (janela.length < LIMITE) { janela.push(agora); return Promise.resolve(); }
		return new Promise(function (r) { setTimeout(r, 6e4 - (agora - janela[0]) + 50); }).then(vez);
	}

	function produtos(e) {
		var k = chave(e), c = ler(k);
		if (c) return Promise.resolve(c);
		if (voando[k]) return voando[k];
		var p = vez().then(function () { return base('produtos', e); }).then(function (d) {
			delete voando[k];
			// 5.58.3: só guarda se houver ao menos uma bateria com preço.
			if (d && !d.offline && d.produtos && d.produtos.some(function (x) { return Number(x.price) > 0; })) gravar(k, d);
			return d;
		}, function (er) { delete voando[k]; throw er; });
		voando[k] = p;
		return p;
	}

	window.awrY = function (a, e, b) {
		base = base || b;
		var S = window.AWRSugest;
		if (a === 'sugestoes' && S) {
			var r = S.sugerir(e && e.q);
			if (r) return Promise.resolve(r);
			S.carregar();
		}
		if (a === 'produtos') return produtos(e || {});
		return vez().then(function () { return b(a, e); });
	};

	/* Pré-busca só no toque/clique: mesma regra de ano do clique (função f do awr-search.js). */
	function anoDe(v, digitado) {
		var m = String(digitado || '').match(/\b(19[89]\d|20\d{2})\b/), h = m ? Number(m[0]) : null;
		return h && h >= v.yearStart && h <= v.yearEnd ? h : v.yearEnd;
	}
	window.awrPre = function (lista, digitado, ul) {
		if (!ul) return;
		ul.__awrLista = lista; ul.__awrDig = digitado;
		if (ul.__awrPre) return;
		ul.__awrPre = 1;
		ul.addEventListener('pointerdown', function (x) {
			var li = x.target.closest && x.target.closest('li[data-i]'), v = li && ul.__awrLista && ul.__awrLista[Number(li.dataset.i)];
			if (!base || !v || v.tipo !== 'veiculo' || !v.slug) return;
			produtos({ veiculo: v.slug, ano: anoDe(v, ul.__awrDig) }).catch(function () {});
		}, { passive: true });
	};
	if (window.AWRSugest) window.AWRSugest.carregar();
})();
